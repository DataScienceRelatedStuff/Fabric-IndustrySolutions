"""
conftest.py is recognized automatically by pytest and makes usage of fixtures transparent with no need to import them
"""