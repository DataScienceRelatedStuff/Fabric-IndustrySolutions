import pytest

from dmf.utils.immutable_dict import ImmutableDict

immutable_err_msg = "This dictionary is immutable."


class TestImmutableDict:
    def test_immutable_dict_creation_from_dict(self):
        d = ImmutableDict({"a": 1, "b": 2})
        assert d['a'] == 1
        assert d['b'] == 2

    def test_immutable_dict_creation(self):
        d = ImmutableDict(a=1, b=2)
        assert d['a'] == 1
        assert d['b'] == 2

    def test_immutable_dict_contains(self):
        d = ImmutableDict(a=1, b=2)
        assert 'a' in d
        assert 'c' not in d

    def test_immutable_dict_setitem(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            d['a'] = 2

    def test_immutable_dict_delitem(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            del d['a']

    def test_immutable_dict_clear(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            d.clear()

    def test_immutable_dict_pop(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            d.pop('a')

    def test_immutable_dict_popitem(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            d.popitem()

    def test_immutable_dict_setdefault(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            d.setdefault('a', 2)

    def test_immutable_dict_update(self):
        d = ImmutableDict(a=1)
        with pytest.raises(TypeError, match=immutable_err_msg):
            d.update({'b': 2})

    def test_is_hashable(self):
        d = ImmutableDict(a=1)
        assert hash(d) is not None
        set([d])
