import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from tests.utils.constants import Constants

SourceField = str
SourceTable = str
Source = str
TargetTable = str
TargetField = str
SourceFieldsPerSource = Dict[SourceTable, List[SourceField]]
TargetFieldsPerSourceField = Dict[SourceTable, Dict[SourceField, List[Tuple[TargetTable, TargetField]]]]


def reduced_config_path(test_name: str) -> Path:
    return Constants.GENERATED_TRANSFORMATION_SPECS_ROOT / test_name / "ts.json"


def reduce_config(
    test_name: str,
    sources,
    transformation_spec_file_path: Path,
    source_fields_per_source=None,
    target_fields_per_source_field=None,
):
    reduced_path = reduced_config_path(test_name)
    reduce_transformation_spec(
        json_path=transformation_spec_file_path,
        new_path=reduced_path,
        sources=sources,
        source_fields_per_source=source_fields_per_source,
        target_fields_per_source_field=target_fields_per_source_field,
    )


def reduce_transformation_spec(
    json_path: Path,
    new_path: Path,
    sources: List[SourceTable],
    source_fields_per_source: Optional[SourceFieldsPerSource] = None,
    target_fields_per_source_field: Optional[TargetFieldsPerSourceField] = None,
):
    """takes a json path and write a new json file with only a subset of the keys in a the returned path"""
    new_dict = get_reduced_config_as_dict(
        json_path=json_path,
        sources=sources,
        source_fields_per_source=source_fields_per_source,
        target_fields_per_source_field=target_fields_per_source_field,
    )

    _create_parent_path(new_path)
    with open(new_path, "w+") as f:
        json.dump(new_dict, f, indent=2)


def get_reduced_config_as_dict(
    json_path: Path,
    sources: List[SourceTable],
    source_fields_per_source: Optional[SourceFieldsPerSource] = None,
    target_fields_per_source_field: Optional[TargetFieldsPerSourceField] = None,
):
    if not source_fields_per_source:
        source_fields_per_source = {}

    if not target_fields_per_source_field:
        target_fields_per_source_field = {}

    if not json_path.exists():
        raise FileNotFoundError(f"File {json_path} does not exist")

    with open(json_path, "r") as f:
        dmf_config = json.load(f)

    return _reduce(
        dmf_config,
        sources,
        source_fields_per_source,
        target_fields_per_source_field,
    )


def _create_parent_path(path: Path):
    if not path.parent.exists():
        path.parent.mkdir(parents=True)


def _reduce(
    dmf_config: Dict,
    sources: List[SourceTable],
    source_fields_per_source: Dict[SourceTable, List[SourceField]],
    target_fields_per_source_field: Dict[SourceTable, Dict[SourceField, List[Tuple[TargetTable, TargetField]]]],
) -> Dict:
    _reduce_sources(dmf_config, sources)
    _reduce_source_fields(dmf_config, source_fields_per_source)
    _reduce_target_fields(dmf_config, target_fields_per_source_field)
    return dmf_config


def _reduce_sources(dmf_contract: Dict, sources: List[SourceTable]):
    if not sources:
        return

    reduced_sources = [
        source
        for source in dmf_contract["source_configurations"]
        if source["source_id"] in sources and source["create_view_only"] == False
    ]
    reduced_source_views = []
    for source in reduced_sources:
        reduced_source_views = [
            source_view
            for source_view in dmf_contract["source_configurations"]
            if source_view["create_view_only"] == True
            and source_view["source_id"] in source["data_access_definition"]["data_source_id"]
        ]

    dmf_contract["source_configurations"] = reduced_sources + reduced_source_views


def _reduce_source_fields(dmf_contract: Dict, source_fields_per_source: Dict[SourceTable, List[SourceField]]):
    if not source_fields_per_source:
        return

    sources = dmf_contract["source_configurations"]
    for source in sources:
        source_name = source["source_id"]
        if source_name not in source_fields_per_source:
            continue

        # name of field we always write , to compue last modified date
        source_field_name = source["source_table_column_name"]

        for target in source["target_configurations"]:
            reduced_target_transformations = [
                target_transformation
                for target_transformation in target["target_columns_transformations"]
                if target_transformation["original_source_field_name"] in source_fields_per_source[source_name]
                or target_transformation["target_field_name"] == source_field_name
            ]
            target["target_columns_transformations"] = reduced_target_transformations


def _reduce_target_fields(
    dmf_contract: Dict,
    target_fields_per_source: Dict[SourceTable, Dict[SourceField, List[Tuple[TargetTable, TargetField]]]],
):
    if not target_fields_per_source:
        return

    target_tables = set()
    for source_name, source_fields in target_fields_per_source.items():
        for source_field, target_fields in source_fields.items():
            for target_table, target_field in target_fields:
                target_tables.add(target_table)

    sources = dmf_contract["source_configurations"]
    for source in sources:
        source_name = source["source_id"]
        if source_name not in target_fields_per_source:
            continue
        reduced_target_configurations = [
            target for target in source["target_configurations"] if target["target_id"] in target_tables
        ]

        source["target_configurations"] = reduced_target_configurations
        # name of field we always wrrite , to compue last modified date
        source_field_name = source["source_table_column_name"]

        for target in source["target_configurations"]:
            reduced_target_transformations = [
                target_transformation
                for target_transformation in target["target_columns_transformations"]
                if (
                    target_transformation["original_source_field_name"] in target_fields_per_source[source_name]
                    and (target_transformation["transformation_target_id"], target_transformation["target_field_name"])
                    in target_fields_per_source[source_name][target_transformation["original_source_field_name"]]
                )
                or (target_transformation["target_field_name"] == source_field_name)
            ]
            target["target_columns_transformations"] = reduced_target_transformations


def reduce_given_transformation_spec(
    transformation_spec_path,
    reduced_contract_path,
    sources,
    source_fields_per_source=None,
    target_fields_per_source_field=None,
):
    # reduced_path = self.reduced_adaptor_path(test_name)
    reduce_transformation_spec(
        json_path=transformation_spec_path,
        new_path=reduced_contract_path,
        sources=sources,
        source_fields_per_source=source_fields_per_source,
        target_fields_per_source_field=target_fields_per_source_field,
    )
