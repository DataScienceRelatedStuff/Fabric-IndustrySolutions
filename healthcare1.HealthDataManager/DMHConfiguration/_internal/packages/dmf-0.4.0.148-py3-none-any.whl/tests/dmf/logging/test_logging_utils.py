import logging
import time
from dmf.utils.logging_utils import Timed, SyntheticId
import pytest
from dmf.logging import Logger


@SyntheticId
class Foo:

    @Timed(Logger)
    def bar(self, x, y=10):
        time.sleep(0.1)
        return x+y


def test_log(mocker):
    spy = mocker.spy(Logger, 'info')
    assert 42 == Foo().bar(31, y=11)

    assert spy.call_count == 1
    args = str(spy.call_args.args).split(" ")
    assert args[0].__contains__("Foo") and args[3].__contains__("bar") and args[4].__contains__("elapsed")


def test_missing_mixin():
    class Bad():

        @Timed(Logger)
        def bar(self):
            pass

    with pytest.raises(ValueError, match="has no `id` attribute. Please use SyntheticId"):
        Bad().bar()
