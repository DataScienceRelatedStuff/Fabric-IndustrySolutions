# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class to extract metadata tags from dicom file
"""

import json
from pydicom import dcmread
import io
from pyspark.sql.functions import udf
from pyspark.sql.types import *
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C

@udf(MapType(StringType(), StringType()))
def extract_metadata(dcm_file_content: bytes):
    """
    This method is used to extract metadata tags from dcm file content

    Args:
        dcm_file_content (str): dcm file content from which tags needs to be extracted

    Returns:
        dict: a dictionary containing information about all the tags into json structure, 
        and all the individual tags which needs to be extracted as columns
    """        
        
    try:
        ds = dcmread(io.BytesIO(dcm_file_content))
            
        #removing pixel data tag from the FileDataset object
        del ds.PixelData
        
        # to_json_dict() method is used get all the tags information in the form 
        # of a json dictionary object as per Dicom json model
        tags_json = ds.to_json_dict() 
        
        metadata = {}
        
        # the below part of the code is used to extract dicom tags individually 
        # as per the constant defined
        failed_tags_extract = []
        for tag_key in C.DEFAULT_TAGS_AS_COLUMN:
            try:
                tag_value = str(ds[tag_key].value)
                metadata[tag_key.lower()] = tag_value
            except Exception as e:
                failed_tags_extract.append(tag_key)
                metadata[tag_key.lower()] = ""
        
        if failed_tags_extract:
            metadata[C.FAILED_TAGS_ATTR_NAME] = failed_tags_extract
        metadata[C.TAGS_JSON_COLUMN_NAME] = json.dumps(tags_json)
        return metadata
    except Exception as ex:
        return { C.ERROR_ATTR_NAME : str(ex) }