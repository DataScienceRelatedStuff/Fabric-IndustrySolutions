import pytest

from rmt.file_model.values_mapping.file_model import FileModel


class TestFileModel:

    def _get_query_str(self, file1_name, file1_path, file2_name, file2_path, sql):
        return '"query":{"tables":[{"name":"%s","path":"%s"},{"name":"%s","path":"%s"}],"sql":"%s"}' % (file1_name, file1_path, file2_name, file2_path, sql)

    def _get_values_str(self, target_key, source_key1, source_key2, target_key2, source_key3):
        return '"values":[{"targetKey":"%s","sourceKeys":["%s","%s"]},{"targetKey":"%s","sourceKeys":["%s"]}]' % (target_key, source_key1, source_key2, target_key2, source_key3)

    def _get_values_and_query_str(self, file1_name, file1_path, file2_name, file2_path, sql, target_key, source_key1, source_key2, target_key2, source_key3):
        return f"{self._get_query_str(file1_name, file1_path, file2_name, file2_path, sql)},{self._get_values_str(target_key, source_key1, source_key2, target_key2, source_key3)}"

    def test_load_model_with_query(self):

        file1_name = "concept"
        file1_path = "/scale_test/reference-data/concept"
        file2_name = "concept_relationship"
        file2_path = "/scale_test/reference-data/concept_relationship"
        sql = "sql query"

        query_str = self._get_query_str(file1_name, file1_path, file2_name, file2_path, sql)
        model = FileModel.from_str('%s%s%s' % ("{", query_str, "}"))

        assert model.query.sql == sql
        assert model.query.tables[0].name == file1_name
        assert model.query.tables[0].path == file1_path
        assert model.query.tables[1].name == file2_name
        assert model.query.tables[1].path == file2_path

    def test_load_model_with_values(self):

        target_key = 1
        source_key1 = "source_key1"
        source_key2 = "source_key2"
        target_key2 = 2
        source_key3 = "source_key3"

        values_str = self._get_values_str(target_key, source_key1, source_key2, target_key2, source_key3)
        model = FileModel.from_str('%s%s%s' % ("{", values_str, "}"))

        assert model.values[0].targetKey == target_key
        assert model.values[0].sourceKeys[0] == source_key1
        assert model.values[0].sourceKeys[1] == source_key2
        assert model.values[1].targetKey == target_key2
        assert model.values[1].sourceKeys[0] == source_key3

    def test_load_model_with_query_and_values(self):

        file1_name = "concept"
        file1_path = "/scale_test/reference-data/concept"
        file2_name = "concept_relationship"
        file2_path = "/scale_test/reference-data/concept_relationship"
        sql = "sql query"
        target_key = 1
        source_key1 = "source_key1"
        source_key2 = "source_key2"
        target_key2 = 2
        source_key3 = "source_key3"

        query_and_values_str = self._get_values_and_query_str(file1_name, file1_path, file2_name, file2_path, sql, target_key, source_key1, source_key2, target_key2, source_key3)
        with pytest.raises(ValueError):
            FileModel.from_str('%s%s%s' % ("{", query_and_values_str, "}"))

    def test_load_model_without_query_or_values(self):

        with pytest.raises(ValueError):
            FileModel.from_str('{}')
