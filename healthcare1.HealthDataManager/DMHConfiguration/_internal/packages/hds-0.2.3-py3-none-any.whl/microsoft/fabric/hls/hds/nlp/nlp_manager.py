# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from typing import Optional
from delta import DeltaTable

from pyspark import StorageLevel
from pyspark.sql import DataFrame, functions as F
from pyspark.sql import SparkSession
from pyspark.sql.utils import AnalysisException
from py4j.protocol import Py4JJavaError
from microsoft.fabric.hls.hds.nlp.errors.nlp_unrecoverable_error import NLPUnrecoverableError
from microsoft.fabric.hls.hds.nlp.services.nlp_service import NLPService
from microsoft.fabric.hls.hds.nlp.constants import NLPConstants as C
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.nlp.flatten.flatten_nlp_results import FlattenNLPResults
from microsoft.fabric.hls.hds.nlp.errors.nlp_data_load_error import NLPDataLoadError
from microsoft.fabric.hls.hds.nlp.errors.nlp_data_path_error import NLPDataPathError
from microsoft.fabric.hls.hds.nlp.errors.nlp_data_save_error import NLPDataSaveError
from microsoft.fabric.hls.hds.nlp.errors.nlp_flattening_error import NLPFlatteningError
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper


class NLPManager:
    """
    This module contains the NLPManager class, which provides functionality for
    processing text data using the Azure Text Analytics for Health API.
    """

    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-arguments

    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        nlp_api_endpoint: str,
        nlp_credentials: str,
        flatten_config_dir: str,
        flatten_config_name: str,
        silver_database_path: str,
        **kwargs,
    ):
        """
        Initialize the NLP Pipeline.

        Args:
            spark_session (SparkSession): The SparkSession object to be used for all data
                processing.
            nlp_api_endpoint (str): The NLP API endpoint to send text data for processing.
            nlp_credentials (str): The credentials required to access the NLP API.
            flatten_config_dir (str): The path to the configuration file used for flattening
                the NLP results.
            flatten_config_name (str): The name of the flatten configuration file
            silver_database_path (str): The path to the silver tables
            model_version (Optional[str]):Indicates which model will be used for scoring,
                e.g. "latest", "2019-10-01". Defaults to "latest"
            fhir_version (Optional[str]): The FHIR Spec version that the result will use to
                format the fhir_bundle on the result object. For additional information see
                https://www.hl7.org/fhir/overview.html.
            The only acceptable values to pass in are None and "4.0.1". The default value is None.
            enable_text_analytics_logs (Optional[bool]): Indicates whether or not to log text analytics API requests. Disabled by default.
            nlp_column_mappings (Optional[Dict[str, str]]): Mapping of the dataframe column
                with the unstructured text to analyze
        """
        self.spark = spark
        self._logger = LoggingHelper.get_nlpingestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )
        self.nlp_service_logger = LoggingHelper.get_nlpingestion_logger(
            self.spark, NLPService.__name__, GlobalConstants.LOGGING_LEVEL
        )
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.nlp_api_endpoint = nlp_api_endpoint
        self.nlp_credentials = nlp_credentials
        self.flatten_config_dir = flatten_config_dir
        self.silver_database_path = silver_database_path
        self.flatten_config_name = flatten_config_name
        self.nlp_column_mappings = kwargs.get(
            "nlp_column_mappings", C.DEFAULT_NLP_COLUMNS_NAMING
        )
        self.nlp_model_version = kwargs.get(
            "model_version", C.DEFAULT_TEXT_ANALYTICS_MODEL_VERSION
        )
        self.nlp_fhir_version = kwargs.get(
            "fhir_version", C.DEFAULT_TEXT_ANALYTICS_FHIR_VERSION
        )
        self.enable_text_analytics_logs = kwargs.get("enable_text_analytics_logs", GlobalConstants.ENABLE_TEXT_ANALYTICS_LOGS)
        self.nlp = NLPService(
            nlp_endpoint=self.nlp_api_endpoint,
            nlp_password=self.nlp_credentials,
            nlp_column_mappings=self.nlp_column_mappings,
            model_version=self.nlp_model_version,
            fhir_version=self.nlp_fhir_version,
            enable_text_analytics_logs=self.enable_text_analytics_logs,
            data_manager_logger=self.nlp_service_logger,
        )

        # retrieves the default parallelism value directly from the SparkContext.
        # If the "spark.default.parallelism" configuration is not set, it will fall
        # back to the number of cores available on the cluster.
        self.default_parallelism = self.spark.sparkContext.defaultParallelism

    def read_delta_table(self, delta_database_path: str, delta_table_name: str):
        """
        Reads data from the specified Delta table within a given database.

        This function reads data from the given Delta table located in the specified database.

        Args:
            delta_database_path (str): The path to the delta database.
            delta_table_name (str): The name of delta table
        Returns:
            DataFrame: A DataFrame containing the data read and loaded from the specified Delta table.
        """
        table_path = f"{delta_database_path}/{delta_table_name.lower()}"
        try:
            if DeltaTable.isDeltaTable(self.spark, table_path):
                # Read data from the Delta table
                return self.spark.read.format("delta").load(table_path)
            else: 
                return None
        except AnalysisException as ex:
            raise NLPDataLoadError(
                message=f"{LC.NLP_MANAGER_DATA_LOAD_ERR_MSG} {table_path}: {str(ex)}"
            ) from ex
        except Py4JJavaError as ex:
            raise NLPDataLoadError(
                message=f"{LC.NLP_MANAGER_DATA_LOAD_ERR_MSG} {table_path}: {str(ex)}"
            ) from ex

    def __load_dataframe_from_table(
        self, table_name: str, count_limit: int = C.DEFAULT_MAX_DOC_LIMIT
    ) -> Optional[DataFrame]:
        """
        Load a DataFrame from the specified table, applying a row limit if specified.

        This method attempts to read the flattened NLP results data and get the latest meta_lastUpdated value.
        It then filters the input data to include only rows with a meta_lastUpdated value greater than the latest value.
        If no latest meta_lastUpdated value is found, it reads all data from the source folder path.

        Args:
            table_name (str): The name of the table to load the dataframe from
            count_limit (int): The maximum number of rows to load from the source folder.

        Returns:
            Optional[DataFrame]: The loaded DataFrame with the specified row limit, or None if an error occurs.
        """
        try:
            # Initialize latest_last_updated as None
            latest_last_updated = None

            id_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_ID_KEY]
            text_column = self.nlp_column_mappings[
                C.DEFAULT_NLP_COLUMNS_NAMING_TEXT_KEY
            ]
            timestamp_column = self.nlp_column_mappings[
                C.DEFAULT_NLP_COLUMNS_NAMING_LAST_UPDATED_KEY
            ]
            
            input_df = None
            
            # Load data from the source folder path
            input_df = self.read_delta_table(delta_database_path=self.silver_database_path,
                                                 delta_table_name=table_name) 
            if input_df is None:
                return input_df
            else:
                input_df = input_df.select(id_column,
                                     text_column,
                                     timestamp_column)

            # Attempt to read flattened NLP results data and get the latest meta_lastUpdated value
            try:
                last_updated_df = self.read_delta_table(
                    delta_database_path=self.silver_database_path,
                    delta_table_name=C.NLP_ENTITY_FHIR_RESOURCE_TYPE,
                )
                if last_updated_df is not None:
                    last_updated_df = last_updated_df.agg(F.max("parent_meta_lastUpdated").alias("meta_last_updated"))
                    # Proceed only if the Dataframe is not empty
                    if last_updated_df.count() > 0:
                        latest_last_updated = last_updated_df.first()["meta_last_updated"]
            except NLPDataLoadError as ex:
                self._logger.debug(
                    message=f"{LC.NLP_MANAGER_DATA_LOAD_ERR_MSG} '{self.silver_database_path}.{C.NLP_ENTITY_RESOURCE_TYPE}' {LC.NLP_MANAGER_DATA_LOAD_SUFFIX_ERR_MSG} {str(ex)[:100]}..."
                )


            if latest_last_updated:
                # Load data from the source folder path
                input_df = input_df.filter(
                    F.col(timestamp_column) > latest_last_updated
                )
                self._logger.info(
                    message=f"{LC.NLP_MANAGER_DATA_FILTERING_INFO_MSG} '{latest_last_updated}'. {LC.NLP_MANAGER_DATA_TABLE_INFO_MSG} {self.silver_database_path}.{table_name}"
                )
            else:
                self._logger.info(
                    message=f"{LC.NLP_MANAGER_DATA_LOAD_PROCEED_INFO_MSG} {LC.NLP_MANAGER_DATA_TABLE_INFO_MSG}'{self.silver_database_path}.{table_name}'. {LC.NLP_MANAGER_DOCUMENT_COUNT_INFO_MSG} {input_df.count()}"
                )

            input_df = input_df.orderBy(F.col(timestamp_column))
            self._logger.info(
                f"{LC.NLP_MANAGER_DATA_LOAD_ORDERING_INFO_MSG} `{timestamp_column}`."
            )

            # Limit the number of rows if count_limit is provided or to the default max document limit 0f 1000
            count_limit = min(count_limit, C.DEFAULT_MAX_DOC_LIMIT)
            input_df = input_df.limit(count_limit)
            self._logger.info(
                message=f"{LC.NLP_MANAGER_DATA_LOAD_DOCUMENT_COUNT_LIMITING_INFO_MSG} {input_df.count()}."
            )

            return input_df
        except NLPDataPathError as ex:
            raise NLPDataPathError(
                message=f"{LC.NLP_MANAGER_DATA_LOAD_ERR_MSG} '{self.silver_database_path}.{table_name}': {str(ex)}"
            ) from ex
        except NLPDataLoadError as ex:
            raise NLPDataLoadError(
                message=f"{LC.NLP_MANAGER_DATA_LOAD_ERR_MSG}  '{self.silver_database_path}.{table_name}': {str(ex)}"
            ) from ex
        except AnalysisException as ex:
            raise NLPDataLoadError(
                message=f"{LC.NLP_MANAGER_DATA_LOAD_ERR_MSG}  '{self.silver_database_path}.{table_name}': {str(ex)}"
            ) from ex

    def __retry_on_recoverable_errors(self, source_df: DataFrame, retry_count: int) -> DataFrame:
        """Analyze the resulting dataframe from calling TA4H service for any recoverable errors.
        Retry if any recoverable errors are found

        Args:
            source_df (DataFrame): The resulting dataframe from calling TA4H Service
            retry_count (int): The number of times to retry if recoverable errors are found

        Returns:
            DataFrame: The resulting dataframe after retried on recoverable errors
        """
        input_df = source_df
        self._logger.info(
            f"{LC.NLP_MANAGER_RETRY_INPUT_DF_INFO_MSG} {source_df.count()}"
        )
        num_retries = 0
        id_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_ID_KEY]
        result_column = self.nlp_column_mappings[
            C.DEFAULT_NLP_COLUMNS_NAMING_RESULT_KEY
        ]
        for _ in range(retry_count):
            # Get DataFrame with recoverable errors
            error_df = input_df.filter(
                F.col("is_error")
                & F.col(f"{result_column}.error.code").isin(
                    C.DEFAULT_RECOVERABLE_ERROR_CODES
                )
            )
            # Break the loop if no recoverable errors are found
            if error_df.count() == 0:
                self._logger.info(
                    message=f"{LC.NLP_MANAGER_RETRY_TERMINATED_INFO_MSG} {num_retries}"
                )
                break

            # Retry NLP analysis on error_df DataFrame
            retry_result_df = self.nlp.analyze(
                source_df=error_df,
                default_parallelism=self.default_parallelism,
                batch_size=C.DEFAULT_BATCH_SIZE,
            )

            # Rename columns in retry_result_df other than 'id' column
            retry_result_df = retry_result_df.select(
                [
                    F.col(column).alias(column + '_retry') if column != 'id' else F.col(column) 
                 for column in retry_result_df.columns
                 ]
            )
            
            # Merge the retry_result_df DataFrame with the input_df DataFrame
            merged_df = input_df.join(
                retry_result_df, on=id_column, how="left_outer"
            )

            # Update the 'is_error' and 'result' columns based on the values from retry_result_df
            merged_df = merged_df.withColumn(
                "is_error",
                F.when(F.col("is_error_retry").isNull(), F.col("is_error")).otherwise(
                    F.col("is_error_retry")
                ),
            )
            merged_df = merged_df.withColumn(
                result_column,
                F.when(
                    F.col(f"{result_column}_retry").isNull(), F.col(result_column)
                ).otherwise(F.col(f"{result_column}_retry")),
            )

            # List all columns that ends with '_retry'
            columns_to_drop = [column for column in merged_df.columns if column.endswith('_retry')]
            
            # Drop these columns
            for col_name in columns_to_drop:
                merged_df = merged_df.drop(col_name)

            input_df = merged_df
            num_retries += 1
            self._logger.info(
                f"{LC.NLP_MANAGER_RETRY_SUCCESSFUL_INFO_MSG} {num_retries}"
            )

        return input_df

    def __flatten_and_save_successful_rows(self, success_df: DataFrame):
        """
        Method for flattening and saving successful rows.

        Args:
            success_df: DataFrame containing the results from the NLP pipeline.

        Returns:
            None
        """
        try:
            flatten_nlp_results = FlattenNLPResults(
                spark=self.spark,
                solution_name=self.solution_name,
                workspace_name=self.workspace_name,
                configuration_dir=self.flatten_config_dir,
                configuration_name=self.flatten_config_name,
                flatten_output_database_path=self.silver_database_path,
            )
            flatten_nlp_results.process(input_df=success_df)
        except NLPFlatteningError as ex:
            raise NLPFlatteningError(f"{str(ex.message)}") from ex
        except NLPDataSaveError as ex:
            raise NLPDataSaveError(f"{str(ex.message)}") from ex

    def create_nlp_tables(self):
        """Create NLP Tables
        """
                        
        self.__flatten_and_save_successful_rows(None)

    def extract_and_log_nlp_errors(self, result_dataframe: DataFrame):
        """
        Extracts error details from the NLP results DataFrame and logs them.

        Note: This function will be deprecated once we integrate pymds logger(https://msdata.visualstudio.com/A365/_wiki/wikis/SynapseML%20Team%20Wiki/60925/Kusto-Logs-(MDS)) into our module.
        Parameters:
            result_dataframe (DataFrame): Input DataFrame containing error details.

        Returns:
            None
        """
        id_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_ID_KEY]
        result_column = self.nlp_column_mappings[C.DEFAULT_NLP_COLUMNS_NAMING_RESULT_KEY]
        # Filter the DataFrame to extract rows with errors
        error_df = result_dataframe.filter(F.col("is_error") == "True")\
                        .withColumn("error_code", F.col(f"{result_column}.error.code"))\
                        .withColumn("error_message", F.col(f"{result_column}.error.message"))\
                        .select(id_column, "error_code", "error_message")
       
        # Collect error details as a list of dictionaries
        error_details = error_df.collect()
        
        # Log each error
        for error_detail in error_details:
            doc_id = error_detail[id_column]
            error_code = error_detail["error_code"]
            error_message = error_detail["error_message"]
            message = LC.NLP_MANAGER_PIPELINE_INDIVIDUAL_CUSTOM_ERR_MSG.format(
                doc_id=doc_id, 
                error_code=error_code,
                error_message=error_message)
                    
            self._logger.error(message)
                    
    # pylint: disable=broad-exception-caught
    def run_nlp_pipeline(
        self,
        table_name: str = C.DEFAULT_NLP_RESOURCE_TYPE_TO_ANALYZE,
        retry_count: int = C.DEFAULT_NLP_PIPELINE_MAX_RETRY_COUNT,
        document_limit: int = C.DEFAULT_MAX_DOC_LIMIT,
    ):
        """
        Runs the NLP pipeline using the Azure Text Analytics for Health API.

        This method takes a table name, processes the documents using the Azure Text Analytics for Health API,
        retries on any recoverable errors, flattens the results and persists the result in the the nlp_output path.

        Args:
            table_name: str (str): The table name with unstructured text to analyze.
            retry_count (int): Retry count on the subset of errors whose initial analysis fail with recoverable errors.
            nlp_column_name_mapping (Optional[Dict[str, str]]): A dictionary to map input column names.
                Default is None, which uses default column names.
            document_limit (int): The maximum number of documents to process. Default preview limit is 1000.
        """
        try:
            self._logger.info(message=LC.NLP_MANAGER_PIPELINE_START_INFO_MSG)

            self._logger.info(f"{LC.NLP_MANAGER_LOADING_DATA_FROM_TABLE_INFO_MSG.format(table_name=table_name)}")
            input_df = self.__load_dataframe_from_table(
                table_name=table_name, count_limit=document_limit
            )

            if input_df is None or input_df.count() == 0:
                self._logger.info(
                    message=LC.NLP_MANAGER_PIPELINE_SUCCESS_NO_NEW_RECORDS_INFO_MSG
                )
                self.__flatten_and_save_successful_rows(None)
                return

            input_df_count = input_df.count()
            self._logger.info(
                message=f"{LC.NLP_MANAGER_PIPELINE_LOAD_DF_INFO_MSG} {input_df_count}"
            )

            self._logger.info(f"{LC.NLP_MANAGER_CALLING_NLPSERVICE_INFO_MSG}")
            initial_result_df = self.nlp.analyze(
                source_df=input_df,
                default_parallelism=self.default_parallelism,
                batch_size=C.DEFAULT_BATCH_SIZE,
            )

            self._logger.info(f"{LC.NLP_MANAGER_CHECKING_RECOVERABLE_ERRORS_INFO_MSG}")
            result_df = self.__retry_on_recoverable_errors(
                initial_result_df, retry_count
            )

            result_df.persist(StorageLevel.MEMORY_AND_DISK)

            final_result_df_count = result_df.count()

            self._logger.info(
                message=f"{LC.NLP_MANAGER_FINAL_ANALYZED_DATAFRAME_INFO_MSG} {final_result_df_count}"
            )
            if final_result_df_count > 0:
                success_df = result_df.filter(F.col("is_error") == "False")
                success_count = success_df.count()
            else:
                success_count = 0

            error_count = input_df_count - success_count
            if success_count > 0:
                self.__flatten_and_save_successful_rows(success_df)
                
                self._logger.info(LC.NLP_MANAGER_PIPELINE_SUCCESS_INFO_MSG
                    + f"{LC.NLP_MANAGER_TOTAL_ANALYZED_RECORDS_INFO_MSG} {input_df_count}."
                    + f"{LC.NLP_MANAGER_TOTAL_SUCCESSFULLY_ANALYZED_RECORDS_INFO_MSG} {success_count}."
                    + f"{LC.NLP_MANAGER_TOTAL_ERROR_ANALYZED_RECORDS_INFO_MSG} {error_count}.")
                # Log any errors that might exist
                if error_count > 0:
                    self.extract_and_log_nlp_errors(result_dataframe=result_df)
                    
            else:
                self.extract_and_log_nlp_errors(result_dataframe=result_df)
                message = f"{LC.NLP_MANAGER_PIPELINE_UNRECOVERABLE_ERRORS_INFO_MSG} {LC.NLP_MANAGER_TOTAL_ANALYZED_RECORDS_INFO_MSG} {input_df_count}. {LC.NLP_MANAGER_TOTAL_ERROR_ANALYZED_RECORDS_INFO_MSG} {error_count}."
                self._logger.error(message)
                raise NLPUnrecoverableError(message)
        except Exception as ex:
            self._logger.error(str(ex))
            raise
        finally:
            if 'result_df' in locals():
                result_df.unpersist()
            if 'initial_result_df' in locals():
                initial_result_df.unpersist()
                
