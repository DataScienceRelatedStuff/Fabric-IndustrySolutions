from tests.utils.envcompile.model.env_config_model import EnvConfigModel
from tests.utils.envcompile.model.common.entity_type_enum import EntityTypeEnum

class EnvCompiler:
    
    def compile(dmf_contract: str, env_config:str) -> str:
        env_config_model = EnvConfigModel.from_str(env_config)
        dmf_contract = dmf_contract.replace("SOURCE_LOCATION", env_config_model.data_root_location(EntityTypeEnum.SOURCE))
        dmf_contract = dmf_contract.replace("TARGET_LOCATION", env_config_model.data_root_location(EntityTypeEnum.TARGET))
        dmf_contract = dmf_contract.replace("SECONDARY_LAKE_LOCATION", env_config_model.secondary_lake_location)
        return dmf_contract
        