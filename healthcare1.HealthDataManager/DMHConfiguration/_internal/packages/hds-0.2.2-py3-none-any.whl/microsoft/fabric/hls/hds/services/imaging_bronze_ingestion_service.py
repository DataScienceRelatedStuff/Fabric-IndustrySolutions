# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class used for ingesting imaging metadata to bronze delta table
"""
import os
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import FolderPath
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.metadata_extraction_orchestrator import MetadataExtractionOrchestrator
from microsoft.fabric.hls.hds.medical_imaging.dicom.utils.utils import Utils
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.archive_extractor import ArchiveExtractor
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter

telemetry_reporter = TelemetryReporter()

# Report ImagingBronzeIngestionService module import
telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
                                activity_name=GlobalConstants.IMAGING_BRONZE_INGESTION_ACTIVITY_NAME)

class ImagingBronzeIngestionService:
    """
    Class used for ingesting imaging metadata to bronze delta table
    """
    
    def __init__(self, 
                spark: SparkSession,
                workspace_name: str,
                lakehouse_name: str,
                solution_name: str,
                **kwargs) -> None:
        """
        Args:
            - spark: spark session
            - workspace_name: Name of the Fabric Workspace
            - lakehouse_name (str): The lakehouse name where the target table and dcm files are located
            - solution_name (str): Name of the HDS-Healthcare data solutions OneLake workload solution
            - **kwargs (dict): An optional dictionary that customer can use to configure the bronze_ingestion service
            - dcm_file_drop_path : the path where input (.zip or .dcm) files will be located. Default will be 'abfss://{workspace_name}@{one_lake_endpoint}/{lakehouse_name}.Lakehouse/Files/Ingest'
            - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
            - max_batch_size_dcm_files (int): maximum batch size for .dcm files to pick up , otherwise default it from constants 
            - max_batch_size_archive_files (int): maximum batch size for .zip files to pick up , otherwise default it from constants 
            - checkpoint_path (str): the Files path to where the checkpoint files will be located. Default will be 'abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/medical_imaging/dicom_metadata_extraction`
            - max_archive_file_size_in_mb : Input for max archive file size in MB, otherwise default it from constants
            - max_thread_size_archive_extract : Input for max thread size to extract files with in a archive file, otherwise default it from constants
            - max_thread_size_dcm_file : Input for max thread size to move DCM files from drop to year/month/day folder, otherwise default it from constants
        """
        self.spark: SparkSession = spark
        self.workspace_name = workspace_name
        self.lakehouse_name = lakehouse_name
        self.solution_name = solution_name
        self.one_lake_endpoint = kwargs.get("one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT)
        self.max_batch_size_dcm_files = kwargs.get("max_batch_size_dcm_files", C.MAX_BATCH_SIZE_DCM_FILES_DEFAULT)
        self.max_batch_size_archive_files = kwargs.get("max_batch_size_archive_files", C.MAX_BATCH_SIZE_ARCHIVE_FILES_DEFAULT)
        self.max_archive_file_size_in_mb = kwargs.get("max_archive_file_size_in_mb", C.MAX_ARCHIVE_FILE_SIZE_IN_MB_DEFAULT)
        self.max_thread_size_archive_extract = kwargs.get("max_thread_size_archive_extract", C.MAX_THREAD_SIZE_ARCHIVE_EXTRACT_DEFAULT)
        self.max_thread_size_dcm_file = kwargs.get("max_thread_size_dcm_file", C.MAX_THREAD_SIZE_DCM_FILE)
        
        self.dcm_files_extract_folder = os.path.join(GlobalConstants.MEDICAL_IMAGING_FOLDER, C.DCM_FILES_EXTRACT_FOLDER)
        
        self._logger = LoggingHelper.get_imaging_bronze_ingestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )
        
        try:
            self.lakehouse_files_root_path = FolderPath.get_fabric_files_path(workspace_name=self.workspace_name,
                                                                        one_lake_endpoint=self.one_lake_endpoint,
                                                                        lakehouse_name=self.lakehouse_name)
            
            self.target_table_path = FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.lakehouse_name
                )
            
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                solution_name=self.solution_name
            )
            self.checkpoint_path = kwargs.get(
                "checkpoint_path",
                FolderPath.get_fabric_workload_files_checkpoint_folder_path(root_path=self.config_files_root_path,
                                                                        checkpoint_folder_name=f"{GlobalConstants.MEDICAL_IMAGING_FOLDER}/{C.METADATA_EXTRACT_CHECKPOINT_FOLDER}")
            )
            
            self.dcm_file_drop_path = kwargs.get(
                "dcm_file_drop_path",
                os.path.join(self.lakehouse_files_root_path, C.DCM_FILE_DROP_FOLDER)
            )
            
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise
        
    def ingest(self) -> None:
        """
        -> This method extract ".zip" files and move ".dcm" files into ready to process folder.
        -> This method process dicom files present inside current date(today) folder and 
        save the metadata output into delta table.
        """
        # Report Imaging Raw to Bronze Ingestion Pipeline Usage
        telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
                                        activity_name=GlobalConstants.IMAGING_BRONZE_INGESTION_ACTIVITY_NAME)
        
        date_path = Utils.get_current_date_in_utc()
        self._setup_dicom_files(date_path)
        self._start_dicom_metadata_extract(date_path)
        
    def _start_dicom_metadata_extract(self, date_path):
        metadata_extract_orchestrator = MetadataExtractionOrchestrator(self.spark, 
                                                                os.path.join(self.lakehouse_files_root_path, self.dcm_files_extract_folder), 
                                                                self.target_table_path,
                                                                self.checkpoint_path)
        metadata_extract_orchestrator.process(date_path)        

    def _setup_dicom_files(self, date_path):
        """
        This method extract ".zip" files and move ".dcm" files into ready to process folder.
        """    
        _archive_extractor = ArchiveExtractor(
                            self.spark, 
                            self.lakehouse_files_root_path,
                            self.dcm_file_drop_path,
                            self.max_batch_size_dcm_files,
                            self.max_batch_size_archive_files,
                            self.max_archive_file_size_in_mb,
                            self.max_thread_size_archive_extract,
                            self.max_thread_size_dcm_file)
        _archive_extractor.start_process(date_path)