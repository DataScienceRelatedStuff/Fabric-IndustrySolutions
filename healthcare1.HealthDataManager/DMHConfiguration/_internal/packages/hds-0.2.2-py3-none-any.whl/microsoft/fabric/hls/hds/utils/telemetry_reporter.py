# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import importlib.util
# pylint: disable=E0401,C0415
class TelemetryReporter:
    """
    A class to handle telemetry reporting.

    This class provides functionality to report telemetry data. It checks for the
    availability of the required telemetry module and uses it if available.
    If the module is not available, it falls back to a default behavior (e.g., a no-op or mock implementation).

    Attributes:
        module_available (bool): Indicates whether the telemetry module is available.
    """

    def __init__(self):
        """
        Initializes the TelemetryReporter by checking the availability of the telemetry module.
        """
        self.module_available = self._check_module_availability('synapse.ml.fabric.telemetry_utils')

    def _check_module_availability(self, module_name):
        """
        Checks whether a given module is available for import.

        Args:
            module_name (str): The name of the module to check.

        Returns:
            bool: True if the module is available, False otherwise.
        """
        try: 
            return importlib.util.find_spec(module_name) is not None
        except (ModuleNotFoundError, ValueError):
            return False

    def report_usage(self, feature_name, activity_name, attributes = None):
        """
        Reports usage telemetry data.

        If the telemetry module is available, this function calls the module's reporting function.
        Otherwise, it executes a fallback behavior.

        Args:
            feature_name (str): The name of the feature to report.
            activity_name (str): The name of the activity to report.
            attributes (dict, optional): Additional attributes to report. Defaults to None.
        """
        if attributes is None:
            attributes = {}

        if self.module_available:
            from synapse.ml.fabric.telemetry_utils import report_usage_telemetry
            report_usage_telemetry(feature_name, activity_name, attributes)
        else:
            # Fallback behavior if the module is not available
            print(f"Synapse ML Telemetry module not available. Would have reported: {feature_name}, {activity_name}, {attributes}")
