# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with class containing flatten normalization logic
"""
import hashlib
import re
import datetime
import json
from typing import Union
from pyspark.sql.types import ArrayType, StringType, StructType, StructField, Row
from pyspark.sql.functions import udf
from microsoft.fabric.hls.hds.flatten.constants import FlattenConstants as C
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC

class FlattenNormalization:
    """
    Class for doing flatten functionality based on provided or internal configuration
    """
    @staticmethod
    def normalize_date(date: Union[str, datetime.datetime, datetime.date, None])\
            -> Union[datetime.datetime,None]:
        """
        Normalization of the data string

        Following the logic from https://github.com/hlstests/a3/blob/master/algorithm.md
        """
        # type_data_str = type(date)
        # print(f"{date} is type of {type_data_str}")
        generated_str = None
        if date is None:
            return None
        # return date types without normalization
        if isinstance(date, datetime.datetime):
            return date
        # add zero time to the date without normalization
        if isinstance(date, datetime.date):
            return datetime.datetime.combine(date, datetime.datetime.min.time()).\
                replace(tzinfo=datetime.timezone.utc)
        # we dont support other types rather string and datetime
        if not isinstance(date, str):
            return None
        # try to match the string
        if re.match(pattern=C.RE_DATE_YEAR, string=date):
            generated_str = f"{date}-01-01 00:00:00.000+0000"
        if re.match(pattern=C.RE_DATE_YEAR_MONTH, string=date):
            generated_str = f"{date}-01 00:00:00.000+0000"
        if re.match(pattern=C.RE_DATE_YEAR_MONTH_DAY, string=date):
            generated_str = f"{date} 00:00:00.000+0000"
        if re.match(pattern=C.RE_DATE_TIME_PART, string=date):
            parts = re.match(
                pattern=C.RE_DATE_FULL_PARTS, string=date)
            if parts:
                # get 3 numbers milliseconds part with leading .
                mil_seconds_parts = '.000'
                if parts[4]:
                    mil_seconds_parts = str(
                        parts[4] or '')+'.000'[len(str(parts[4] or '')):]

                timezone_part = "+0000"
                # if timezone already present in +00 or -00 format, leave as is
                if parts[5] and (parts[5][0] == '+' or parts[5][0] == '-'):
                    timezone_part = parts[5].replace(":", "")
                generated_str = f"{parts[1]} {parts[3]}{mil_seconds_parts}{timezone_part}"
        if generated_str:
            return datetime.datetime.strptime(generated_str, '%Y-%m-%d %H:%M:%S.%f%z')
        return None

    @staticmethod
    def normalize_url(link_str: str) -> Union[str,None]:
        """
        Normalization of the url
        """
        if not isinstance(link_str, str) or link_str is None:
            return None
        
        link_encoded = link_str.encode()
        hash_object = hashlib.sha1(link_encoded)
        return hash_object.hexdigest()

    @staticmethod
    def normalize_resource_id(id_value: str,
                              type_value: str,
                              base_url: Union[str, None] = None
                              ) -> Union[str,None]:
        """
        Resource/reference id normalization. 
        """
        
        if id_value is None or type_value is None:
            return None
        
        full_url = type_value + '/' + id_value
        if base_url:
            base_url = FlattenNormalization.remove_url_scheme_regex(base_url)
            full_url = base_url + '/' + full_url

        return FlattenNormalization.normalize_url(full_url)
    
    @staticmethod
    def remove_url_scheme_regex(url: str):
        """
        Removes the scheme from a URL.

        This function uses a regular expression to remove the scheme (e.g., 'http://', 'https://') from a URL.
        If the URL is empty either before or after removing the scheme, the function returns None.

        Args:
            url (str): The URL from which to remove the scheme.

        Returns:
            str or None: The URL without the scheme, or None if the URL is empty.
        """
        return re.sub(r'^\w+://', '', url) if isinstance(url, str) and url else None
    
    @staticmethod
    def get_reference_details(reference_string: str):
        """
        Normalization by reference string
        """
        # Check if the input is not a string
        if not isinstance(reference_string, str):
            return None, None, None, None

        # Pattern for literal references
        pattern_literal = r'((http|https):\/\/([A-Za-z0-9\-\\\.\:\%\$]*\/)+)?' + C.VALID_FHIR_TYPES + r'\/([A-Za-z0-9\-\.]{1,64})(\/_history\/[A-Za-z0-9\-\.]{1,64})?'

        # Pattern for logical references
        pattern_logical = C.VALID_FHIR_TYPES + r'\?identifier=([^|]*)\|(.*)'

        # Try to match the literal reference pattern
        match_literal = re.search(pattern_literal, reference_string)
        if match_literal:
            reference_type = "Literal"
            base_url = match_literal.group(1) or None
            resource_type = match_literal.group(4)
            resource_id = match_literal.group(5)
            return reference_type, base_url, resource_type, resource_id

        # Try to match the logical reference pattern
        match_logical = re.search(pattern_logical, reference_string)
        if match_logical:
            reference_type = "Logical"
            resource_type = match_logical.group(1)
            system = match_logical.group(2)
            value = match_logical.group(3)
            return reference_type, system, resource_type, value

        # If no match, return None
        return None, None, None, None

    @staticmethod
    def create_row_from_string(data: str , schema: StructType) -> Row:
        """Create a Row object based on the provided schema."""
        data_dict = json.loads(data) if data else {}
        row_data = {}
        for field in schema:
            row_data[field.name] = data_dict.get(field.name, None)
        return Row(**row_data)
    
    @staticmethod
    def normalize_ref_struct(reference_row: Row) -> Row:
        """
        Reference struct normalization
        
        Args:
        reference_row (Row): The input row representing a reference in a FHIR resource. 
                             It should have the fields 'reference', 'type', 'identifier', 'extension', 'display', id, and id_orig.

        Returns:
            Row: The normalized reference row.
        """

        # Default values for all fields
        reference, type_, display, extension, id_, id_orig = None, None, None, None, None, None
        identifier = Row(use=None, type=None, system=None, value=None, period=None, assigner=None)

        if not isinstance(reference_row, (Row, dict)):
            # Handle unexpected data type here
            return Row(reference=reference, type=type_, identifier=identifier, display=display, extension=extension, id=id_, id_orig=id_orig)
 
        if reference_row:
            reference = reference_row["reference"] if "reference" in reference_row else None
            type_ = reference_row["type"] if "type" in reference_row else None
            display = reference_row["display"] if "display" in reference_row else None
            extension = reference_row["extension"] if "extension" in reference_row else None
            
            # Handle identifier
            prev_identifier = reference_row["identifier"] if "identifier" in reference_row else {}
            if prev_identifier:
                if isinstance(prev_identifier, (Row, dict)):
                    identifier = Row(
                        use=prev_identifier["use"] if "use" in prev_identifier else None,
                        type=prev_identifier["type"] if "type" in prev_identifier else None,
                        system=prev_identifier["system"] if "system" in prev_identifier else None,
                        value=prev_identifier["value"] if "value" in prev_identifier else None,
                        period=prev_identifier["period"] if "period" in prev_identifier else None,
                        assigner=prev_identifier["assigner"] if "assigner" in prev_identifier else None
                    )
                elif isinstance(prev_identifier, (StringType, str)):
                    identifier = FlattenNormalization.create_row_from_string(prev_identifier, C.NORM_REF_IDENTIFIER_SCHEMA)
                
            if reference:
                reference_type, base_url, resource_type, resource_id = FlattenNormalization.get_reference_details(reference)
                type_ = type_ or resource_type
                if reference_type == "Literal":
                    id_orig = resource_id
                    id_ = FlattenNormalization.normalize_resource_id(base_url=base_url,
                                                                      id_value=resource_id,
                                                                      type_value=type_)
                elif reference_type == "Logical":
                    identifier = Row(
                        use=identifier["use"],
                        type=identifier["type"] ,
                        system=base_url,
                        value=resource_id,
                        period=identifier["period"],
                        assigner=identifier["assigner"]
                    )

        return Row(reference=reference,
                   type=type_,
                   identifier=identifier,
                   display=display,
                   extension=extension,
                   id=id_,
                   id_orig=id_orig)
    
    @staticmethod
    # Define a UDF that normalizes a column with nested references array
    def normalize_ref_array(column_data: list) -> list:
        """
        Nested reference array normalization udf
        """
        
        if column_data:
            return [FlattenNormalization.normalize_ref_struct(row) for row in column_data]

        return column_data
    
    @staticmethod
    # Define a UDF that normalizes a specified nested references
    def normalize_nested_ref_struct_in_array(nested_ref_name: str, column_data: list) -> list:
        """
        Nested struct reference in an array normalization udf
        """
        if column_data:
            return [
                {
                    **(row if isinstance(row, dict) else row.asDict()),
                    **{nested_ref_name: FlattenNormalization.normalize_ref_struct(row[nested_ref_name])}
                }
                for row in column_data
            ]
        return column_data
    
    @staticmethod
    def normalize_nested_ref_struct_in_struct(nested_ref_name: str, row: Row) -> Row:
        """
        Nested reference normalization for a StructType field
        """
        if row:
            row_dict = row if isinstance(row, dict) else row.asDict()

            # Normalize the nested_ref_name field
            nested_value = row_dict.get(nested_ref_name)
            normalized_value = FlattenNormalization.normalize_ref_struct(nested_value)
            row_dict[nested_ref_name] = normalized_value

            # Convert the dictionary back to a Row object
            return Row(**row_dict)
        
        return row
    
    @staticmethod
    def normalize_nested_ref_array_in_struct(nested_ref_name: str, row: Row) -> Row:
        """
        Nested reference normalization for a ArrayType field
        """
        if row:
            row_dict = row if isinstance(row, dict) else row.asDict()
            
            # Normalize the nested_ref_name field
            nested_value = row_dict.get(nested_ref_name)
            normalized_value = FlattenNormalization.normalize_ref_array(nested_value)
            row_dict[nested_ref_name] = normalized_value

            # Convert the dictionary back to a Row object
            return Row(**row_dict)
        
        return row
    
    @staticmethod
    # Define a UDF that normalizes a specified nested references
    def normalize_nested_ref_array_in_array(nested_ref_name: str, column_data: list) -> list:
        """
        Nested reference normalization udf
        """
        if column_data:
            return [
                {
                    **(row if isinstance(row, dict) else row.asDict()), 
                    **{nested_ref_name: FlattenNormalization.normalize_ref_array(row[nested_ref_name])}
                }
                for row in column_data
            ]
        return column_data
    
    @staticmethod
    def create_normalize_nested_ref_udf(original_col_schema, nested_ref_name, nested_array):
        """
        Nested reference normalization dynamic udf
        """
        is_root_array_type = isinstance(original_col_schema, ArrayType)
        col_schema_fields = original_col_schema.elementType.fields if is_root_array_type else original_col_schema.fields

        field_name_to_index = {field.name: index for index, field in enumerate(col_schema_fields)}
        if nested_ref_name not in field_name_to_index:
            raise ValueError(LC.REFERENCE_NORMALIZATION_INVALID_CONFIG.format(nested_ref_name=nested_ref_name))

        nested_ref_index = field_name_to_index[nested_ref_name]
        extended_schema_fields = col_schema_fields[:]

        nested_ref_field_schema = C.NORM_REF_ARRAY_UDF_SCHEMA if nested_array else C.NORM_REF_STRUCT_UDF_SCHEMA
        extended_schema_fields[nested_ref_index] = StructField(nested_ref_name, nested_ref_field_schema, True)

        if is_root_array_type:
            extended_schema = ArrayType(StructType(extended_schema_fields), True)
            if nested_array:
                return udf(lambda column_data: FlattenNormalization.normalize_nested_ref_array_in_array(nested_ref_name, column_data), extended_schema)
            return udf(lambda column_data: FlattenNormalization.normalize_nested_ref_struct_in_array(nested_ref_name, column_data), extended_schema)

        extended_schema = StructType(extended_schema_fields)
        if nested_array:
            return udf(lambda column_data: FlattenNormalization.normalize_nested_ref_array_in_struct(nested_ref_name, column_data), extended_schema)

        return udf(lambda column_data: FlattenNormalization.normalize_nested_ref_struct_in_struct(nested_ref_name, column_data), extended_schema)
