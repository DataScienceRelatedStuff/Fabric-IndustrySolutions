from typing import List
from pathlib import Path
from dmf.model.data_feed_configuration import DataFeedConfiguration
from tests.utils.config_utils import ConfigUtils
from tests.utils.dmf_application_test_util import DMFApplicationTestUtil


class TestDMFApplicationCommon:
    @staticmethod
    def run_dmf_with_mocked_reduced_config(spark, source_tables: List, target_table,
                                           transformation_spec_file_location: Path,
                                           env_config_file_path: Path, source_tables_location: Path,
                                           target_tables_location: Path) -> DataFeedConfiguration:

        full_dmf_config = DMFApplicationTestUtil.generate_config_from_file(spark, transformation_spec_file_location,
                                                                           env_config_file_path, source_tables_location,
                                                                           target_tables_location)

        reduced_config = ConfigUtils.reduce_config(source_tables, target_table, full_dmf_config)

        DMFApplicationTestUtil.start_dmf(reduced_config, spark)

        return reduced_config
