import os
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession, DataFrame
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC


class FileStreamReader:
    def __init__(self, spark: SparkSession, **kwargs):
        """
        Args:
        spark: spark session
        """
        self.spark: SparkSession = spark
        self.kwargs = kwargs
        self._logger = LoggingHelper.get_bronzeingestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )

    def set_up_streaming_json(self, schema_obj, streaming_path, **kwargs) -> DataFrame:
        """
        Given the streaming path and a schema path, this function will
        set up the initial configuration for reading data via streaming

        Returns:
            DataFrame: a streaming Dataframe
        """
        # set up streaming
        file_streaming_df = self.spark.readStream.schema(schema_obj)
        # apply any additional options (max_files_per_trigger, etc.)
        for option, value in self.kwargs.items():
            file_streaming_df = file_streaming_df.option(option, value)

        # loads the JSON file stream and returns as a DF
        file_streaming_df = file_streaming_df.json(streaming_path)

        return file_streaming_df  # type: ignore

    def set_up_streaming_csv(
        self, schema_obj, streaming_path, delimiter: str = "\t", **kwargs
    ) -> DataFrame:
        """
        Given the streaming path and a schema path, this function will
        set up the initial configuration for reading data via streaming

        Returns:
            DataFrame: a streaming Dataframe
        """
        # set up streaming
        file_streaming_df = self.spark.readStream
        # apply any additional options (max_files_per_trigger, etc.)
        for option, value in self.kwargs.items():
            file_streaming_df = file_streaming_df.option(option, value)

        # loads the JSON file stream and returns as a DF
        file_streaming_df = file_streaming_df.options(
            header="True", delimiter=delimiter
        ).csv(path=streaming_path, schema=schema_obj)

        return file_streaming_df  # type: ignore
