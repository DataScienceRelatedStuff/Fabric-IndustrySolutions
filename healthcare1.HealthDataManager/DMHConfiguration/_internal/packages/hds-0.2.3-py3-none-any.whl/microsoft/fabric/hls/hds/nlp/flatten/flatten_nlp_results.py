# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import concurrent.futures
from typing import Dict, List
from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.flatten.flatten_manager import FlattenManager
from microsoft.fabric.hls.hds.nlp.constants import NLPConstants as C
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.nlp.errors.nlp_flattening_error import NLPFlatteningError
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import Utils
from microsoft.fabric.hls.hds.utils.thread_pool_manager import ThreadPoolManager


class FlattenNLPResults:
    """
    A class for flattening NLP analysis results into separate DataFrames for entities and entity relationships.
    """

    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        configuration_dir: str,
        configuration_name: str,
        flatten_output_database_path: str
    ):
        """
        Initialize the FlattenNLPResults instance with a Spark session and
        an configuration path.

        :param spark: A SparkSession instance.
        :param configuration_dir: The directory where the configuration is located.
        :param configuration_name: The name of the configuration file in the configuration_dir
        :param flatten_output_database_path: The database path to which to write the flattened output.
        """
        # Instantiate the flattening library for entities and entity relationships
        self.spark = spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.configuration_dir = configuration_dir
        self.configuration_name = configuration_name
        self.flatten_output_database_path = flatten_output_database_path
        self.fl_manager = FlattenManager(
            spark=spark,
            solution_name=self.solution_name,
            workspace_name=self.workspace_name,
            source_schema_root_dir=configuration_dir,
            transformation_config_root_dir=configuration_dir,
            unique_columns=C.DEFAULT_NLP_OUTPUT_UNIQUE_COLUMNS,
            source_modified_on_column=GlobalConstants.DEFAULT_NLP_SOURCE_MODIFIED_ON_COLUMN
        )
        self.logger = LoggingHelper.get_nlpingestion_logger(
            self.spark, FlattenNLPResults.__name__, GlobalConstants.LOGGING_LEVEL
        )

    def process(self, input_df: DataFrame):
        """
        Flatten the input DataFrame containing NLP analysis results into
        separate DataFrames for entities and entity relationships.

        :param input_df: The input DataFrame containing NLP analysis results.
        """
        self.logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")
        config_path = f"{self.configuration_dir}/{self.configuration_name}"
        config_entities = Utils.load_config(
            self.spark,
            config_path=config_path,
        )

        if not config_entities:
            self.logger.info(LC.FLATTENING_EMPTY_CONFIG_FILE.format(config_path=config_path))
            return
        
        # Call silver_setup_fn to create silver tables in parallel
        try:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=len(config_entities)
            ) as executor:
                flatten_manager_tasks = {
                    executor.submit(
                        self.fl_manager.process_resource,
                        input_df,
                        None,
                        resource_config,
                        self.flatten_output_database_path
                    ): resource_config
                    for resource, resource_config in config_entities.items()
                }
                # Call Threadpool manager to await till all threads execute
                thread_pool_manager = ThreadPoolManager(spark=self.spark)
                thread_pool_manager.await_all_termination(futures=flatten_manager_tasks)
        except Exception as ex:
            raise NLPFlatteningError(str(ex)) from ex

        self.logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")
