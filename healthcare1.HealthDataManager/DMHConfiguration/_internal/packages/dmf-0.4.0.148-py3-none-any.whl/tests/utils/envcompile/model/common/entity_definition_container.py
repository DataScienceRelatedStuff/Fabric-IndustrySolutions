from typing import Optional

from pydantic import field_validator

from tests.utils.envcompile.model.common.entity_definition_container_type_enum import EntityDefinitionContainerTypeEnum
from tests.utils.envcompile.model.common.immutable_model import ImmutableModel


class EntityDefinitionContainer(ImmutableModel):
    type: EntityDefinitionContainerTypeEnum
    name: Optional[str] = None

    @field_validator('type')
    def check_type(cls, v: EntityDefinitionContainerTypeEnum):
        if v is None:
            raise ValueError("'type' is mandatory")

    @field_validator('name')
    def check_name(cls, v: Optional[str]):
        if not v and type == EntityDefinitionContainerTypeEnum.METASTORE:
            raise ValueError("'name' is mandatory for type EntityDefinitionContainerTypeEnum.METASTORE")
