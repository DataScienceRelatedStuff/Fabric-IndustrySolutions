import os.path
from typing import List, Optional, Union

from urllib3.util import Url

from rmt.filesystem.file_system_client import FileSystemClient
from rmt.runners.runner import REFERENCE_MAPPING_PATH
from tests.common.test_case_common import TestCaseCommon
from tests.conftest import TESTS_ROOT_DIR


class TesterFileSystemClient(FileSystemClient):
    def __init__(self, test_name: str):
        self.test_name = test_name

    def get_file_content(self, folder_url: Union[Url, str], file_name: str) -> str:
        with open(os.path.join(folder_url, file_name), encoding="utf-8") as f:
            content = f.read()
        content = content.replace("/tests/data", f"{TESTS_ROOT_DIR}/data")
        content = content.replace(
            "MOCK_SECONDARY_LAKE", TestCaseCommon.mapping_output_path_by_test_name(self.test_name)
        )
        return content

    def get_file_content_from_path(self, file_path: Union[Url, str]) -> str:
        with open(file_path, encoding="utf-8") as f:
            content = f.read()
        content = content.replace("/tests/data", f"{TESTS_ROOT_DIR}/data")
        content = content.replace(
            "MOCK_SECONDARY_LAKE", TestCaseCommon.mapping_output_path_by_test_name(self.test_name)
        )
        return content

    def list_files(self, folder_url: Union[Url, str], file_type: Optional[str] = None) -> List[str]:
        result: List[str] = []

        for file in os.listdir(folder_url):
            if file_type and file.endswith(f".{file_type}"):
                result.append(file)
        return result

    def join_paths(self, url1: Union[Url, str], url2: Union[Url, str]) -> str:
        if url2 == REFERENCE_MAPPING_PATH:
            return TestCaseCommon.mapping_output_path_by_test_name(self.test_name)
        else:
            return os.path.join(url1, url2)

    def path_exist(self, url: Union[Url, str]) -> bool:
        return os.path.exists(url)

    def get_all_subfolders(self, folders: List[Union[Url, str]]) -> List[str]:
        """walks recursively on all folders and subfolders and returns all subfolders"""
        result: List[str] = []
        for folder in folders:
            result.append(folder)
            for root, dirs, _files in os.walk(folder):
                for dir in dirs:
                    result.append(os.path.join(root, dir))
        return result
