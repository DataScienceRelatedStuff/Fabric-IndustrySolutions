# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a data class to extract archived files and place them into ready to process state
"""

from pyspark.sql import SparkSession
from datetime import datetime

from microsoft.fabric.hls.hds.medical_imaging.dicom.core.archive_extract_handler import ArchiveExtractHandler
from microsoft.fabric.hls.hds.medical_imaging.dicom.utils.utils import Utils
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C

from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import Utils as PlatformCommonUtil


class ArchiveExtractor():
    
    """
    This class is used to extract files from archive folder and move them into ready state to start the metadata extraction.
    """  
    
    def __init__(self, spark: SparkSession, 
                lakehouse_files_root_path : str, 
                dcm_file_drop_path : str,
                max_batch_size_dcm_files : int,
                max_batch_size_archive_files : int,
                max_archive_file_size_in_mb : int,
                max_thread_size_archive_extract : int,
                max_thread_size_dcm_file : int) -> None : 
        
        self._spark = spark
        self._lakehouse_files_root_path = lakehouse_files_root_path
        self._dcm_file_drop_path = dcm_file_drop_path
        self._max_batch_size_dcm_files = max_batch_size_dcm_files
        self._max_batch_size_archive_files = max_batch_size_archive_files
        self._max_archive_file_size_in_mb = max_archive_file_size_in_mb
        self._max_thread_size_archive_extract = max_thread_size_archive_extract
        self._max_thread_size_dcm_file = max_thread_size_dcm_file
        self._extract_current_date_path = ""
        
        self._logger = LoggingHelper.get_imaging_metadata_extraction_logger(
                            self._spark, self.__class__.__name__, GC.LOGGING_LEVEL)

        Utils.set_hadoop_default_path(spark,self._lakehouse_files_root_path)


    def start_process(self, current_date_path: str):
        
        self._logger.info(LC.ARCHIVE_EXTRACT_STATE_INFO_MSG.format(
                state= C.STATE_STARTED, 
                process_name=C.ARCHIVE_EXTRACTION_PROCESS_NAME, 
                timestamp=datetime.now(), 
                files_path=self._dcm_file_drop_path))
        
        try:            
            if PlatformCommonUtil.path_exists(self._dcm_file_drop_path):
                
                drop_folder_files = PlatformCommonUtil.list_files(self._dcm_file_drop_path)
                
                if drop_folder_files:                 
                    files_lst_zip , files_lst_dcm =  self._filter_files(drop_folder_files)
                    if files_lst_zip or files_lst_dcm:
                        self._pre_extract_process(current_date_path)
                        self._iterate_move_extract_files(files_lst_zip,files_lst_dcm)
                else:
                    self._logger.info(LC.ARCHIVE_EXTRACT_FOLDER_EMPTY_INFO_MSG.format(
                        process_name = C.ARCHIVE_EXTRACTION_PROCESS_NAME, 
                        state= C.STATE_COMPLETED, 
                        dcm_files_path=self._dcm_file_drop_path))
                    return             
            else:
                self._logger.error(LC.PATH_NOT_EXIST_ERR_MSG.format(
                    process_name= C.ARCHIVE_EXTRACTION_PROCESS_NAME,
                    path=self._dcm_file_drop_path)) 
                return               
        except Exception as ex:                    
            self._logger.error(message=str(ex))
            raise     
        
        self._logger.info(LC.ARCHIVE_EXTRACT_STATE_INFO_MSG.format(
            state= C.STATE_COMPLETED, 
            process_name=C.ARCHIVE_EXTRACTION_PROCESS_NAME, 
            timestamp=datetime.now(),
            files_path=self._dcm_file_drop_path))  

    def _pre_extract_process(self, current_date : str):
        
        self._extract_current_date_path = PlatformCommonUtil.join_path(self._lakehouse_files_root_path,
                                GC.MEDICAL_IMAGING_FOLDER,
                                C.DCM_FILES_EXTRACT_FOLDER,
                                current_date)
        
        Utils.create_folders_if_not_exist(self._extract_current_date_path)
        
        if int(self._max_batch_size_dcm_files) <= 0 : 
            self._max_batch_size_dcm_files = C.MAX_BATCH_SIZE_DCM_FILES_DEFAULT
        
        if int(self._max_batch_size_archive_files) <=0 :
            self._max_batch_size_dcm_files = C.MAX_BATCH_SIZE_ARCHIVE_FILES_DEFAULT
        
        if int(self._max_archive_file_size_in_mb) <=0 :
            self._max_archive_file_size_in_mb = C.MAX_ARCHIVE_FILE_SIZE_IN_MB_DEFAULT
        

    def _iterate_move_extract_files(self, files_lst_zip : list, files_lst_dcm : list):
                
        archive_extract_handler = ArchiveExtractHandler(self._spark,
                                                        self._extract_current_date_path,
                                                        self._max_thread_size_archive_extract)
        if files_lst_dcm:  
            archive_extract_handler.move_dcm_files(files_lst_dcm, self._max_thread_size_dcm_file)
        
        if files_lst_zip:
            archive_extract_handler.begin_archive_extracts(files_lst_zip)
            self.drop_archive_files(files_lst_zip)

    def _filter_files(self,files_list : list) :
        archive_file_size_in_bytes = Utils.get_size_in_bytes(self._max_archive_file_size_in_mb)

        files_lst_zip = list(filter(lambda file_extension: file_extension.name.endswith('.zip') 
                                        and file_extension.size <= int(archive_file_size_in_bytes),
                                        files_list))[:self._max_batch_size_archive_files]
        files_lst_dcm = list(filter(lambda file_extension: file_extension.name.endswith('.dcm'),
                                        files_list))[:self._max_batch_size_dcm_files]
        return files_lst_zip, files_lst_dcm
    
    def drop_archive_files(self, archive_files_list :list):
        for archive_file in archive_files_list:
            PlatformCommonUtil.remove_dir(archive_file.path)