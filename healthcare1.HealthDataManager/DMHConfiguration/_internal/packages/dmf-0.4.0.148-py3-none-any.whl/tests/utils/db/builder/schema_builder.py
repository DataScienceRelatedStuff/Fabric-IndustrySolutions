import os.path
import json
from abc import ABC, abstractmethod
from typing import Dict

from tests.utils.db.model.column import Column
from tests.utils.db.model.table import Table


class SchemaBuilder(ABC):

    def __init__(self, spark, metadata_file, db, warehouse_location):
        self.spark = spark
        self.metadata_file = metadata_file
        self.tables: Dict[str, Table] = {}
        self.db = db
        self.warehouse_location = warehouse_location

    def drop_db(self):
        self.spark.sql(f"DROP DATABASE IF EXISTS {self.db} CASCADE;")

    def create_db(self):

        self.parse_tables()

        self._create_db()
        self._create_tables()

    def parse_tables(self):
        metadata = self._read_db_metadata()
        for item in metadata["items"]:
            table_name = item["name"]
            if table_name in self._used_tables():
                partition_columns = None
                item_properties = item["properties"]
                partitioning = item_properties["Partitioning"]
                if partitioning:
                    partition_columns = partitioning["Keys"]
                storage_format = item_properties["StorageDescriptor"]["Format"]
                table = Table(name=table_name,
                              type=item_properties["TableType"],
                              format=storage_format["FormatType"],
                              partition_columns=partition_columns,
                              additional_properties=storage_format["Properties"],
                              location_root=self.data_location(),
                              db=self.db)

                for column in item_properties["StorageDescriptor"]["Columns"]:
                    column_type = column["OriginDataTypeName"]
                    table.columns.append(Column(name=column["Name"],
                                                type=column_type["TypeName"],
                                                precision=column_type["Precision"],
                                                scale=column_type["Scale"]
                                                )
                                         )

                self.tables[table_name] = table

    def _read_db_metadata(self):
        with open(self.metadata_file) as json_data:
            metadata = json.load(json_data)

        return metadata

    def _create_db(self):
        db_location = os.path.join(self.warehouse_location, self.db)
        self.spark.sql(f"CREATE DATABASE IF NOT EXISTS {self.db} LOCATION '{db_location}';")

    def _create_tables(self):

        for table in self.tables.values():
            try:
                self.spark.sql(str(table))
            except Exception:
                print(f"Cannot create table {table.name}")
                raise

    def _truncate_table(self, table: Table):
        try:
            self.spark.sql(f'TRUNCATE TABLE {table.name}')
        except Exception:
            print(f"Cannot truncate table `{table.db}`.`{table.name}`")
            raise

    def truncate_tables(self):
        for table in self.tables.values():
            self._truncate_table(table)

    def clean_tables(self):
        for table in self.tables.values():
            table.del_contents(self.spark)

    @abstractmethod
    def _used_tables(self):
        pass

    @staticmethod
    def data_location() -> str:
        pass
