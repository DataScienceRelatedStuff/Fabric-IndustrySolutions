import sys
import logging
import uuid
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.utils.spark_logger import SparkLogger
from microsoft.fabric.hls.hds.utils.SparkLoggerAppInsights import SparkLoggerAppInsights
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
import inspect

class DataManagerLogger():
    '''
    Class for logging operations

    The log will include the severity level, timestamp, logger name, and message
    
    :param: spark -- Current spark session
    :param: logger_name -- the name of the logger
    :param: log_level -- only events of this level and above will be tracked 
    '''
    
    def __init__(self, spark: SparkSession, logger_name: str, log_level: int = logging.DEBUG, run_id: uuid.UUID = uuid.uuid4()):
        log_format = logging.Formatter("%(asctime)s::%(name)s::%(levelname)s::%(message)s")
        
        # Initialize init arguments
        self._spark = spark
        self._logger_name = logger_name
        self._log_level = log_level
        self._run_id = run_id
        
        # Set up stdout_logger
        console_handler = logging.StreamHandler(sys.stdout) 
        console_handler.setFormatter(log_format)
        stdoutLoggerName = f"{LC.ConsoleLoggerName.format(logger_name=logger_name)}"
        self._stdout_logger = logging.getLogger(stdoutLoggerName)
        if (self._stdout_logger.hasHandlers()):
            self._stdout_logger.handlers.clear()
        self._stdout_logger.addHandler(console_handler) 
        self._stdout_logger.setLevel(self._log_level)
        self._stdout_logger.propagate = False
        
        # Set up spark loggers
        self._spark_logger = SparkLogger.get_logger(self._spark, self._logger_name, self._log_level)
        self._spark_logger_app_insights = SparkLoggerAppInsights.get_logger(self._spark, self._run_id, self._logger_name, self._log_level)

    def debug(self, message: str, *args, **kwargs):
        '''
        A utility method to log at the DEBUG level
        
        :param: message -- the message to be logged
        :param: args/kargs -- (optional) a list of additional arguments 
        '''
        func = inspect.currentframe().f_back.f_code
        self._post_data(logging.DEBUG, message, func, *args, **kwargs)
    
    def info(self, message: str, *args, **kwargs):
        '''
        A utility method to log at the INFO level
        
        :param: message -- the message to be logged
        :param: args/kargs -- (optional) a list of additional arguments 
        '''
        func = inspect.currentframe().f_back.f_code
        self._post_data(logging.INFO, message, func, *args, **kwargs)
    
    def warning(self, message: str, *args, **kwargs):
        '''
        A utility method to log at the WARNING level
        
        :param: message -- the message to be logged
        :param: args/kargs -- (optional) a list of additional arguments 
        '''
        func = inspect.currentframe().f_back.f_code
        self._post_data(logging.WARNING, message, func, *args, **kwargs)
    
    def error(self, message: str, *args, **kwargs):
        '''
        A utility method to log at the ERROR level
        
        :param: message -- the message to be logged
        :param: args/kargs -- (optional) a list of additional arguments 
        '''
        func = inspect.currentframe().f_back.f_code
        self._post_data(logging.ERROR, message, func, *args, **kwargs)
    
    def critical(self, message: str, *args, **kwargs):
        '''
        A utility method to log at the CRITICAL level
        
        :param: message -- the message to be logged
        :param: args/kargs -- (optional) a list of additional arguments 
        '''
        func = inspect.currentframe().f_back.f_code
        self._post_data(logging.CRITICAL, message, func, *args, **kwargs)
        
    def _post_data(self, level: int, message: str, func, *args, **kwargs):
        '''
        A utility method to encapsulate sending messages at the specified level
        
        :params: level -- the severity level of the statement
        :params: message -- the message to be logged
        '''
        
        logging_message = f"{func.co_name}::{LC.RunId}::{self._run_id}::{message}"
        self._stdout_logger.log(level, logging_message, *args, **kwargs)
        self._spark_logger.log(level, logging_message, *args, **kwargs)
        self._spark_logger_app_insights.log(level, logging_message, *args, **kwargs)
