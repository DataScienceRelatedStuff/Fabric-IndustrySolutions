from dataclasses import dataclass
from typing import Optional
from pyspark.sql.types import BinaryType, BooleanType, DataType, DateType, DecimalType, DoubleType, FloatType, IntegerType, LongType, StringType, TimestampType
from tests.utils.envcompile.model.common.models_base import FieldTypeEnum


_FIELD_TYPES = {
    FieldTypeEnum.integer: IntegerType,
    FieldTypeEnum.bigint: LongType,
    FieldTypeEnum.string: StringType,
    FieldTypeEnum.decimal: DecimalType,
    FieldTypeEnum.double: DoubleType,
    FieldTypeEnum.float: FloatType,
    FieldTypeEnum.timestamp: TimestampType,
    FieldTypeEnum.boolean: BooleanType,
    FieldTypeEnum.datetime: TimestampType,
    FieldTypeEnum.date: DateType,
    FieldTypeEnum.long: LongType,
    FieldTypeEnum.binary: BinaryType,
}


@dataclass
class FieldParsingExtraProps:
    precision: Optional[int]
    scale: Optional[int]


class CommonParsing:
    @staticmethod
    def parse_field_type(field_type: FieldTypeEnum, extra_props: FieldParsingExtraProps = None) -> DataType:
        try:
            if field_type == FieldTypeEnum.decimal:
                return CommonParsing._parse_decimal_field(extra_props=extra_props)
            return _FIELD_TYPES[field_type]()
        except KeyError:
                raise Exception(f"Unknown target field type: {field_type}. Is this a valid parquet type?")
            

    @staticmethod
    def _parse_decimal_field(extra_props: FieldParsingExtraProps = None) -> DateType:
        if (
            extra_props is not None
            and extra_props.precision is not None
            and extra_props.scale is not None
        ):
            return DecimalType(precision=extra_props.precision, scale=extra_props.scale)
        return DecimalType()
