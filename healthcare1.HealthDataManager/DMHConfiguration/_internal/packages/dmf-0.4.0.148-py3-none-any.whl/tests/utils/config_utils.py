import traceback
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
from typing import Union, List
from pyspark.sql import SparkSession
from dmf.model.data_feed_configuration import DataFeedConfiguration
from dmf.model.common.data_access_definition import DataSourceId
from dmf.model.source_configuration import SourceConfiguration
from dmf.utils.common import Common
from dmf.logging import Logger
from dmf.utils.global_constants import GlobalConstants
from tests.utils.constants import Constants
from tests.utils.envcompile.env_compiler import EnvCompiler


class ConfigUtils:
    @staticmethod
    def generate_dmf_config_from_transformation_spec(spark: SparkSession,
                                                     transformation_spec_file_location: Path,
                                                     env_config_file_path: Path,
                                                     source_tables_location: Path) -> DataFeedConfiguration:
        try:
            transformation_spec_content = ConfigUtils.compile_ts_from_path(spark,
                                                                          transformation_spec_file_location,
                                                                          env_config_file_path,
                                                                          source_tables_location)
            config = DataFeedConfiguration.from_str(transformation_spec_content)
        except Exception as e:
            Logger.error(f"an error accrued while parsing the transformation spec file.{e}")
            Logger.error(traceback.format_exc())
            raise
        
        return config

    @staticmethod
    def compile_ts_from_path(spark: SparkSession,
                             transformation_spec_file_location: Path,
                             env_config_file_path: Path,
                             source_tables_location: Path) -> str:
        try:
            transformation_spec_content = Common.read_configuration_file(transformation_spec_file_location)
            env_config_str = Common.read_configuration_file(env_config_file_path)
            
            env_config_str = env_config_str.replace("MOCK_SOURCE_LOCATION", str(source_tables_location))
            env_config_str = env_config_str.replace("MOCK_TARGET_LOCATION", str(Constants.SINK_TABLES_ROOT))
            env_config_str = env_config_str.replace("MOCK_SECONDARY_LAKE_LOCATION", spark.conf.get(GlobalConstants.SPARK_CONFIG_SECONDARY_LAKE_ROOT_VARIABLE))
            return EnvCompiler.compile(transformation_spec_content, env_config_str)
        except Exception as e:
            Logger.error(f"an error accrued while compiling the transformation spec file.{e}")
            Logger.error(traceback.format_exc())
            raise

    @staticmethod
    def reduce_config(source_ids: Union[DataSourceId, List[DataSourceId]],
                  target_ids: Union[DataSourceId, List[DataSourceId]],
                  orig_config: DataFeedConfiguration) -> DataFeedConfiguration:
        """reduce a given DataFeedConfiguration to have only given source_ids and target_ids. source_id and target_id can be
        both a single str or a list"""
        
        if type(source_ids) is not list:
            source_ids = [source_ids]
            
        if type(target_ids) is not list:
            target_ids = [target_ids]

        filtered_source_to_target_configs = defaultdict(list)
        for source_config in orig_config.source_configurations:
            if source_config.data_access_definition.data_source_id in source_ids:
                if source_config.create_view_only:
                    filtered_source_to_target_configs[source_config] = []
                else:
                    for target_config in source_config.target_configurations:
                        if target_config.data_access_definition.data_source_id in target_ids:
                            filtered_source_to_target_configs[source_config].append(target_config)
                            
        filtered_source_configs = []
        for source_config, target_configs in filtered_source_to_target_configs.items():
            source_config: SourceConfiguration
            filtered_source_configs.append(SourceConfiguration(
                source_id=source_config.source_id,
                create_view_only=source_config.create_view_only,
                view_alias=source_config.view_alias,
                feed_id=source_config.feed_id,
                data_access_definition=deepcopy(source_config.data_access_definition),
                table_schema=deepcopy(source_config.table_schema),
                target_configurations=frozenset(deepcopy(target_config) for target_config in target_configs),
                mapping_definitions=deepcopy(source_config.mapping_definitions),
                source_to_reference_mappings=deepcopy(source_config.source_to_reference_mappings),
                source_table_column_name=source_config.source_table_column_name
            ))
        return DataFeedConfiguration(
            feed_id=orig_config.feed_id,
            source_configurations=frozenset(filtered_source_configs),
            reference_values_configuration=orig_config.reference_values_configuration
        )

