import os.path

import pytest

from rmt.contract.configuration.internal.model_internal import ModelInternal
from rmt.contract.configuration.internal.rmt_spec_reader import RMTSpecReader
from tests.common.test_case_common import TestCaseCommon
from tests.common.tester_file_system_client import TesterFileSystemClient
from tests.conftest import TESTS_ROOT_DIR

RMT_SPEC_DIR = os.path.join(TESTS_ROOT_DIR, "data", "rmt_spec")


class TestRMTSpecReader:
    @staticmethod
    def run_rmt_spec_reader(file_path: str, test_name="test") -> ModelInternal:
        return RMTSpecReader.read(file_path, TesterFileSystemClient(test_name))

    def test_read_valid_file(self, logger):
        test_name = "test_read_valid_file"
        rmt_spec = TestRMTSpecReader.run_rmt_spec_reader(os.path.join(RMT_SPEC_DIR, "rmt_spec.json"), test_name)
        assert "Gender" in rmt_spec.reference_tables
        assert rmt_spec.secondary_lake_location == TestCaseCommon.mapping_output_path_by_test_name(test_name)

    def test_missing_file(self, logger):
        with pytest.raises(Exception):
            test_name = "test_missing_file"
            TestRMTSpecReader.run_rmt_spec_reader(os.path.join(RMT_SPEC_DIR, "not_existing_file.json"), test_name)
