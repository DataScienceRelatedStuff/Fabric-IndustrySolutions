from enum import Enum


class EntityTypeEnum(str, Enum):
    SOURCE = 'source'
    TARGET = 'target'
