import pytest

from dmf.transformations.processor.conditions.conditioned_ids import ConditionedNullIdsFilter


class TestConditionedIds:
    def test_raises_value_error_when_column_not_in_dataframe(self, spark):
        df = spark.createDataFrame([("a", "b")], ["column1", "column2"])
        with pytest.raises(ValueError, match="Column 'column3' not in source_df"):
            ConditionedNullIdsFilter.filter(df, ["column3"])

    def test_filtering_rows_with_null_columns_from_dataframe(self, spark):
        df = spark.createDataFrame(
            [
                ("a", "b"),
                ("a", None),
                (None, "b"),
                (None, None)
            ],
            ["column1", "column2"])
        assert df.count() == 4
        filtered_df = ConditionedNullIdsFilter.filter(df, ["column2", "column1"])
        assert filtered_df.count() == 1

    def test_with_empty_list_of_columns_returns_same_data(self, spark):
        df = spark.createDataFrame(
            [
                ("a", "b"),
                ("a", None),
                (None, "b"),
                (None, None)
            ],
            ["column1", "column2"])
        assert df.count() == 4
        filtered_df = ConditionedNullIdsFilter.filter(df, [])
        assert filtered_df.count() == 4
