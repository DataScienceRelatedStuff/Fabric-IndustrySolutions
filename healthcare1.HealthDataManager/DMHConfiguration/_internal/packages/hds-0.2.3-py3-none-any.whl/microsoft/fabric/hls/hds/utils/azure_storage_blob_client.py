from threading import Thread
from azure.storage.blob import BlobServiceClient, BlobLeaseClient, BlobClient
from azure.identity import ManagedIdentityCredential
from microsoft.fabric.hls.hds.utils.spoof_token import SpoofToken
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
import time

class AzureStorageBlobClient():
    def __init__(self,
                 account_url: str,
                 container_name: str,
                 blob_name: str,
                 is_leased_client: bool = True):
        """Initialize blob client
        Args:
            account_url (str): The url of the storage account
            container_name (str): Container name
            blob_name (str): Blob name
            is_leased_client (bool, optional): Whether to take a lease on the blob clint to block others from making changes on the blob client Defaults to True.
        """        
        self.account_url = account_url
        self.container_name = container_name
        self.blob_name = blob_name
        self.is_leased_client = is_leased_client
        self.is_blob_deleted = False
        
    def __enter__(self):
        
        """Invoked on entry to the body of the with statement. Instantiate a blob client with a lease
        """
        credential_spoof = ManagedIdentityCredential()
        
        # monkey-patch the contents of the private `_credential`
        credential_spoof._credential = SpoofToken(GlobalConstants.STORAGE_AUDIENCE_TYPE) 
        blob_service_client = BlobServiceClient(
            account_url= self.account_url,
            credential= credential_spoof)
        
        # Instantiate a BlobClient
        self.blob_client = blob_service_client.get_blob_client(container=self.container_name, blob=self.blob_name)
        
        if(self.is_leased_client):
            self.lease_client = self.acquire_blob_lease()
        
            # Create a deamon thread to keep renewing the lease
            daemon = Thread(target=self.renew_lease, daemon=True)
            daemon.start()
            
        return self

    def acquire_blob_lease(self) -> BlobLeaseClient:

        """Acquire a lease on the blob

        Returns: 
           BlobLeaseCLient : the leased client on the blob
        """
        return self.blob_client.acquire_lease(
            GlobalConstants.LEASE_EXPIRATION_IN_SECONDS
        )
    
    def download_blob_contents(self) -> str:
        """_summary_

        Returns:
            str: _description_
        """
        downloader = self.blob_client.download_blob(max_concurrency=1, encoding='UTF-8')
        return downloader.readall()
    
    def upload_blob_contents(self, contents: str, overwrite_blob: bool = True): 
        """Upload Blob Contents

        Args:
            contents (str): _description_
        """
        if(self.is_leased_client):
            self.blob_client.upload_blob(contents, lease=self.lease_client, overwrite=overwrite_blob)
        else:
            self.blob_client.upload_blob(contents, overwrite=overwrite_blob)
        
    def delete_blob_snapshots(self):
        self.blob_client.delete_blob(delete_snapshots="include", lease=self.lease_client)
        self.is_blob_deleted = True
        
    def renew_lease(self):
        
        """Renew the lease
        """
        while True:
            time.sleep(GlobalConstants.LEASE_RENEWAL_IN_SECONDS)
            self.lease_client.renew()

    def __exit__(self, *args):
        """Invoked on exit from the body of the with statement. Relase the lease on the client
        """
        if self.is_leased_client and not self.is_blob_deleted:
            self.lease_client.release()