import pytest
from tests.dmf.workflow.tests_e2e.fhir_to_omop_e2e_tests_helper import FhirToOmopE2ETestsHelper
from pyspark.sql.functions import lit, col

from tests.utils.constants import Constants

source_table = "Observation"
target_table = "observation"
day_zero_record_pk = "f9dc3abed2a5c7c9999c104edbecdae85fdcbd1d"
day_one_record_pk = "fcdba1790e766e15e1e1ea06e9592ac7e52ef048"
source_update_col = "code_coding_code"
target_update_col = "observation_source_value"
source_pk_col = "id"


class TestE2EDayOneTestsForObservation:
    
    @pytest.mark.long
    def test_e2e_fhir_omop_observation_day_1_new_addition_scenario(self, spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path):
        # Arrange.
        test_name = "observation_day_1_new_addition_scenario"
        with FhirToOmopE2ETestsHelper(spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path, source_table, target_table, test_name, source_pk_col) as helper:
            helper.reduce_transformation_spec(test_name, sources=[source_table])

            day_0_df = helper.generate_day_zero_df([day_zero_record_pk])
            day_1_df = helper.generate_day_one_df([day_one_record_pk])

            # Act.
            target_df = helper.simulate_day_zero_and_one_transactions(
                day_0_df=day_0_df,
                day_1_df=day_1_df,
                test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT)

            # Assert.
            assert target_df.count() == 2, "Target should have two records, one from day 0 and another from day 1"

    # @pytest.mark.long
    def test_e2e_fhir_omop_observation_day_1_update_old_data_scenario(self, spark,
                                                                      fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path):
        # Arrange.
        test_name = "observation_day_1_update_old_data_scenario"
        with FhirToOmopE2ETestsHelper(spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path, source_table, target_table, test_name, source_pk_col) as helper:
            helper.reduce_transformation_spec(test_name, sources=[source_table])

            day_0_df = helper.generate_day_zero_df([day_zero_record_pk])
            day_1_df = helper.generate_day_one_df([day_zero_record_pk]).withColumn(source_update_col, lit("new_code_coding_code"))

            # Act.
            target_df = helper.simulate_day_zero_and_one_transactions(
                day_0_df=day_0_df,
                day_1_df=day_1_df,
                test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT)

            # Assert.
            assert target_df.count() == 1, "Target should have a single record from day 0, which gets updated in place on day 1"
            assert target_df.first()[target_update_col] == day_1_df.first()[source_update_col],\
                "Target's single record should have the updated value"

    @pytest.mark.long
    def test_e2e_fhir_omop_observation_day_1_add_and_update_old_data_scenario(self, spark,
                                                                              fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path):
        # Arrange.
        test_name = "observation_day_1_add_and_update_old_data_scenario"
        with FhirToOmopE2ETestsHelper(spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path, source_table, target_table, test_name, source_pk_col) as helper:
            helper.reduce_transformation_spec(test_name, sources=[source_table])

            day_0_df = helper.generate_day_zero_df([day_zero_record_pk])

            day_1_updated_df = helper.generate_day_one_df([day_zero_record_pk]).withColumn(source_update_col, lit("new_code_coding_code"))
            day_1_new_df = helper.generate_day_one_df([day_one_record_pk])

            day_1_df = day_1_new_df.union(day_1_updated_df)

            # Act.
            target_df = helper.simulate_day_zero_and_one_transactions(
                day_0_df=day_0_df,
                day_1_df=day_1_df,
                test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT)

            # Assert.
            assert target_df.count() == 2, "Target should have a record from day 0, and another from day 1"
            assert target_df.filter(col(target_update_col) == day_1_updated_df.first()[source_update_col]).count() == 1,\
                "Target should have one of the records with up to date value coming from day 1"
