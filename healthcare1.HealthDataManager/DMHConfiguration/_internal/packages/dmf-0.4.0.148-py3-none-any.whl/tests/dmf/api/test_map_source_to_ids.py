import uuid

import pytest
from pyspark.sql.functions import lit, current_timestamp
from pyspark.sql.types import StructType, StructField, StringType

from dmf.api.keys import map_source_to_ids
from dmf.transformations.reader.reader_factory import ReaderFactory
from dmf.workflow.dmf_application import DMFApplication
from tests.utils.constants import Constants


class TestIdsMappingApi:
    source_internal_id_column_name = "source_internal_id"
    source_external_id_column_name = "source_external_id"
    schema = StructType([StructField(source_internal_id_column_name, StringType(), True),
                         StructField(source_external_id_column_name, StringType(), True)])
    mapped_id_column = "mapped_id"

    def test_ids_mapping_same_feed(self, spark):
        ids_table_name = "ids_table"
        source_system_id = "source_system"

        data1_source1 = [("aa1", "bb1"), ("aa2", "bb2"), ("aa3", "bb3")]
        data2_source1 = [("aa4", "bb4"), ("aa5", "bb5"), ("aa6", "bb6")]

        df1 = spark.createDataFrame(data1_source1, self.schema)
        df2 = spark.createDataFrame(data2_source1, self.schema)

        df1_enriched = map_source_to_ids(ids_table_name,
                                         source_system_id,
                                         df1,
                                         self.source_internal_id_column_name,
                                         self.source_external_id_column_name,
                                         self.mapped_id_column,
                                         Constants.SINK_TABLES_ROOT)

        df1_mapped_columns = df1_enriched.filter(
            f"{self.mapped_id_column} is not null and feed_id = '{source_system_id}'").count()

        df2_enriched = map_source_to_ids(ids_table_name,
                                         source_system_id,
                                         df2,
                                         self.source_internal_id_column_name,
                                         self.source_external_id_column_name,
                                         self.mapped_id_column,
                                         Constants.SINK_TABLES_ROOT)

        df2_mapped_columns = df2_enriched.filter(
            f"{self.mapped_id_column} is not null and feed_id = '{source_system_id}'").count()

        assert df1_mapped_columns + df2_mapped_columns == len(data1_source1) + len(data2_source1)

    def test_ids_mapping_different_feeds(self, spark):
        ids_table_name = "ids_table"
        feed1 = "source_system_1"
        feed2 = "source_system_2"

        data1 = [("aa1", "bb1"), ("aa2", "bb2"), ("aa3", "bb3")]
        data2 = [("aa4", "bb4"), ("aa5", "bb5"), ("aa6", "bb6")]

        df1 = spark.createDataFrame(data1, self.schema)
        df2 = spark.createDataFrame(data2, self.schema)

        df1_enriched = map_source_to_ids(ids_table_name,
                                         feed1,
                                         df1,
                                         self.source_internal_id_column_name,
                                         self.source_external_id_column_name,
                                         self.mapped_id_column,
                                         Constants.SINK_TABLES_ROOT)

        df1_mapped_columns = df1_enriched.filter(f"{self.mapped_id_column} is not null and feed_id = '{feed1}'").count()
        assert df1_mapped_columns == len(data1)

        df2_enriched = map_source_to_ids(ids_table_name,
                                         feed2,
                                         df2,
                                         self.source_internal_id_column_name,
                                         self.source_external_id_column_name,
                                         self.mapped_id_column,
                                         Constants.SINK_TABLES_ROOT)

        df2_mapped_columns = df2_enriched.filter(f"{self.mapped_id_column} is not null and feed_id = '{feed2}'").count()
        assert df2_mapped_columns == len(data2)

    def test_null_ids_are_not_mapped(self, spark):
        ids_table_name = "ids_table"
        feed_id = "source_system_1"

        data = [("aa1", "bb1"), (None, None), ("aa3", "bb3")]

        df = spark.createDataFrame(data, self.schema)

        df_enriched = map_source_to_ids(ids_table_name,
                                        feed_id,
                                        df,
                                        self.source_internal_id_column_name,
                                        self.source_external_id_column_name,
                                        self.mapped_id_column,
                                        Constants.SINK_TABLES_ROOT)

        df_mapped_columns = df_enriched.filter(f"{self.mapped_id_column} is not null").count()
        assert df_mapped_columns == sum(1 for x in data if x[0] is not None)
        assert df_enriched.count() == len(data)

    @pytest.mark.long
    def test_dmf_preserves_unchanged_value_in_added_column_of_target_table_without_running_cc_after_table_modification \
                    (self, spark, sus_dataverse_temp_db_builder,
                     sus_config_temp_db):
        """
        # This test is to check that the dmf preserves the unchanged value in the added column of the target table
        # without running cc after table modification.
        # The test is implemented as follows:
        # 1. Run DMF as "day 0"
        # 2. Modify the target table by adding a new column
        # 3. Populate the new column with some values
        # 4. Run DMF as "day 1"
        # 5. Check that the values in the new column are preserved
        """

        # Run DMF as "day 0"
        source_config_table_name = "msdyn_facility_updated"
        source_table_name = "msdyn_facility"
        target_table_name = "Facility"

        DMFApplication._start(sus_config_temp_db, spark)
        for source_config in sus_config_temp_db.source_configurations:
            for target_config in source_config.target_configurations:
                if target_config.target_id == target_table_name:
                    data_access_definition = target_config.data_access_definition

        assert data_access_definition is not None, "Target table was not found in the target configurations"
        reader = ReaderFactory.get_instance(data_access_definition)
        df = reader.read(spark)

        # Modify the target table by adding a new column
        added_column_name = uuid.uuid4().hex
        added_column_value = "1"

        # Populate the new column with some values
        df = df.select("*", lit(added_column_value).cast(StringType().simpleString()).
                       alias(added_column_name))

        # Save facility_df to the target table
        df. \
            write.format("delta") \
            .option("overwriteSchema", "true") \
            .mode("overwrite").save(data_access_definition.data_source_owner_id)

        # Verify that modified table was saved correctly
        reader = ReaderFactory.get_instance(data_access_definition)
        df = reader.read(spark)
        assert added_column_name in df.columns
        assert df.select(added_column_name).distinct().collect()[0][0] == added_column_value

        # Run DMF as "day 1"
        source_column_name_to_update = "msdyn_name"
        source_column_value_to_update = uuid.uuid4().hex
        target_field_name = "FacilityName"
        for source_config in sus_config_temp_db.source_configurations:
            if source_config.source_id == source_config_table_name:
                source_modified_date_column_name = source_config.table_schema.source_modified_date_column_name

        # Modify the source table to simulate Day 1
        source_table_df = spark.sql(f"select * from {sus_dataverse_temp_db_builder.db}.{source_table_name}")
        source_table_df = source_table_df. \
            drop(source_modified_date_column_name, source_column_name_to_update). \
            select("*", lit(source_column_value_to_update).cast(StringType().simpleString()).
                   alias(source_column_name_to_update),
                   lit(current_timestamp()).alias(source_modified_date_column_name))

        source_table_df.write.format("csv").mode("append").saveAsTable(source_table_name)

        # Run DMF as "day 1"
        DMFApplication._start(sus_config_temp_db, spark)

        # Verify that the new value was saved correctly
        reader = ReaderFactory.get_instance(data_access_definition)
        df = reader.read(spark)
        assert added_column_name in df.columns
        assert df.select(added_column_name).distinct().collect()[0][0] == added_column_value
        assert df.select(target_field_name).distinct().collect()[0][0] == source_column_value_to_update
