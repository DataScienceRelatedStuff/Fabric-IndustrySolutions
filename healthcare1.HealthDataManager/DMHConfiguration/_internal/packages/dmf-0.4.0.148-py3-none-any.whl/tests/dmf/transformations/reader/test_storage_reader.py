import os
from typing import List

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

from dmf.model.common.data_access_definition import DataAccessDefinition
from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.transformations.reader.reader_factory import ReaderFactory
from dmf.transformations.reader.storage_reader import StorageReader


class TestStorageReader:

    def test_reading_multiple_formats(self, spark):
        data_formats = ["csv", "parquet", "delta"]
        schema = StructType([
            StructField("int_col", IntegerType(), False),
            StructField("str_col", StringType(), True),
            StructField("part_col", StringType(), False)
        ])

        data = [
            (1, "a", "part1"),
            (2, "b", "part1"),
            (1, "a", "part2"),
            (2, "b", "part2"),
        ]

        for data_format in data_formats:
            root_location = spark.conf.get("spark.sql.warehouse.dir")
            table_name = "my_table"
            location = os.path.join(root_location, "temp_ut", table_name, data_format)
            TestStorageReader._persist_data(spark, data, schema, data_format, location)
            data_access_def = DataAccessDefinition(data_source_id=table_name,
                                                   data_source_type=DataSourceTypeEnum.STORAGE,
                                                   data_source_owner_id=location,
                                                   data_format=data_format)

            reader = ReaderFactory.get_instance(data_access_definition=data_access_def)
            assert isinstance(reader, StorageReader)

            df = reader.read(spark)
            assert df.count() == 4
            assert df.select("part_col").distinct().count() == 2

    @staticmethod
    def _persist_data(spark: SparkSession,
                      data: List[tuple],
                      schema: StructType,
                      data_format: str,
                      location: str):
        df = spark.createDataFrame(data=data, schema=schema)

        df.write.partitionBy("part_col").format(data_format).save(location)
