from datetime import datetime
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType, StructField, StringType, LongType, Row, IntegerType, TimestampType
from dmf.transformations.model.transformation_types import PartitionConfig
from dmf.transformations.steps.partition_manager import PartitionManager


def test_add_partition_with_divider(spark: SparkSession):
    schema = StructType(
        [
            StructField("CustomerId", LongType(), True),
            StructField("col2", StringType(), True),
        ]
    )
    data = [
        (400000, "foo"),
        (100000, "bar"),
    ]
    partition_input_col = 'CustomerId'
    partition_col_name = 'prCustomerId'
    partition_config = PartitionConfig(
        partition_input_col, partition_col_name, "{0}/200000", IntegerType())
    df = _add_partition(spark, data, partition_config, schema)
    assert df.schema == StructType(
        [StructField(partition_input_col, LongType(), True),
         StructField("col2", StringType(), True),
         StructField(partition_col_name, IntegerType(), True)]
    )
    assert df.collect() == [Row(CustomerId=400000, col2='foo', prCustomerId=2),
                            Row(CustomerId=100000, col2='bar', prCustomerId=0)]


def test_add_partition_with_year_function(spark: SparkSession):
    schema = StructType(
        [
            StructField("Timestamp", TimestampType(), True),
            StructField("col2", StringType(), True),
        ]
    )
    first_dt = datetime(2022, 9, 5, 15, 24, 54, 48010)
    second_dt = datetime(2021, 9, 5, 15, 24, 54, 48010)
    data = [
        (first_dt, "foo"),
        (second_dt, "bar"),
    ]
    partition_input_col = 'Timestamp'
    partition_col_name = 'prYear'
    partition_config = PartitionConfig(
        partition_input_col, partition_col_name, "year({0})", IntegerType())
    df = _add_partition(spark, data, partition_config, schema)
    assert df.schema == StructType([StructField(partition_input_col, TimestampType(), True),
                                    StructField('col2', StringType(), True),
                                    StructField(partition_col_name, IntegerType(), True)])
    assert df.collect() == [
        Row(Timestamp=first_dt, col2='foo', prYear=2022),
        Row(Timestamp=second_dt, col2='bar', prYear=2021)]


def _add_partition(spark, data, partitioner_config, schema) -> DataFrame:
    return PartitionManager.add_partition(spark.createDataFrame(data, schema), [partitioner_config])


def test_distinct_partitions(spark: SparkSession):
    schema = StructType(
        [
            StructField("col1", StringType(), True),
            StructField("part1", LongType(), True),
            StructField("part2", LongType(), True),
        ]
    )
    data = [
        ("a", 17, 42),
        ("b", 17, 42),
        ("c", 17, 18),
        ("d", 1, 2),
    ]
    rows = PartitionManager._distinct_partitions(
        spark.createDataFrame(data, schema), ["part1", "part2"]).collect()
    assert rows == [Row(part1=17, part2=42),
                    Row(part1=17, part2=18),
                    Row(part1=1, part2=2)]


def test_filter_by_source_partitions(spark):

    partition1_field = StructField("part1", LongType(), True)
    partition2_field = StructField("part2", LongType(), True)

    source_schema = StructType(
        [
            StructField("data_source", StringType(), True),
            partition1_field,
            partition2_field,
        ]
    )
    source_data = [
        ("a", 1, 100),
        ("b", 1, 200),
        ("c", 2, 200),
        ("d", 3, 100)
    ]

    target_schema = StructType(
        [StructField('data_target', StringType(), True), partition1_field, partition2_field])

    target_data = (
        ['e', 1, 100],
        ['f', 1, 300],
        ['g', 2, 200],
        ['h', 3, 200]
    )
    source_df = spark.createDataFrame(source_data, source_schema)
    target_df = spark.createDataFrame(target_data, target_schema)
    rows = PartitionManager.filter_target_by_source_partitions(
        source_df, target_df, [partition1_field.name, partition2_field.name]).collect()
    assert rows == [Row(part1=1, part2=100, data_target='e'),
                    Row(part1=2, part2=200, data_target='g')]


def test_filter_by_source_partitions_no_partitions(spark):

    source_schema = StructType(
        [StructField("data_source", StringType(), True)])

    source_data = [
        ["a"],
        ["b"],
        ["c"],
        ["d"]
    ]

    target_schema = StructType(
        [StructField('data_target', StringType(), True)])

    target_data = [
        ["e"],
        ["f"],
        ["g"],
        ["h"]
    ]
    source_df = spark.createDataFrame(source_data, source_schema)
    target_df = spark.createDataFrame(target_data, target_schema)
    rows = PartitionManager.filter_target_by_source_partitions(
        source_df, target_df, []).collect()
    assert rows == [Row(data_target='e'),
                    Row(data_target='f'),
                    Row(data_target='g'),
                    Row(data_target='h')]
