from pathlib import Path
import uuid

import traceback
from mock import patch
import pytest

from dmf.last_processed_line_computer.last_processed_lines import LastProcessedLineCalculator
from dmf.transformations.writer.storage_writer import StorageWriter
from dmf.utils.global_constants import GlobalConstants
from project_root import PROJECT_ROOT_DIR
from tests.dmf.workflow.test_dmf_application_common import TestDMFApplicationCommon
from tests.utils.constants import Constants
from tests.utils.dmf_application_test_util import DMFApplicationTestUtil



class TestDMFApplicationFHIRtoOMOP:
    patient_query = "select Patient.*, Patient.id as p_id, Patient.meta_lastUpdated as p_meta_lastUpdated, PatientAddress.* from Patient       left join PatientAddress on Patient.id=PatientAddress.id"
    patient_table_name = "Patient"
    fhir_tables_under_test = [
        patient_table_name, patient_query, "PatientAddress", "PatientGeneralPractitioner"]
    fhir_source_parquet_root = Path(
        PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "parquet"

    @pytest.mark.long
    def test_e2e_day0_patient_table_source_and_target_on_storage(self,
                                                                 spark,
                                                                 mocker,
                                                                 fhir_omop_dmf_transformation_spec_path,
                                                                 fhir_omop_env_config_path):

        required_target_name = "person"

        target_table_location = Constants.SINK_TABLES_ROOT / "omop" / str(uuid.uuid4())

        spy_writer = mocker.spy(StorageWriter, "write")

        try:
            TestDMFApplicationCommon. \
                run_dmf_with_mocked_reduced_config(spark=spark,
                                                   source_tables=self.fhir_tables_under_test,
                                                   target_table=required_target_name,
                                                   transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path,
                                                   env_config_file_path=fhir_omop_env_config_path,
                                                   source_tables_location=self.fhir_source_parquet_root,
                                                   target_tables_location=target_table_location)

        except Exception:
            raise

        assert spy_writer.call_count == 1

        required_target_name = "person"
        target_df = spark.read.format("delta").load(str(target_table_location/ required_target_name))

        assert target_df.count() > 0

    @pytest.mark.long
    def test_e2e_day1_no_update_patient_table_source_and_target_on_storage(self,
                                                                           spark,
                                                                           mocker,
                                                                           fhir_omop_dmf_transformation_spec_path,
                                                                           fhir_omop_env_config_path):
        required_target_name = "person"


        target_table_location = Constants.SINK_TABLES_ROOT / \
                                "omop" / str(uuid.uuid4())

        spy_writer = mocker.spy(StorageWriter, "write")

        try:
            TestDMFApplicationCommon. \
                run_dmf_with_mocked_reduced_config(spark=spark,
                                                   source_tables=self.fhir_tables_under_test,
                                                   target_table=required_target_name,
                                                   transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path,
                                                   env_config_file_path=fhir_omop_env_config_path,
                                                   source_tables_location=self.fhir_source_parquet_root,
                                                   target_tables_location=target_table_location)

            TestDMFApplicationCommon. \
                run_dmf_with_mocked_reduced_config(spark=spark,
                                                   source_tables=self.fhir_tables_under_test,
                                                   target_table=required_target_name,
                                                   transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path,
                                                   env_config_file_path=fhir_omop_env_config_path,
                                                   source_tables_location=self.fhir_source_parquet_root,
                                                   target_tables_location=target_table_location)

        except Exception:
            traceback.print_exc()
            raise AssertionError("got Exception in DMFApplication")

        assert spy_writer.call_count == 1

        required_target_name = "person"
        target_df = spark.read.format("delta").load(str(target_table_location/ required_target_name))

        assert target_df.count() > 0

    @pytest.mark.long
    def test_all_hands_hc(self,
                          spark,
                          fhir_omop_dmf_transformation_spec_path,
                          fhir_omop_env_config_path):

        source_tables_location = Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "parquet"
        target_tables_location = Constants.SINK_TABLES_ROOT / "omop" / str(uuid.uuid4())

        DMFApplicationTestUtil.start_from_transformation_spec(
            spark=spark, transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path, env_config_file_path=fhir_omop_env_config_path,
            source_tables_location=source_tables_location, target_tables_location=target_tables_location)

        source_table_column_name = "SourceTable"
        location_df = spark.read.format("delta").load(str(target_tables_location / "location"))
        location_source_tables = location_df.select(source_table_column_name).distinct().collect()
        expected_source_table_ids = ['Patient_fhir', 'Organization_fhir']
        assert {row[source_table_column_name]
                for row in location_source_tables} == set(expected_source_table_ids)

        patient_last_processed = LastProcessedLineCalculator._compute_last_processed_line(
            expected_source_table_ids[0], location_df, source_table_column_name)
        organization_last_processed = LastProcessedLineCalculator._compute_last_processed_line(
            expected_source_table_ids[1], location_df, source_table_column_name)
        # this is specific to the data
        assert patient_last_processed == organization_last_processed

        person_df = spark.read.format("delta").load(str(target_tables_location / "person"))
        death_df = spark.read.format("delta").load(str(target_tables_location / "death"))
        patient_df = spark.read.format("delta").load(str(self.fhir_source_parquet_root / "Patient"))
        dead_patients = patient_df.filter("deceasedDateTime IS NOT NULL")
        person_mapping = spark.read.format('delta').load(str(Path(spark.conf.get("spark.sql.warehouse.dir")) / GlobalConstants.ID_MAPPING_PATH / "PERSON_ID_MAPPING"))
        assert patient_df.count() == person_mapping.count(), "person_mapping should have the same number of rows as patient"
        assert person_df.count() == patient_df.count(), "person should have the same number of rows as patient"
        assert death_df.count() == dead_patients.count(), "wrong number of death rows projected"

    @pytest.mark.long
    def test_all_hands_hc_no_update(self,
                                    spark,
                                    fhir_omop_dmf_transformation_spec_path,
                                    fhir_omop_env_config_path):

        source_tables_location = Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "parquet"
        target_tables_location = Constants.SINK_TABLES_ROOT / "omop" / str(uuid.uuid4())

        # first run
        DMFApplicationTestUtil.start_from_transformation_spec(spark=spark,
                                                              transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path, env_config_file_path=fhir_omop_env_config_path,
                                                              source_tables_location=source_tables_location, target_tables_location=target_tables_location)
        for output_table in ["location", "care_site", "person"]:
            output_table_path = target_tables_location / output_table
            df = spark.read.format("delta").load(str(output_table_path))
            count = df.count()
            print(f"{output_table}: {count}")
            assert count > 0
        # second run
        with patch.object(StorageWriter, 'write', return_value=None) as mock_write:
            DMFApplicationTestUtil. \
                start_from_transformation_spec(spark=spark, transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path,
                                               env_config_file_path=fhir_omop_env_config_path, source_tables_location=source_tables_location, target_tables_location=target_tables_location)

        mock_write.assert_not_called()
        for output_table in ["location", "care_site"]:
            output_table_path = target_tables_location / output_table
            df = spark.read.format("delta").load(str(output_table_path))
            assert df.count() > 0
