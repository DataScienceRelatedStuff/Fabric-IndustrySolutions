from azure.core.credentials import AccessToken
import time
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from notebookutils import mssparkutils

class SpoofToken:
    def __init__(self, 
                 audience_type: str):
        
        """Spoof AAD access token for a given audience using mssparkutils
        
        :param audience_type: Audience for the Azure AD token
        """
        self.audience_type = audience_type
        
    def get_token(self, *args, **kwargs) -> AccessToken:
        
        """Return AAD token for a given audience

        Returns:
            _type_: _description_
        """
        return AccessToken(
            token=mssparkutils.credentials.getToken(audience=self.audience_type),
            expires_on=int(time.time())+GlobalConstants.TOKEN_EXPIRATION_IN_SECONDS 
        )