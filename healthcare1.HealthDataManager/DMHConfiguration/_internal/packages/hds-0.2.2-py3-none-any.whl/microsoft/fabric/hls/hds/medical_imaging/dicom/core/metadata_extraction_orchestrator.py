# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class to orchestrate metadata extraction
"""

import os
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, from_json, concat, lit, regexp_extract
from datetime import datetime
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.metadata_extractor import extract_metadata
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import Utils as CommonUtils
from microsoft.fabric.hls.hds.utils.dataframe_utils import add_current_timestamp_column
from notebookutils import mssparkutils
from microsoft.fabric.hls.hds.medical_imaging.dicom.utils.utils import Utils

class MetadataExtractionOrchestrator:
    """
    Class used to orchestrate metadata extraction process
    """    
    
    def __init__(self, spark: SparkSession, dcm_files_root_folder: str, lakehouse_path: str, checkpoint_path: str):
        """
        Initialize MetadataExtractionOrchestrator instance
        
        Args:
            spark (SparkSession): spark session to run spark utlities
            dcm_files_root_folder (str): root folder path which contains all the date folders containing dcm files
            lakehouse_path (str): path where delta table(output) need to be stored
            checkpoint_path (str): path where checkpoint files for dicom metadata extraction will be stored
        """  
              
        self.spark = spark
        self._logger = LoggingHelper.get_imaging_metadata_extraction_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL)
        self.dcm_files_root_folder = dcm_files_root_folder
        self.lakehouse_path = lakehouse_path
        self.checkpoint_path = checkpoint_path
         
    def process(self, path: str):
        """
        This method is used to process dicom files present inside a given folder path 
        and save the metadata output into delta table.

        Args:
            path (str): folder path where dicom files are present
        """  
        
        dcm_files_path = os.path.join(self.dcm_files_root_folder, path)
        
        self._logger.info(LC.PROCESSING_STATE_INFO_MSG.format(
            state= C.STATE_STARTED, 
            process_name=C.METADATA_EXTRACTION_PROCESS_NAME, 
            timestamp=datetime.now(), 
            dcm_files_path=dcm_files_path))
        
        if not CommonUtils.path_exists(dcm_files_path):
            self._logger.error(LC.PATH_NOT_EXIST_ERR_MSG.format(
                process_name= C.METADATA_EXTRACTION_PROCESS_NAME,
                path=dcm_files_path))
            return
        
        df_stream = Utils.read_files_to_df_stream(self.spark, f'{self.dcm_files_root_folder}/**/**/**')
        query = (df_stream.writeStream.format("delta")
            .trigger(availableNow=True)
            .option("checkpointLocation", self.checkpoint_path)
            .foreachBatch(lambda df, epoch_id: self._process_dcm_files(dcm_files_path, df, C.FAILED_NUM_RETRIES))
            .start())
 
        query.awaitTermination()
        
        self._logger.info(LC.PROCESSING_STATE_INFO_MSG.format(
            state= C.STATE_COMPLETED, 
            process_name=C.METADATA_EXTRACTION_PROCESS_NAME, 
            timestamp=datetime.now(), 
            dcm_files_path=dcm_files_path))
      
    def _process_dcm_files(self, dcm_files_path: str, df:DataFrame, num_retries: int):
        
        """
        This method is used recursively to process dcm files until either 
        we exceed number of retries or do not have any failed files.

        Args:
            dcm_files_path (str): path where dcm files are located
            df (dataframe): contains dcm files content and file path
            num_retries (int): number of retries
        """   
           
        delta_table_path = os.path.join(self.lakehouse_path, C.METADATA_TABLE_NAME)
        if(num_retries < 0):
            #moving files for which processing failed to failed folder
            if df and df.count() > 0:
                try:
                    failed_files_path = os.path.join(dcm_files_path, C.FAILED_FILES_FOLDER)
                    mssparkutils.fs.mkdirs(failed_files_path)
                    for row in df.collect():
                        Utils.move_files(row.filepath, failed_files_path)
                except Exception as e:
                    self._logger.error(LC.FAILED_FILES_NOT_MOVED_ERR_MSG.format(
                        error_msg=str(e)
                    ))
                    raise
            return
        
        if df.count() > 0:
            self._logger.info(LC.RETRY_INFO_MSG.format(
                process_name=C.METADATA_EXTRACTION_PROCESS_NAME, 
                retry_attempt=abs(num_retries-C.FAILED_NUM_RETRIES)+1))
            
            df = df.withColumn(C.EXTRACTED_METADATA_ATTR_NAME, extract_metadata(col(C.DCM_FILE_CONTENT_ATTR_NAME))) 
            
            df_success = df.filter(col(f"{C.EXTRACTED_METADATA_ATTR_NAME}.{C.ERROR_ATTR_NAME}").isNull())
            df_success_with_tags_failure = df_success.filter(col(f"{C.EXTRACTED_METADATA_ATTR_NAME}.{C.FAILED_TAGS_ATTR_NAME}").isNotNull())
            for row in df_success_with_tags_failure.collect():
                self._logger.warning(LC.TAGS_EXTRACTION_FAILED_MSG.format(
                    dcm_file_name= os.path.basename(row.filepath),
                    failed_tags = row.metadataExtracted[C.FAILED_TAGS_ATTR_NAME]
                ))
            
            df_failed = df.filter(col(f"{C.EXTRACTED_METADATA_ATTR_NAME}.{C.ERROR_ATTR_NAME}").isNotNull())
            for row in df_failed.collect():
                self._logger.error(LC.PROCESSING_FAILED_ERR_MSG.format(
                        process_name= C.METADATA_EXTRACTION_PROCESS_NAME, 
                        dcm_file_name= os.path.basename(row.filepath), 
                        error_mssg=row.metadataExtracted[C.ERROR_ATTR_NAME]))
                
            self._logger.info(LC.PROCESSING_STATUS_INFO_MSG.format(
                total_dcm_files=df.count(),
                success_files_count=df_success.count(),
                success_with_warn_count=df_success_with_tags_failure.count(),
                failed_files_count=df_failed.count()
            ))
            
            if df_success.count() > 0:
                for tag_key in C.DEFAULT_TAGS_AS_COLUMN:
                    df_success = df_success.withColumn(tag_key.lower(), col(f'{C.EXTRACTED_METADATA_ATTR_NAME}.{tag_key.lower()}'))
                
                df_success = df_success.withColumn(f"{C.TAGS_JSON_COLUMN_NAME}_string", col(f"{C.EXTRACTED_METADATA_ATTR_NAME}.{C.TAGS_JSON_COLUMN_NAME}"))\
                    .withColumn(C.TAGS_JSON_COLUMN_NAME, from_json(col(f"{C.TAGS_JSON_COLUMN_NAME}_string"), C.METADATA_JSON_DICT_SCHEMA))\
                        .drop(C.EXTRACTED_METADATA_ATTR_NAME, C.DCM_FILE_CONTENT_ATTR_NAME)
            
                df_success = add_current_timestamp_column(df_success, GlobalConstants.DEFAULT_BRONZE_CREATED_DATE_COL)
            
                self._logger.info(LC.SAVE_DELTA_TABLE_TO_PATH_INFO_MSG.format(table_path=delta_table_path))
                df_success.write.format("delta").mode("append").save(delta_table_path)

            self._process_dcm_files(
                dcm_files_path,
                df_failed.drop(C.EXTRACTED_METADATA_ATTR_NAME),
                num_retries-1) 