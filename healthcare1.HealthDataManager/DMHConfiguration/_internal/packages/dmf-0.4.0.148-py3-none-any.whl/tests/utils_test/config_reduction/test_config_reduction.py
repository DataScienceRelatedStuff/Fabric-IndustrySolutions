# import json
# from pathlib import Path
# import tempfile

# from project_root import PROJECT_ROOT_DIR
# from tests.utils.config_reduction.config_reduction import _reduce



# def test_sources_reduction():
#     config = {
#         "source_configurations": [
#             {
#                 "source_id": "Patient"
#             },
#             {
#                 "source_id": "Encounter"
#             },
#             {
#                 "source_id": "Observation"
#             },
#         ]
#     }
#     result = _reduce(config, ["Encounter", "Observation"], [], {}, {})
#     assert result == {
#         "source_configurations": [
#             {
#                 "source_id": "Encounter"
#             },
#             {
#                 "source_id": "Observation"
#             },
#         ]
#     }


# def test_sources_fields_reduction():
#     contract = {
#         "source_configurations": [
#             {
#                 "source_id": "Patient",
#                 "target_configurations": [
#                     {
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "p_id",
#                             }
                            
#                         ]
#                     },
#                 ]
#             },
#             {
#                 "source_id": "Encounter",
#                 "target_configurations": [
#                     {
#                          "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "birthDateYear",
#                             }
                            
#                         ]
#                     },
#                     {
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "p_id",
#                             }
                            
#                         ]
#                     },
#                 ]
#             },
#             {
#                 "source_id": "Observation",
#                 "target_configurations": [
#                     {
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "o_id",
#                             },
#                             {
#                                 "original_source_field_name": "subject_reference_id",
#                             }
#                         ]
#                     }
#                 ]
#             },
#         ]
#     }
#     result = _reduce(
#         contract,
#         [],
#         [],
#         {"Patient": ["p_id"], "Encounter": ["p_id"], "Observation": ["subject_reference_id"]},
#         {})
#     assert result == {
#         "source_configurations": [
#             {
#                 "source_id": "Patient",
#                 "target_configurations": [
#                     {
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "p_id",
#                             }
                            
#                         ]
#                     },
#                 ]
#             },
#             {
#                 "source_id": "Encounter",
#                 "target_configurations": [
#                     {
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "p_id",
#                             }
                            
#                         ]
#                     },
#                 ]
#             },
#             {
#                 "source_id": "Observation",
#                 "target_configurations": [
#                     {
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "subject_reference_id",
#                             }
#                         ]
#                     }
#                 ]
#             },
#         ]
#     }


# def test_target_fields_reduction():
#     contract = {
#         "source_configurations": [
#             {
#                 "source_id": "Patient",
#                 "target_configurations": [
#                     {
#                         "data_access_definition":
#                             {
#                                 "data_source_id": "person",
#                             }
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "person_id",
#                             },
#                             {
#                                 "original_source_field_name": "person_source_value",
#                             },    
                            
#                         ]
#                     }
#                 ]
#             },
#             {
#                 "source_id": "Encounter",
                
#                 "target_configurations": [
#                     {
#                          "data_access_definition":
#                             {
#                                 "data_source_id": "visit_occurrence",
#                             }
#                          "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "visit_occurrence_id",
#                             }
                            
#                         ]
#                     },
#                     {
#                         "data_access_definition":
#                         {
#                             "data_source_id": "visit_",
#                         }
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "visit_id",
#                             }
                            
#                         ]
#                     },
#                 ]
#             },
#             {
#                 "source_id": "Observation",
#                 "target_configurations": [
#                     {
#                         "data_access_definition":
#                             {
#                                 "data_source_id": "person",
#                             }
#                         "target_columns_transformations":[
#                             {
#                                 "original_source_field_name": "o_id",
#                                 "target_field_name": "FacilityName",
#                             },
#                             {
#                                 "original_source_field_name": "subject_reference_id",
#                                 "target_field_name": "FacilityName",
#                             }
#                         ]
#                     }
#                 ]
#             },
#         ]
#     }
   
    
#     result = _reduce(
#         adaptor,
#         [],
#         [],
#         {},
#         {"Observation":
#              {"subject_reference_id": [("person", "person_id")]},
#          "Patient":
#              {"p_id": [("person", "person_source_value")]}
#          })
#     assert result == {
#         "sourceTables": [
#             {
#                 "tableName": "Patient",
#                 "sourceFields": [
#                     {
#                         "fieldName": "p_id",
#                         "targetFields": {
#                             "fields": [
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_source_value"
#                                 }
#                             ]
#                         }
#                     },
#                 ]
#             },
#             {
#                 "tableName": "Encounter",
#                 "sourceFields": [
#                     {
#                         "fieldName": "e_id",
#                         "targetFields": {},
#                         "fields": [
#                             {
#                                 "tableName": "visit_occurrence",
#                                 "fieldName": "visit_occurrence_id"
#                             },
#                             {
#                                 "tableName": "visit_",
#                                 "fieldName": "visit_id"
#                             }
#                         ]
#                     },
#                     {
#                         "fieldName": "birthDateYear"
#                     }
#                 ]
#             },
#             {
#                 "tableName": "Observation",
#                 "sourceFields": [
#                     {
#                         "fieldName": "o_id"
#                     },
#                     {
#                         "fieldName": "subject_reference_id",
#                         "targetFields": {
#                             "fields": [
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_id"
#                                 }
#                             ]
#                         }
#                     }
#                 ]
#             },
#         ]
#     }


# def test_reduction_combination():
#     adaptor = {
#         "sourceTables": [
#             {
#                 "tableName": "Patient",
#                 "sourceFields": [
#                     {
#                         "fieldName": "p_id",
#                         "targetFields": {
#                             "fields": [
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_id"
#                                 },
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_source_value"
#                                 }
#                             ]
#                         }
#                     },
#                 ]
#             },
#             {
#                 "tableName": "Encounter",
#                 "sourceFields": [
#                     {
#                         "fieldName": "e_id",
#                         "targetFields": {},
#                         "fields": [
#                             {
#                                 "tableName": "visit_occurrence",
#                                 "fieldName": "visit_occurrence_id"
#                             },
#                             {
#                                 "tableName": "visit_",
#                                 "fieldName": "visit_id"
#                             }
#                         ]
#                     },
#                     {
#                         "fieldName": "birthDateYear"
#                     }
#                 ]
#             },
#             {
#                 "tableName": "Observation",
#                 "sourceFields": [
#                     {
#                         "fieldName": "o_id"
#                     },
#                     {
#                         "fieldName": "subject_reference_id",
#                         "targetFields": {
#                             "fields": [
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_id"
#                                 },
#                                 {
#                                     "tableName": "not_important",
#                                     "fieldName": "not_important"
#                                 }
#                             ]
#                         }
#                     }
#                 ]
#             },
#         ]
#     }
#     result = _reduce(
#         adaptor,
#         ["Observation", "Patient"],
#         [],
#         {"Patient": ["p_id"]},
#         {"Observation":
#              {"subject_reference_id": [("person", "person_id")]},
#          "Patient":
#              {"p_id": [("person", "person_source_value")]}
#          })
#     assert result == {
#         "sourceTables": [
#             {
#                 "tableName": "Patient",
#                 "sourceFields": [
#                     {
#                         "fieldName": "p_id",
#                         "targetFields": {
#                             "fields": [
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_source_value"
#                                 }
#                             ]
#                         }
#                     }
#                 ]
#             },
#             {
#                 "tableName": "Observation",
#                 "sourceFields": [
#                     {
#                         "fieldName": "o_id"
#                     },
#                     {
#                         "fieldName": "subject_reference_id",
#                         "targetFields": {
#                             "fields": [
#                                 {
#                                     "tableName": "person",
#                                     "fieldName": "person_id"
#                                 }
#                             ]
#                         }
#                     }
#                 ]
#             },
#         ]
#     }


# def test_real_file():
#     with tempfile.NamedTemporaryFile() as f:
#         test_data_dir = Path(PROJECT_ROOT_DIR) / "tests" / "adaptor_reduction" / "test_data"
#         reduce_contract(json_path=test_data_dir / "adaptor.json",
#                        new_path=Path(f.name),
#                        sources=["Patient", "Encounter"],
#                        query_tables=["Patient", "PatientAddress", "Encounter", "EncounterParticipant"],
#                        source_fields_per_source={"Patient": ["p_id", "birthDate"], "Encounter": ["e_id"]},
#                        target_fields_per_source_field={
#                            "Patient": {"p_id": [("person", "person_source_value")]},
#                            "Encounter": {"e_id": [("visit_occurrence", "visit_occurrence_id")]}}
#                        )
#         with open(f.name) as f:
#             reduced_adaptor = json.load(f)
#         with open(test_data_dir / "reduced_adaptor.json") as f:
#             expected_reduced_adaptor = json.load(f)
#         assert reduced_adaptor == expected_reduced_adaptor
