import os

from pyspark.sql.types import StructType, StructField, StringType

from dmf.api.reference_data import map_source_to_reference_values
from dmf.utils.global_constants import GlobalConstants
from tests.utils.constants import Constants


class TestReferenceMappingApi:

    def test_default_value_is_set_and_ref_value_mapped(self, spark, reference_mapping_data_sus):
        source_column_name = "ref_value_column"
        src_schema = StructType([
            StructField("data_column", StringType(), False),
            StructField(source_column_name, StringType(), True)
        ])

        mapping_df = spark. \
            read. \
            format("delta"). \
            load(os.path.join(str(Constants.SPARK_WAREHOUSE_LOCATION),
                              GlobalConstants.REFERENCE_MAPPING_PATH)). \
            filter("source_domain = 'SUS' and target_table = 'FacilityType' and target_field = 'FacilityTypeId'")

        real_source_reference_value = mapping_df.select("source_value").take(1)[0][0]

        src_data = [("data1", None), ("data2", real_source_reference_value), ("data3", "ref3")]
        src_df = spark.createDataFrame(src_data, src_schema)

        required_mapped_column_name = "mapped_column"
        default_ref_value = -999

        ref_df = map_source_to_reference_values(src_df,
                                                "SUS",
                                                default_ref_value,
                                                source_column_name,
                                                "FacilityType",
                                                "FacilityTypeId",
                                                required_mapped_column_name,
                                                str(Constants.SPARK_WAREHOUSE_LOCATION))

        assert required_mapped_column_name in ref_df.columns
        assert source_column_name in ref_df.columns
        mapped_ref_df = ref_df.filter(f"{required_mapped_column_name} != {default_ref_value}")
        assert mapped_ref_df.count() == 1

        # Check that mapped value is really from the mapping table
        joined_df = mapped_ref_df.join(mapping_df,
                                       mapped_ref_df[required_mapped_column_name] == mapping_df["target_value"],
                                       how='inner')

        assert joined_df.count() == 1
