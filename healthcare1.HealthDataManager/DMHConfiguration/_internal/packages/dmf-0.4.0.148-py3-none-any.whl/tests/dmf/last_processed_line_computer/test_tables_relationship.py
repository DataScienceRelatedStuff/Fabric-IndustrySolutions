from collections import defaultdict

import pytest


@pytest.mark.skip("the test seems to be flaky")
def test_compute_table_relations(config):
    data_tables = defaultdict(set)
    for source_config in config.source_configurations:
        for target_config in source_config.target_configurations:
            data_tables[source_config.data_access_definition.data_source_id].\
                add(target_config.data_access_definition.data_source_id)
    assert dict(data_tables) == {'contact': {'CustomerMaritalStatus',
                                             'Customer',
                                             'CustomerContactPurpose',
                                             'CustomerStatus',
                                             'CustomerEducation',
                                             'CustomerEmployment',
                                             'CustomerFinancialProfile',
                                             'CustomerTelephoneNumber',
                                             'CustomerCharacteristic',
                                             # 'CustomerLocation', # FIXME disabled in dmfAdaptor
                                             'IndividualCustomer',
                                             'CustomerEmail',
                                             # 'Branch',# FIXME disabled in dmfAdaptor
                                             'Location'},
                                 'msfsi_bank': {'Channel',
                                                'FinancialInstitution',
                                                'Location'},
                                 'msfsi_branch': {'Branch',
                                                  'Channel',
                                                  'FinancialInstitution',
                                                  'Location'},
                                 'msfsi_group': {'Household'},
                                 'msfsi_groupmember': {'Customer',
                                                       'Household',
                                                       'HouseholdMember',
                                                       'HouseholdMemberRole'},
                                 'msfsi_lifemoment': {'CustomerEvent',
                                                      'Customer'},
                                 'msfsi_groupfinancialholding': {'Household',
                                                                 'CustomerAccount'},
                                 'msfsi_relationship': {'Customer',
                                                        'RelatedCustomer'}
                                 }
