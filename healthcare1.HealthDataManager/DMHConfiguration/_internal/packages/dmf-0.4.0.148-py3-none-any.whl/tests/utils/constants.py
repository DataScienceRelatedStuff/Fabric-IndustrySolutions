import os.path
from pathlib import Path

from project_root import PROJECT_ROOT_DIR


class Constants:
    SINK_TABLES_ROOT = Path(PROJECT_ROOT_DIR) / "sink.db"
    MAPPING_TABLES_LOCATION = SINK_TABLES_ROOT / "keys"
    SPARK_WAREHOUSE_LOCATION = Path(PROJECT_ROOT_DIR) / "spark-warehouse"
    FHIR_TABLES_LOCATION = Path(PROJECT_ROOT_DIR) / "tests/data/db/fhir/parquet"
    GENERATED_TRANSFORMATION_SPECS_ROOT = (Path(PROJECT_ROOT_DIR) /
                                           "tests/dmf/workflow/tests_e2e/generated_transformation_specs")
