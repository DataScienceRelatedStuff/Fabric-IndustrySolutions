from typing import List, Optional

from dmf.model.common.data_access_definition import DataAccessDefinition
from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.model.source_configuration import SourceConfiguration
from dmf.model.target_configuration.target_configuration import TargetConfiguration
from dmf.model.target_configuration.target_transformation import ColumnTransformation
from dmf.model.target_configuration.target_table_schema import TargetTableSchema, TableColumn
from pyspark.sql.types import StringType, StructField, StructType
from pyspark.sql import DataFrame

from dmf.transformations.processor.field_values_source_enricher import FieldValuesSourceEnricher
from dmf.model.target_configuration.target_transformation import ColumnTransformation


class TestFieldValuesSourceEnricher:
    key_name = "id"
    column_1 = "column_1"
    column_2 = "column_2"
    column_3 = "column_3"
    source_schema = StructType([
        StructField(key_name, StringType(), False),
        StructField(column_1, StringType(), True),
        StructField(column_2, StringType(), True),
        StructField(column_3, StringType(), True),
    ])
    source_data = [
        {key_name: "id1", column_1: "a", column_2: "b", column_3: "c"},
        {key_name: "id2", column_1: "a", column_2: "a", column_3: "a"},
        {key_name: "id3", column_1: "b", column_2: "b", column_3: "b"},
    ]

    def test_no_field_values(self, spark):
        df = spark.createDataFrame(self.source_data, self.source_schema)

        config = self.source_config([])
        data, extra_columns = self.enrich(df, config)
        assert data == self.source_data
        assert extra_columns == []

        config = self.source_config([
            self.target_column_mapping(self.column_1),
            self.target_column_mapping(self.column_2)
        ])
        data, extra_columns = self.enrich(df, config)
        assert data == self.source_data
        assert extra_columns == []

    def test_literal_field_values(self, spark):
        df = spark.createDataFrame(self.source_data, self.source_schema)

        config = self.source_config([
            self.target_column_mapping(self.column_1, "1"),
            self.target_column_mapping(self.column_2, "2")
        ])
        data, extra_columns = self.enrich(df, config)
        expected_name_1 = f"{self.column_1}_target_id_{self.column_1}_{ColumnTransformation._stable_hash('1')}"
        expected_name_2 = f"{self.column_2}_target_id_{self.column_2}_{ColumnTransformation._stable_hash('2')}"
        assert data == [
            {self.key_name: "id1", self.column_1: "a", self.column_2: "b", self.column_3: "c",
             expected_name_1: 1, expected_name_2: 2},
            {self.key_name: "id2", self.column_1: "a", self.column_2: "a", self.column_3: "a",
             expected_name_1: 1, expected_name_2: 2},
            {self.key_name: "id3", self.column_1: "b", self.column_2: "b", self.column_3: "b",
             expected_name_1: 1, expected_name_2: 2}
        ]
        assert set(extra_columns) == {
            TableColumn(name=expected_name_2,
                        type=StringType(),
                        is_primary_key=False,
                        is_nullable=False,
                        expression=None,
                        is_fk_to_ref_table=False),
            TableColumn(name=expected_name_1,
                        type=StringType(),
                        is_primary_key=False,
                        is_nullable=False,
                        expression=None,
                        is_fk_to_ref_table=False),
        }

    def test_literal_field_values_with_strings(self, spark):
        df = spark.createDataFrame(self.source_data, self.source_schema)

        config = self.source_config([
            self.target_column_mapping(self.column_1, "'foo'"),
            self.target_column_mapping(self.column_2, "'bar'")
        ])
        data, extra_columns = self.enrich(df, config)
        expected_name_1 = f"""{self.column_1}_target_id_{self.column_1}_{ColumnTransformation._stable_hash("'foo'")}"""
        expected_name_2 = f"""{self.column_2}_target_id_{self.column_2}_{ColumnTransformation._stable_hash("'bar'")}"""
        assert data == [
            {self.key_name: "id1", self.column_1: "a", self.column_2: "b", self.column_3: "c",
             expected_name_1: "foo", expected_name_2: "bar"},
            {self.key_name: "id2", self.column_1: "a", self.column_2: "a", self.column_3: "a",
             expected_name_1: "foo", expected_name_2: "bar"},
            {self.key_name: "id3", self.column_1: "b", self.column_2: "b", self.column_3: "b",
             expected_name_1: "foo", expected_name_2: "bar"}
        ]
        assert set(extra_columns) == {
            TableColumn(name=expected_name_2,
                        type=StringType(),
                        is_primary_key=False,
                        is_nullable=False,
                        expression=None,
                        is_fk_to_ref_table=False),
            TableColumn(name=expected_name_1,
                        type=StringType(),
                        is_primary_key=False,
                        is_nullable=False,
                        expression=None,
                        is_fk_to_ref_table=False),
        }

    def enrich(self, df: DataFrame, config: SourceConfiguration):
        df, extra_columns = FieldValuesSourceEnricher.enrich(config, df)
        return [row.asDict() for row in df.collect()], extra_columns

    def source_config(self, columns_mapping: List[ColumnTransformation]) -> SourceConfiguration:
        tc = TargetConfiguration(
            feed_id="feed_id",
            target_id="target_id",
            data_access_definition=DataAccessDefinition(
                data_source_id="target_id",
                data_source_type=DataSourceTypeEnum.TABLE,
                data_source_owner_id="owner_id",
                data_format="delta"
            ),
            target_columns_transformations=frozenset(columns_mapping),
            partitions_config=frozenset(),
            temporal_tables_semantics=None,
            table_schema=TargetTableSchema(
                id="target_id",
                relations=frozenset(),
                columns=frozenset(),
                db="db"
            ),
            target_modified_date_column_name="modifiedOn",
        )
        return SourceConfiguration(
            source_id="source_id",
            feed_id="feed_id",
            data_access_definition=DataAccessDefinition(
                data_source_id="source_id",
                data_source_type=DataSourceTypeEnum.TABLE,
                data_source_owner_id="owner_id",
                data_format="delta",
            ),
            schema=None,
            target_configurations=frozenset([tc]),
            mapping_definitions=frozenset(),
            create_view_only=False,
            view_alias=None,
            source_to_reference_mappings=frozenset(),
            source_table_column_name="source_table_column_name",
        )

    def target_column_mapping(self,
                              name: str,
                              target_field_value: Optional[str] = None) -> ColumnTransformation:
        return ColumnTransformation(
            transformation_target_id="target_id",
            original_source_field_name=name,
            target_field_name=name,
            target_field_type=StringType(),
            source_field_type=StringType(),
            target_field_value=target_field_value,
            is_source_primary_key=False,
            source_field_calculated_value=None,
            target_field_condition=None,
            owner_target_id="target_id",
            should_be_id_mapped=False,
        )
