import os
from typing import Dict, List

import pytest
from pyspark.sql import DataFrame

from rmt.app.reference_values_mapper import ReferenceValuesMapper
from rmt.core.values_mapping.mapping_definition import MappingDefinition
from rmt.core.values_mapping.mapping_definitions_reader import MappingDefinitionsReader
from rmt.core.values_mapping.mapping_query_definition import MappingQueryDefinition, SourceMappingFile
from rmt.core.values_mapping.mapping_values_definition import MappingValuesDefinition, TargetMapping
from tests.common.test_case_common import TestCaseCommon
from tests.conftest import TESTS_ROOT_DIR


class TestRMT:
    @staticmethod
    def run_rmt(
        spark,
        mapping_definitions_by_source: Dict[str, List[MappingDefinition]],
        test_name: str,
        delete=True,
        number_of_partition_files: int = -1,
    ) -> DataFrame:
        class MockedMappingDefinitionsReader(MappingDefinitionsReader):
            def __init__(self, mapping_definitions_by_source_dict):
                self.mapping_definitions_by_source = mapping_definitions_by_source_dict

            @property
            def sources(self) -> List[str]:
                return list(self.mapping_definitions_by_source.keys())

            def read(self, source: str) -> List[MappingDefinition]:
                return self.mapping_definitions_by_source[source]

        mocked_mapping_definitions_reader = MockedMappingDefinitionsReader(mapping_definitions_by_source)

        mapping_output_full_path = TestCaseCommon.mapping_output_path_by_test_name(test_name)
        if delete:
            TestCaseCommon.clean_mapping_output_for_test(test_name)

        ReferenceValuesMapper.create_reference_values_mapping(
            spark,
            source_domain="source_domain",
            mapping_definitions_reader=mocked_mapping_definitions_reader,
            mapping_file_output_path=mapping_output_full_path,
            number_of_partition_files=number_of_partition_files,
        )
        mapping_dataframe = spark.read.format("delta").load(mapping_output_full_path)
        return mapping_dataframe

    @staticmethod
    def mapping_query_definition_of_concept() -> MappingQueryDefinition:
        source_mapping_files = [
            SourceMappingFile(
                file_path=os.path.join(TESTS_ROOT_DIR, "data", "mapping_data", "concept"), file_name="concept"
            ),
            SourceMappingFile(
                file_path=os.path.join(TESTS_ROOT_DIR, "data", "mapping_data", "vocabulary"), file_name="vocabulary"
            ),
            SourceMappingFile(
                file_path=os.path.join(TESTS_ROOT_DIR, "data", "mapping_data", "concept_relationship"),
                file_name="concept_relationship",
            ),
        ]
        sql = """select cr.concept_id_2 as target_value , concat_ws('<->', c.concept_code, fv.Fhir_Uri) as source_value
        from concept c inner join vocabulary fv on c.vocabulary_id = fv.vocabulary_id left outer join concept_relationship cr on
        c.concept_id = cr.concept_id_1 and cr.relationship_id = 'Maps to' Union select c.concept_id as target_value,
        concat_ws('<->', c.concept_code, fv.Fhir_Uri,'NH') as source_value from CONCEPT c inner join vocabulary fv on c.vocabulary_id = fv.vocabulary_id"""

        return MappingQueryDefinition(
            target_table_name="concept",
            target_field_name="concept_id",
            source_mapping_files=source_mapping_files,
            sql=sql,
        )

    @staticmethod
    def mapping_values_definitions_of_concept() -> MappingValuesDefinition:
        return MappingValuesDefinition(
            target_table_name="concept",
            target_field_name="concept_id",
            values=[TargetMapping(target_key_value=1, source_values=["2076-8<->urn:oid:2.16.840.1.113883.6.238<->NH"])],
        )

    @staticmethod
    def mapping_values_definitions_of_gender() -> MappingValuesDefinition:
        return MappingValuesDefinition(
            target_table_name="Gender",
            target_field_name="GenderId",
            values=[
                TargetMapping(target_key_value=1, source_values=["104800000", "male"]),
                TargetMapping(target_key_value=2, source_values=["104800001"]),
                TargetMapping(target_key_value=3, source_values=["104800002"]),
                TargetMapping(target_key_value=4, source_values=["104800003"]),
            ],
        )

    @staticmethod
    def mapping_values_definitions_of_gender2() -> MappingValuesDefinition:
        return MappingValuesDefinition(
            target_table_name="Gender",
            target_field_name="GenderId",
            values=[
                TargetMapping(target_key_value=10, source_values=["104800000", "male"]),
                TargetMapping(target_key_value=11, source_values=["104800001"]),
                TargetMapping(target_key_value=12, source_values=["104800002"]),
            ],
        )

    def test_rmt_with_1_query_mapping_definition(self, spark):
        query_mapping_definition = TestRMT.mapping_query_definition_of_concept()
        mapping_dataframe = TestRMT.run_rmt(
            spark, {"source1": [query_mapping_definition]}, "test_rmt_with_1_query_mapping_definition"
        )
        assert mapping_dataframe.count() == 15

    def test_rmt_with_1_values_mapping_definition(self, spark):
        values_mapping_definition = TestRMT.mapping_values_definitions_of_gender()
        mapping_dataframe = TestRMT.run_rmt(
            spark, {"source1": [values_mapping_definition]}, "test_rmt_with_1_values_mapping_definition"
        )
        assert mapping_dataframe.count() == 5

    def test_rmt_run_twice_with_1_values_mapping_definition_override(self, spark):
        values_mapping_definition = TestRMT.mapping_values_definitions_of_gender()
        mapping_dataframe = TestRMT.run_rmt(
            spark,
            {"source1": [values_mapping_definition]},
            "test_rmt_run_twice_with_1_values_mapping_definition_override",
        )
        override_values_mapping_definition = TestRMT.mapping_values_definitions_of_gender2()
        mapping_dataframe = TestRMT.run_rmt(
            spark,
            {"source1": [override_values_mapping_definition]},
            "test_rmt_run_twice_with_1_values_mapping_definition_override",
            False,
        )
        assert mapping_dataframe.count() == 4

    def test_rmt_with_1_values_mapping_definition_override_in_2_sources(self, spark):
        values_mapping_definition = TestRMT.mapping_values_definitions_of_gender()
        override_values_mapping_definition = TestRMT.mapping_values_definitions_of_gender2()
        mapping_dataframe = TestRMT.run_rmt(
            spark,
            {"source1": [values_mapping_definition], "source2": [override_values_mapping_definition]},
            "test_rmt_with_1_values_mapping_definition_override_in_2_sources",
        )

        assert mapping_dataframe.count() == 5

    def test_rmt_with_1_values_mapping_definition_override_in_1_sources(self, spark):
        values_mapping_definition = TestRMT.mapping_values_definitions_of_gender()
        override_values_mapping_definition = TestRMT.mapping_values_definitions_of_gender2()
        with pytest.raises(ValueError):
            TestRMT.run_rmt(
                spark,
                {"source1": [values_mapping_definition, override_values_mapping_definition]},
                "test_rmt_with_1_values_mapping_definition_override_in_1_sources",
            )

    def test_rmt_with_2_mapping_definition_and_2_overrides(self, spark):
        query_mapping_definition = TestRMT.mapping_query_definition_of_concept()
        override_query_mapping_definition = TestRMT.mapping_values_definitions_of_concept()
        values_mapping_definition = TestRMT.mapping_values_definitions_of_gender()
        override_values_mapping_definition = TestRMT.mapping_values_definitions_of_gender2()
        mapping_dataframe = TestRMT.run_rmt(
            spark,
            {
                "source1": [query_mapping_definition, values_mapping_definition],
                "source2": [override_query_mapping_definition, override_values_mapping_definition],
            },
            "test_rmt_with_2_mapping_definition_and_2_overrides",
        )
        assert mapping_dataframe.count() == 20

    def test_rmt_with_invalid_number_of_partitions(self, spark):
        query_mapping_definition = TestRMT.mapping_query_definition_of_concept()
        with pytest.raises(Exception, match="Number of partitions must be either greater"):
            TestRMT.run_rmt(
                spark, {"source1": [query_mapping_definition]}, "test_rmt_with_invalid_number_of_partitions", True, 0
            )

    def test_rmt_with_number_of_partitions(self, spark):
        values_mapping_definition = TestRMT.mapping_values_definitions_of_gender()
        mapping_dataframe = TestRMT.run_rmt(
            spark, {"source1": [values_mapping_definition]}, "test_rmt_with_number_of_partitions", True, 1
        )
        assert mapping_dataframe.count() == 5
