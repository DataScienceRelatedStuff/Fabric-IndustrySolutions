import pytest
from pyspark.sql.types import IntegerType, StringType

from rmt.contract.configuration.reference_table import ReferenceTable, TableColumn
from rmt.core.tables_creating.model.internal import ReferenceTableData, ReferenceTableFieldMapping
from rmt.core.tables_creating.reference_tables_data_validator import InvalidReferenceTableDataError, ReferenceTablesDataValidator

table_name = "reftable1"
key_field = "TypeId"
name_field = "TypeName"
field_mapping = [
    ReferenceTableFieldMapping(referenceFieldName="col1", adrmFieldName=key_field),
    ReferenceTableFieldMapping(referenceFieldName="col2", adrmFieldName=name_field),
]


@pytest.fixture(scope="function")
def ref_table1_data():
    return ReferenceTableData(
        adrmTableName=table_name,
        data=[{"col1": 1, "col2": "one"}, {"col1": 2, "col2": "two"}],
        fieldMapping=field_mapping,
    )


@pytest.fixture(scope="function")
def ref_table11_data():
    return ReferenceTableData(
        adrmTableName=table_name,
        data=[{"col1": 3, "col2": "three"}, {"col1": 4, "col2": "four"}],
        fieldMapping=field_mapping,
    )


class TestReferenceTableDataValidator:
    def test_no_errors_are_thrown_when_data_is_valid(self, ref_table1_data, ref_table11_data):
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        validator.validate()

    def test_an_error_is_thrown_for_unknown_ref_table(self, ref_table1_data, ref_table11_data):
        unknown_table_name = table_name + "foobar"
        validator = ReferenceTablesDataValidator(
            reference_tables_data={unknown_table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {unknown_table_name} is not a known reference table"]

    def test_an_error_is_thrown_if_unmapped_key_field(self, ref_table1_data: ReferenceTableData):
        ref_table1_data.fieldMapping.pop(0)  # remove key field mapping
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {table_name} is missing key field {key_field} definition"]

    def test_an_error_is_thrown_if_unmapped_name_field(self, ref_table1_data: ReferenceTableData):
        ref_table1_data.fieldMapping.pop(1)  # remove name field mapping
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {table_name} is missing name field {name_field} definition"]

    def test_unpopolated_key_raises_an_error(self, ref_table1_data, ref_table11_data):
        ref_table11_data.data.append({"col2": "five"})
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {table_name} is missing key field {key_field} definition for data row 3"]

    def test_unpopolated_name_raises_an_error(self, ref_table1_data, ref_table11_data):
        ref_table11_data.data.append({"col1": 5})
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {table_name} is missing name field {name_field} definition for data row 3"]

    def test_duplicated_ids_mapping_raises_an_error(self, ref_table1_data, ref_table11_data):
        ref_table11_data.data.append({"col1": 3, "col2": "thrii"})
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {table_name} has duplicate value(s): [3]"]

    def test_duplicated_names_mapping_raises_an_error(self, ref_table1_data, ref_table11_data):
        ref_table11_data.data.append({"col1": 33, "col2": "three"})
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == [f"Table {table_name} has duplicate value(s): ['three']"]

    def test_multiple_errors_are_collected(self, ref_table1_data, ref_table11_data):
        ref_table11_data.data.append({"col1": 3, "col2": "three"})
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data, ref_table11_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == sorted(
            [
                f"Table {table_name} has duplicate value(s): ['three']",
                f"Table {table_name} has duplicate value(s): [3]",
            ]
        )

    def test_rows_misssing_non_null_fields_raises_an_error(self, ref_table1_data: ReferenceTableData):
        non_null_field_name = "non_null_field"
        ref_table1_data.fieldMapping.append(
            ReferenceTableFieldMapping(referenceFieldName="col3", adrmFieldName=non_null_field_name),
        )
        validator = ReferenceTablesDataValidator(
            reference_tables_data={table_name: [ref_table1_data]},
            reference_tables={
                table_name: ReferenceTable(
                    table_name=table_name,
                    key_field=key_field,
                    name_field=name_field,
                    columns=[
                        TableColumn(name=key_field, type=IntegerType(), is_nullable=True),
                        TableColumn(name=name_field, type=StringType(), is_nullable=True),
                        TableColumn(name=non_null_field_name, type=StringType(), is_nullable=False),
                    ],
                )
            },
        )
        error_messages = self._validate(validator)
        assert error_messages == sorted(
            [
                f"Table {table_name} is missing key field col3, row: 1 which is not nullable in reference table definition",
                f"Table {table_name} is missing key field col3, row: 2 which is not nullable in reference table definition",
            ]
        )

    def _validate(self, validator):
        with pytest.raises(InvalidReferenceTableDataError) as exc_info:
            validator.validate()
        return self._collect_error_messages(exc_info)

    def _collect_error_messages(self, exc_info):
        return sorted([e.args[0] for e in exc_info.value.context["errors"]])
