from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StringType, StructType, StructField, LongType, Row
from dmf.utils.global_constants import GlobalConstants
from dmf.ids_mapping.adrm_ids_enricher import AdrmIdsEnricher


class TestAdrmIdsEnricher:

    def create_source_dataframe(self, spark: SparkSession, source_data: list) -> DataFrame:
        source_schema = StructType(
            [
                StructField("key_col", StringType(), True),
                StructField("data", LongType(), True),
            ])

        source_df = spark.createDataFrame(source_data, source_schema)

        return source_df

    def create_source_ext_dataframe(self, spark: SparkSession, source_data: list) -> DataFrame:
        source_schema = StructType(
            [
                StructField("key_col", StringType(), True),
                StructField("ext_key_col", StringType(), True),
                StructField("data", LongType(), True),
            ])

        source_df = spark.createDataFrame(source_data, source_schema)

        return source_df

    def create_id_mapping_dataframe(self, spark: SparkSession, id_mapping_data: list) -> DataFrame:
        id_mapping_schema = StructType(
            [
                StructField(GlobalConstants.INTERNAL_ID_COLUMN_NAME,
                            StringType(), True),
                StructField(GlobalConstants.EXTERNAL_ID_COLUMN_NAME,
                            StringType(), True),
                StructField(GlobalConstants.ADRM_ID_COLUMN_NAME,
                            LongType(), True),
                StructField(GlobalConstants.FEED_ID_COLUMN_NAME,
                            StringType(), True),
            ])

        id_mapping_df = spark.createDataFrame(id_mapping_data, id_mapping_schema)

        return id_mapping_df

    def test_enrich_one_key(self, spark: SparkSession):
        feed_id = "feed_1"
        id_mapping_data = [
            ("a_int", "a_int", 1, feed_id),
            ("b_int", "b_int", 2, feed_id),
            ("c_int", "c_int", 3, feed_id),
        ]

        source_data = [
            ("a_int", 1),
            ("b_int", 2),
            ("c_int", 3),
        ]

        source_df = self.create_source_dataframe(spark, source_data)
        id_mapping_df = self.create_id_mapping_dataframe(spark, id_mapping_data)

        df = AdrmIdsEnricher.enrich(source_df, feed_id, "key_col", id_mapping_df, "new_id_col")
        rows = df.collect()

    def test_enrich_with_ext_id(self, spark: SparkSession):
        feed_id = "feed_1"
        id_mapping_data = [
            ("a_int", "a_ext", 1, feed_id),
            ("b_int", "b_ext", 2, feed_id),
            ("c_int", "c_ext", 3, feed_id),
        ]

        source_data = [
            ("a_int", "a_ext", 1),
            ("b_int", "b_ext", 2),
            ("c_int", "c_ext", 3),
        ]

        source_df = self.create_source_ext_dataframe(spark, source_data)
        id_mapping_df = self.create_id_mapping_dataframe(spark, id_mapping_data)

        df = AdrmIdsEnricher.enrich(source_df, feed_id, "ext_key_col", id_mapping_df, "new_id_col")
        rows = df.collect()

        assert rows == [Row(key_col1='a_int', key_col2='a_ext', data=1, new_id_col=1),
                        Row(key_col1='b_int', key_col2='b_ext', data=2, new_id_col=2),
                        Row(key_col1='c_int', key_col2='c_ext', data=3, new_id_col=3),
                        ]

    def test_enrich_one_key_multiple_feeds(self, spark: SparkSession):
        id_mapping_data = [
            ("a_int", "a_int", 1, "feed_1"),
            ("b_int", "b_int", 2, "feed_1"),
            ("a_int", "a_int", 3, "feed_2"),
        ]

        source_data = [
            ("a_int", 1),
            ("b_int", 2),
        ]

        source_df = self.create_source_dataframe(spark, source_data)
        id_mapping_df = self.create_id_mapping_dataframe(spark, id_mapping_data)

        df = AdrmIdsEnricher.enrich(source_df, "feed_1", "key_col", id_mapping_df, "new_id_col")
        rows = [row.asDict() for row in df.collect()]

        assert rows == [
            {"key_col": "a_int", "data": 1, "new_id_col": 1},
            {"key_col": "b_int", "data": 2, "new_id_col": 2}
        ]

        df = AdrmIdsEnricher.enrich(source_df, "feed_2", "key_col", id_mapping_df, "new_id_col")
        rows = [row.asDict() for row in df.collect()]

        assert rows == [
            {"key_col": "a_int", "data": 1, "new_id_col": 3},
            {"key_col": "b_int", "data": 2, "new_id_col": None},
        ]

    def test_enrich_not_exist_key(self, spark: SparkSession):
        feed_id = "feed_1"
        id_mapping_data = [
            ("a", "a_ext",  1, feed_id),
            ("b", "b",      2, feed_id),
            ("c", "c",      3, feed_id),
        ]

        source_data = [
            ("d", 1),
            ("b", 2),
            ("c", 3),
        ]

        source_df = self.create_source_dataframe(spark, source_data)
        id_mapping_df = self.create_id_mapping_dataframe(spark, id_mapping_data)

        df = AdrmIdsEnricher.enrich(source_df, feed_id, "key_col", id_mapping_df, "new_id_col")
        rows = df.collect()

        assert set(rows) == set([
            Row(key_col='b', data=2, new_id_col=2),
            Row(key_col='c', data=3, new_id_col=3),
            Row(key_col='d', data=1, new_id_col=None)
        ])

    def test_enrich_ext_id_is_null(self, spark: SparkSession):
        feed_id = "feed_1"
        id_mapping_data = [
            ("a", None, 1, feed_id),
            ("b", None, 2, feed_id),
            ("c", None, 3, feed_id)
        ]

        source_data = [
            ("a", 1),
            ("b", 2),
            ("c", 3),
        ]

        source_df = self.create_source_dataframe(spark, source_data)
        id_mapping_df = self.create_id_mapping_dataframe(spark, id_mapping_data)
        rows = AdrmIdsEnricher.enrich(source_df, feed_id, "key_col", id_mapping_df, "new_id_col").collect()
        assert rows == [Row(key_col1='a', data=1, new_id_col=1),
                        Row(key_col1='b', data=2, new_id_col=2),
                        Row(key_col1='c', data=3, new_id_col=3),
                        ]
