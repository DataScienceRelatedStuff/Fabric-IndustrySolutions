from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Column:
    name: str
    type: str
    precision: Optional[int] = field(default=None)
    scale: Optional[int] = field(default=None)

    def __str__(self):
        string = f"`{self.name}` {self.type.upper()}"
        if self.type == "decimal":
            string += f"({self.precision},{self.scale})"

        return string
