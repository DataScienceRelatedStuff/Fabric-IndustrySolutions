from unittest.mock import MagicMock
from pyspark.sql import SparkSession, DataFrame
from dmf.transformations.processor.temp_view_creator import TempViewCreator
from dmf.transformations.reader.storage_reader import StorageReader


class TestTempViewCreator:
    
    def temp_view_creator_read(self, df, view_name, mocker):
        reader = StorageReader("db", "parquet")
        mocker.patch(
            "dmf.transformations.reader.storage_reader.StorageReader.read",
            return_value=df,
        )
        mocker.patch(
            "dmf.transformations.reader.reader_factory.ReaderFactory.get_instance",
            return_value=reader,
        )

        config = MagicMock()
        config.data_access_definition = MagicMock()
        temp_view_creator = TempViewCreator(spark=MagicMock(), config=config, view_name=view_name)
        return temp_view_creator.read()

    def test_reader_return_df(self, spark: SparkSession, mocker):
        df = spark.createDataFrame([("a", 1), ("b", 2)], ["col1", "col2"])
        result = self.temp_view_creator_read(df, "test_view", mocker)
        assert result is True
        df = spark.sql("select * from test_view")
        assert df.count() == 2

    def test_reader_return_none(self, spark: SparkSession, mocker):
        result = self.temp_view_creator_read(None, "", mocker)
        assert result is True
