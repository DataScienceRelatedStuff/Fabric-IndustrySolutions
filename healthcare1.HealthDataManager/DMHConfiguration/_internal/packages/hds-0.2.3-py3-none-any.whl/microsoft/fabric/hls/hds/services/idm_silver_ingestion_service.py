# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import traceback
from notebookutils import mssparkutils
from pyspark.sql import SparkSession
from typing import Dict
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import (
    LoggingConstants as LC,
)
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter
from microsoft.fabric.hls.hds.services.dtt_workflow_service import (
    DTTWorkflowService,
)

telemetry_reporter = TelemetryReporter()

# Report IDMIngestionService module import
telemetry_reporter.report_usage(
    feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
    activity_name=GlobalConstants.PATIENT_OUTREACH_SILVER_INGESTION_ACTIVITY_NAME,
)

class IDMSilverIngestionService:
    def __init__(self,
                 spark: SparkSession,
                 workspace_name: str,
                 solution_name: str,
                 source_lakehouse_name: str,
                 target_lakehouse_name: str,
                 **kwargs):
        """
        Uses DTT library to transform and ingest marketing data into Silver Lake
        Args:
        - spark: spark session
        - workspace_name - str: Name of the Fabric Workspace
        - solution_name: Name of the DMH OneLake workload solution
        - source_lakehouse_name: str- The lakehouse name of where the source tables are located. Expected to be the Bronze database as per the medallion architecture
        - target_lakehouse_name: str - The lakehouse name of where the target tables are located. Expected to be the Silver database as per the medallion architecture
        kwargs: Optional. Additional arguments to be set on the IDMIngestionService
        Possible values:
         - idm_config_path: str - The path to the industry data model config folder. The default is "abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/idm
         - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
         
        """
        self.spark = spark
        self._logger = LoggingHelper.get_patientoutreach_idm_silveringestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.source_lakehouse_name = source_lakehouse_name
        self.target_lakehouse_name = target_lakehouse_name
        self.one_lake_endpoint = kwargs.get(
            "one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT
        )
        self.ci_profile_id = kwargs.get("ci_profile_id")
        try:
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(workspace_name=self.workspace_name,
                                                                                        one_lake_endpoint=self.one_lake_endpoint,
                                                                                        solution_name=self.solution_name)
            self.source_tables_path = FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.source_lakehouse_name)
            
            self.idm_tables_path = FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.target_lakehouse_name)
            self.idm_files_path=FolderPath.get_fabric_files_path( 
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.target_lakehouse_name)
            self.idm_config_path = kwargs.get(
                "idm_config_path",
                FolderPath.get_fabric_workload_files_idm_config_folder_path(root_path=self.config_files_root_path),
            )
            self.dtt_secondary_lake_path = (
                FolderPath.get_fabric_workload_files_idm_dtt_secondary_lake_folder_path(
                    root_path=self.config_files_root_path
                )
            )
            self.dmf_config_path = FolderPath.get_idm_dmf_configuration_files(root_path=self.config_files_root_path)
            self.rmt_config_path = FolderPath.get_idm_rmt_configuration_files(root_path=self.config_files_root_path)
            self.env_config_path = FolderPath.get_idm_environment_configuration_file(root_path=self.config_files_root_path)
            self.rmt_reference_tables_dir = FolderPath.get_idm_fabric_workload_files_rmt_mapping_folder_path(root_path=self.config_files_root_path)     
        
            self._logger.info(self.dmf_config_path)
            self._logger.info(self.rmt_config_path)
            self.setDTTAppInsightsKey()
        
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise
        
        self.dtt_env_config = f"""{{
            "storage": {{
                "target": {{
                    "entities": {{
                        "default": {{
                            "location": "{self.idm_tables_path}",
                            "format": "delta"
                        }}
                    }}
                }},
                "secondary_lake": {{
                    "location": "{self.dtt_secondary_lake_path}"
                }}    
            }}
        }}"""
        mssparkutils.fs.put(self.env_config_path, self.dtt_env_config, overwrite=True)
        self._logger.info(self.env_config_path)
        self.placeholder_values: Dict = {
            "{{dtt_source}}": f"`{self.source_lakehouse_name}`",
            "{{ci_profile_id}}": f"{self.ci_profile_id}"
        }
       
    def setDTTAppInsightsKey(self):
        """
        set the DTT's application insights instrumentation key and ingestion endpoint to spark configuration
        """

        dtt_app_insights_connection_string = Utils.get_app_insights_connection_string(
            spark=self.spark
        )
        
        if dtt_app_insights_connection_string:
            self.spark.conf.set(
                GlobalConstants.SPARK_DTT_APP_INSIGHTS_CONNECTION_STRING,
                dtt_app_insights_connection_string,
            )
            self._logger.info(f"{LC.DTT_APP_INSIGHTS_SET_INFO_MSG}")

    def ingest(self):
        """Using DTT ingest source data into IDM tables"""

        try:
            self._logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")

            # Call DTT to transform Data
            self.__dtt_workflow()
            self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")
        except Exception as ex:
            self._logger.error(
                f"{LC.IDM_TRANSFORMATION_EXCEPTION_ERROR_MSG.format(str(ex), traceback.print_exc())}"
            )
            raise


    def __dtt_workflow(self):
        """Invokes the dtt workflow"""
        rmt_mapping_folder_paths=[f"{self.rmt_reference_tables_dir}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_MAPPING_FOLDER}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_DATA_HEALTHCARE_FOLDER}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_DOMAIN_FOLDER}"]
        self._logger.info(f"{rmt_mapping_folder_paths[0]}")
        self._logger.info(f"{self.rmt_reference_tables_dir}")
        rmt_data_folder_paths=[f"{self.rmt_reference_tables_dir}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_DATA_FOLDER}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_DATA_COMMON_FOLDER}",f"{self.rmt_reference_tables_dir}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_DATA_FOLDER}/{GlobalConstants.IDM_RMT_REFERENCE_TABLES_DATA_HEALTHCARE_FOLDER}"]
       
        self._logger.info(rmt_data_folder_paths[0])
        adapter = f"{self.idm_config_path}/{GlobalConstants.IDM_DMF_ADAPTER_FILE}"
        db_target_schema = f"{self.idm_config_path}/{GlobalConstants.IDM_DB_TARGET_SCHEMA}"
        db_target_schema_config = (
            f"{self.idm_config_path}/{GlobalConstants.IDM_DB_TARGET_SCHEMA_CONFIG}"
        )
        db_semantics = f"{self.idm_config_path}/{GlobalConstants.IDM_DB_SEMANTICS}"
        db_semantics_config = (
            f"{self.idm_config_path}/{GlobalConstants.IDM_DB_SEMANTICS_CONFIG}"
        )
        
        dtt_adapter = self.spark.read.text(adapter, wholetext=True).collect()[0][0]
        for placeholder in self.placeholder_values:
            dtt_adapter = dtt_adapter.replace(
                placeholder, self.placeholder_values[placeholder])
      
        config_files = {
            "adaptor_file_content": dtt_adapter,
            "target_db_semantics_file_location": db_semantics,
            "env_config_file_location": self.env_config_path,
            "target_db_schema_file_location": db_target_schema,
            "db_schema_config_location": db_target_schema_config,           
            "target_db_semantics_config_file_location": db_semantics_config,
            "rmt_target_path":self.idm_tables_path
        }
        
        
        dtt_workflow = DTTWorkflowService( 
            spark=self.spark,   
            rmt_out_path=self.rmt_config_path,
            dtt_out_path=self.dmf_config_path,
            config_files=config_files,
            rmt_ordered_mapping_definitions_folders=rmt_mapping_folder_paths,
            executeRMTReferenceTable=True,
            rmt_reference_tables_folders_paths=rmt_data_folder_paths,
        )
        dtt_workflow.execute_dtt_workflow()