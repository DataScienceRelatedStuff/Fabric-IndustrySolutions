import pytest

from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.model.source_configuration import MappingDefinition


class TestSourceConfiguration:

    def test_mapping_definition_incompatible_values(self):
        with pytest.raises(ValueError):
            MappingDefinition(
                target_mapping_table_name="target_mapping_table_name",
                source_mapping_table_name="source_mapping_table_name",
                target_id_column_name="target_id_column_name",
                internal_id_column_name="internal_id_column_name",
                external_id_column_name="external_id_column_name",
                db="db",
                mapping_entity_type=DataSourceTypeEnum.STORAGE,
                secondary_lake_location="secondary_lake_location"
            )
