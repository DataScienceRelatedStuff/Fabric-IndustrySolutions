from pathlib import Path
from typing import Set
from tests.utils.db.builder.schema_builder import SchemaBuilder
from project_root import PROJECT_ROOT_DIR


used_dataverse_tables = {
    "contact",
    "msfsi_group",
    "msfsi_groupmember",
    "msfsi_lifemoment",
    "msfsi_relationship",
    "msfsi_groupfinancialholding",
    "msfsi_financialholding",
    "transactioncurrency"
}


class DataverseSchemaBuilder(SchemaBuilder):

    def _used_tables(self) -> Set:
        return used_dataverse_tables

    @staticmethod
    def data_location() -> Path:
        return Path(PROJECT_ROOT_DIR, "tests", "data", "db", "dataverse", "csv")
