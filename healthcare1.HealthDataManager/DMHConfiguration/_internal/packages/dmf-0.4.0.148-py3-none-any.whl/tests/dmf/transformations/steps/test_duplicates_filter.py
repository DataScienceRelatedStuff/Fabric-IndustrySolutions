from datetime import datetime
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType, LongType
from dmf.transformations.steps.duplicates_filter import DuplicatesFilter
import tests.utils.dataframe_utils as dfu


class TestDuplicatesFilter:
    date1 = datetime(2022, 8, 1)
    date2 = datetime(2022, 8, 2)
    date3 = datetime(2022, 8, 3)
    date4 = datetime(2022, 8, 4)
    date5 = datetime(2022, 8, 5)
    date6 = datetime(2022, 8, 6)

    def test_keep_latest_single_key_single_data(self, spark):
        schema = StructType(
            [
                StructField("key", StringType(), False),
                StructField("data", StringType(), False),
                StructField("ordering_col", TimestampType(), False)
            ]
        )

        data = [
            ("key1", "d1", self.date1),
            ("key1", "d1", self.date2),
            ("key1", "d10", self.date3),
            ("key2", "d12", self.date1),
            ("key2", "d12", self.date2),
            ("key3", "d2", self.date4),
            ("key4", "d3", self.date5),
            ("key4", "d3", self.date6),
        ]

        expected_result_data = [
            ("key1", "d1", self.date2),
            ("key1", "d10", self.date3),
            ("key2", "d12", self.date2),
            ("key3", "d2", self.date4),
            ("key4", "d3", self.date6),
        ]

        df = spark.createDataFrame(data=data, schema=schema)

        result_df = DuplicatesFilter.filter(df, ["key"], ["data"], "ordering_col", True)

        expectd_df = spark.createDataFrame(data=expected_result_data, schema=schema)

        assert result_df.exceptAll(expectd_df).count() == 0
        assert expectd_df.exceptAll(result_df).count() == 0

    def test_keep_latest_multi_key_multi_data_first_data_remains_constant(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_first_data_changes(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 100, self.date2)
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 100, self.date2)
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_all_data_change(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 200, self.date2)
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 200, self.date2)
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_with_duplicate_row(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
            ("key1", 1, "d1", 200, self.date3),
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date3),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_two_keys_with_duplicate_row(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
            ("key1", 1, "d1", 200, self.date3),
            ("key2", 5, "d2", 1000, self.date1),
            ("key2", 5, "d2", 1000, self.date2),
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date3),
            ("key2", 5, "d2", 1000, self.date2),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_with_all_real_or_one_null_value(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_with_duplication_of_one_of_null_values(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
            ("key6", 7, None, 777, self.date4),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
            ("key6", 7, None, 777, self.date4),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_with_duplication_of_all_values_when_one_value_is_null(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
            ("key6", 7, None, 555, self.date4),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date4),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_with_no_duplication_when_one_entry_contains_only_null_values(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, None, self.date3),
            ("key6", 7, None, 555, self.date4),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, None, self.date3),
            ("key6", 7, None, 555, self.date4),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_latest_multi_key_multi_data_all_entries_contain_all_null_values(self, spark):
        data = [
            ("key6", 7, None, None, self.date3),
            ("key6", 7, None, None, self.date4),
        ]

        expected_data = [
            ("key6", 7, None, None, self.date4),
        ]

        self._generic_multi_key_multi_data_test(spark, data, expected_data, True)

    def test_keep_first_single_key_single_data(self, spark):
        schema = StructType(
            [
                StructField("key", StringType(), False),
                StructField("data", StringType(), False),
                StructField("ordering_col", TimestampType(), False)
            ]
        )

        data = [
            ("key1", "d1", self.date1),
            ("key1", "d1", self.date2),
            ("key1", "d10", self.date3),
            ("key2", "d12", self.date1),
            ("key2", "d12", self.date2),
            ("key3", "d2", self.date4),
            ("key4", "d3", self.date5),
            ("key4", "d3", self.date6),
        ]

        expected_result_data = [
            ("key1", "d1", self.date1),
            ("key1", "d10", self.date3),
            ("key2", "d12", self.date1),
            ("key3", "d2", self.date4),
            ("key4", "d3", self.date5),
        ]

        df = spark.createDataFrame(data=data, schema=schema)

        result_df = DuplicatesFilter.filter(
            df, ["key"], ["data"], "ordering_col", False)

        expectd_df = spark.createDataFrame(
            data=expected_result_data, schema=schema)

        assert result_df.exceptAll(expectd_df).count() == 0
        assert expectd_df.exceptAll(result_df).count() == 0

    def test_keep_first_multi_key_multi_data_first_data_remains_constant(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_first_data_changes(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 100, self.date2)
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 100, self.date2)
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_all_data_change(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 200, self.date2)
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d2", 200, self.date2)
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_with_duplicate_row(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
            ("key1", 1, "d1", 200, self.date3),
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_two_keys_with_duplicate_row(self, spark):
        data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
            ("key1", 1, "d1", 200, self.date3),
            ("key2", 5, "d2", 1000, self.date1),
            ("key2", 5, "d2", 1000, self.date2),
        ]

        expected_data = [
            ("key1", 1, "d1", 100, self.date1),
            ("key1", 1, "d1", 200, self.date2),
            ("key2", 5, "d2", 1000, self.date1),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_with_all_real_or_one_null_value(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_with_duplication_of_one_of_null_values(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
            ("key6", 7, None, 777, self.date4),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
            ("key6", 7, None, 777, self.date4),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_with_duplication_of_all_values_when_one_value_is_null(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
            ("key6", 7, None, 555, self.date4),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, 555, self.date3),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_with_no_duplication_when_one_entry_contains_only_null_values(self, spark):
        data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, None, self.date3),
            ("key6", 7, None, 555, self.date4),
        ]

        expected_data = [
            ("key6", 7, "d6", 2000, self.date1),
            ("key6", 7, "d6", None, self.date2),
            ("key6", 7, None, None, self.date3),
            ("key6", 7, None, 555, self.date4),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)

    def test_keep_first_multi_key_multi_data_all_entries_contain_all_null_values(self, spark):
        data = [
            ("key6", 7, None, None, self.date3),
            ("key6", 7, None, None, self.date4),
        ]

        expected_data = [
            ("key6", 7, None, None, self.date3),
        ]

        self._generic_multi_key_multi_data_test(
            spark, data, expected_data, False)
    
    def test_return_df_schema_is_identical_to_input_df_schema(self, spark):
        schema = StructType(
            [
                StructField("key", StringType(), False),
                StructField("data", StringType(), False),
                StructField("ordering_col", TimestampType(), False)
            ]
        )

        data = [
            ("key1", "d1", self.date1),
            ("key1", "d1", self.date2)
        ]

        df = spark.createDataFrame(data=data, schema=schema)
        result_df = DuplicatesFilter.filter(df, ["key"], ["data"], "ordering_col", True)

        assert df.schema.__eq__(result_df.schema)
        
    @staticmethod
    def _generic_multi_key_multi_data_test(spark, data, expected_data, keep_first: bool):
        schema = StructType(
            [
                StructField("key_part1", StringType(), True),
                StructField("key_part2", IntegerType(), True),
                StructField("data_part1", StringType(), True),
                StructField("data_part2", LongType(), True),
                StructField("ordering_col", TimestampType(), True)
            ]
        )

        df = spark.createDataFrame(data=data, schema=schema)
        result_df = DuplicatesFilter.filter(df, ["key_part1", "key_part2"], ["data_part1", "data_part2"], "ordering_col", keep_first)
        expected_df = spark.createDataFrame(data=expected_data, schema=schema)

        assert dfu.is_data_identical(expected_df, result_df)
