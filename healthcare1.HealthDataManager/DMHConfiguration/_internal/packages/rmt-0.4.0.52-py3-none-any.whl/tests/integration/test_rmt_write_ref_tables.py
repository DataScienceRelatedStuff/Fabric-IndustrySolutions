import shutil
import tempfile
from typing import List, Tuple

import pytest
from pyspark.sql.types import IntegerType, StringType

from rmt.app.reference_tables_creator import ReferenceTablesCreator
from rmt.contract.configuration.reference_table import ReferenceTable, TableColumn
from rmt.file_model.tables_creating.reference_tables_data_file_reader import ReferenceTablesDataFileReader
from tests.common.tester_file_system_client import TesterFileSystemClient

table_name = "reftable1"
table2_name = "Country"


@pytest.fixture(scope="function")
def target_path():
    return tempfile.mkdtemp()


@pytest.fixture(scope="function")
def reference_tables_data_tmp_folders() -> Tuple[str, str, str]:
    parent_folder1 = tempfile.mkdtemp()
    parent_folder2 = tempfile.mkdtemp()
    parent_folder3 = tempfile.mkdtemp(dir=parent_folder1)
    return (parent_folder1, parent_folder2, parent_folder3)


@pytest.fixture(scope="session")
def tests_data_dir(tests_data_dir):
    return tests_data_dir / "reference_tables_data_integration"


@pytest.fixture(scope="function")
def reference_tables_root_folders(reference_tables_data_tmp_folders, tests_data_dir):
    parent_folder1, parent_folder2, parent_folder3 = reference_tables_data_tmp_folders
    shutil.copy2(tests_data_dir / f"{table_name}.json", parent_folder1)
    shutil.copy2(tests_data_dir / "subfolder" / f"{table_name}.json", parent_folder2)
    shutil.copy2(tests_data_dir / f"{table2_name}.json", parent_folder3)
    return [parent_folder1, parent_folder2]


key_field = "TypeId"
key2_field = "CountryId"
name_field = "TypeName"
description_field = "Description"
name2_field = "iso3DigitCountryCode"
name3_field = "IsoCountryName"
ref_tables = {
    table_name: ReferenceTable(
        table_name=table_name,
        key_field=key_field,
        name_field=name_field,
        columns=[
            TableColumn(name=key_field, type=IntegerType(), is_nullable=False),
            TableColumn(name=name_field, type=StringType(), is_nullable=False),
            TableColumn(name=description_field, type=StringType(), is_nullable=True),
        ],
    ),
    table2_name: ReferenceTable(
        table_name=table2_name,
        key_field=key2_field,
        name_field=name2_field,
        columns=[
            TableColumn(name=key2_field, type=IntegerType(), is_nullable=False),
            TableColumn(name=name2_field, type=IntegerType(), is_nullable=False),
            TableColumn(name=name3_field, type=StringType(), is_nullable=False),
        ],
    ),
}


class TestRMTWriteRefTables:
    def test_write_multiple_ref_tables(self, spark, target_path: str, reference_tables_root_folders: List[str]):
        tables_reader = ReferenceTablesDataFileReader(
            file_system_client=TesterFileSystemClient("test_write_multiple_ref_tables"),
            reference_tables_data_folders=reference_tables_root_folders,
        )
        ReferenceTablesCreator.create_reference_data_tables(
            spark, target_path, ref_tables, tables_reader=tables_reader
        )
        df = spark.read.format("delta").load(f"{target_path}/{table_name}")
        df2 = spark.read.format("delta").load(f"{target_path}/{table2_name}")
        assert sorted((r.TypeId, r.TypeName) for r in df.select("TypeId", "TypeName").collect()) == [
            (1001, "Group"),
            (1002, "Department"),
            (1003, "Cost Center"),
            (10000000, "Unit"),
            (10000001, "Team"),
            (10000002, "Division"),
        ]
        assert sorted(
            (r.CountryId, r.iso3DigitCountryCode, r.IsoCountryName)
            for r in df2.select("CountryId", "iso3DigitCountryCode", "IsoCountryName").collect()
        ) == [(4, 4, "Afghanistan"), (8, 8, "Albania"), (12, 12, "Algeria")]
