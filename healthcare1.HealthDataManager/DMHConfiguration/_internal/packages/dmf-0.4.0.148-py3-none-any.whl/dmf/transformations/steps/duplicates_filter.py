from typing import List

from pyspark.sql import Column, DataFrame, Window
from pyspark.sql import functions as F


class DuplicatesFilter:
    ROW_NUM_COLUMN_NAME: str = "rownum"

    @staticmethod
    def filter(df: DataFrame, key_col_names: List[str], data_col_names: List[str], ordering_col_name: str,
               keep_latest: bool = False) -> DataFrame:
        """
        This method assumes that it receives a DataFrame that contains only 1 update per day per a PK.
        The method identifies repeating values in 'data_col_names' columns and leaves only the most recent record
        if keep_latest=true, otherwise leaves only the oldest record
        """
        if not df:
            raise ValueError("Source Dataframe is not defined")

        if not key_col_names:
            raise ValueError("Key columns list cannot be empty")

        if not data_col_names:
            raise ValueError("Data columns list cannot be empty")

        if not ordering_col_name:
            raise ValueError("Ordering column name is not defined")

        partitioning_cols = [F.col(col_name) for col_name in key_col_names]
        adjacent_values_enriched_df = DuplicatesFilter._fill_adjacent_values(
            df,
            partitioning_cols,
            data_col_names,
            ordering_col_name,
            keep_latest)
        row_numbered_df = DuplicatesFilter._enrich_row_number(
            adjacent_values_enriched_df,
            partitioning_cols,
            ordering_col_name,
            keep_latest)

        joined_filter = " ".join([
            DuplicatesFilter._non_repeating_entries_filter(data_col_names, keep_latest),
            "or",
            DuplicatesFilter._first_entry_in_partition_filter()
        ]
        )

        final_df = row_numbered_df.filter(joined_filter).select(df.columns)
        return final_df

    @staticmethod
    def _first_entry_in_partition_filter() -> str:
        return f"{DuplicatesFilter.ROW_NUM_COLUMN_NAME} == 1"

    @staticmethod
    def _non_repeating_entries_filter(data_col_names: List[str], keep_latest: bool) -> str:
        filters = []
        for data_col_name in data_col_names:
            filters.append(
                f"{data_col_name} <=> {DuplicatesFilter._adjacent_value_col_name(data_col_name, keep_latest)}")
        return "not(" + " AND ".join(filters) + ")"

    @staticmethod
    def _enrich_row_number(df: DataFrame, partitioning_cols: List[Column], ordering_col_name: str,
                           keep_latest: bool) -> DataFrame:
        """
        This method uses Window to order records for partitions defined by 'partitioning_cols'
        orders them in a reverse order and adds rownum. The entry with rownum = 1 is the first entry in the partition
        """
        if keep_latest:
            ordered_column = F.col(ordering_col_name).desc()
        else:
            ordered_column = F.col(ordering_col_name).asc()

        window = Window.partitionBy(*partitioning_cols).orderBy(ordered_column)
        df_with_row_num = df.select('*', F.row_number().over(window).alias(DuplicatesFilter.ROW_NUM_COLUMN_NAME))
        return df_with_row_num

    @staticmethod
    def _fill_adjacent_values(df: DataFrame, partitioning_cols: List[Column], data_col_names: List[str],
                              ordering_col_name: str, keep_latest: bool) -> DataFrame:
        """
        This method uses Window to enrich given 'df' DataFrame with data values of the adjacent record
        """
        if keep_latest:
            ordered_column = F.col(ordering_col_name).asc()
        else:
            ordered_column = F.col(ordering_col_name).desc()

        window = Window.partitionBy(*partitioning_cols).orderBy(ordered_column)

        extended_df = df
        for data_col_name in data_col_names:
            extended_df = extended_df.select(
                "*",
                F.lead(F.col(data_col_name))
                .over(window)
                .alias(DuplicatesFilter._adjacent_value_col_name(data_col_name, keep_latest))
            )

        return extended_df

    @staticmethod
    def _adjacent_value_col_name(orig_col_name: str, keep_latest: bool) -> str:
        if keep_latest:
            return f"next_{orig_col_name}"
        return f"previous_{orig_col_name}"

# SIG # Begin Windows Authenticode signature block
# MIIoLAYJKoZIhvcNAQcCoIIoHTCCKBkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDU+Q7jJJ23w6se
# bWEoypmb3GUodkKRf+ZTKwHSpkdGsKCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIMB1Bh+wu++4ZqOFxYBBoiK6
# QUyRnxg0+q3PiBPT4NzWMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAJexFRd06LijralV0nUt8M40pooezdieyc5a/6peC09V8qrjIP6IkOGvn
# 3Sx15Tv7IIlgzlfCqPAvQUnDJcZAW5FbWBMSLa1IYRxsfVdvvtjRAPBpMGZOZVMH
# iEC1cR/FJrCZOUm4Du0Jw76JH9yQX7jztLoMwky6QhSU40Ya7StP4+cAHGb6aKbc
# 9vfHRFxWRREofZ4o/2BkqdQruKgweKObpS2xedQ6CsGJmNNOYXmpHjF+8tu7891O
# eS2DCYiDWu26YCWI0jjFTlM8brUhA5PUsy0OBedcIsCtPMsYYuaORPwCfiFV/iY5
# 0ytPChY09tHq4YNhifD14hgK7TchnaGCF5YwgheSBgorBgEEAYI3AwMBMYIXgjCC
# F34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCC6fqAMgeoXdQ4ML7Ncb4YGqMa+K3BHR2+MTAztvVR2owIGZXsRVFP2
# GBIyMDI0MDExMDEzMTQwOS4wNlowBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo4OTAwLTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# Ee0wggcgMIIFCKADAgECAhMzAAAB0x0ymhc7QDBzAAEAAAHTMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIzMDUyNTE5MTIy
# NFoXDTI0MDIwMTE5MTIyNFowgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo4OTAwLTA1RTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALSOq5M3iDXFuFcJzwxX5067xSpzcpttpa2Lm92wBYzU
# Ph9VKL7g1aAa0/8FVFitWPahWeczLR5rOJ1A4ni5SxwExs8dozFo2mBtEb0URBEW
# dwBSm1acj5U+Xnc8Pow8vTLPxwcLZkPfB4XjD64wMAacvfoGSbSys41e+cz142+c
# bl2OikSqIeh1ZJq5HJ7i5+0FHaxPAYdWbEq7QZLh87zs2BsnhUbMgJHJlfD35G+9
# cwb+OEzXUfwBYrMqmfSgwabUxIx428tRZvfUdJl6TH80ES1e+Z2jvk5XTfQ0eAhe
# KHFgR5KBQjF9sjk6aAyr9UMJCnav9/L/k1VrcqMJCg2qaYQzqisAnZcqNiEQnOin
# idYJwn3vRTqtekE8rhcY0oEWGEtrvhMz/KxMUisRc4kbV9S5d9x1ZvQTHQUB5NOv
# qCaYKqt4k16M0d98b9UR4Xss29Sq5gVGd2IJSGDLrbitbqm1ydBOJF8TRAv+AsXj
# WQDa9kxjNxzXoSJhdBAFoXdcC0x26HV2lepM89AQ7cyzn/kH8q2OFKykxw9S9G9v
# fkhY36r4v7MTCKmGacIYVO7I4ypzlATSu4Y3czHRW/rH+Fw6ZpfGsdAak0ojk+fv
# 1iTz0ByWpTaZcfPVkdan4oFzcPpU/svfYmXDGEnHdqxrTznG/Rc8PnwxFbVZoa9p
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQU0scghrgUAPj3jPfmG/MKabTjXmIwHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBAEBiWFihRD7hppDngwU18ToTLy/ita/4u0NF
# KMwzZf2Di5qcD1xTtWK12kg9X/MTq/gASF79WeDZQBHmqPZJXezP58Oo3pUtZRmw
# pHRBHYlhcqcU9FWPXp7NnI/vN3kfwiy+xwRyid5f5pEcXTEYYzi0MutLzi+PpGbR
# uChYtdacxNnmQ/ijCcaabQuyYie67QYqsNmeR5NWZ+TyBNPLx3XLc/YhhzZQjiIl
# hcK5JooK4V47TCrKxym+EZBKejVcAUrehrJu4PWZKhDFP2rvv4sAYZBuJKgaWBON
# BBrJixBo9wbVDhA3A40aqQBIJlNvMmWeaQeCRaUpItO6U5qKVYhjiFLURn7D6xfQ
# En0twzXjaHnU6Vcsyg8unMcBvrHbaKloAnkp/e7IVo4pbDiGe7TNaz48o93X3ad1
# 4raiBZ9oV1+cS+RYMMfZ2gv5kDlAF3xeeCz+Z3cGueWXYGRn+CJkT98rKiWuJHdp
# MBYLEUJcoiX8KW7ZtueP2p9VgukBVARw9oJ9MB/s5kGVeaW4RO+rVj9I2HELownV
# AsKeRdIj/+JdimZEpPvzdApGCaj/jO2Pe4v1nvFtsbEhKD4/QdNFfXnLhNF4Fs7Z
# EU3IKPzyA45GT6zBPWRopdR8YHjOODle6XFJvLe4s3FB5sTpMTdwArT5+djlSkdo
# R2XDh7uKMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA1Aw
# ggI4AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046ODkwMC0wNUUwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAFLH
# bdwxw0HUhDCz8tiRFdrsjkmwoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDpSH6wMCIYDzIwMjQwMTEwMDIyNTUy
# WhgPMjAyNDAxMTEwMjI1NTJaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOlIfrAC
# AQAwCgIBAAICFiICAf8wBwIBAAICFCMwCgIFAOlJ0DACAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQsFAAOCAQEAkiskP1mVvNsCuanMynvWrCDm4e9gmQxnt2JAaXT6W1XK
# E+kftgHARrqXT1c8UqD0lhXcpNU+kXLZOiSnEELv8c7rc6nx8bpY6HPe6UmJwZ76
# pz9ikZsitVbcUs5MzXVaCB2bbHL8jv4JJ/KKhX9auXAVc2aMgu5Gi2eRy/HWJpGG
# qeQ1bbkeg/zaZLl0RrCtxj4ypIlK8/E+w4eNrgz4XTcK08kh5Pa1zYFiusGFqz4b
# 7MsaA378FmJspmpCkOT3kDYUnQKvlwgcLhl4T9ru9MGhWJYm8oIqrUT3bZOoU4Vn
# vxhZu1+kGAvFAZp/+QikyUrwDCnFEyLfSAoEpSj/OjGCBA0wggQJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB0x0ymhc7QDBzAAEAAAHT
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEID2339fap767CEWFvvWR5SIU8VgLWZnlxhVbzrRB7qSH
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgkmb06sTg7k9YDUpoVrO2v24/
# 3qtCASf62Aa1jfE6qvUwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAdMdMpoXO0AwcwABAAAB0zAiBCCOEwK2EEqk5V86oFP3q3klfIxu
# M43/qWopnUwn4PbgtDANBgkqhkiG9w0BAQsFAASCAgCho9LcBZOdxPWOunntXkKb
# 5I3GjW3tJ6OqJTQ4s3IKw9tCYilNOlFwbGgu2UtVg+334OuDYjd4GCKeqnxNe8J+
# U8l10y7lVHgu1BH5YI2iT2fwpiApqe4PZ0vsdXeheCqXFU7BiDodBdnTr9mpf5JC
# 7WoxpUo3iOz0LZnTwlgvO3J3I6sngygCueWl3aH8FcfggkeMH6WtE+Aca0FkaK9z
# efazZFkULzTyxSkOokZXWU8hzyv7qDxtxD9+DywVRPeFJMmH65IZcmCXpJQxQTeM
# D6oFGgHQnC7yuG5nVQeJ3qBX+Oq5gdreRnCjrUf2+Bz+y3bj4a5K313vShBJi5Cg
# D5W33jfmkNws0g+PtybFLvsY8HsxAjdsRPH4thFINj+hv3QC2hw6av3LJMooLoBp
# 3C+6mDctulmNrXFmHPUMzi/+gmdgRACeoPfcUB9t/Vmp6AtI6f73dY8WejEaBBg9
# ba+VjBi1ubVhecuE9aqyWW2551czum66b0hpkRLDgNeUTm1YVH/DnkZ0XzalrKF7
# AmPWynfnBxVJt0SWzZ496G0sKoOISSv5O6BvGvPm2kDU9OYuwdiJ2ahIGI0ZuCeI
# QHH2+L5B8Nsa3E1y0yf+yiWSVwol+gUUFQPwFvLw2olbsW6pBVOUgHHN3Ud7skpk
# YDITs3bJDD4t7g8Bc+YEtg==
# SIG # End Windows Authenticode signature block