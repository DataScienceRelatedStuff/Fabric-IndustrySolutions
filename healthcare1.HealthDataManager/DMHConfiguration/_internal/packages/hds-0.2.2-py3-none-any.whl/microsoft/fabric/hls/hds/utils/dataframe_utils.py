# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
DataFrame utilities
"""
import re
from typing import List, Optional, Union
from pyspark.sql import DataFrame, Column, SparkSession
from pyspark.sql.types import StructType, ArrayType, TimestampType
from pyspark.sql.functions import col, to_json, current_timestamp, expr, max as spark_max
from pyspark.sql.utils import AnalysisException
from delta import DeltaTable
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.flatten.normalization import FlattenNormalization
from microsoft.fabric.hls.hds.flatten.constants import FlattenConstants as C
from microsoft.fabric.hls.hds.utils.data_manager_logger import DataManagerLogger


def flatten_struct(
    input_df: DataFrame,
    struct_column_name: str,
    flattened_columns_prefix: str,
    keep_struct_column: bool = False,
) -> DataFrame:
    """
    Flatten structure type
    Arguments:
    - struct_column_name:str - name of the column to flatten
    - flattened_columns_prefix:str - prefix before names of struct type in result dataframe
    - keep_struct_column:bool - should we remove column to flatten or not

    Returns:
    - pyspark.sql.DataFrame - flattened dataframe
    """
    existing_columns: List[Column] = [
        col("`" + c[0] + "`")
        for c in input_df.dtypes
        if (keep_struct_column | ("`" + c[0] + "`" != "`" + struct_column_name + "`"))
    ]
    flattened_columns: List[Column] = [
        col("`" + struct_column_name + "`" + "." + c).alias(
            flattened_columns_prefix + c
        )
        for c in input_df.select("`" + struct_column_name + "`" + ".*").columns
    ]

    return input_df.select(existing_columns + flattened_columns)

def stringify_complex_types(input_df: DataFrame) -> DataFrame:
    """
    Stringify the complex field types and append them as new
    columns with postfix "_string" in the dataframe

    Args:
    - input_df: DataFrame - Dataframe for processing.
    """

    # get all the complex type fields in the dataframe like array, structs
    complex_fields = [
        field.name
        for field in input_df.schema.fields
        if isinstance(field.dataType, ArrayType)
        or isinstance(field.dataType, StructType)
    ]

    return input_df.select(
        [col("*")]
        + [
            to_json(col(colname), options={"ignoreNullFields": False}).alias(
                f"{colname}_string"
            )
            for colname in complex_fields
        ]
    )


def flatten_all_dataframe_struct(input_df: DataFrame) -> DataFrame:
    """Flatten a dataframe complex type (StructType) with nested columns.
    It will check that generated column names are unique.
    Arguments:
    - input_df: pyspark.sql.DataFrame - dataframe to flatten

    Returns:
    - pyspark.sql.DataFrame - flattened dataframe
    """

    def generate_unique_column(proposed_name, input_columns):
        """Generate a unique column name."""
        if proposed_name not in input_columns:
            return proposed_name
        else:
            return generate_unique_column(proposed_name + "_", input_columns)

    # get the complex fields of StructType in the dataframe
    complex_fields = dict(
        [
            (field.name, field.dataType)
            for field in input_df.schema.fields
            if isinstance(field.dataType, StructType)
        ]
    )

    # flatten the complex fields
    for col_name, complex_field in complex_fields.items():
        expanded = [
            col("`" + col_name + "`" + "." + k).alias(
                generate_unique_column(col_name + "_" + k, input_df.columns)
            )
            for k in [n.name for n in complex_field]
        ]

        input_df = input_df.select("*", *expanded)
    return input_df


def drop_flattened_columns(
    input_df: DataFrame, struct_column_name: str, flattened_columns_prefix: str
) -> DataFrame:
    """
    Drop columns received after flattening with func flatten_struct
    """
    flattened_columns: List[str] = [
        flattened_columns_prefix + c
        for c in input_df.select(struct_column_name + ".*").columns
    ]

    return input_df.drop(*flattened_columns)


def sanitize_df_columns(input_df: DataFrame) -> DataFrame:
    """
    # We may need to replace '.' with '_' in column names to avoid
    # the error mentioned here - https://mungingdata.com/pyspark/avoid-dots-periods-column-names/
    """
    sanitized_cols = (column.replace(".", "_") for column in input_df.columns)
    return input_df.toDF(*sanitized_cols)


def encode_df_string(input_str: str) -> str:
    """
    Encodes with ` column names with dot(.) in it
        in case string already encoded - it will return it as is
        in case string representing an expression - it will return as is

    Used to encode value which can represent both: columns or expressions
    """
    # already encoded
    if "`" in input_str:
        return input_str
    # match definition of variable with '.' (dots)
    if re.match(pattern=r"^(\w+)(\.\w+)+$", string=input_str):
        return f"`{input_str}`"
    return input_str


def find_managed_delta_table_using_path(
    spark_session: SparkSession, delta_table_path: str
) -> Union[DeltaTable, None]:
    """
    Finds managed delta table by name and database

    Normally we should successfully get DeltaTable object by name, but in case of local
    development and using from a different thread we may not be able to find it by name.
    The same time delta table exists in the database and we can find it by location.

    Arguments:
        - spark_session : SparkSession - spark session to access resources/files/load dataframes
        - delta_table_path : str - The path where the Delta table resides or should be created.

    Returns:
        - DeltaTable - delta table object or None if unable to find
    """
    delta_result = None

    try:
        delta_result = DeltaTable.forPath(spark_session, delta_table_path)
    except AnalysisException:
        return delta_result
    return delta_result

def is_delta_table_empty(spark: SparkSession, table_path: str):
    """Check if delta table is empty

    Args:
        spark: spark session
        table_path (str): the path to the delta table

    Returns:
        _type_: _description_
    """
    delta_table = DeltaTable.forPath(spark, table_path)
    return delta_table.toDF().isEmpty()

def create_delta_table_managed_using_path(
    df_to_process: DataFrame,
    delta_table_path: str):
    """Create managed delta table from the dataframe
    
    Args:
        df_to_process (DataFrame): The dataframe to use to create the delta table
        delta_table_path (str): The path where the Delta table resides or should be created.
    """
    
    delta_table_df = df_to_process.limit(0)
    # Create managed delta table from the dataframe
    delta_table_df.write.format("delta").mode(
        "overwrite").save(delta_table_path)

def get_or_create_managed_delta_table_using_path(spark_session: SparkSession,
                                      data_manager_logger: DataManagerLogger,
                                      df_to_process: DataFrame,
                                      delta_table_path: str):
    """
    Retrieves an existing managed Delta table or creates a new one if it doesn't exist.
    
    Parameters:
    - spark_session (SparkSession): The active Spark session.
    - delta_table_path (str): The path where the Delta table resides or should be created.
    - df_to_process (DataFrame): The DataFrame used to create the Delta table if it doesn't exist.
    
    Returns:
    - DeltaTable: The retrieved or newly created Delta table.
    
    Raises:
    - ValueError: If the Delta table cannot be created or retrieved.
    """
    # Try to get Delta table if it exists, otherwise create it
    try:
        delta_table = find_managed_delta_table_using_path(spark_session=spark_session,
                                               delta_table_path=delta_table_path)
    except AnalysisException:
        delta_table = None

    # If we can't find it, let's create it
    if not delta_table:
        create_delta_table_managed_using_path(delta_table_path=delta_table_path,
                                   df_to_process=df_to_process)
        try:
            delta_table = find_managed_delta_table_using_path(spark_session=spark_session,
                                                   delta_table_path=delta_table_path)
        except AnalysisException:
            delta_table = None

    if not delta_table:
        data_manager_logger.error(
            f"{LC.CREATING_AND_FINDING_DATABASE_ERR_MSG} {delta_table_path}")
        raise ValueError(
            f"{LC.CREATING_AND_FINDING_DATABASE_ERR_MSG} {delta_table_path}")

    return delta_table

def find_managed_delta_table_using_name(
    spark_session: SparkSession, delta_table_name: str, delta_database: Union[str, None]
) -> Union[DeltaTable, None]:
    """
    Finds managed delta table by name and database

    Normally we should successfully get DeltaTable object by name, but in case of local
    development and using from a different thread we may not be able to find it by name.
    The same time delta table exists in the database and we can find it by location.

    Arguments:
        - spark_session : SparkSession - spark session to access resources/files/load dataframes
        - delta_table_name : str - name of the delta table, where to save dataframe
        - delta_database : str - name of the database, where delta table is located

    Returns:
        - DeltaTable - delta table object or None if unable to find
    """
    delta_result = None

    # Construct full Delta table name
    full_delta_table_name = (
        f"`{delta_database}`.`{delta_table_name}`"
        if delta_database
        else f"`{delta_table_name}`"
    )

    try:
        delta_result = DeltaTable.forName(spark_session, full_delta_table_name)
    except AnalysisException:
        # lets see if we can find it in the database
        # todo: check in the next version of Delta Lake if we can find it by name
        list_tables = spark_session.catalog.listTables(delta_database)
        if list_tables:
            if delta_table_name in [table.name for table in list_tables]:
                # find details about location fo the delta table
                location = (
                    spark_session.sql(f"DESCRIBE DETAIL {full_delta_table_name}")
                    .select("location")
                    .collect()[0][0]
                )
                if location:
                    delta_result = DeltaTable.forPath(spark_session, location)
    return delta_result


def create_delta_table_managed_using_name(
    df_to_process: DataFrame,
    delta_table_name: str,
    delta_database: Union[str, None] = None,
):
    """
    Create managed delta table from the dataframe
    (location is specified by delta_database and delta_table_name)
    """
    # Construct full Delta table name
    full_delta_table_name = (
        f"`{delta_database}`.`{delta_table_name}`"
        if delta_database
        else f"`{delta_table_name}`"
    )
    delta_table_df = df_to_process.limit(0)
    # Create managed delta table from the dataframe
    delta_table_df.write.format("delta").mode(
        "overwrite").saveAsTable(full_delta_table_name)

def get_or_create_managed_delta_table_using_name(spark_session: SparkSession,
                                      data_manager_logger: DataManagerLogger,
                                      df_to_process: DataFrame,
                                      delta_table_name: str,
                                      delta_database: Union[str, None] = None):
    """
    Retrieves an existing managed Delta table or creates a new one if it doesn't exist.
    
    Parameters:
    - spark_session (SparkSession): The active Spark session.
    - delta_database (str): The name of the database where the Delta table resides or should be created.
    - delta_table_name (str): The name of the Delta table to retrieve or create.
    - df_to_process (DataFrame): The DataFrame used to create the Delta table if it doesn't exist.
    
    Returns:
    - DeltaTable: The retrieved or newly created Delta table.
    
    Raises:
    - ValueError: If the Delta table cannot be created or retrieved.
    """
    # Construct full Delta table name for error logging
    full_delta_table_name = f"`{delta_database}`.`{delta_table_name}`" if delta_database else f"`{delta_table_name}`"

    # Try to get Delta table if it exists, otherwise create it
    try:
        delta_table = find_managed_delta_table_using_name(spark_session=spark_session,
                                               delta_table_name=delta_table_name,
                                               delta_database=delta_database)
    except AnalysisException:
        delta_table = None

    # If we can't find it, let's create it
    if not delta_table:
        create_delta_table_managed_using_name(delta_database=delta_database,
                                   delta_table_name=delta_table_name,
                                   df_to_process=df_to_process)
        try:
            delta_table = find_managed_delta_table_using_name(spark_session=spark_session,
                                                   delta_table_name=delta_table_name,
                                                   delta_database=delta_database)
        except AnalysisException:
            delta_table = None

        if not delta_table:
            data_manager_logger.error(
                f"{LC.CREATING_AND_FINDING_DATABASE_ERR_MSG} {full_delta_table_name}")
            raise ValueError(
                f"{LC.CREATING_AND_FINDING_DATABASE_ERR_MSG} {full_delta_table_name}")

    return delta_table

def add_current_timestamp_column(input_df: DataFrame, column_name: str):
    """
    Add a new column with the current timestamp to the DataFrame.

    Parameters:
    - df: The input DataFrame.
    - column_name: The name of the new column.

    Returns:
    - DataFrame with the new column.
    """
    
    return input_df.withColumn(column_name, current_timestamp())

def add_normalized_current_timestamp_column(spark_session: SparkSession, 
                                            input_df: DataFrame,
                                            column_name: str):
    """
    Add a new column with the current timestamp to the DataFrame.

    Parameters:
    - df: The input DataFrame.
    - column_name: The name of the new column.

    Returns:
    - DataFrame with the new normalized timestamp column.
    """
    def __check_udf_registered(udf_name: str) -> bool:
        """
        Check if UDF is registered in spark session
        """
        return udf_name in [func.name for func in spark_session.catalog.listFunctions()]
    
    if not __check_udf_registered(C.NORM_UDF_NORM_DATE):
        spark_session.udf.register(
            C.NORM_UDF_NORM_DATE, FlattenNormalization.normalize_date, TimestampType())

    # Add a new column with the current timestamp to the DataFrame.
    input_df = add_current_timestamp_column(input_df=input_df, column_name=column_name)
    
    # Normalize the timestamp column
    norm_expression = f"{C.NORM_UDF_NORM_DATE}(`{column_name}`)"
    
    return input_df.withColumn(colName=column_name, col=expr(norm_expression))

def append_unique_to_delta_managed_using_name(spark_session: SparkSession,
                                   data_manager_logger: DataManagerLogger,
                                   df_to_process: DataFrame,
                                   delta_table_name: str,
                                   unique_columns: List[str],
                                   delta_database: Union[str, None] = None):
    """
    Append a dataframe to managed delta table (inserts only new rows)
    (location is specified by delta_database and delta_table_name)

    Arguments:
    - spark_session : SparkSession - spark session to access resources/files/load dataframes
    - data_manager_logger : DataManagerLogger - logger to log messages
    - df_to_process : DataFrame - dataframe to save
    - delta_table_name : str - name of the delta table, where to save dataframe
    - unique_columns : List[str] - a set of columns that uniquely identify a row.
        The same set of these columns in the row will not be updated in delta table
    - delta_database : str (optional) - name of the delta database, where to save dataframe.
    It is optional, if not specified, delta table will be saved in the default database
    default database is specified in spark.sql.defaultDatabase property like
    `spark_session.conf.set("spark.sql.catalog.spark_catalog.currentDatabase", delta_database)`
    """

    # Try to get Delta table if it exists, otherwise create it
    delta_table = get_or_create_managed_delta_table_using_name(spark_session=spark_session,
                                                    data_manager_logger=data_manager_logger,
                                                    df_to_process=df_to_process,
                                                    delta_table_name=delta_table_name,
                                                    delta_database=delta_database
                                                    )
    
    if not unique_columns:
        data_manager_logger.error(LC.EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG)
        raise ValueError(LC.EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG)

    merge_condition = " AND ".join(
        f"delta_table.{col_name} IS NOT DISTINCT FROM df_to_process.{col_name}"
        for col_name in unique_columns
    )

    # Create a list of values for the INSERT clause
    value_list = {f"`{col}`": f"df_to_process.`{col}`" for col in df_to_process.columns}

    delta_table.alias("delta_table").merge(
        df_to_process.alias("df_to_process"), merge_condition
    ).whenNotMatchedInsert(values=value_list).execute()  # type: ignore
    
def append_unique_to_delta_managed_using_path(spark_session: SparkSession,
                                   data_manager_logger: DataManagerLogger,
                                   df_to_process: DataFrame,
                                   unique_columns: List[str],
                                   delta_table_path: str):
    """
    Append a dataframe to managed delta table (inserts only new rows)
    (location is specified by delta_database and delta_table_name)

    Arguments:
    - spark_session : SparkSession - spark session to access resources/files/load dataframes
    - data_manager_logger : DataManagerLogger - logger to log messages
    - df_to_process : DataFrame - dataframe to save
    - unique_columns : List[str] - a set of columns that uniquely identify a row.
        The same set of these columns in the row will not be updated in delta table
    - delta_table_path : str - The path to the delta database
    """

    # Try to get Delta table if it exists, otherwise create it
    delta_table = get_or_create_managed_delta_table_using_path(spark_session=spark_session,
                                                    data_manager_logger=data_manager_logger,
                                                    df_to_process=df_to_process,
                                                    delta_table_path=delta_table_path
                                                    )
    if not unique_columns:
        data_manager_logger.error(
            LC.EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG)
        raise ValueError(LC.EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG)

    merge_condition = ' AND '.join(
            f"delta_table.{col_name} = df_to_process.{col_name}" for col_name in unique_columns)

    delta_table.alias("delta_table").merge(
        source=df_to_process.alias("df_to_process"), condition=merge_condition
    ).whenNotMatchedInsertAll().execute()  # type: ignore


def upsert_unique_to_delta_managed(spark_session: SparkSession,
                                    data_manager_logger: DataManagerLogger,
                                    df_to_process: DataFrame,
                                    delta_table_path: str,
                                    unique_columns: List[str],
                                    **kwargs):
    """
    Upserts data from a source DataFrame into a Delta table based on unique columns. 
    The dataframe should only contain unique records
    
    Parameters:
    - spark_session: Active Spark session.
    - data_manager_logger: Logger for capturing logs.
    - df_to_process: Source DataFrame to be upserted.
    - delta_table_path: The path to the target delta table.
    - unique_columns: List of columns that define uniqueness for upsert.
    - delta_database: Optional database name where the Delta table resides.
    - kwargs: dict - An optional dictionary of keyword arguments 
            to pass to the upsert_unique_to_delta_managed:
                - source_modified_on_column: Timestamp column of when the source data was last modified. 
                Used to identify the latest version of the source data. Default is 'meta_lastUpdated'

    Returns:
    None
    """
    
    # Add the normalized modified_date column with the current timestamp
    # we need to add it at the beginning of the process to ensure delta schema will have it
    df_to_process = add_normalized_current_timestamp_column(spark_session=spark_session,
                                                            input_df=df_to_process,
                                                            column_name=GC.DEFAULT_SILVER_MODIFIED_DATE_COL)
    
    # By default 'meta_lastUpdated' is the timestamp column for Silver tables
    source_timestamp_column = kwargs.get("source_modified_on_column", GC.DEFAULT_SOURCE_MODIFIED_ON_COLUMN)
    delta_table = get_or_create_managed_delta_table_using_path(spark_session=spark_session,
                                                        data_manager_logger=data_manager_logger,
                                                        df_to_process=df_to_process,
                                                        delta_table_path=delta_table_path
                                                        )
    if not unique_columns:
        data_manager_logger.error(LC.EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG)
        raise ValueError(LC.EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG)
    
    # Prepare the source data by filtering for only one unique record
    df_to_process = prepare_source_data(input_df=df_to_process,
                                        data_manager_logger=data_manager_logger,
                                        unique_columns=unique_columns,
                                        full_delta_table_path=delta_table_path,
                                        timestamp_column=source_timestamp_column)

    merge_condition = ' AND '.join(
            f"delta_table.{col_name} = df_to_process.{col_name}" for col_name in unique_columns)

    # Define the update condition to ensure only the latest records are retained
    update_condition = f"delta_table.{source_timestamp_column} < df_to_process.{source_timestamp_column}"

    # Perform the merge operation
    delta_table.alias("delta_table").merge(
    source=df_to_process.alias("df_to_process"), condition=merge_condition
    ).whenMatchedUpdateAll(condition=update_condition
    ).whenNotMatchedInsertAll().execute()

def prepare_source_data(input_df: DataFrame,
                        data_manager_logger: DataManagerLogger,
                        unique_columns: Optional[List[str]] = None,
                        full_delta_table_path: str = None,
                        timestamp_column: str = GC.DEFAULT_SOURCE_MODIFIED_ON_COLUMN
                        ) -> DataFrame:
    """
    Prepares the source data by retaining only the latest records based on unique columns.
    
    Parameters:
    - input_df: Source DataFrame.
    - data_manager_logger: Logger for capturing logs.
    - unique_columns: List of columns that define uniqueness.
    - full_delta_table_name: Full delta table name.
    - timestamp_column: Column name representing the timestamp. Default is "meta_lastUpdated".
    
    Returns:
    DataFrame with only the latest records.
    """
    
    # Ensure df is a DataFrame
    if not isinstance(input_df, DataFrame):
        raise ValueError(LC.UPSERT_UNIQUE_TO_DELTA_MANAGED_ERR_MSG)
    
    if unique_columns is None:
        unique_columns = GC.DEFAULT_SILVER_UNIQUE_COLUMNS

    df_latest = input_df
    pre_filtered_df_count = input_df.count()
    
    if pre_filtered_df_count > 1:
        # Find the latest timestamp for each unique key
        latest_timestamps = input_df.groupBy(*unique_columns).agg(spark_max(timestamp_column).alias("latest_timestamp"))
        
        # Join the original DataFrame with the latest timestamps to filter out only the latest unique records
        df_latest = input_df.join(latest_timestamps, on=unique_columns). \
                        where(input_df[timestamp_column] == latest_timestamps["latest_timestamp"]). \
                        drop("latest_timestamp"). \
                        dropDuplicates(subset=unique_columns)
                            
        
        # Get the number of filtered records
        filtered_record_count = pre_filtered_df_count - df_latest.count()
        data_manager_logger.info(LC.UPSERT_UNIQUE_TO_DELTA_MANAGED_INFO_MSG.format(delta_table_path=full_delta_table_path, record_count=filtered_record_count))
    
    return df_latest

def append_to_delta_table_using_path(
    df_to_process: DataFrame,
    delta_table_path: str,
    logger:DataManagerLogger
):
    """
    Write the dataframe to delta_table_path.
    Merges schema if dataframe schema is different from the table in the path.

    Arguments:
    - df_to_process : DataFrame - dataframe to save
    - delta_table_path: the path to the delta table
    - logger - DataManagerLogger to use
    """
    
    if df_to_process is not None:
        df_to_process = add_current_timestamp_column(input_df=df_to_process, column_name=GC.DEFAULT_BRONZE_CREATED_DATE_COL)

    logger.info(f'{LC.SAVE_DELTA_TABLE_TO_PATH_INFO_MSG.format(table_path=delta_table_path)}')
    df_to_process.write.option("mergeSchema", "true").mode("append").format(
        "delta"
    ).save(delta_table_path)

def has_schema_evolved(current_schema: StructType, incoming_schema: StructType) -> bool:
    """
    Checks if the incoming schema is a subset of the current schema.
    All fields in the incoming schema must be present in the current schema.
    Handles nested StructType and ArrayType.

    Parameters:
    current_schema (StructType): The current schema.
    incoming_schema (StructType): The incoming schema.

    Returns:
    bool: False if the incoming schema is a subset of the current schema, True otherwise.
    """
    def flatten_schema(schema: StructType, prefix: str = '') -> dict:
        """
        Flattens a Spark StructType schema into a dictionary for easier comparison.
        """
        fields = {}
        for field in schema.fields:
            field_name = prefix + field.name
            if isinstance(field.dataType, StructType):
                fields.update(flatten_schema(field.dataType, prefix=field_name + "."))
            elif isinstance(field.dataType, ArrayType) and isinstance(field.dataType.elementType, StructType):
                fields.update(flatten_schema(field.dataType.elementType, prefix=field_name + "."))
            else:
                    fields[field_name] = field.dataType.simpleString()
        return fields

    current_schema_flat = flatten_schema(current_schema)
    incoming_schema_flat = flatten_schema(incoming_schema)

    # Check if every field in incoming_schema is in current_schema
    for field, dtype in incoming_schema_flat.items():
        if field not in current_schema_flat or current_schema_flat[field] != dtype:
            return True
    return False