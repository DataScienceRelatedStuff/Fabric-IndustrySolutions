class NLPFailedError(Exception):
    """Exception raised for errors when NLP fails.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message="NLP failed."):
        self.message = message
        super().__init__(self.message)