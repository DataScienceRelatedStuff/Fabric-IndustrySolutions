import pytest
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, Row, TimestampType
from dmf.transformations.steps.target_changeable_selector import TargetChangeableSelector


class TestTargetChangeableSelector:
    
    _source_data = [
        ("a", "1", "s3", "s4"),
        ("a", "2", "s3", "s4"),
        ("b", "1", "s1", "s2"),
    ]
    _target_data = [
        ("a", "1", "t3", "t4", datetime(2022, 1, 2)),
        ("a", "1", "t1", "t2", datetime(2022, 1, 1)),
        ("a", "2", "t3", "t4", datetime(2022, 1, 2)),
        ("a", "2", "t1", "t2", datetime(2022, 1, 1)),
        ("c", "1", "t3", "t4", datetime(2022, 1, 2)),
        ("c", "1", "t1", "t2", datetime(2022, 1, 1)),
    ]
        
    _result_row_related_1_last = Row("a", "1", "t3", "t4", datetime(2022, 1, 2))
    _result_row_related_1_not_last = Row("a", "1", "t1", "t2", datetime(2022, 1, 1))
    _result_row_related_2_last = Row("a", "2", "t3", "t4", datetime(2022, 1, 2))
    _result_row_related_2_not_last = Row("a", "2", "t1", "t2", datetime(2022, 1, 1))
    _result_row_not_related_last = Row("c", "1", "t3", "t4", datetime(2022, 1, 2))
    _result_row_not_related_not_last = Row("c", "1", "t1", "t2", datetime(2022, 1, 1))
    
    def test_get_changeable(self, init_data):
        
        result_df = TargetChangeableSelector.get_changeable(
            self._source_df, self._target_df, self._key_names, self._ordering_col_name)
        rows = result_df.orderBy(self._order_by_cols).collect()
        assert rows == [self._result_row_related_1_last,
                        self._result_row_related_2_last]
    
    def test_get_unchangeable(self, init_data):

        result_df = TargetChangeableSelector.get_unchangeable(
            self._source_df, self._target_df, self._key_names, self._ordering_col_name)
        rows = result_df.orderBy(self._order_by_cols).collect()
        assert rows == [self._result_row_related_1_not_last,
                        self._result_row_related_2_not_last,
                        self._result_row_not_related_not_last,
                        self._result_row_not_related_last]
                        
    def test_get_related(self, init_data):

        result_df = TargetChangeableSelector.get_related_to_source(
            self._source_df, self._target_df, self._key_names)
        rows = result_df.orderBy(self._order_by_cols).collect()
        assert rows == [self._result_row_related_1_not_last,
                        self._result_row_related_1_last,
                        self._result_row_related_2_not_last,
                        self._result_row_related_2_last]

    def test_get_unrelated(self, init_data):

        result_df = TargetChangeableSelector.get_unrelated_to_source(
            self._source_df, self._target_df, self._key_names)
        rows = result_df.orderBy(self._order_by_cols).collect()
        assert rows == [self._result_row_not_related_not_last,
                        self._result_row_not_related_last]

    def test_get_last(self, init_data):

        result_df = TargetChangeableSelector._get_last_records(
            self._target_df, self._key_names, self._ordering_col_name)
        rows = result_df.orderBy(self._order_by_cols).collect()
        assert rows == [self._result_row_related_1_last,
                        self._result_row_related_2_last,
                        self._result_row_not_related_last]
    
    def test_get_not_last(self, init_data):

        result_df = TargetChangeableSelector._get_not_last_records(
            self._target_df, self._key_names, self._ordering_col_name)
        rows = result_df.orderBy(self._order_by_cols).collect()
        assert rows == [self._result_row_related_1_not_last,
                        self._result_row_related_2_not_last,
                        self._result_row_not_related_not_last]
    
    @pytest.fixture()
    def init_data(self, spark: SparkSession):
        
        self._ordering_col_name = "modifiedon"
        key_name_1 = "key_1"
        key_name_2 = "key_2"

        source_schema = StructType([
            StructField(key_name_1, StringType(), True),
            StructField(key_name_2, StringType(), True),
            StructField("source_data_1", StringType(), True),
            StructField("source_data_2", StringType(), True),
        ])
        target_schema = StructType([
            StructField(key_name_1, StringType(), True),
            StructField(key_name_2, StringType(), True),
            StructField("target_data_1", StringType(), True),
            StructField("target_data_2", StringType(), True),
            StructField(self._ordering_col_name, TimestampType(), True),
        ])
       
        self._order_by_cols = [key_name_1, key_name_2, self._ordering_col_name]
        self._key_names = [key_name_1, key_name_2]
        self._source_df = spark.createDataFrame(self._source_data, source_schema)
        self._target_df = spark.createDataFrame(self._target_data, target_schema)
        
   