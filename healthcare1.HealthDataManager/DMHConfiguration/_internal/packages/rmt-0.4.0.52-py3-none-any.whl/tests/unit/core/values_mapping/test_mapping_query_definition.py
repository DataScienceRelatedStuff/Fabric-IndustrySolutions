import os

from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType, StructField, StructType

from rmt.core.values_mapping.mapping_query_definition import MappingQueryDefinition, SourceMappingFile
from rmt.core.values_mapping.mapping_schema import MappingSchema
from tests.conftest import TESTS_ROOT_DIR


class TestQueryMappingDefinition:

    def getQueryMappingDefinition(self):
        target_table_name = "concept"
        target_field_name = "concept_id"
        sql = """select cr.concept_id_2 as target_value , concat_ws('<->', c.concept_code, fv.Fhir_Uri) as source_value from concept c
        inner join vocabulary fv on c.vocabulary_id = fv.vocabulary_id left outer join concept_relationship cr on
        c.concept_id = cr.concept_id_1 and cr.relationship_id = 'Maps to' Union select c.concept_id as target_value,
        concat_ws('<->', c.concept_code, fv.Fhir_Uri,'NH') as source_value from CONCEPT c inner join vocabulary fv on
        c.vocabulary_id = fv.vocabulary_id"""
        concept_mapping_file = SourceMappingFile(os.path.join(TESTS_ROOT_DIR, "data", "mapping_data", "concept"), "concept")
        concept_relationship_mapping_file = SourceMappingFile(os.path.join(TESTS_ROOT_DIR, "data", "mapping_data", "concept_relationship"), "concept_relationship")
        vocabulary_mapping_file = SourceMappingFile(os.path.join(TESTS_ROOT_DIR, "data", "mapping_data", "vocabulary"), "vocabulary")

        mapping_definition = MappingQueryDefinition(target_table_name, target_field_name, sql, [concept_mapping_file, concept_relationship_mapping_file, vocabulary_mapping_file])
        return mapping_definition

    def test_to_mapping_dataframe(self, spark: SparkSession):

        mapping_definition = self.getQueryMappingDefinition()
        mapping_dataframe = mapping_definition.to_mapping_dataframe(spark, "HLC")
        assert (
                mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN] == "HLC"
        )
        assert (
            mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE]
            == mapping_definition.target_table_name
        )
        assert (
            mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD]
            == mapping_definition.target_field_name
        )
        assert mapping_dataframe.count() == 15

    def test_remove_null_target_values_no_nulls(self, spark):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "female", "gender", "genderId", 2)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        mapping_dataframe = MappingQueryDefinition.remove_null_target_values(mapping_dataframe)
        assert mapping_dataframe.count() == 2

    def test_remove_null_target_values(self, spark):
        row1 = ("Test", "male", "gender", "genderId", None)
        row2 = ("Test", "female", "gender", "genderId", 2)
        schema_fields = [field for field in MappingSchema.schema.fields if field.name != MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE]
        schema_fields.append(StructField(MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE, IntegerType(), True))
        schema = StructType(schema_fields)
        mapping_dataframe = spark.createDataFrame([row1, row2], schema)
        mapping_dataframe = MappingQueryDefinition.remove_null_target_values(mapping_dataframe)
        assert mapping_dataframe.count() == 1
