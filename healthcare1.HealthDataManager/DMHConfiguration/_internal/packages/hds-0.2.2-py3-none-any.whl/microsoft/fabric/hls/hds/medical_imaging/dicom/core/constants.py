# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class containing constants used through out the package
"""
from pyspark.sql.types import *

class ImagingStudyConstants:
    """
    This class contains constants used through out medical_imaging module
    """
    MAX_BATCH_SIZE_DCM_FILES_DEFAULT = 1000
    MAX_BATCH_SIZE_ARCHIVE_FILES_DEFAULT = 100
    MAX_ARCHIVE_FILE_SIZE_IN_MB_DEFAULT = 100
    DCM_FILES_EXTRACT_FOLDER = "dcm_file_extract"
    
    MAX_THREAD_SIZE_DCM_FILE = 100  
    MAX_THREAD_SIZE_ARCHIVE_EXTRACT_DEFAULT = 50
    MAX_THREAD_SIZE_ARCHIVE_FILES = 2
    
    STATE_STARTED = 'started'
    STATE_COMPLETED = 'completed'
    
    METADATA_EXTRACT_CHECKPOINT_FOLDER = "dicom_metadata_extraction"
    DCM_FILE_DROP_FOLDER = "Ingest"
    
    METADATA_EXTRACTION_PROCESS_NAME = "Metadata Extraction"
    ARCHIVE_EXTRACTION_PROCESS_NAME = "Archive Extraction"

    FAILED_FILES_FOLDER = "failed"
    FAILED_NUM_RETRIES = 2
    
    METADATA_TABLE_NAME = "dicomimagingmetastore"
    FILE_PATH_COLUMN_NAME = "filepath"
    TAGS_JSON_COLUMN_NAME = "metadata"
    ID_COLUMN_NAME = "id"
    
    ERROR_ATTR_NAME = "error"
    DCM_FILE_CONTENT_ATTR_NAME = "content"
    MODIFICATION_TIME_ATTR_NAME = "modificationTime"
    LENGTH_ATTR_NAME = "length"
    PATH_ATTR_NAME = "path"
    FAILED_TAGS_ATTR_NAME = "failedTags"
    EXTRACTED_METADATA_ATTR_NAME = "metadataExtracted"
    
    METADATA_JSON_DICT_SCHEMA = MapType(StringType(), StructType([
            StructField("vr", StringType(), True),
            StructField("Value", ArrayType(StringType(), True), True)
            ]))
    
    DEFAULT_TAGS_AS_COLUMN = [
        'StudyInstanceUID', 'PatientName', 'PatientID', 'PatientBirthDate', 'AccessionNumber', 'ReferringPhysicianName', 
            'StudyDate', 'StudyDescription', 'ModalitiesInStudy', 'SeriesInstanceUID', 'Modality', 'PerformedProcedureStepStartDate', 
                'ManufacturerModelName', 'SOPInstanceUID', 'StudyTime', 'TimezoneOffsetFromUTC', 'NumberOfStudyRelatedSeries', 
                        'NumberOfStudyRelatedInstances', 'SeriesNumber', 'SeriesDescription', 'NumberOfSeriesRelatedInstances', 
                            'BodyPartExamined', 'Laterality', 'SeriesDate', 'SeriesTime', 'SOPClassUID', 'InstanceNumber', 'DocumentTitle'
    ]

    #constants used for dicom metadata to fhir ndjson conversion
    DICOM_TO_FHIR_CHECKPOINT_FOLDER = "dicom_to_fhir"
    AVRO_SCHEMA_FILE_EXT = ".avsc"
    DICOM_TO_FHIR_MAPPING_FILE_NAME = "metadata_fhir_mapping.json"
    
    GROUP_BY_ELEMENTS = {
        'series': ['StudyInstanceUID', 'SeriesInstanceUID'],
        'study': ['StudyInstanceUID']
    }
    
    FHIR_STUDY_ELEMENT = "study"
    FHIR_SERIES_ELEMENT = "series"
    
    FHIR_NDJSON_NAME_FORMAT = "%Y-%m-%dT%H.%M.%S.%fZ"
    FHIR_NDJSON_FILE_EXT = ".ndjson"
    MAX_RECORDS_PER_NDJSON = 1000
    
    FHIR_LANDING_ZONE_ROOT_FOLDER = "FHIR"
    FHIR_NAMESPACE = "dicom_imaging"
    FHIR_IMAGING_STUDY_RES_NAME = "ImagingStudy"