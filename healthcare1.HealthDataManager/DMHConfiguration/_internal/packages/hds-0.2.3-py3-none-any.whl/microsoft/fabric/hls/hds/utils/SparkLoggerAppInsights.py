import logging
import uuid
from pyspark.sql import SparkSession
from opencensus.ext.azure.log_exporter import AzureLogHandler
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.SparkLoggerAbstractBaseClass import ABCSparkLogger
from microsoft.fabric.hls.hds.utils.SparkLoggerCustomDimensions import CustomDimensionsFilter
from notebookutils import mssparkutils
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils


class SparkLoggerAppInsights(ABCSparkLogger):
    """
    Class for wrapping setup for the Spark logger
    """
    
    def __init__(self, spark: SparkSession, run_id: uuid.UUID, logger_name: str, log_level: int) -> None:
        self._spark = spark
        self.spark_logger = None

        instrumentation_key = Utils.get_app_insights_instrumentation_key(spark)
        if instrumentation_key:
            try:
                handler = AzureLogHandler(connection_string = instrumentation_key)
            except Exception as e:
                raise ValueError("Invalid connection string for AzureLogHandler") from e
            
            formatter = logging.Formatter('%(message)s')
            handler.setFormatter(formatter)
            handler.setLevel(log_level)

            handler.addFilter(CustomDimensionsFilter({"RunId": str(run_id)}))
            self.spark_logger = logging.getLogger(f"{LC.AppInsightsSparkLoggerName.format(logger_name=logger_name)}")
            # Clean up handlers
            if (self.spark_logger.hasHandlers()):
                self.spark_logger.handlers.clear()
            self.spark_logger.addHandler(handler) 
            self.spark_logger.setLevel(log_level)
            self.spark_logger.propagate = False

    def info(self, message: str):
        if self.spark_logger:
            self.spark_logger.info(message)
        else:
            super().info(message)

    def error(self, message: str):
        if self.spark_logger:
            self.spark_logger.error(message)
        else:
            super().error(message)

    def debug(self, message: str):
        if self.spark_logger:
            self.spark_logger.debug(message)
        else:
            super().debug(message)

    def warning(self, message: str):
        if self.spark_logger:
            self.spark_logger.warning(message)
        else:
            super().warning(message)

    def critical(self, message: str):
        if self.spark_logger:
            self.spark_logger.critical(message)
        else:
            super().critical(message)

    def log(self, level: int, msg: str):
        # Passes the given severity level and calls the native py4j logging methods
        if level == logging.DEBUG:
            self.debug(msg)
        elif level == logging.INFO:
            self.info(msg)
        elif level == logging.WARNING:
            self.warning(msg)
        elif level == logging.ERROR:
            self.error(msg)
        elif level == logging.CRITICAL:
            self.critical(msg)

    @staticmethod
    def get_logger(spark: SparkSession, run_id: uuid.UUID, logger_name: str, log_level: int = logging.DEBUG):
        """
        Passes the message from the Logger wrapper to the spark logger object

        :param: logger_name -- name of the logger
        :param: log_level -- logging level
        """
        logger = SparkLoggerAppInsights(spark, run_id, logger_name, log_level)
        return logger