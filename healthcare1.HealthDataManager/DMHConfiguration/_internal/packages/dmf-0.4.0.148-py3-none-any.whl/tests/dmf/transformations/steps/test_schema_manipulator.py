from pyspark.sql.types import StructType, StructField, IntegerType, StringType, LongType, DateType, TimestampType
from datetime import datetime, date
from dmf.transformations.steps.source_schema_manipulator import SourceSchemaManipulator


def test_schema_manipulator_adjust_to_target(spark):
    source_schema = StructType([
        StructField("source_id", IntegerType(), True),
        StructField("source_data1", IntegerType(), True),
        StructField("source_data2", TimestampType(), True),
        StructField("source_data3", DateType(), True),
        StructField("unrelated_source", IntegerType(), True)])
    source_data = [
        (1, 1, datetime(2022, 9, 1, 1), date(2022, 9, 1), 1)
    ]

    target_schema = StructType([
        StructField("target_id", LongType(), True),
        StructField("target_data1", StringType(), True),
        StructField("target_data2", DateType(), True),
        StructField("target_data3", TimestampType(), True),
        StructField("unrelated_target", IntegerType(), True)])

    target_data = [
        (2, "2", date(2022, 9, 2), datetime(2022, 9, 2, 2), 2)
    ]

    source_df = spark.createDataFrame(source_data, source_schema)
    target_df = spark.createDataFrame(target_data, target_schema)
    columns_mapping = {"source_id": ["target_id"], "source_data1": ["target_data1"],
                       "source_data2": ["target_data2"], "source_data3": ["target_data3"]}
    result_df = SourceSchemaManipulator.adjust_to_target(source_df, columns_mapping, frozenset(), target_df.dtypes, "target_id")
    result_types_dict = dict(result_df.dtypes)
    target_types_dict = dict(target_df.dtypes)
    for source_col, target_cols in columns_mapping.items():
        for target_col in target_cols:
            assert result_types_dict[target_col] == target_types_dict[target_col]
    assert result_types_dict["unrelated_source"] == "int"
    assert target_types_dict["unrelated_target"] == "int"
    rows = result_df.collect()
    assert rows == [(1, "1", date(2022, 9, 1), datetime(2022, 9, 1), 1)]


def test_schema_manipulator_adjust_to_target_source_to_multi_target(spark):
    source_schema = StructType([
        StructField("source_id", IntegerType(), True),
        StructField("source_data1", IntegerType(), True),
        StructField("source_data3", DateType(), True),
        StructField("unrelated_source", IntegerType(), True)])
    source_data = [
        (1, 1, date(2022, 9, 1), 1)
    ]

    target_schema = StructType([
        StructField("target_id", LongType(), True),
        StructField("target_data1a", StringType(), True),
        StructField("target_data1b", IntegerType(), True),
        StructField("target_data2", TimestampType(), True),
        StructField("unrelated_target", IntegerType(), True)])

    target_data = [
        (2, "2", 2, datetime(2022, 9, 2, 2), 2)
    ]

    source_df = spark.createDataFrame(source_data, source_schema)
    target_df = spark.createDataFrame(target_data, target_schema)
    columns_mapping = {"source_id": ["target_id"], "source_data1": ["target_data1a", "target_data1b"],
                       "source_data3": ["target_data2"]}
    result_df = SourceSchemaManipulator.adjust_to_target(source_df, columns_mapping, frozenset(), target_df.dtypes, "target_id")
    result_types_dict = dict(result_df.dtypes)
    target_types_dict = dict(target_df.dtypes)

    for source_col, target_cols in columns_mapping.items():
        for target_col in target_cols:
            assert result_types_dict[target_col] == target_types_dict[target_col]
    assert result_types_dict["unrelated_source"] == "int"
    assert target_types_dict["unrelated_target"] == "int"
    rows = result_df.collect()
    assert rows == [(1, "1", 1, datetime(2022, 9, 1), 1)]
