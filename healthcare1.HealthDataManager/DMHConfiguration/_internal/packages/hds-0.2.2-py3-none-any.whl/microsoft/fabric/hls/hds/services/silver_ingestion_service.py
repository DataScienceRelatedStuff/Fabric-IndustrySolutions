# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import concurrent.futures
import json
from typing import Dict, Callable
from delta import DeltaTable
from pyspark.sql import SparkSession, DataFrame
from microsoft.fabric.hls.hds.errors.silver_ingestion_failed_error import SilverIngestionFailedError
from microsoft.fabric.hls.hds.utils.dataframe_utils import is_delta_table_empty , find_managed_delta_table_using_path , has_schema_evolved
from microsoft.fabric.hls.hds.structured_stream.delta_table_stream_reader import DeltaTableStreamReader
from microsoft.fabric.hls.hds.structured_stream.stream_orchestrator import StreamOrchestrator
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.thread_pool_manager import ThreadPoolManager
from microsoft.fabric.hls.hds.utils.utils import FolderPath
from microsoft.fabric.hls.hds.utils.extension_parser import ExtensionParser
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter

telemetry_reporter = TelemetryReporter()

# Report SilverIngestionService module import
telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
                                activity_name=GlobalConstants.SILVER_INGESTION_ACTIVITY_NAME)

class SilverIngestionService:
    def __init__(self, 
                 spark: SparkSession,
                 workspace_name: str,
                 solution_name: str,
                 target_lakehouse_name: str,
                 source_lakehouse_name: str,
                 **kwargs):
        """
        Args:
        spark: spark session
        - workspace_name: Name of the Fabric Workspace
        - solution_name: Name of the HDS-Healthcare data solutions OneLake workload solution
        - target_lakehouse_name (str): The lakehouse name of where the target tables are located. Should be silver as per the medallion architecture
        - source_lakehouse_name (str): The lakehouse name of where the source tables are located. Should be bronze as per the medallion architecture
          - kwargs: dict - An optional dictionary that customer can use to configure the silver_ingestion service
            - config_path: str - the path to where the config is stored. Default will be "abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/fhir4_3/transformation/flatten/flatten_config.json"
            - max_bytes_per_trigger: int - maximum number of bytes to be considered in every trigger.
            - source_tables_path: str - The path where all the source tables will be located. abfss://{workspace_name}@{one_lake_endpoint}/{source_lakehouse_name}.Lakehouse/Tables
            - target_tables_path: str - The path for where all the target tables will be located. abfss://{workspace_name}@{one_lake_endpoint}/{target_lakehouse_name}.Lakehouse/Tables
            - checkpoint_path (str): the Files path to where the checkpoint files will be located. Default will be 'abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/{target_lakehouse_name}"
            - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
        """
        self.spark = spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.target_lakehouse_name = target_lakehouse_name
        self.source_lakehouse_name = source_lakehouse_name
        self.one_lake_endpoint = kwargs.get("one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT)
        self._logger = LoggingHelper.get_silveringestion_logger(
                self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
            )
        
        ExtensionParser.register(spark)
        
        try:
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(workspace_name=self.workspace_name,
                                                                                one_lake_endpoint=self.one_lake_endpoint,
                                                                                solution_name=self.solution_name)
            self.main_config_path = kwargs.get(
                "config_path",
                FolderPath.get_fabric_workload_files_flatten_config_folder_path(root_path=self.config_files_root_path),
            )
            
            self.source_tables_path = kwargs.get(
                "source_tables_path",
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.source_lakehouse_name
                ),
            )
            self.target_tables_path = kwargs.get(
                "target_tables_path",
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.target_lakehouse_name
                ),
            )

            self.checkpoint_path_prefix = kwargs.get(
                "checkpoint_path",
                FolderPath.get_fabric_workload_files_checkpoint_folder_path(root_path=self.config_files_root_path,
                                                                            checkpoint_folder_name=self.target_lakehouse_name),
            )
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise
        
        self.config_entities = {}
        self.__load_config()

    def ingest(self, silver_transformation_fn: Callable):
        """Using the silver_transformation_fn to transform data in the config file

        Args:
            silver_transformation_fn (Callable): A function that accepts a dataframe as an argument and returns the resulting dataframe name and dataframe to save under silver_table_path_prefix

        """
        # Report Bronze to Silver Ingestion Pipeline Usage
        telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
                                        activity_name=GlobalConstants.SILVER_INGESTION_ACTIVITY_NAME)
        
        self._logger.info(f"{LoggingConstants.BEGAN_EXECUTION_INFO_MSG}")
        # Set up streaming on all source tables
        streaming_queries = []
        delta_table_stream_reader = DeltaTableStreamReader(self.spark)
        resources_with_no_source_data = []
        for resource, resource_config in self.config_entities.items():
            source_table_path = f"{self.source_tables_path}/{resource.lower()}"
            target_table_path = f"{self.target_tables_path}/{resource.lower()}"
            # Check if the source table is not a Delta table or is empty
            if not DeltaTable.isDeltaTable(
                self.spark, source_table_path
            ) or is_delta_table_empty(spark=self.spark, table_path=source_table_path):
                # For resources with no source data, mark only those whose target
                # table's in Silver does not exist for Silver transformation.
                # This ensures we only run Silver transformations for Empty tables only during the initial load
                # Schema evolution is only handled when there is data to be ingested for the Silver transformation
                # For downstream dependencies, it's paramount to run Silver table setup function which handles creating of
                # tables required required downstream as well as schema evolution when there is no source data.
                # Note: Schema evolution is already handled when persisting the data using Delta auto schema evolution feature
                if not DeltaTable.isDeltaTable(self.spark, target_table_path):
                    self._logger.info(
                    f"{LoggingConstants.SILVER_INGESTION_SOURCE_TABLE_DOES_NOT_EXIST_OR_EMPTY.format(source_table_path=source_table_path, target_table_path=target_table_path)}"
                    )
                    resources_with_no_source_data.append(resource_config)
                else:
                    self._logger.info(
                    f"{LoggingConstants.SILVER_INGESTION_TRANSFORMATION_SKIPPED.format(source_table_path=source_table_path, target_table_path=target_table_path)}"
                    )
            else:
                self._logger.info(
                    f"{LoggingConstants.SILVER_INGESTION_SOURCE_TABLE_DOES_EXIST.format(table_path=source_table_path)}"
                )
                delta_table_stream_df = delta_table_stream_reader.set_up_streaming(
                    delta_table_path=source_table_path
                )
                query = self.__start_silver_ingestion(
                    delta_table_stream_df,
                    silver_transformation_fn,
                    resource,
                    resource_config,
                )  # Set up and start streaming. Keep in mind that bronze delta table might not already exist
                streaming_queries.append(query)

        # Call silver_transformation_fn with None Dataframe for resource that do not haave source data
        if resources_with_no_source_data:
            self._logger.info(LoggingConstants.FLATTENING_SOURCE_RESOURCES_WITH_NO_DATA.format(resources_with_no_source_data=resources_with_no_source_data))
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(resources_with_no_source_data)) as executor:
                self._logger.info(f"{LoggingConstants.CREATE_SILVER_TABLES_INFO_MSG}")
                none_dataframe_tasks = {executor.submit(silver_transformation_fn,None,0, resource_config, self.target_tables_path): resource_config for resource_config in resources_with_no_source_data}

                # Call Threadpool manager to await till all threads execute
                thread_pool_manager = ThreadPoolManager(spark=self.spark)
                thread_pool_manager.await_all_termination(futures=none_dataframe_tasks)


        stream_orchestrator = StreamOrchestrator(self.spark)
        stream_orchestrator.await_all_termination(streaming_queries)

        self._logger.info(f"{LoggingConstants.COMPLETED_EXECUTION_INFO_MSG}")

    def setup(self, silver_setup_fn: Callable, get_avro_schema_fn: Callable):
        """
        Silver Ingestion Set Up:
            - Creates all resulting silver tables for the resources in config
        Args:
            silver_transformation_fn: A function that accepts a dataframe as an argument and returns the resulting dataframe name and dataframe to save under silver_table_path_prefix
        """

        self._logger.info(f"{LoggingConstants.BEGAN_EXECUTION_INFO_MSG}")

        
        if not self.config_entities:
            self._logger.info(LoggingConstants.FLATTENING_EMPTY_CONFIG_FILE.format(config_path=self.main_config_path))
            return
        
        new_entities_config =  {}
        for table_name, config in self.config_entities.items():
            target_table_path = f"{self.target_tables_path}/{table_name.lower()}"
            if not DeltaTable.isDeltaTable(self.spark, target_table_path):
                self._logger.debug(f"{LoggingConstants.SILVER_INGESTION_SETUP_TABLE_DOES_NOT_EXIST.format(table_path=target_table_path)}")
                
                new_entities_config[table_name] = config
                    
        if len(new_entities_config) > 0:
            # Call silver_setup_fn to create silver tables in parallel
            try:
                with concurrent.futures.ThreadPoolExecutor(
                    max_workers=len(new_entities_config)
                ) as executor:
                    self._logger.info(f"{LoggingConstants.CREATE_SILVER_TABLES_INFO_MSG}")
                    create_tables_tasks = {
                        executor.submit(
                            silver_setup_fn, resource_config, self.target_tables_path
                        ): resource_config
                        for resource, resource_config in new_entities_config.items()
                    }

                    # Call Threadpool manager to await till all threads execute
                    thread_pool_manager = ThreadPoolManager(spark=self.spark)
                    thread_pool_manager.await_all_termination(futures=create_tables_tasks)
            except Exception as ex:
                raise SilverIngestionFailedError(
                    f"{LoggingConstants.CREATING_EMPTY_SILVER_TABLES_ERR_MSG.format(exception_details=ex)}"
                ) from ex
        else:
            self._logger.info(f"{LoggingConstants.SILVER_INGESTION_SETUP_TABLES_SKIPPED}")

        self._logger.info(f"{LoggingConstants.COMPLETED_EXECUTION_INFO_MSG}")

    def __start_silver_ingestion(
        self,
        delta_table_stream_df: DataFrame,
        silver_transformation_fn: Callable,
        table_name: str,
        resource_config: Dict,
    ):
        """start streaming - Use foreachbatch to call a custom transformation function for each batch

        Args:
            delta_table_stream_df (DataFrame): the streaming df to transform
            silver_transformation_fn (function): The transformation function to apply on delta_table_stream_df
            table_name (str): The name of the table being streamed
            resource_config (Dict): The config to pass to the silver_transformation_fn for this resource

        Returns:
            _type_: _description_
        """
        return (
            delta_table_stream_df.writeStream.trigger(availableNow=True)
            .option(
                GlobalConstants.CHECKPOINT_LOCATION_OPTION_NAME,
                f"{self.checkpoint_path_prefix}/{table_name}",
            )
            .foreachBatch(
                lambda df, epochId: silver_transformation_fn(
                    df, epochId, resource_config, self.target_tables_path
                )
            )
            .queryName(
                f"{self.source_tables_path}_{self.target_tables_path}_{table_name}"
            )
            .start()
        )

    def __load_config(self):
        """
        Load main configuration and initialize internal list with supported resources
        """
        config_content = self.spark.sparkContext.wholeTextFiles(
            self.main_config_path
        ).collect()[0][1]

        self.main_config_json = json.loads(str(config_content))
        for entry in self.main_config_json[GlobalConstants.SILVER_CONFIG_RESOURCES_KEY]:
            self.config_entities[entry[GlobalConstants.SILVER_CONFIG_NAME_KEY]] = entry
