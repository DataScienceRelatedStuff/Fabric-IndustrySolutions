from pyspark.sql import DataFrame

from rmt.core.values_mapping.mapping_adder import MappingAdder
from rmt.core.values_mapping.mapping_schema import MappingSchema


class TestMappingAdder:

    @staticmethod
    def is_data_identical(df1: DataFrame, df2: DataFrame) -> bool:
        df2_aligned = df2.select(*df1.columns)
        return ((df1.exceptAll(df2_aligned).count() == 0) and
                (df2_aligned.exceptAll(df1).count() == 0))

    @staticmethod
    def run_and_assert_result_data_equals_expected_data(spark, mapping_data, add_data, expected_data, mapping_adder_method):

        mapping_df = spark.createDataFrame(mapping_data, MappingSchema.schema)
        add_df = spark.createDataFrame(add_data, MappingSchema.schema)
        expected_df = spark.createDataFrame(expected_data, MappingSchema.schema)

        result_df = mapping_adder_method(mapping_df, add_df)

        assert TestMappingAdder.is_data_identical(result_df, expected_df)

    def test_add_mapping_definitions_to_empty_mapping(self, spark):

        mapping_dataframe_data = []
        mapping_definitions_data = [("HC", "male", "gender", "genderId", 1),
                                    ("HC", "female", "gender", "genderId", 2)]
        expected_data = [("HC", "male", "gender", "genderId", 1),
                         ("HC", "female", "gender", "genderId", 2)]

        TestMappingAdder.run_and_assert_result_data_equals_expected_data(spark, mapping_dataframe_data, mapping_definitions_data, expected_data, MappingAdder.add)

    def test_add_mapping_definitions_to_non_empty_mapping(self, spark):

        mapping_dataframe_data = [("HC", "male", "gender", "genderId", 1)]
        mapping_definitions_data = [("HC", "female", "gender", "genderId", 2)]
        expected_data = [("HC", "male", "gender", "genderId", 1),
                         ("HC", "female", "gender", "genderId", 2)]

        TestMappingAdder.run_and_assert_result_data_equals_expected_data(spark, mapping_dataframe_data,
                                                                         mapping_definitions_data, expected_data, MappingAdder.add)

    def test_add_source_to_empty_mapping(self, spark):
        mapping_dataframe_data = []
        mapping_definitions_data = [("HC", "male", "gender", "genderId", 1),
                                    ("HC", "female", "gender", "genderId", 2)]
        expected_data = [("HC", "male", "gender", "genderId", 1),
                         ("HC", "female", "gender", "genderId", 2)]

        TestMappingAdder.run_and_assert_result_data_equals_expected_data(spark, mapping_dataframe_data,
                                                                         mapping_definitions_data, expected_data, MappingAdder.add_source)

    def test_add_source_to_non_empty_mapping(self, spark):

        mapping_dataframe_data = [("HC", "male", "gender", "genderId", 1)]
        mapping_definitions_data = [("HC", "female", "gender", "genderId", 2)]
        expected_data = [("HC", "male", "gender", "genderId", 1),
                         ("HC", "female", "gender", "genderId", 2)]

        TestMappingAdder.run_and_assert_result_data_equals_expected_data(spark, mapping_dataframe_data,
                                                                         mapping_definitions_data, expected_data, MappingAdder.add_source)

    def test_add_source_to_mapping_with_override(self, spark):
        mapping_dataframe_data = [("HC", "male", "gender", "genderId", 0),
                                  ("HC", "other", "gender", "genderId", 3)]
        mapping_definitions_data = [("HC", "male", "gender", "genderId", 1),
                                    ("HC", "female", "gender", "genderId", 2)]
        expected_data = [("HC", "male", "gender", "genderId", 1),
                         ("HC", "female", "gender", "genderId", 2),
                         ("HC", "other", "gender", "genderId", 3)]

        TestMappingAdder.run_and_assert_result_data_equals_expected_data(spark, mapping_dataframe_data,
                                                                         mapping_definitions_data, expected_data, MappingAdder.add_source)
