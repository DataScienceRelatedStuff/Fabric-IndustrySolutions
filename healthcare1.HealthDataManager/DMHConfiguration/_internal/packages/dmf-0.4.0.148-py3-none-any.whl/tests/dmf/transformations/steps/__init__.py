"""
unit tests for periodic transformations
"""