import json
from collections import defaultdict
from copy import deepcopy
from typing import Dict, List, Optional

from tests.utils.db.config_model.db_schema.ext_model import DBSchemaModel
from tests.utils.db.config_model.db_schema.model import Column, FieldProperties, JoinPair, ModelItem, OriginDataTypeName, RelationShip
from tests.utils.db.config_model.db_schema_config.model import ConfigField, ExcludedFields, PartitionField, PrimaryKey, RawDBConfigModel, DBConfigExtra


class DBConfigModel(RawDBConfigModel):
    @classmethod
    def from_str(cls, db_schema_config: str) -> "DBConfigModel":
        try:
            db_config_model = cls(**json.loads(db_schema_config))
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse DB schema config Json: {e}")
        db_config_model.verify_extra_config()
        db_config_model.verify_fields_are_present_in_config()
        return db_config_model

    @staticmethod
    def _filter_required_tables(db_schema: DBSchemaModel, required_tables: Dict[str, ExcludedFields]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        db_schema.tables = [t for t in db_schema.tables if t.name in required_tables]
        return db_schema

    @staticmethod
    def _remove_fields(db_schema: DBSchemaModel, required_tables: Dict[str, ExcludedFields]) -> None:
        if not required_tables:
            return
        excluded_columns: Optional[ExcludedFields] = None

        def should_keep(column: Column):
            return column.name not in excluded_columns.exclude

        for table_model in db_schema.tables:
            excluded_columns = required_tables.get(table_model.name)
            if not excluded_columns:
                continue
            existing_columns: List[Column] = table_model.storageDescriptor.columns
            table_model.storageDescriptor.columns = list(filter(should_keep, existing_columns))

    @staticmethod
    def _add_fields(db_schema: DBSchemaModel, fields_to_add: List[ConfigField], configuration: DBConfigExtra) -> None:
        if not fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for field in fields_to_add:
            if not field.enabled:
                continue
            config_field: ConfigField = deepcopy(field)
            config_field.tables = []
            relevant_tables = DBConfigModel._parse_required_tables_for_added_fields(configuration, db_schema, field)
            for table_name in relevant_tables:
                fields_grouped_by_table[table_name].append(config_field)
        fields_grouped_by_table = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: List = table_model.storageDescriptor.columns
            for config_field in fields_grouped_by_table.get(table_model.name, []):
                new_column = Column(
                    name=config_field.name,
                    originDataTypeName=OriginDataTypeName(
                        typeName=config_field.type,
                        isNullable=True,
                        properties=FieldProperties(
                            minValue=None,
                            maxValue=None,
                            description=config_field.description,
                            dateFormat=None,
                            timestampFormat=None
                        ),
                        length=None,
                        scale=None,
                        precision=None
                    )
                )
                datatype_config: OriginDataTypeName = new_column.originDataTypeName
                if config_field.length is not None:
                    datatype_config.length = config_field.length
                if config_field.scale is not None:
                    datatype_config.scale = config_field.scale
                if config_field.precision is not None:
                    datatype_config.precision = config_field.precision
                existing_columns.append(new_column)

    @staticmethod
    def _parse_required_tables_for_added_fields(configuration: DBConfigExtra, db_schema: DBSchemaModel, field: ConfigField) -> List[str]:
        field_tables = field.tables
        if field_tables == ["*"]:
            if field.name not in (configuration.sourceTableField, configuration.modifiedOnTargetField):
                raise ValueError(f"Table name ('*') is only supported for config field names "
                                 f"{(configuration.sourceTableField, configuration.modifiedOnTargetField)}")
            all_tables_names = [t.name for t in db_schema.tables]
            relevant_tables = all_tables_names
        else:
            if "*" in field_tables:
                raise ValueError(f"Invalid table name ('*') in config field {field.name}: in position: {field_tables.index('*')}")
            relevant_tables = field_tables
        return relevant_tables

    @staticmethod
    def _add_partitions_fields(db_schema: DBSchemaModel, partition_fields_to_add: List[PartitionField]) -> None:
        if not partition_fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for partition_field in partition_fields_to_add:
            if not partition_field.enabled:
                continue
            new_partition_field: PartitionField = deepcopy(partition_field)
            new_partition_field.tables = []
            for table_name in partition_field.tables:
                fields_grouped_by_table[table_name].append(partition_field)
        fields_grouped_by_table: Dict[str, List[PartitionField]] = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: List = table_model.storageDescriptor.columns
            if table_model.name in fields_grouped_by_table:
                for partition_field in fields_grouped_by_table[table_model.name]:
                    new_column = Column(
                        name=partition_field.name,
                        originDataTypeName=OriginDataTypeName(
                            typeName=partition_field.type,
                            isNullable=False,
                            properties=FieldProperties(
                                minValue=None,
                                maxValue=None,
                                description=partition_field.description,
                                dateFormat=None,
                                timestampFormat=None
                            ),
                            length=None,
                            scale=None,
                            precision=None
                        )
                    )
                    existing_columns.append(new_column)

    @staticmethod
    def _remove_redundant_relations(db_schema: DBSchemaModel, required_tables: Optional[Dict]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        for table_model in db_schema.tables:
            filtered_relationships = []
            for r in table_model.properties.relationships:
                to_entity = r.toEntity
                if to_entity in required_tables:
                    filtered_relationships.append(r)
            table_model.properties.relationships = filtered_relationships
        return db_schema

    def verify_fields_are_present_in_config(self):
        if not self.fields:
            return
        if not self.configuration:
            return

        fields_names = [field.name for field in self.fields if field.enabled]
        for field in [self.configuration.modifiedOnTargetField, self.configuration.sourceTableField]:
            if field is not None:
                if field not in fields_names:
                    raise ValueError(f"Field {field} is not present in fields config")

    @staticmethod
    def _update_primary_keys(db_schema: DBSchemaModel, primary_keys: List[PrimaryKey]) -> None:
        for primary_key in primary_keys:
            try:
                table_model: ModelItem = db_schema.tables_dict[primary_key.table]
            except KeyError:
                raise ValueError(f"Table {primary_key.table} not found in schema")
            old_pks = table_model.properties.primaryKeys[:]  # copy
            new_pks = table_model.properties.primaryKeys[:]  # copy
            existing_fields = [column.name for column in table_model.storageDescriptor.columns]
            for key_to_remove in primary_key.config.remove:
                if key_to_remove not in old_pks:
                    raise ValueError(f"Key {key_to_remove} not present in table {primary_key.table}")
                new_pks.remove(key_to_remove)
            for key_to_add in primary_key.config.add:
                if key_to_add in old_pks:
                    raise ValueError(f"Key {key_to_add} already present in table {primary_key.table}")
                if key_to_add not in existing_fields:
                    raise ValueError(f"Key {key_to_add} not present in table {primary_key.table}")
                new_pks.append(key_to_add)
            for old_key, new_key in primary_key.config.replace.items():
                if old_key not in existing_fields:
                    raise ValueError(f"Key {old_key} not present in table {primary_key.table}")
                if old_key not in old_pks:
                    raise ValueError(f"Key {old_key} not present in primary keys of table {primary_key.table}")
                if new_key not in existing_fields:
                    raise ValueError(f"Key {new_key} not present in table {primary_key.table}")
                new_pks.remove(old_key)
                new_pks.append(new_key)
            table_model.properties.primaryKeys = new_pks
            DBConfigModel._update_primary_keys_in_relationships(db_schema, primary_key, table_model)

    @staticmethod
    def _update_primary_keys_in_relationships(db_schema: DBSchemaModel, primary_key: PrimaryKey, table_model: ModelItem):
        # update all fks that reference this table
        for old_key, new_key in primary_key.config.replace.items():
            pointing_join_pairs: List[JoinPair] = db_schema.get_pointing_fks_on_field(table_model.name, old_key)
            for join_pair in pointing_join_pairs:
                join_pair.toAttribute = new_key
        for new_key in primary_key.config.remove:
            pointing_relationships: List[RelationShip] = db_schema.get_pointing_relationships_on_field(table_model.name, new_key)
            for rel in pointing_relationships:
                rel.joinPairs = list(filter(lambda jp: jp.toAttribute != new_key, rel.joinPairs))

    def adapt_schema(self, db_schema: DBSchemaModel) -> DBSchemaModel:

        db_schema = DBConfigModel._filter_required_tables(db_schema, self.tables)
        db_schema = DBConfigModel._remove_redundant_relations(db_schema, self.tables)
        DBConfigModel._remove_fields(db_schema, self.tables)
        DBConfigModel._add_fields(db_schema, self.fields, self.configuration)
        DBConfigModel._update_primary_keys(db_schema, self.primaryKeys)
        DBConfigModel._add_partitions_fields(db_schema, self.partitionFields)
        return db_schema

    def verify_extra_config(self):
        if bool(self.configuration.modifiedOnTargetField) ^ bool(self.configuration.sourceTableField):
            raise ValueError("Both modifiedOnTargetField and sourceTableField must be specified, or neither of them")
