from unittest.mock import MagicMock

import pytest

from rmt.filesystem.file_system_client import FileSystemClient
from rmt.filesystem.files_reader import FilesReader


class TestFilesReader:
    @pytest.fixture
    def file_system_client_mock(self):
        return MagicMock(spec=FileSystemClient)

    def test_read_dir_content_with_empty_file_names(self, spark, file_system_client_mock):
        path = "/path/to/dir"
        file_system_client_mock.list_files.return_value = ["file1.json", "file2.json"]
        file_system_client_mock.get_file_content.side_effect = lambda p, f: f"content of {f}"

        result = FilesReader.read_folder_json_content(file_system_client_mock, path)

        assert result == {"file1": "content of file1.json", "file2": "content of file2.json"}
        file_system_client_mock.list_files.assert_called_once_with(path, "json")

    def test_read_dir_content_with_specified_file_names(self, spark, file_system_client_mock):
        path = "/path/to/dir"
        file_names = ["file1.json"]
        file_system_client_mock.list_files.return_value = ["file1.json", "file2.json"]
        file_system_client_mock.get_file_content.side_effect = lambda p, f: f"content of {f}"

        result = FilesReader.read_folder_json_content(file_system_client_mock, path, file_names=file_names)

        assert result == {"file1": "content of file1.json"}

    def test_read_dir_content_with_missing_files(self, spark, file_system_client_mock):
        path = "/path/to/dir"
        file_names = ["missing-file.json"]
        file_system_client_mock.list_files.return_value = ["existing-file.json"]

        with pytest.raises(FileNotFoundError) as exc_info:
            FilesReader.read_folder_json_content(file_system_client_mock, path, file_names=file_names)
        assert str(exc_info.value) == f"Missing configuration file: {file_names[0]} in folder {path}"
