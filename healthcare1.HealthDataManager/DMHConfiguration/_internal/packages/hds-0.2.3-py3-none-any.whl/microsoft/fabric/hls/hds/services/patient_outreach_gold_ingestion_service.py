# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import traceback
from notebookutils import mssparkutils
from typing import Dict
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.ddl_helper.ddl_helper import DDLHelper
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import (
    LoggingConstants as LC,
)
from microsoft.fabric.hls.hds.services.dtt_workflow_service import DTTWorkflowService
from microsoft.fabric.hls.hds.services.vocabulary_ingestion_service import (
    VocabularyIngestionService,
)
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.extension_parser import ExtensionParser
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter
from microsoft.fabric.hls.hds.services.dtt_workflow_service import (
    DTTWorkflowService,
)

telemetry_reporter = TelemetryReporter()

# Report PatientOutreachGoldIngestionService module import
telemetry_reporter.report_usage(
    feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
    activity_name=GlobalConstants.PATIENT_OUTREACH_GOLD_INGESTION_ACTIVITY_NAME,
)


class PatientOutreachGoldIngestionService:
    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        source_lakehouse_name: str,
        target_lakehouse_name: str,
        **kwargs,
    ):
        """
        Uses DTT library to transform and ingest data into Gold shape for Patient Outreach Reporting (Gold tables)
        Args:
        - spark: spark session
        - workspace_name - str: Name of the Fabric Workspace
        - solution_name: Name of the DMH OneLake workload solution
        - source_lakehouse_name: str- The lakehouse name of where the source tables are located. Expected to be the silver database as per the medallion architecture
        - target_lakehouse_name: str - The lakehouse name of where the target tables are located. Expected to be the gold database(poagold in that case) as per the medallion architecture

        kwargs: Optional. Additional arguments to be set on the PatientOutreachGoldIngestionService object.
        Possible values:
         - poagold_config_path: str - The path to the PatientOutreach gold config folder. The default is "abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/poagold/"
         - checkpoint_path: str - The path to the vocabulary structured streaming checkpoint folder. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/poagold`
         - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
        """
        self.spark = spark
        self._logger = LoggingHelper.get_patientoutreachgoldingestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )

        ExtensionParser.register(spark)

        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.source_lakehouse_name = source_lakehouse_name
        self.target_lakehouse_name = target_lakehouse_name
        self.one_lake_endpoint = kwargs.get(
            "one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT
        )

        try:
            self.config_files_root_path = (
                FolderPath.get_fabric_workload_files_root_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    solution_name=self.solution_name,
                )
            )
            
            self.source_tables_path = FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.source_lakehouse_name,
            )

            self.poagold_tables_path = FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.target_lakehouse_name,
            )
            
            self.poagold_config_path = kwargs.get(
                "poagold_config_path",
                f"{self.config_files_root_path}/{GlobalConstants.DATA_MANAGER_INTERNAL_FOLDER_PATH}/{GlobalConstants.PATIENT_OUTREACH_GOLD_CONFIG_PATH}"
            )
            
            # should be fine to use dtt_secondary_lake_path as the checkpoint path
            # we are creating in poa gold layer unique table names (ending with 'fact' or 'dim')
            self.dtt_secondary_lake_path = (
                FolderPath.get_fabric_workload_files_poa_dtt_secondary_lake_folder_path(
                    root_path=self.config_files_root_path
                )
            )
            
            self.poagold_checkpoint_path = f"{self.config_files_root_path}/{GlobalConstants.DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{GlobalConstants.PATIENT_OUTREACH_FOLDER}/{GlobalConstants.DTT_CONFIG_FOLDER}"
           
            self.dmf_config_path = f"{self.poagold_checkpoint_path}/{GlobalConstants.DMF_CONFIG_PATH}"
            self.rmt_config_path = f"{self.poagold_checkpoint_path}/{GlobalConstants.RMT_CONFIG_PATH}"
            self.env_config_path = f"{self.poagold_checkpoint_path}/{GlobalConstants.ENV_CONFIG_PATH}"
           
            self.rmt_mapping_dir = f"{self.poagold_config_path}/{GlobalConstants.PATIENT_OUTREACH_RMT_REFERENCE_FOLDER}/{GlobalConstants.PATIENT_OUTREACH_RMT_REFERENCE_MAPPING_FOLDER}"
            self.rmt_data_dir = f"{self.poagold_config_path}/{GlobalConstants.PATIENT_OUTREACH_RMT_REFERENCE_FOLDER}/{GlobalConstants.PATIENT_OUTREACH_RMT_REFERENCE_DATA_FOLDER}"

            self.setDTTAppInsightsKey()

        except Exception as ex:
            self._logger.error(message=str(ex))
            raise

        # db config to read src storage, check if it exists
        self.dtt_env_config = f"""{{
            "storage": {{
                "source": {{
                    "entities": {{
                        "default": {{
                            "location": "{self.source_tables_path}",
                            "format": "delta"
                        }}
                    }}
                }},
                "target": {{
                    "entities": {{
                        "default": {{
                            "location": "{self.poagold_tables_path}",
                            "format": "delta"
                        }}
                    }}
                }},
                "secondary_lake": {{
                    "location": "{self.dtt_secondary_lake_path}"
                }}
            }}
        }}"""

        
    def setDTTAppInsightsKey(self):
        """
        set the DTT's application insights instrumentation key and ingestion endpoint to spark configuration
        """

        dtt_app_insights_connection_string = Utils.get_app_insights_connection_string(
            spark=self.spark
        )
        
        if dtt_app_insights_connection_string:
            self.spark.conf.set(
                GlobalConstants.SPARK_DTT_APP_INSIGHTS_CONNECTION_STRING,
                dtt_app_insights_connection_string,
            )
            self._logger.info(f"{LC.DTT_APP_INSIGHTS_SET_INFO_MSG}")

    def ingest(self):
        """Using DTT ingest source data into Patient Outreach Gold shape tables"""

        # Report Patient Outreach GOLD Ingestion Pipeline Usage
        telemetry_reporter.report_usage(
            feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
            activity_name=GlobalConstants.PATIENT_OUTREACH_GOLD_INGESTION_ACTIVITY_NAME,
        )

        try:
            self._logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")
            # Call DTT to transform Data
            self.__dtt_workflow()
            self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")
        except Exception as ex:
            self._logger.error(
                f"{LC.POAGOLD_TRANSFORMATION_EXCEPTION_ERROR_MSG.format(str(ex), traceback.print_exc())}"
            )
            raise ex

    def __dtt_workflow(self):
        """Invokes the dtt workflow"""
        rmt_mapping_folder_path = [f"{self.rmt_mapping_dir}"]
        rmt_data_folder_path = [f"{self.rmt_data_dir}"]

        # todo: rmt being updated to take file contents vs. path, once ready remove logic below
        mssparkutils.fs.put(self.env_config_path, self.dtt_env_config, overwrite=True)

        dtt_adapter = f"{self.poagold_config_path}/{GlobalConstants.PATIENT_OUTREACH_DTT_ADAPTER_FILE}"
        db_target_schema = f"{self.poagold_config_path}/{GlobalConstants.DB_TARGET_SCHEMA}"
        db_target_schema_config = (
            f"{self.poagold_config_path}/{GlobalConstants.DB_TARGET_SCHEMA_CONFIG}"
        )
        db_semantics = f"{self.poagold_config_path}/{GlobalConstants.DB_SEMANTICS}"
        db_semantics_config = (
            f"{self.poagold_config_path}/{GlobalConstants.DB_SEMANTICS_CONFIG}"
        )
        
        config_files = {
            "adaptor_file_location": dtt_adapter,
            "target_db_semantics_file_location": db_semantics,
            "env_config_file_location": self.env_config_path,
            "target_db_schema_file_location": db_target_schema,
            "db_schema_config_location": db_target_schema_config,           
            "target_db_semantics_config_file_location": db_semantics_config,
            "rmt_target_path": self.poagold_tables_path,
        }
        
        dtt_workflow = DTTWorkflowService( 
            spark=self.spark,   
            rmt_out_path=self.rmt_config_path,
            dtt_out_path=self.dmf_config_path,
            config_files=config_files,
            executeRMTReferenceTable=True,
            rmt_ordered_mapping_definitions_folders=rmt_mapping_folder_path,
            rmt_reference_tables_folders_paths=rmt_data_folder_path,
        )
        
        dtt_workflow.execute_dtt_workflow()