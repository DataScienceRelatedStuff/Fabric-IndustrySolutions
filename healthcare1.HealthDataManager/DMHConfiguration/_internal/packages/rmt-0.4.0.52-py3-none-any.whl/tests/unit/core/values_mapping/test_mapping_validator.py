
import pytest
from pyspark.shell import spark

from rmt.core.values_mapping.mapping_schema import MappingSchema
from rmt.core.values_mapping.mapping_validator import MappingValidator
from rmt.core.values_mapping.mapping_values_definition import MappingValuesDefinition


class TestMappingValidator:

    def test_validate_mapping_for_source_with_no_duplicates(self):
        mapping_definitions = [
            MappingValuesDefinition("table1", "field1", []),
            MappingValuesDefinition("table2", "field2", []),
            MappingValuesDefinition("table3", "field3", [])
        ]
        MappingValidator.validate_mapping_for_source("source", mapping_definitions)

    def test_validate_mapping_for_source_with_duplicates(self):
        mapping_definitions = [
            MappingValuesDefinition("table1", "field1", []),
            MappingValuesDefinition("table2", "field2", []),
            MappingValuesDefinition("table2", "field3", [])
        ]

        with pytest.raises(ValueError) as e:
            MappingValidator.validate_mapping_for_source("source", mapping_definitions)
            assert str(e) == "Duplicate target table name/s found: {'table2'} in source: source"

    def test_validate_mappings_unique_no_duplicates(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "female", "gender", "genderId", 2)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        MappingValidator._validate_mappings_unique(mapping_dataframe)
        assert mapping_dataframe.count() == 2

    def test_validate_mappings_unique_1_duplicate(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "male", "gender", "genderId", 2)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        with pytest.raises(Exception, match="duplicate mapping"):
            mapping_dataframe = MappingValidator._validate_mappings_unique(mapping_dataframe)

    def test_validate_mappings_unique_2_duplicates(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "female", "gender", "genderId", 2)
        row3 = ("Test", "other", "gender", "genderId", 3)
        row4 = ("Test", "male", "gender", "genderId", 2)
        row5 = ("Test", "female", "gender", "genderId", 3)
        mapping_dataframe = spark.createDataFrame([row1, row2, row3, row4, row5], MappingSchema.schema)
        with pytest.raises(Exception, match="duplicate mapping"):
            mapping_dataframe = MappingValidator._validate_mappings_unique(mapping_dataframe)

    def test_validate_mappings_unique_1_duplicate_same_value(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "male", "gender", "genderId", 1)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        with pytest.raises(Exception, match="duplicate mapping"):
            mapping_dataframe = MappingValidator._validate_mappings_unique(mapping_dataframe)

    def test_remove_duplicate_values(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "male", "gender", "genderId", 1)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        mapping_dataframe = MappingValidator._remove_duplicate_values(mapping_dataframe)
        assert mapping_dataframe.count() == 1

    def test_validate_no_duplicates_mapping_unique(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "female", "gender", "genderId", 2)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        mapping_dataframe = MappingValidator.validate(mapping_dataframe)
        assert mapping_dataframe.count() == 2

    def test_validate_no_duplicates_mapping_not_unique(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "male", "gender", "genderId", 2)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        with pytest.raises(Exception, match="duplicate mapping"):
            mapping_dataframe = MappingValidator.validate(mapping_dataframe)

    def test_validate_duplicates_mapping_unique(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "male", "gender", "genderId", 1)
        mapping_dataframe = spark.createDataFrame([row1, row2], MappingSchema.schema)
        mapping_dataframe = MappingValidator.validate(mapping_dataframe)
        assert mapping_dataframe.count() == 1

    def test_validate_duplicates_mapping_not_unique(self):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "male", "gender", "genderId", 1)
        row3 = ("Test", "male", "gender", "genderId", 2)
        mapping_dataframe = spark.createDataFrame([row1, row2, row3], MappingSchema.schema)
        with pytest.raises(Exception, match="duplicate mapping"):
            mapping_dataframe = MappingValidator.validate(mapping_dataframe)
