import os
import sys
import shutil
import uuid
from pathlib import Path
from typing import Generator

import pytest
from pyspark.sql import SparkSession
from pytest_mock import mocker

from dmf.logging import Logger
from dmf.model.data_feed_configuration import DataFeedConfiguration
from dmf.utils.global_constants import GlobalConstants
from tests.utils.db.builder.dataverse_schema_builder import DataverseSchemaBuilder
from tests.utils.db.builder.adrm_schema_builder import AdrmSchemaBuilder
from project_root import PROJECT_ROOT_DIR
from tests.utils.constants import Constants
from tests.utils.db.builder.sustainability_dataverse_schema_builder import SustainabilityDataverseSchemaBuilder
from tests.utils.config_utils import ConfigUtils

transformation_spec_file_name = "ts.json"
env_config_file_name = "EnvConfig.json"

dmf_tests_config_base_dir = Path(PROJECT_ROOT_DIR) / 'tests' / 'data' / 'config'
fhir_omop_config_path_dir = dmf_tests_config_base_dir / 'fhir-omop'
sus_dv_adrm_config_path_dir = dmf_tests_config_base_dir / 'dv-adrm-sus'
fhir_idm_config_path_dir = dmf_tests_config_base_dir / 'fhir-idm'
fhir_omop_source_path_dir = Path(PROJECT_ROOT_DIR) / 'tests' / 'data' / 'db' / 'fhir' / 'parquet'
reference_mapping_data_path = Path(PROJECT_ROOT_DIR) / "spark-warehouse" / GlobalConstants.REFERENCE_MAPPING_PATH


#############################
# spark                     #
#############################


@pytest.fixture(scope="session")
def spark() -> Generator[SparkSession, None, None]:
    spark, warehouse_location = spark_session()
    clean_database_files(warehouse_location)
    yield spark
    spark.stop()


def set_env():
    """
    This points pyspark in to find the active python installation. Ideally it should be your virtual env
    """
    os.environ['PYSPARK_PYTHON'] = sys.executable
    os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable


def get_warehouse_location(spark):
    return spark.conf.get("spark.sql.warehouse.dir")


def spark_session():
    set_env()
    warehouse_location = Path(PROJECT_ROOT_DIR, "spark-warehouse")
    shutil.rmtree(path=warehouse_location, ignore_errors=True)
    os.mkdir(path=warehouse_location)
    tests_log_config_path = Path(PROJECT_ROOT_DIR, 'tests', 'spark-log4j.properties')
    spark = SparkSession.builder. \
        master("local[4]").appName("test"). \
        config("spark.driver.memory", "4g"). \
        config(GlobalConstants.SPARK_CONFIG_SECONDARY_LAKE_ROOT_VARIABLE, str(warehouse_location)). \
        config("spark.sql.legacy.timeParserPolicy", "LEGACY"). \
        config("spark.sql.sources.partitionOverwriteMode", "dynamic"). \
        config("spark.sql.warehouse.dir", str(warehouse_location)). \
        config("spark.hadoop.javax.jdo.option.ConnectionURL",
               "jdbc:derby:memory:;databaseName=${metastoreLocation.getAbsolutePath};create=true"). \
        config("spark.sql.shuffle.partitions", "4"). \
        config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension"). \
        config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog"). \
        config("spark.jars.packages", "io.delta:delta-core_2.12:2.2.0"). \
        config("spark.driver.extraJavaOptions", f"-Dlog4j.configuration=file://{tests_log_config_path}"). \
        config("spark.executor.extraJavaOptions", f"-Dlog4j.configuration=file://{tests_log_config_path}"). \
        getOrCreate()
    Logger.init_logger(spark)
    spark.sparkContext.setLogLevel("ERROR")

    return spark, warehouse_location


#############################
# databases                 #
#############################


@pytest.fixture(scope="function")
def cleanup(spark):
    """
    Cleans the spark warehouse and the sink tables root. this is needed to avoid conflicts while creating the databases
    later
    """
    clean_database_files(get_warehouse_location(spark))


def clean_database_files(warehouse_location):
    """
    Cleans the spark warehouse and the sink tables root. this is needed to avoid conflicts while creating the databases
    later
    """
    shutil.rmtree(path=warehouse_location, ignore_errors=True)
    clean_db_sink_tables_root()


def clean_db_sink_tables_root():
    shutil.rmtree(path=Constants.SINK_TABLES_ROOT, ignore_errors=True)


def build_sus_dataverse_db(spark, db_name, metadata_file) -> DataverseSchemaBuilder:
    schema_builder = SustainabilityDataverseSchemaBuilder(
        spark=spark,
        metadata_file=metadata_file,
        adapter_file=os.path.join(PROJECT_ROOT_DIR, 'tests', 'utils', 'db', 'dmf-configuration', 'dv-adrm-sus',
                                  'Adapter.json'),
        db=db_name,
        warehouse_location=get_warehouse_location(spark))
    schema_builder.create_db()
    return schema_builder


def build_sus_temp_dataverse_db(spark, db_name, metadata_file, mocker) -> DataverseSchemaBuilder:
    schema_builder = SustainabilityDataverseSchemaBuilder(
        spark=spark,
        metadata_file=metadata_file,
        adapter_file=os.path.join(PROJECT_ROOT_DIR, 'tests', 'utils', 'db', 'dmf-configuration', 'dv-adrm-sus',
                                  'Adapter.json'),
        db=db_name,
        warehouse_location=get_warehouse_location(spark))
    data_folder = schema_builder.data_location()
    data_folder_copy = os.path.join(data_folder.parent, uuid.uuid4().__str__().replace('-', '_'))
    shutil.copytree(src=data_folder, dst=data_folder_copy)
    mocker.patch('tests.utils.db.builder.sustainability_dataverse_schema_builder.SustainabilityDataverseSchemaBuilder.'
                 'data_location', return_value=data_folder_copy)
    schema_builder.create_db()
    return schema_builder


@pytest.fixture(scope="session")
def dataverse_db_name() -> str:
    return "dataverse"


@pytest.fixture(scope="session")
def sus_dataverse_db_builder(spark, dataverse_db_name) -> Generator[DataverseSchemaBuilder, None, None]:
    metadata_file = Path(
        # PROJECT_ROOT_DIR, "tests", "utils", "db", "descriptors", "sus_dataverse.json")
        PROJECT_ROOT_DIR, "tests", "utils", "db", "dmf-configuration", "dv-adrm-sus", "DBSourceSchema.json")
    schema_builder = build_sus_dataverse_db(spark, dataverse_db_name, metadata_file)
    GlobalConstants.SOURCE_DB = dataverse_db_name
    yield schema_builder
    schema_builder.drop_db()


@pytest.fixture(scope="function")
def sus_dataverse_temp_db_builder(spark, dataverse_db_name, mocker) -> Generator[DataverseSchemaBuilder, None, None]:
    metadata_file = Path(
        PROJECT_ROOT_DIR, "tests", "utils", "db", "dmf-configuration", "dv-adrm-sus", "DBSourceSchema.json")

    schema_builder = build_sus_temp_dataverse_db(spark,
                                                 f"{dataverse_db_name}_{uuid.uuid4().__str__().replace('-', '_')}",
                                                 metadata_file, mocker)
    GlobalConstants.SOURCE_DB = dataverse_db_name
    yield schema_builder
    shutil.rmtree(path=schema_builder.data_location(), ignore_errors=True)
    schema_builder.drop_db()



#############################
# config file paths         #
#############################

@pytest.fixture(scope="session")
def fhir_omop_dmf_transformation_spec_path() -> Path:
    return fhir_omop_config_path_dir / transformation_spec_file_name


@pytest.fixture(scope="session")
def sus_dv_adrm_dmf_transformation_spec_path() -> Path:
    return sus_dv_adrm_config_path_dir / transformation_spec_file_name


@pytest.fixture(scope="session")
def fhir_idm_dmf_transformation_spec_path() -> Path:
    return fhir_idm_config_path_dir / transformation_spec_file_name


@pytest.fixture(scope="session")
def fhir_omop_env_config_path() -> Path:
    return fhir_omop_config_path_dir / env_config_file_name


@pytest.fixture(scope="session")
def sus_dv_adrm_env_config_path() -> Path:
    return sus_dv_adrm_config_path_dir / env_config_file_name


@pytest.fixture(scope="session")
def fhir_idm_env_config_path() -> Path:
    return fhir_idm_config_path_dir / env_config_file_name


#############################
# misc.                     #
#############################


@pytest.fixture(scope="function")
def disable_processors_parallelism(mocker):
    """
    This fixture disables the parallelism of the processors, so that the tests are easier to debug
    """
    with mocker.patch('dmf.workflow.processors_scheduler.TargetProcessorScheduler.compute_workers', return_value=1):
        yield


@pytest.fixture(scope="function")
def disable_mapping_parallelism(mocker):
    """
    This fixture disables the parallelism of the ids mapping, so that the tests are easier to debug
    """
    with mocker.patch('dmf.workflow.ids_mapping_orchestrator.IdsMappingOrchestrator._compute_workers', return_value=1):
        yield


@pytest.fixture(scope="function", autouse=True)
def mem_clean(spark) -> None:
    """useful to clean the memory before each test"""
    spark.sparkContext._jvm.System.gc()


#############################
# pytest configuration      #
#############################


# Create a dict of markers.
# The key is used as option, so --run-{key} will run all tests marked with key.
# The value must be a dict that specifies:
# 1. 'help': the command line help text
# 2. 'marker-descr': a description of the marker
# 3. 'skip-reason': displayed reason whenever a test with this marker is skipped.
optional_markers = {
    "long": {"help": "Long lasting tests",
             "marker-descr": "Skips long lasting tests",
             "skip-reason": "Test only runs with the --run-{} option."},
    # add further markers here
}


def pytest_addoption(parser):
    for marker, info in optional_markers.items():
        parser.addoption("--run-{}".format(marker), action="store_true",
                         default=False, help=info['help'])


def pytest_configure(config):
    for marker, info in optional_markers.items():
        config.addinivalue_line("markers",
                                "{}: {}".format(marker, info['marker-descr']))


def pytest_collection_modifyitems(config, items):
    for marker, info in optional_markers.items():
        if not config.getoption("--run-{}".format(marker)):
            skip_test = pytest.mark.skip(
                reason=info['skip-reason'].format(marker)
            )
            for item in items:
                if marker in item.keywords:
                    item.add_marker(skip_test)


@pytest.fixture(scope="session")
def sus_config(spark, sus_dv_adrm_dmf_transformation_spec_path,
               sus_dv_adrm_env_config_path,
               sus_dataverse_db_builder) -> DataFeedConfiguration:
    return ConfigUtils.generate_dmf_config_from_transformation_spec(
        spark=spark,
        transformation_spec_file_location=sus_dv_adrm_dmf_transformation_spec_path,
        env_config_file_path=sus_dv_adrm_env_config_path,
        source_tables_location=sus_dataverse_db_builder.db)


@pytest.fixture(scope="function")
def sus_config_temp_db(spark, sus_dv_adrm_dmf_transformation_spec_path,
                       sus_dv_adrm_env_config_path,
                       sus_dataverse_temp_db_builder) -> DataFeedConfiguration:
    return ConfigUtils.generate_dmf_config_from_transformation_spec(
        spark=spark,
        transformation_spec_file_location=sus_dv_adrm_dmf_transformation_spec_path,
        env_config_file_path=sus_dv_adrm_env_config_path,
        source_tables_location=sus_dataverse_temp_db_builder.db)


@pytest.fixture(scope="function")
def fhir_omop_config(spark, fhir_omop_dmf_transformation_spec_path,
                     fhir_omop_env_config_path) -> DataFeedConfiguration:
    return ConfigUtils.generate_dmf_config_from_transformation_spec(
        spark=spark,
        transformation_spec_file_location=fhir_omop_dmf_transformation_spec_path,
        env_config_file_path=fhir_omop_env_config_path,
        source_tables_location=fhir_omop_source_path_dir)


@pytest.fixture(scope="function")
def fhir_idm_config(spark, fhir_idm_dmf_transformation_spec_path,
                    fhir_idm_env_config_path) -> DataFeedConfiguration:
    return ConfigUtils.generate_dmf_config_from_transformation_spec(
        spark=spark,
        transformation_spec_file_location=fhir_idm_dmf_transformation_spec_path,
        env_config_file_path=fhir_idm_env_config_path,
        source_tables_location=fhir_omop_source_path_dir)


#############################
# reference mapping      #
#############################

@pytest.fixture(scope="session")
def reference_mapping_data_sus():
    copy_reference_mapping_data("sus")


@pytest.fixture(scope="session")
def reference_mapping_data_omop():
    copy_reference_mapping_data("omop")


def copy_reference_mapping_data(source_folder: str):
    shutil.copytree(src=os.path.join(PROJECT_ROOT_DIR, 'tests', 'data', 'reference_mapping', source_folder),
                    dst=reference_mapping_data_path,
                    dirs_exist_ok=True)
