import os
import uuid

import pytest
from pyspark.sql.types import StructType, StructField, LongType, StringType

from dmf.transformations.writer.storage_writer import StorageWriter

partition_column = "id_partition"
columns = ["id", "name", partition_column]

schema = StructType(
    [
        StructField(columns[0], LongType(), True),
        StructField(columns[1], StringType(), True),
        StructField(partition_column, LongType(), True)
    ]
)

formats = [
    "delta"
]


class TestStorageWriter:

    @pytest.mark.parametrize("format", formats)
    def test_write_into_empty_partition(self, spark, format):
        partition_value = 100
        data = [(1, "a", partition_value),
                (2, "b", partition_value)]
        df = spark.createDataFrame(data=data, schema=schema)
        location = os.path.join(spark.conf.get("spark.sql.warehouse.dir"),
                                f"test_write_delta_empty_partition_{uuid.uuid4()}")
        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df, column_names=columns, partition_column=partition_column)

        result_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value}'")
        assert result_df.count() == len(data)

    @pytest.mark.parametrize("format", formats)
    def test_write_into_multiple_empty_partitions(self, spark, format):
        partition_value1 = 100
        partition_value2 = 200
        data = [(1, "a", partition_value1),
                (2, "b", partition_value1),
                (3, "a", partition_value2)
                ]
        df = spark.createDataFrame(data=data, schema=schema)
        location = os.path.join(spark.conf.get("spark.sql.warehouse.dir"),
                                f"test_write_delta_empty_partition_{uuid.uuid4()}")
        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df, column_names=columns, partition_column=partition_column)

        result1_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value1}'")
        assert result1_df.count() == 2

        result2_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value2}'")
        assert result2_df.count() == 1

    @pytest.mark.parametrize("format", formats)
    def test_write_into_full_partition(self, spark, format):
        partition_value = 100
        location = os.path.join(spark.conf.get("spark.sql.warehouse.dir"),
                                f"test_write_delta_empty_partition_{uuid.uuid4()}")

        data1 = [(1, "a", partition_value),
                 (2, "b", partition_value)]
        df1 = spark.createDataFrame(data=data1, schema=schema)

        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df1, column_names=columns, partition_column=partition_column)

        data2 = [(11, "aa", partition_value),
                 (22, "bb", partition_value),
                 (33, "cc", partition_value)]
        df2 = spark.createDataFrame(data=data2, schema=schema)

        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df2, column_names=columns, partition_column=partition_column)

        result_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value}'")
        assert result_df.count() == len(data2)

    @pytest.mark.parametrize("format", formats)
    def test_write_into_multiple_full_partitions(self, spark, format):
        partition_value1 = 100
        partition_value2 = 200
        location = os.path.join(spark.conf.get("spark.sql.warehouse.dir"),
                                f"test_write_delta_empty_partition_{uuid.uuid4()}")

        data1 = [(1, "a", partition_value1),
                 (2, "b", partition_value1),
                 (3, "a", partition_value2)
                 ]

        df1 = spark.createDataFrame(data=data1, schema=schema)
        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df1, column_names=columns, partition_column=partition_column)
        result1_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value1}'")
        assert result1_df.count() == 2

        result2_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value2}'")
        assert result2_df.count() == 1

        data2 = [(11, "aa", partition_value1),
                 (22, "bb", partition_value2),
                 (33, "cc", partition_value2)
                 ]
        df2 = spark.createDataFrame(data=data2, schema=schema)
        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df2, column_names=columns, partition_column=partition_column)

        result1_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value1}'")
        assert result1_df.count() == 1

        result2_df = spark.read.format(format).load(location).filter(f"{partition_column} = '{partition_value2}'")
        assert result2_df.count() == 2

    @pytest.mark.parametrize("format", formats)
    def test_write_into_full_table_no_partition(self, spark, format):
        partition_value = 100
        location = os.path.join(spark.conf.get("spark.sql.warehouse.dir"),
                                f"test_write_delta_empty_partition_{uuid.uuid4()}")

        data1 = [(1, "a", partition_value),
                 (2, "b", partition_value)]
        df1 = spark.createDataFrame(data=data1, schema=schema)
        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df1, column_names=columns)

        data2 = [(11, "aa", partition_value),
                 (22, "bb", partition_value),
                 (33, "cc", partition_value)]
        df2 = spark.createDataFrame(data=data2, schema=schema)
        writer = StorageWriter(location=location, data_format=format, id="target_id")
        writer.write(spark=spark, df=df2, column_names=columns)

        result_df = spark.read.format(format).load(location)
        assert result_df.count() == len(data2)
