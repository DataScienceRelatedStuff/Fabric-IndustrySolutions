import pytest
from pyspark.sql.types import IntegerType, StringType, StructField, StructType

from rmt.core.values_mapping.mapping_schema import MappingSchema


class TestMappingSchema:
    def test_check_dataframe_schema_equal(self, spark):
        df = spark.createDataFrame([], MappingSchema.schema)
        MappingSchema.check_dataframe_schema(df)

    def test_check_dataframe_schema_equal_change_order(self, spark):
        mapping_schema = StructType(
            [
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE, IntegerType(), False
                ),
            ]
        )
        df = spark.createDataFrame([], mapping_schema)
        MappingSchema.check_dataframe_schema(df)

    def test_check_dataframe_schema_missing_column(self, spark):
        mapping_schema = StructType(
            [
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD, StringType(), False
                )
            ]
        )
        df = spark.createDataFrame([], mapping_schema)
        with pytest.raises(Exception, match="missing column"):
            MappingSchema.check_dataframe_schema(df)

    def test_check_dataframe_schema_extar_column(self, spark):
        mapping_schema = StructType(
            [
                StructField("a", StringType(), False),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE, IntegerType(), False
                ),
            ]
        )
        df = spark.createDataFrame([], mapping_schema)
        with pytest.raises(Exception, match="extra column"):
            MappingSchema.check_dataframe_schema(df)

    def test_check_dataframe_schema_type_not_equal(self, spark):
        mapping_schema = StructType(
            [
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE, StringType(), False
                ),
            ]
        )
        df = spark.createDataFrame([], mapping_schema)
        with pytest.raises(Exception, match="wrong schema type"):
            MappingSchema.check_dataframe_schema(df)

    def test_check_dataframe_schema_nullable_not_equal(self, spark):
        mapping_schema = StructType(
            [
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD, StringType(), False
                ),
                StructField(
                    MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE, IntegerType(), True
                ),
            ]
        )
        df = spark.createDataFrame([], mapping_schema)
        with pytest.raises(Exception, match="wrong nullable"):
            MappingSchema.check_dataframe_schema(df)

    def test_adjust_to_schema_same_schema(self, spark):
        row1 = ("Test", "male", "gender", "genderId", 1)
        df = spark.createDataFrame([row1], MappingSchema.schema)
        result = MappingSchema.adjust_to_schema(spark, df)
        MappingSchema.check_dataframe_schema(result)

    def test_adjust_to_schema_same_extra_column(self, spark):
        row1 = ("Test", "male", "gender", "genderId", 1, "extra")
        schema_fields = [field for field in MappingSchema.schema.fields]
        schema_fields.append(StructField("extra", StringType(), False))
        df = spark.createDataFrame([row1], StructType(schema_fields))
        result = MappingSchema.adjust_to_schema(spark, df)
        MappingSchema.check_dataframe_schema(result)

    def test_adjust_to_schema_target_nullable(self, spark):
        row1 = ("Test", "male", "gender", "genderId", None)
        schema_fields = [field for field in MappingSchema.schema.fields if field.name != MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE]
        schema_fields.append(StructField(MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE, IntegerType(), True))
        df = spark.createDataFrame([row1], StructType(schema_fields))
        result = MappingSchema.adjust_to_schema(spark, df)
        MappingSchema.check_dataframe_schema(result)

    def test_adjust_to_schema_cast_field(self, spark):
        row1 = ("Test", "gender", "genderId", 1, 100)
        schema_fields = [field for field in MappingSchema.schema.fields if field.name != MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE]
        schema_fields.append(StructField(MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE, IntegerType(), False))
        df = spark.createDataFrame([row1], StructType(schema_fields))
        result = MappingSchema.adjust_to_schema(spark, df)
        MappingSchema.check_dataframe_schema(result)
