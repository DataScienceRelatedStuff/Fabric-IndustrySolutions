from collections import defaultdict
from typing import List, Optional, Set

from configuration_compiler.column_transformation.data_transformation_generator import DataTransformationGenerator
from configuration_compiler.column_transformation.empty_transformations_cleaner import EmptyTransformationsCleaner
from configuration_compiler.column_transformation.fk_transformations_generator import (
    ForeignKeysTransformationsGenerator,
)
from configuration_compiler.column_transformation.ids_mapping_helper import IdsMappingHelper
from configuration_compiler.column_transformation.missings_pks_filler import MissingPKsFiller
from configuration_compiler.column_transformation.relationships_generator import Relationship, RelationshipsGenerator
from configuration_compiler.column_transformation.tables_path_resolver import TableNamesPair, TablesPathResolver
from configuration_compiler.config_files_models.adapter.ext_model import AdapterModel
from configuration_compiler.config_files_models.adapter.model import SourceField, SourceTable, TargetField
from configuration_compiler.schema_graph import SchemaGraph
from configuration_compiler.spec_models.target_table_schema import TargetTableSchemaExt
from dmf.model.common.types import DataSourceId, TargetId
from dmf.model.target_configuration.target_transformation import ColumnTransformation


class ColumnsTransformationsParser:
    """
    This class is responsible for parsing the transformations between the source and target columns.
    It uses the following classes:
    - TablesPairGenerator: generates all the possible pairs of tables that can be used to generate the transformations
    - TablesPathResolver: resolves the path between two tables
    - DataTransformationGenerator: generates the transformations between two tables
    - ForeignKeysTransformationGenerator: generates the transformations between two tables based on the foreign keys
    - MissingPKsFiller: generates the transformations between two tables based on the missing primary keys
    - EmptyTransformationsCleaner: cleans the empty transformations

    High level flow:
    1. for each adapter source table:
        a. Generate all the possible pairs of tables, and the relation between them.
            for each relation- compute the required transformation of foreign key
        b. Generate the explicit transformations as listed in the adapter (data and primary keys)
        c. Remove the `empty` transformations- empty transformations are transformations for tables
            that only transform the PKs and for that table there are no data columns transformations.
    """

    def __init__(
        self,
        dmf_adaptor: AdapterModel,
        target_tables_schemas: dict[DataSourceId, TargetTableSchemaExt],
    ):
        self.transformations: dict[DataSourceId, dict[TargetId, Set[ColumnTransformation]]] = defaultdict(
            lambda: defaultdict(set)
        )
        self.dmf_adaptor = dmf_adaptor
        self.schema_graph = SchemaGraph(target_tables_schemas)
        self.target_tables_schemas = target_tables_schemas
        self.ids_mapping_helper = IdsMappingHelper(self.target_tables_schemas)

    def parse_column_transformations(self):
        """
        Parses the column transformations for each transformation defined in the adapter.

        This function iterates over each source table in the adapter, computes the relationships for all of the source table related mappings,
        generates the required transformations for the source table, fills in any unmapped primary keys, and cleans
        transformations without data. The parsed transformations are stored in the `transformations` attribute of the class.

        Returns:
            dict: A dictionary where the keys are the source table names and the values are dictionaries.
                  Each inner dictionary has target table IDs as keys and sets of ColumnTransformation objects as values.
        """
        for source_table in self.dmf_adaptor.source_tables:
            relationships = self._compute_relationships_for_source_table(source_table)
            self._generate_required_transformations_for_source_table(relationships, source_table)
            self._fill_in_unmapped_primary_keys(source_table.tableName)
            self._clean_transformations_without_data(source_table.tableName)
        return self.transformations

    def _compute_relationships_for_source_table(self, source_table: SourceTable):
        """
        Computes all the relationships between each target and all anchor tables for a given source table.

        This function iterates over each source field in the given source table, and for each source field,
        it iterates over each target field. For each target field, it computes the table names pairs and
        then computes the relationships for these pairs.

        Args:
            source_table (SourceTable): The source table for which to compute the relationships.

        Returns:
            Set[Relationship]: A set of Relationship objects representing the relationships between each target
                               and all anchor tables for the given source table.
        """
        anchors = [anc.tableName for anc in source_table.targetAnchorTables]
        relationships: Set[Relationship] = set()
        for source_field in self.dmf_adaptor.source_fields_on_source_table(source_table):
            for target_field in self.dmf_adaptor.target_fields_on_source_field(source_field):
                table_names_pairs = self._compute_tables_names_pairs(anchors, source_table, target_field)
                relationships |= self._compute_relationships(table_names_pairs)
        return relationships

    def _generate_required_transformations_for_source_table(
        self, relationships: Set[Relationship], source_table: SourceTable
    ):
        data_transformations = self._generate_data_transformations(source_table)
        fk_transformations = self._generate_fk_transformations(relationships, source_table, data_transformations)
        self._update_transformations(fk_transformations | data_transformations, source_table)

    def _generate_fk_transformations(
        self,
        relationships: Set[Relationship],
        source_table: SourceTable,
        data_transformations: Set[ColumnTransformation],
    ):
        """
        Generates transformations based on the foreign keys. The foreign keys are computed from the relationships.
        If a foreign key transformation is already explicitly defined, it is skipped.

        Args:
            relationships (Set[Relationship]): A set of relationships for which to generate the transformations.
            source_table (SourceTable): The source table for which to generate the transformations.
            data_transformations (Set[ColumnTransformation]): A set of existing data transformations.

        Returns:
            Set[ColumnTransformation]: A set of ColumnTransformation objects representing the foreign key transformations
                                       for the given relationships and source table.
        """
        transformations = set()
        for relationship in relationships:
            if self._relationship_fk_is_already_explicitly_defined(relationship, data_transformations):
                continue
            transformations |= ForeignKeysTransformationsGenerator(
                self.dmf_adaptor, relationship, source_table, self.target_tables_schemas, self.ids_mapping_helper
            ).generate_fks_transformations()
        return transformations

    def _relationship_fk_is_already_explicitly_defined(
        self, realtionship: Relationship, data_transformations: Set[ColumnTransformation]
    ):
        for data_transformation in data_transformations:
            if data_transformation.transformation_target_id == realtionship.origin.id:
                for fk in realtionship.relation.foreign_keys:
                    if data_transformation.target_field_name == fk.from_attribute:
                        return True
        return False

    def _generate_data_transformations(self, source_table: SourceTable) -> Set[ColumnTransformation]:
        """
        Generates explicit transformations as listed in the adapter for the given source table.
        These transformations include both data and primary keys.

        Args:
            source_table (SourceTable): The source table for which to generate the transformations.

        Returns:
            Set[ColumnTransformation]: A set of ColumnTransformation objects representing the explicit transformations
                                       for the given source table.
        """
        transformations = set()
        for source_field in self.dmf_adaptor.source_fields_on_source_table(source_table):
            for target_field in self.dmf_adaptor.target_fields_on_source_field(source_field):
                bypass_key_harmonization = bool(
                    source_table.bypassKeysHarmonization and not source_field.enforceKeyHarmonization
                )
                data_transformation = self._generate_explicit_transformations(
                    source_field, target_field, bypass_key_harmonization
                )
                if data_transformation:
                    transformations.add(data_transformation)
        return transformations

    def _compute_relationships(self, table_names_pairs: Set[TableNamesPair]) -> Set[Relationship]:
        return RelationshipsGenerator(self.target_tables_schemas).compute_relationships(table_names_pairs)

    def _update_transformations(self, all_transformations, source_table):
        """store created transformations
        some transformations are created more than once since paths between tables might overlap"""
        for transformation in all_transformations:
            source_transformations = self.transformations[source_table.tableName]
            target_transformations = source_transformations[transformation.transformation_target_id]
            target_transformations.add(transformation)

    def _generate_explicit_transformations(
        self, source_field: SourceField, target_field: TargetField, bypass_keys_harmonization: bool
    ) -> Optional[ColumnTransformation]:
        return DataTransformationGenerator(
            self.target_tables_schemas, self.ids_mapping_helper, bypass_keys_harmonization
        ).generate_data_transformation(source_field, target_field)

    def _compute_tables_names_pairs(
        self, anchors: List[str], source_table: SourceTable, target_field: TargetField
    ) -> Set[TableNamesPair]:
        path_resolver = TablesPathResolver(
            anchors,
            self.schema_graph,
            self.target_tables_schemas,
            self.dmf_adaptor.target_table_paths,
            source_table.tableName,
            target_field,
        )
        return path_resolver.generate_pairs()

    def _clean_transformations_without_data(self, source_table_name: str):
        """if we have fk transformations which refer tables without data transformations, we remove them.
        This is because we don't want to generate fk values for tables without data.
        for that matter, ref tables are not considered as tables with data always
        """
        transformations_from_source_table = self.transformations[source_table_name]
        EmptyTransformationsCleaner(self.target_tables_schemas).clean(transformations_from_source_table)

    def _fill_in_unmapped_primary_keys(self, source_table_name: str):
        transformations_from_source_table = self.transformations[source_table_name]
        MissingPKsFiller(self.target_tables_schemas, transformations_from_source_table).fill_in_unmapped_primary_keys()

# SIG # Begin Windows Authenticode signature block
# MIIoKgYJKoZIhvcNAQcCoIIoGzCCKBcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCdSxmQv7YjgicC
# Q2gQFrDNMN9mFfZQWqVAh+Gv10b6OaCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgowghoGAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIB+MSPlYwwq1cJkC/SVYFyGi
# iMIot5Y7G7iOr99GW9DFMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAumobMfK7g6nu177cERmDcp4EO0b8Y1J03cOPe/aoPVPra8XG20yVVufk
# IVJ2EhZTwDbnt0w+qOhiYsAu0v8wZYPeZsZVK+LEW0t7ioYvAnw2YGCzn82TuNwN
# ru4L3Da5pTEalqoe1yHfrS+LsV6QDho7ARxiIm8L5kMsJ/Lj3z8xBgn/j/Njh3OA
# QO7qxd4zO1/slHez9x+21cx4ikXdQFYnc2QHeBM39naLKQMQyMnayzsrhlnDdKQO
# uwwGgdcPaJ/1ausXTWlpYBu37qV4H9eIGe+KqODAp8C5Zcz72vvab097ozkctMya
# gRuC+eMxx+UFVYVuGi/K8/xoFptbBKGCF5QwgheQBgorBgEEAYI3AwMBMYIXgDCC
# F3wGCSqGSIb3DQEHAqCCF20wghdpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCVH1dpjicVeNLrofC3KigTovcpJSBugsKmSauVIBia9QIGZXsm93s+
# GBMyMDI0MDExMTEyMjE1OC45NTFaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046MzMwMy0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHqMIIHIDCCBQigAwIBAgITMwAAAcyGpdw369lhLQABAAABzDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzA1MjUxOTEy
# MDFaFw0yNDAyMDExOTEyMDFaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046MzMwMy0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDMsSIF8e9NmEc+83NVZGgWWZi/wBYt8zhxAfSGM7xw
# 7K7CbA/1A4GhovPvkIY873tnyzdyZe+6YHXx+Rd618lQDmmm5X4euiYG53Ld7WIK
# +Dd+hyi0H97D6HM4ZzGqovmwB0fZ3lh+phJLoPT+9yrTLFzkkKw2Vcb7wXMBziD0
# MVVYbmwRlRaypTntl39IENCEijW9j6MElTyXP2zrc0OthQN5RrMTY5iZja3MyHCF
# mYMGinmHftsaG3Ydi8Ga8BQjdtoTm5dVhnqs2qKNEOqZSon28R4Xff0tlJL5UHyI
# 3bywH/+zQeJu8qnsSCi8VFPOsZEb6cZzhXHaAiSGtdKAbQRaAIhExbIUpeJypC7l
# +wqKC3BO9ADGupB9ZgUFbSv5ECFjMDzbfm8M5zz2A4xYNPQXqZv0wGWL+jTvb7kF
# YiDPPe+zRyBbzmrSpObB7XqjqzUFNKlwp+Mx15k1F7FMs5EM2uG68IQsdAGBkZbS
# DmuGmjPbZ7dtim+XHuh3NS6JmXYPS7rikpCbUsMZMn5eWxiWFIk6f00skR4RLWmh
# 0N6Oq+KYI1fA59LzGiAbOrcxgvQkRo3OD4o1JW9z1TNMwEbkzPrXMo8rrGsuGoyY
# Wcsm9xhd0GXIRHHC64nzbI3e0G5jqEsWQc4uaQeSRyr70KRijzVyWjjYfsEtvVMl
# JwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFIKmHGRdPIdLRXtsR5XRSyM3+2kMMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQB5GUMo9XviUl3g72u8oQTorIKDoAdgWZ4L
# Q9+dAEQCmaetsThkxbNm15seu7GmwpZdhMQN8TNddGki5s5Ie+aA2VEo9vZz31ll
# usHBXAVrQtpufQqtIA+2nnusfaYviitr6p5kVT609LITOYgdKRWEpfx/4yT5R9yM
# eKxoxkk8tyGiGPZK40ST5Z14OPdJfVbkYeCvlLQclsX1+WBZNx/XZvazJmXjvYjT
# uG0QbZpxw4ZO3ZoffQYxZYRzn0z41U7MDFlXo2ihfasdbHuua6kpHxJ9AIoUevh3
# mzvUxYp0u0z3wYDPpLuo+M2VYh8XOCUB0u75xG3S5+98TKmFbqZYgpgr6P+YKeao
# 2YpB1izs850YSzuwaX7kRxAURlmN/j5Hv4wabnOfZb36mDqJp4IeGmwPtwI8tEPs
# uRAmyreejyhkZV7dfgJ4N83QBhpHVZlB4FmlJR8yF3aB15QW6tw4CaH+PMIDud6G
# eOJO4cQE+lTc6rIJmN4cfi2TTG7e49TvhCXfBS2pzOyb9YemSm0krk8jJh6zgeGq
# ztk7zewfE+3shQRc74sXLY58pvVoznfgfGvy1llbq4Oey96KouwiuhDtxuKlTnW7
# pw7xaNPhIMsOxW8dpSp915FtKfOqKR/dfJOsbHDSJY/iiJz4mWKAGoydeLM6zLmo
# hRCPWk/Q5jCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNN
# MIICNQIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjMzMDMtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBO
# TuZ3uYfiihS4zRToxisDt9mJpKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6UnmNTAiGA8yMDI0MDExMTAzNTk0
# OVoYDzIwMjQwMTEyMDM1OTQ5WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDpSeY1
# AgEAMAcCAQACAgR+MAcCAQACAhQBMAoCBQDpSze1AgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQELBQADggEBAKj2VD7xtmO3UlhXMSNzezfRDZvjpQaCYqBXhXrjdL+FYz+Y
# /lTYJYMtsCvB8y8dhm7jGq7pyg38fpQ74cgmdGuIxFoTcNb4Vz6yEQB8CQMmoRkl
# pvEDSAlQl/e3EAnn/TGE5eiJqFefBcFwQ7RRmVgkO9HKPPYzldnxCZNht0O+PXcL
# lcKLaPTCzpXJYx3zWZL0Noj9nbtpX+P3j5KtqZyOfQ/xTkXt4v36v41eEyWeDClM
# 8V6CD0+rxCmrxiGMrurmTG1OZDnbbIIcScKoMEucXO5cHK8SMZTunyZRjukP8Nke
# mdZ99ClJZiEdVTJCIVewKoMPINl90gvhMFFgmxwxggQNMIIECQIBATCBkzB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAcyGpdw369lhLQABAAABzDAN
# BglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8G
# CSqGSIb3DQEJBDEiBCAYe/TGWE4pWROcicPg1gNk4rF/YBOoGK/42fgprfb0qjCB
# +gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINbuZQHC/sMCE+cgKVSkwKpDICfn
# efFZYgDbF4HrcFjmMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAHMhqXcN+vZYS0AAQAAAcwwIgQggkxBRGCAMo5CcqGzPTbsOEPoKdXH
# 8o/+UhltqnCFgF4wDQYJKoZIhvcNAQELBQAEggIAYScGMHA2OMRWdQrCItGPejTE
# 89l5UMUfcQ2SQKtC2CT8ly59DM9398ARb5STY0qDTN9X04wyY6zaJ8vvqkNNYxqy
# YxxM8PcyMgEHS5FnTgHlZB3xQzWBlGuthYuG+nUoBeN0gq3mSsQAscerkltBmY4x
# J85Rf6wNjKQ8GMqoFtm8pCaoldqllSkBuHk3fdp5BvYYO6/C2q4qTFhfS6dLNXVa
# 81kruh8R+JQwMcjogSxf141KX4Qv3Ok+kxSVMry4mGfKKz+IHmXPV54WZiAW2ena
# GADTLWx7eKnxCfxiM8WPEB5pWBm6dGbfKWWgdy+HKRcMjNgnZUaq/kYTKvKgN0tB
# DWVirJNmpgpfQi4Zdzg6wbb/8pyqiDMI6WeViwjgSwmyjvCLp8cFmTgNbby2T8vy
# 0r9DJjAoOebHXfl1nn7kbxa3eEtxRleZ5ozceGyJEq7iDj4DCILiZGgO6sAuNTyd
# ghRJLuV3H7GeY2BL/BxyoxxWXX+WajNnuKfdCvfiP9sDOJyt0ZNIdnLdNLY7m3uF
# p0ikuVGhb37B1V50GDqIShn0cAMmRMHoGk+N4yO4i9cKg+jBZ9AEcZI54eBKeig2
# u9fm7XsdNFmrtBjmSpw6+x2KkNps+pIwSv2aye1edmeSaLABHfARgQIcxRiPm60P
# j8c4hAGL7wlpNqmPgD0=
# SIG # End Windows Authenticode signature block