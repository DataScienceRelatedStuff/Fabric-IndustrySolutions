# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
class NLPUnrecoverableError(Exception):
    """
    Exception raised for errors when NLP Analysis on an input dataframe fails.
    
    This exception is raised when there is a failure during the NLP analysis process,
    such as errors in the input DataFrame or issues encountered while running the
    analysis itself.

    Attributes:
        message (str): explanation of the error
    """

    def __init__(self, message="NLP analysis failed."):
        self.message = message
        super().__init__(self.message)
