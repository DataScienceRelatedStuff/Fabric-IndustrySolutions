# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class to generate ndjson files for fhir resource data from dicom tags
"""
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import *
from pyspark.sql.functions import *
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C
import json
from datetime import datetime, timezone
from microsoft.fabric.hls.hds.medical_imaging.dicom.utils.dicom_to_fhir_utils import DicomToFhirUtils
from notebookutils import mssparkutils
from microsoft.fabric.hls.hds.utils.utils import FolderPath
from microsoft.fabric.hls.hds.utils.utils import Utils as CommonUtils
from microsoft.fabric.hls.hds.structured_stream.delta_table_stream_reader import DeltaTableStreamReader

class MetadataToFhirConvertor:
    """
    This is a class used to generate ndjson files for fhir resource data from dicom tags
    """
    
    def __init__(self, 
                 spark: SparkSession,
                 workspace_name: str,
                 lakehouse_name: str,
                 solution_name: str,
                 **kwargs) -> None:
        """
        Args:
            - spark: spark session
            - workspace_name (str): Name of the Fabric Workspace
            - lakehouse_name (str): The lakehouse name where dicom bronze metastore table is located
            - solution_name (str): Name of the HDS-Healthcare data solutions OneLake workload solution
            - **kwargs (dict): An optional dictionary that customer can use to configure the bronze_ingestion service
                - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
                - fhir_ndjson_files_root_path(str): The path where we want to store the generated ndjson files. Default is under the under 'medical_imaging' folder
                - fhir_namespace (str): the namespace used in fhir landing zone contract. Default will be 'dicom_imaging' 
                - dicom_to_fhir_config_path (str): The json file path containing mapping between dicom tags and fhir elements. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/medical_imaging/dicom`
                - avro_schema_path (str): The avro schema file path for ImagingStudy. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/fhir4_3/schema`
                - checkpoint_path (str): the Files path to where the checkpoint files will be located. Default will be 'abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/medical_imaging/dicom_to_fhir`
                - delta_table_path (str): the path for dicomimagingmetastore table. Default will be 'abfss://{workspace_name}@{one_lake_endpoint}/{lakehouse_name}.Lakehouse/Tables' 
                - max_records_per_ndjson (int): the maximum number of ImagingStudy records per ndjson file. Default will be 1000
        """
        self.spark= spark
        self.workspace_name = workspace_name
        self.lakehouse_name = lakehouse_name
        self.solution_name = solution_name
        self.one_lake_endpoint = kwargs.get("one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT)
        self._logger = LoggingHelper.get_imaging_metadata_to_fhir_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL)
        
        self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            solution_name=self.solution_name
        )
        self.config_file_path = kwargs.get(
            "dicom_to_fhir_config_path", 
            f"{self.config_files_root_path}/{GlobalConstants.DEFAULT_DICOM_TO_FHIR_CONFIG_PATH}/{C.DICOM_TO_FHIR_MAPPING_FILE_NAME}"
        )
        self.mapping_config = json.loads(
            self.spark.sparkContext.wholeTextFiles(
                self.config_file_path
            ).collect()[0][1]
        )
        
        self.checkpoint_path = kwargs.get(
            "checkpoint_path",
            FolderPath.get_fabric_workload_files_checkpoint_folder_path(root_path=self.config_files_root_path,
                                                                        checkpoint_folder_name=f"{GlobalConstants.MEDICAL_IMAGING_FOLDER}/{C.DICOM_TO_FHIR_CHECKPOINT_FOLDER}")
        )
        
        avro_schema_file_path = kwargs.get(
            "avro_schema_path", 
            FolderPath.get_fabric_workload_files_schema_root_folder_path(root_path=self.config_files_root_path)
        )
        self.imaging_study_avro_schema_path = f"{avro_schema_file_path}/{C.FHIR_IMAGING_STUDY_RES_NAME.lower()}{C.AVRO_SCHEMA_FILE_EXT}"
        self.spark_schema = CommonUtils.load_schema_from_avro_schema(
            self.spark, 
            CommonUtils.load_config_file(
                self.spark, 
                self.imaging_study_avro_schema_path
            )
        )
        
        self.lakehouse_files_root_path = FolderPath.get_fabric_files_path(
            workspace_name=self.workspace_name,
            one_lake_endpoint=self.one_lake_endpoint,
            lakehouse_name=self.lakehouse_name
        )
        self.fhir_ndjson_files_root_path = kwargs.get(
            "fhir_ndjson_files_root_path", 
            f"{self.lakehouse_files_root_path}/{GlobalConstants.MEDICAL_IMAGING_FOLDER}"
        )
        self.fhir_namespace = kwargs.get("fhir_namespace", C.FHIR_NAMESPACE)
        
        self.delta_table_path = kwargs.get("delta_table_path", 
                                           FolderPath.get_fabric_tables_path(
                                                workspace_name=self.workspace_name,
                                                one_lake_endpoint=self.one_lake_endpoint,
                                                lakehouse_name=self.lakehouse_name
                                            ))
        
        self.max_records_per_ndjson = kwargs.get("max_records_per_ndjson", C.MAX_RECORDS_PER_NDJSON)
        
    def _modify_expr_str_level_based(self, key: str, level: int, expr_str: str) -> str:
        """
        This method is used to modify expr string based on the nesting level

        Args:
            key (str): element key 
            level (int): nesting level
            expr_str (str): expression string

        Returns:
            str: modified expression string
        """    
            
        if level == 1:
            return(f"collect_set({expr_str}).alias('{key}')")
        else:
            return(f"{expr_str}.alias('{key}')")
    
    def _generate_expr_str(self, schema, value: dict, mappings:list= []) -> str:
        """
        This method is used to generate expr str for a dict mapping element 
        based on if its a calc column or a normal nested struct column

        Args:
            schema : schema for the element being processed
            value (dict): value of the dict mapping element being processed
            mappings (list, optional): child mapping expression list (if its a normal nested struct column). Defaults to [].

        Returns:
            str: generated expression string
        """      
          
        if DicomToFhirUtils.is_calc_column(value):
            expr_str = f"{value['calc']}.cast({schema})"
        else:
            expr_str = f"struct({', '.join(mappings)})"
        return expr_str
    
    def _generate_mappings_expr(self, mapping: dict, spark_schema: StructType, ignore_elements:list=[], level: int =1) -> list:
        """
        This method is used recursively to generate pyspark expressions for aggregations 
        based on mapping config passed

        Args:
            mapping (dict): mapping dictionary for which expressions need to be generated
            spark_schema (StructType): spark schema
            ignore_elements (list, optional): list of elements to be ignored while generating expressions. Defaults to [].
            level (int, optional): nesting level. Defaults to 1.

        Returns:
            list: list of pyspark expression strings
        """        
        mappings_expr = []
        
        for key, value in mapping.items():
            if key in ignore_elements:
                mappings_expr.append(f"collect_set(col('{key}')).alias('{key}')")
                continue
            
            schema_for_key = DicomToFhirUtils.get_fhir_element_schema(spark_schema, key)
            if isinstance(value, dict):
                #if element value is of type dict then recursively call this method 
                # to generate expression for nested elements as well
                child_mappings_expr = self._generate_expr_str(
                    schema_for_key, 
                    value, 
                    self._generate_mappings_expr(value, schema_for_key, ignore_elements, level+1)
                )
                mappings_expr.append(self._modify_expr_str_level_based(key, level, child_mappings_expr))
            elif isinstance(value, list):
                #if element value is of type list then recursively call this method 
                # for each element in the list to generate expression for them as well
                child_mappings = []
                for valueItem in value:
                    child_mappings.append(
                        self._generate_expr_str(
                            schema_for_key, 
                            valueItem, 
                            self._generate_mappings_expr(valueItem, schema_for_key, ignore_elements, level+1)
                        ))
                
                child_mappings_expr = child_mappings[0]
                if len(value) > 1:
                    #This is a handling for special elements like 'identifier' 
                    # which will have multiple nested structures
                    child_mappings = [f"to_json({child_mapping})" for child_mapping in child_mappings]
                    child_mappings_expr = f"array({', '.join(child_mappings)})"
                    
                mappings_expr.append(self._modify_expr_str_level_based(key, level, child_mappings_expr))
            else:
                mappings_expr.append(self._modify_expr_str_level_based(key, level, f"{value}.cast({schema_for_key})"))
                
        return mappings_expr
    
    def _df_groupby_and_agg(self, 
                           df: DataFrame, 
                           fhir_element_name: str, 
                           ignore_elements: list = []) -> DataFrame:
        
        """
        This method is used to do appropriate grouping and aggregation based on parameters passed

        Args:
            - df (Dataframe): the dataframe to be processed
            - fhir_element_name (str): the fhir element on which grouping and aggregation needs to be done
            - ignore_elements (list, optional): list of elements which needs to be ignored while processing. Defaults to [].
        Returns:
            DataFrame: dataframe after group by and aggregation
        """    
            
        mapping = DicomToFhirUtils.get_config_mappings(self.mapping_config, fhir_element_name)
        spark_schema = DicomToFhirUtils.get_fhir_element_schema(self.spark_schema, fhir_element_name)
        
        #generate mapping expression for all the elements as defined in the mapping config
        mappings_expr = self._generate_mappings_expr(mapping, spark_schema, ignore_elements)
        
        df_agg = df.groupBy(C.GROUP_BY_ELEMENTS[fhir_element_name]).agg(
            *[eval(mapping_expr) for mapping_expr in mappings_expr]
        )
        
        for column, value in mapping.items():
            if not isinstance(value, list):
                #if its a 1:1 mapping as per mapping config, 
                #take just the first element from the aggregated list
                #Example, say we do group by at series level and there are multiple modalities 
                #(which ideally should not be the case), we take the first value
                df_agg = df_agg.withColumn(
                    column,
                    when(
                        col(column).isNotNull() & col(column).getItem(0).isNotNull(), 
                        col(column).getItem(0)
                    ).otherwise(None))
            else:
                if len(value) > 1:
                    #this is a handling for special cases like 'identifier' fhir element 
                    #where it can have an array of different fhir structures/elements
                    #here also we try to take the first value
                    df_agg = df_agg.withColumn(column, col(column).getItem(0))
        
        #finally after all aggregations, we combine all the elements into a single struct 
        #named after the fhir element parameter passed  
        mapping = [f"'{key}'" for key in mapping.keys()]
        df_agg = df_agg.withColumn(fhir_element_name, eval(f"struct({', '.join(mapping)})"))
        
        df_agg = df_agg.select(*C.GROUP_BY_ELEMENTS[fhir_element_name], fhir_element_name)
        return df_agg
    
    def _generate_ndjson_and_save(self, df: DataFrame, epoch_id: str):
        """
        This method is used to generate fhir ndjson files from dicom metastore table
        """   
        
        if df.count() == 0:
            self._logger.info(LC.NO_NEW_DATA_FOUND_INFO_MSG)
            return
        
        self._logger.info(LC.FHIR_CONVERSION_PROCESS_STATE_INFO_MSG.format(
            epoch_id = epoch_id,
            state = C.STATE_STARTED,
            timestamp = datetime.now(),
            table_loc = self.delta_table_path
        ))
          
        df = DicomToFhirUtils.pre_process_dataframe(df, self.mapping_config)
        
        self._logger.info(LC.RECORDS_NUM_PROCESSED_INFO_MSG.format(
            records_num = df.count()
        ))
        
        #aggregating information at series level
        series_level_agg = self._df_groupby_and_agg(df, C.FHIR_SERIES_ELEMENT)
        
        self._logger.info(LC.FHIR_ELEMENT_COUNT_AFTER_GROUPING_INFO_MSSG.format(
            count= series_level_agg.count(),
            fhir_element_name=C.FHIR_SERIES_ELEMENT
        ))
    
        #joining aggregated information at series level with the original dataframe
        df = df.join(series_level_agg, C.GROUP_BY_ELEMENTS[C.FHIR_SERIES_ELEMENT], "leftouter")
        
        #aggregating information at study level
        study_level_agg = self._df_groupby_and_agg(df, C.FHIR_STUDY_ELEMENT, [C.FHIR_SERIES_ELEMENT]) 
        study_level_agg = study_level_agg.withColumn(C.FHIR_STUDY_ELEMENT, to_json(col(C.FHIR_STUDY_ELEMENT)))
        study_level_agg = study_level_agg.select(C.FHIR_STUDY_ELEMENT)
        
        self._logger.info(LC.FHIR_ELEMENT_COUNT_AFTER_GROUPING_INFO_MSSG.format(
            count= study_level_agg.count(),
            fhir_element_name=C.FHIR_STUDY_ELEMENT
        ))
        
        imaging_study_list = study_level_agg.collect()
        #json cleanup
        imaging_study_list = [
            json.dumps(DicomToFhirUtils.add_id_column(
                DicomToFhirUtils.cleanup_json(
                    json.loads(row.study), self.mapping_config
                ), C.ID_COLUMN_NAME)) 
            for row in imaging_study_list
        ]
        
        #splitting the records into multiple ndjson files 
        data_split = [ 
                        imaging_study_list[i:i + self.max_records_per_ndjson] 
                        for i in range(0, len(imaging_study_list), self.max_records_per_ndjson)
                    ]  
        
        for data in data_split:
            ndjson_data = "\n".join(data)
            current_timestamp = datetime.now(timezone.utc)
            ndjson_file_path = DicomToFhirUtils.get_ndjson_file_path(current_timestamp, self.fhir_namespace)
            
            file_path = f"{self.fhir_ndjson_files_root_path}/{ndjson_file_path}"
            self._logger.info(
                LC.SAVING_NDJSON_FILE_INFO_MSG.format(
                    num_records=len(data), 
                    file_path=file_path
                ))
            mssparkutils.fs.put(file_path, ndjson_data, True)
            
        self._logger.info(LC.FHIR_CONVERSION_PROCESS_STATE_INFO_MSG.format(
            epoch_id = epoch_id,
            state = C.STATE_COMPLETED,
            timestamp = datetime.now(),
            table_loc = self.delta_table_path
        ))
            
    def execute_ndjson_generation(self):
        try:
            stream_reader = DeltaTableStreamReader(self.spark)
            df = stream_reader.set_up_streaming(
                f"{self.delta_table_path}/{C.METADATA_TABLE_NAME}"
            )
        
            query = (df.writeStream.format("delta")
                .trigger(availableNow=True)
                .option("checkpointLocation", self.checkpoint_path)
                .foreachBatch(self._generate_ndjson_and_save)
                .start())
        
            query.awaitTermination()
        except Exception as e:
            self._logger.error(
                LC.SPARK_STREAM_READ_ERR_MSG.format(
                    table_path = self.delta_table_path,
                    error_msg = str(e)
                )
            )
            raise