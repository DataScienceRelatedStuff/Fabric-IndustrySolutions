import json
from typing import List

from sql_metadata import Parser

from tests.utils.db.builder.schema_builder import SchemaBuilder
from tests.utils.db.model.column import Column
from tests.utils.db.model.table import Table


class DBSourceSchemaBaseBuilder(SchemaBuilder):

    def __init__(self, spark, metadata_file, adapter_file, db, warehouse_location):
        super().__init__(spark, metadata_file, db, warehouse_location)
        self._adapter_file = adapter_file

    def parse_tables(self):
        metadata = self._read_db_metadata()
        for entity in metadata:
            table_name = entity['name']
            additional_properties = {
                "multiLine": "true",
                "ignoreLeadingWhiteSpace": "true",
                "ignoreTrailingWhiteSpace": "true",
                "timestampFormat": "M/dd/yyyy hh:mm:ss a",
                "quote": "\"",
                "escape": "\"",
            }
            if entity['entityType'] == 'TABLE' and table_name in self._used_tables():
                table = Table(name=table_name,
                              type="EXTERNAL",
                              format="csv",
                              partition_columns=[],
                              additional_properties=additional_properties,
                              location_root=self.data_location(),
                              db=self.db)

                for column in entity['storageDescriptor']['columns']:
                    precision = 0
                    scale = 0
                    type = column['originDataTypeName']['typeName']
                    if type == "long":
                        type = "bigint"
                    elif type == "decimal":
                        precision = 38
                        scale = 10

                    table.columns.append(Column(name=column['name'],
                                                type=type,
                                                precision=precision,
                                                scale=scale
                                                )
                                         )

                    self.tables[table_name] = table

    def _used_tables(self) -> List[str]:
        # Load Adapter file.
        with open(self._adapter_file) as json_file:
            adapter = json.load(json_file)

            sourceTables = []
            for sourceTable in adapter['sourceTables']:
                isQuery = 'query' in sourceTable

                if not sourceTable['tableName'] in sourceTables and not isQuery:
                    sourceTables.append(sourceTable['tableName'])
                if isQuery:
                    queryTables = Parser(sourceTable['query']).tables
                    for queryTable in queryTables:
                        if queryTable not in sourceTables:
                            sourceTables.append(queryTable)

            if 'queryTables' in adapter:
                for queryTable in adapter['queryTables']:
                    if not queryTable['name'] in sourceTables:
                        sourceTables.append(queryTable['name'])

            return sourceTables
