from pathlib import Path

from tests.utils.db.builder.db_source_schema_base_builder import DBSourceSchemaBaseBuilder
from project_root import PROJECT_ROOT_DIR


class SustainabilityDataverseSchemaBuilder(DBSourceSchemaBaseBuilder):

    @staticmethod
    def data_location() -> Path:
        return Path(PROJECT_ROOT_DIR, "tests", "data", "db", "dv_sus", "csv")
