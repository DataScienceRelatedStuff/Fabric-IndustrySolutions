from pyspark.sql import SparkSession

from rmt.core.values_mapping.mapping_values_definition import MappingValuesDefinition, TargetMapping
from tests.common.test_case_common import TestCaseCommon


class TestMappingValuesDefinition:

    source_domain = "Test"
    target_table = "gender"
    target_field = "genderId"
    target_mapping_1_to_male = TargetMapping(1, ["male"])
    target_mapping_2_to_female = TargetMapping(2, ["female"])
    target_mapping_3_to_2others = TargetMapping(3, ["other", "104800003"])
    target_mapping_1_to_other = TargetMapping(1, ["other"])

    def test_to_mapping_dataframe_empty(self, spark: SparkSession):

        mapping_definition = MappingValuesDefinition(TestMappingValuesDefinition.target_table, TestMappingValuesDefinition.target_field, [])
        mapping_dataframe = mapping_definition.to_mapping_dataframe(spark, TestMappingValuesDefinition.source_domain)
        assert mapping_dataframe.count() == 0

    def test_to_mapping_dataframe_simple(self, spark: SparkSession):

        mapping_definition = MappingValuesDefinition(TestMappingValuesDefinition.target_table,
                                                     TestMappingValuesDefinition.target_field,
                                                     [TestMappingValuesDefinition.target_mapping_1_to_male,
                                                      TestMappingValuesDefinition.target_mapping_2_to_female])
        mapping_dataframe = mapping_definition.to_mapping_dataframe(spark, TestMappingValuesDefinition.source_domain)
        assert mapping_dataframe.count() == 2
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[0],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "male", 1)
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[1],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "female", 2)

    def test_to_mapping_dataframe_with_multi_mapping(self, spark: SparkSession):

        mapping_definition = MappingValuesDefinition(TestMappingValuesDefinition.target_table,
                                                     TestMappingValuesDefinition.target_field,
                                                     [TestMappingValuesDefinition.target_mapping_1_to_male,
                                                      TestMappingValuesDefinition.target_mapping_3_to_2others])
        mapping_dataframe = mapping_definition.to_mapping_dataframe(spark, TestMappingValuesDefinition.source_domain)
        assert mapping_dataframe.count() == 3
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[0],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "male", 1)
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[1],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "other", 3)
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[2],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "104800003", 3)

    def test_to_mapping_dataframe_with_duplicate(self, spark: SparkSession):

        mapping_definition = MappingValuesDefinition(TestMappingValuesDefinition.target_table,
                                                     TestMappingValuesDefinition.target_field,
                                                     [TestMappingValuesDefinition.target_mapping_1_to_male,
                                                      TestMappingValuesDefinition.target_mapping_1_to_other])
        mapping_dataframe = mapping_definition.to_mapping_dataframe(spark, TestMappingValuesDefinition.source_domain)
        assert mapping_dataframe.count() == 2
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[0],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "male", 1)
        TestCaseCommon.assert_mapping_row(mapping_dataframe.collect()[1],
                                          TestMappingValuesDefinition.source_domain,
                                          TestMappingValuesDefinition.target_table,
                                          TestMappingValuesDefinition.target_field, "other", 1)

    # todo handle duplicate?
