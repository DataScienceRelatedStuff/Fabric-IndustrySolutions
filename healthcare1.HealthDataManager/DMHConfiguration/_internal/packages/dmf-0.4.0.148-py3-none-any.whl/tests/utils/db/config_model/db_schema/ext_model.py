import json
from typing import Dict, List, Optional

import pydantic

from tests.utils.db.config_model.db_schema.model import JoinPair, ModelItem, RawSchemaModel, RelationShip


class DBSchemaModel(RawSchemaModel, extra=pydantic.Extra.allow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__tables_dict = None

    @classmethod
    def from_str(cls, db_schema: str) -> "DBSchemaModel":
        try:
            tables = pydantic.parse_obj_as(List[ModelItem], json.loads(db_schema))
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse target DB schema Json: {e}")
        return cls(tables=tables)

    @property
    def tables_dict(self) -> Dict[str, ModelItem]:
        if self.__tables_dict is None:
            self.__tables_dict = {table.name: table for table in self.tables}
        return self.__tables_dict

    def get_pointing_relationships_on_field(self, pointed_table_name: str, pointed_field_name: str) -> List[RelationShip]:
        pointing_tables_on_field: List[ModelItem] = self.get_pointing_tables_on_field(pointed_table_name, pointed_field_name)
        relationships = []
        for table in pointing_tables_on_field:
            for rel in table.properties.relationships:
                for join_pair in rel.joinPairs:
                    if join_pair.toAttribute == pointed_field_name:
                        relationships.append(rel)
        return relationships

    def get_pointing_fks_on_field(self, pointed_table_name: str, pointed_field_name: str) -> List[JoinPair]:
        pointing_tables_on_field: List[ModelItem] = self.get_pointing_tables_on_field(pointed_table_name, pointed_field_name)
        join_pairs = []
        for table in pointing_tables_on_field:
            for rel in table.properties.relationships:
                for join_pair in rel.joinPairs:
                    if join_pair.toAttribute == pointed_field_name:
                        join_pairs.append(join_pair)
        return join_pairs

    def get_field_type(self, table_name: str, field_name: str) -> str:
        table = self.tables_dict[table_name]
        for column in table.storageDescriptor.columns:
            if column.name == field_name:
                return column.originDataTypeName.typeName
        raise ValueError(f"Field {field_name} not found in table {table_name}")

    def get_pointed_tables_by_field(self, pointing_table_name: str, pointing_field_name: str) -> Optional[ModelItem]:
        pointing_table = self.tables_dict[pointing_table_name]
        for rel in pointing_table.properties.relationships:
            if rel.fromEntity == pointing_table_name:
                for join_pair in rel.joinPairs:
                    if join_pair.fromAttribute == pointing_field_name:
                        return self.tables_dict[rel.toEntity]
        return None


    def _fail_on_duplicate_columns(self, table_model):
        """
        Raises ValueError if there are duplicate columns in the table
        this can create havok later on
        """
        duplicate_column = self.find_duplicate_value([c.name for c in table_model.storageDescriptor.columns])
        if duplicate_column:
            raise ValueError(f"Duplicate column {duplicate_column} in table {table_model.name}")

    def table_db_name(self, table: ModelItem) -> str:
        return table.namespace.databaseName
    
    def get_pointing_tables(self, pointed_table_name: str) -> List[ModelItem]:
        pointing_tables = []
        for table in self.tables:
            for rel in table.properties.relationships:
                if rel.toEntity == pointed_table_name:
                    pointing_tables.append(table)
        return pointing_tables

    def get_pointing_tables_on_field(self, pointed_table_name: str, pointed_field_name: str) -> List[ModelItem]:
        pointing_tables = self.get_pointing_tables(pointed_table_name)
        pointing_tables_on_field = []
        for table in pointing_tables:
            for rel in table.properties.relationships:
                for join_pair in rel.joinPairs:
                    if join_pair.toAttribute == pointed_field_name:
                        pointing_tables_on_field.append(table)
        return pointing_tables_on_field
