# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class containing static methods used for dicom metadata to fhir ndjson conversion
"""
from pyspark.sql import DataFrame
import pydicom
import re
import json
import os
from datetime import datetime
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C
from pyspark.sql.types import *
from pyspark.sql.functions import *
import uuid

class DicomToFhirUtils:
    """
    Class containing static methods used for dicom metadata to ImagingStudy fhir ndjson conversion
    """    
    
    @staticmethod
    def get_ndjson_file_path(current_datetime: datetime, fhir_namespace: str) -> str:
        """
        This method is used to get the ndjson file path as per fhir landing zone contract

        Args:
            current_datetime (datetime): datetime for which ndjson needs to be stored
            fhir_namespace (str): namespace used in fhir landing zone contract

        Returns:
            str: path for storing fhir ndjson files
        """        
        ndjson_file_name = f"{C.FHIR_IMAGING_STUDY_RES_NAME}-{current_datetime.strftime(C.FHIR_NDJSON_NAME_FORMAT)}{C.FHIR_NDJSON_FILE_EXT}"
        
        year = str(current_datetime.year)
        month = current_datetime.strftime("%m")  # Zero-padded month
        day = current_datetime.strftime("%d") # Zero-padded day
        
        return os.path.join(C.FHIR_LANDING_ZONE_ROOT_FOLDER, 
                            fhir_namespace,
                            year, month, day,
                            C.FHIR_IMAGING_STUDY_RES_NAME,
                            ndjson_file_name)
    
    @staticmethod
    def add_id_column(study_object: dict, id_column_name: str) -> dict:
        """
        This method is used to add a unique identifier to the begining of a imaging study fhir object

        Args:
            study_object (dict): imaging study object
            id_column_name (str): id column name

        Returns:
            dict: imaging study object with id column added 
        """        
        id_dict = {id_column_name: str(uuid.uuid4())}
        return {**id_dict, **study_object}
    
    @staticmethod
    def is_empty_value(value) -> bool:
        """
        This method is used to identify if a json value is empty

        Args:
            value: any valid json value

        Returns:
            bool: returns true if json value is empty otherwise false
        """        
        if (value is None or 
            (isinstance(value, str) and value.strip() == "") or
            ((isinstance(value, dict) or isinstance(value, list)) 
            and not value)):
            return True
        return False
    
    @staticmethod
    def get_mapping_for_array_element(mapping_config: list, index: int):
        """
        This method is used to fetch config mapping for a particular array element

        Args:
            mapping_config (list) : mapping config for parent array 
            index (int): index for which mapping needs to be fetched

        Returns:
            Mapping config for the child element 
        """        
        try:
            return mapping_config[index]
        except Exception as e:
            return mapping_config[0]
    
    @staticmethod
    def cleanup_json(json_value, mapping_config):
        """
        This method is used recursively to cleanup json which included following:
        - Removing empty values
        - Prettifying json elements present as string
        - Adding any missing brackets as per mapping config

        Args:
            json_value : any valid json value which is getting processed
            mapping_config: mapping config corresponding to the json value element 

        Returns:
            Cleaned up json value
        """        
        if DicomToFhirUtils.is_empty_value(json_value):
            return None
        elif isinstance(json_value, dict):
            for key, value in list(json_value.items()):
                if isinstance(mapping_config[key], list) and not isinstance(value, list):
                    #adding missing brackets as per mapping config
                    json_value[key]= [json_value[key]]
                
                if DicomToFhirUtils.cleanup_json(json_value[key], mapping_config[key]) == None:
                    #removing empty json values
                    del json_value[key]
                    
            if DicomToFhirUtils.is_empty_value(json_value):
                return None
        elif isinstance(json_value, list):
            for index, item in enumerate(json_value):
                try:
                    #prettifying json elements if present as string
                    item_json = json.loads(item)
                    json_value[index] = item_json
                except Exception as e:
                    pass
                
                if DicomToFhirUtils.cleanup_json(json_value[index], DicomToFhirUtils.get_mapping_for_array_element(mapping_config, index)) == None:
                    #removing empty json values
                    del json_value[index]
            if DicomToFhirUtils.is_empty_value(json_value):
                return None

        return json_value
    
    @staticmethod
    def is_calc_column(column_config: dict) -> bool:
        """
        This method is used to check if the column config passed is for calculated column

        Args:
            column_config (dict): column config for the element

        Returns:
            bool: True if its a calculated column, False otherwise
        """        
        if 'calc' in column_config.keys():
            return True
        return False
    
    @staticmethod
    def get_config_mappings(mappings, fhir_element_name):
        """
        This method is used to get config mapping for a particular fhir element

        Args:
            mappings : config mapping object
            fhir_element_name : fhir element name

        Returns:
            mappings for the fhir elemenet
        """        
        if fhir_element_name == C.FHIR_STUDY_ELEMENT:
            return mappings
        
        mappings = mappings[fhir_element_name]
        if isinstance(mappings, list):
            mappings = mappings[0]
        return mappings
    
    @staticmethod
    def get_fhir_element_schema(schema, element):
        """
        This method is used to get schema definition for a particular fhir element

        Args:
            schema : spark schema definition object
            element : fhir element for which schema needs to be fetched

        Returns:
            spark schema for particular fhir element passed
        """        
        if element == C.FHIR_STUDY_ELEMENT:
            return schema
        
        if isinstance(schema, StructType):
            try:
                schema = schema[element].dataType
            except Exception as e:
                schema = StringType()
        if isinstance(schema, ArrayType):
            schema = schema.elementType
        
        return schema
    
    @staticmethod
    def get_tags_required(mapping_obj: dict) -> set:
        """
        This method is used to fetch all the tags/columns required for mapping 
        dicom metadata to fhir as per the mapping config

        Args:
            mapping_obj (dict): mapping object from which tag names need to be fetched

        Returns:
            set: set of tag names 
        """        
        
        mapping_str = json.dumps(mapping_obj)
        pattern = r'col\(\'(\w+)\'\)'
        return set(re.findall(pattern, mapping_str))
    
    @staticmethod
    def normalize_dicom_tag_value(tag_vr: str, tag_value: str):
        """
        This method is used to normalize dicom tag values

        Args:
            tag_vr (str): 'VR' of the tag
            tag_value (str): value of the tag

        Returns:
            any: normalized value for the tag
        """        
        
        if DicomToFhirUtils.is_empty_value(tag_value):
            return tag_value
        if tag_vr == "DA":
            #if the tag is of type date
            #we change the format from YYYYMMDD to YYYY-MM-DD
            return f"{tag_value[:4]}-{tag_value[4:6]}-{tag_value[6:]}"
        elif tag_vr == "TM":
            #if the tag is of type time
            #we change the format from HHMMSS.FFFFFF to HH:MM:SS.FFFFFF
            time_split = tag_value.split(".")
            time_split[0] = ':'.join(time_split[0][i:i + 2] for i in range(0, len(time_split[0]), 2)) 
            return ".".join(time_split)
        return tag_value
    
    @staticmethod
    def get_tag_for_keyword(keyword: str) -> str:
        """
        This method is used to get the tag id for a tag keyword 
        using the pydicom OOB data dict

        Args:
            keyword (str): tag keyword

        Returns:
            str: a string representation of tag id
        """        
        dicom_tag = pydicom.datadict.tag_for_keyword(keyword)
        return f"{dicom_tag >> 16:04X}{dicom_tag & 0xFFFF:04X}"
    
    @staticmethod
    def pre_process_dataframe(df: DataFrame, mapping_config: dict) -> DataFrame:
        """
        This method is used to pre-process the dataframe before the fhir conversion
        - Verify all the tags required for conversion are present as columns in dataframe, if not then extract them from metadata column
        - Format the dicom tag value properly for correct conversion

        Args:
            df (DataFrame): input dataframe to be pre-processed
            mapping_config (dict): mapping config used for conversion
            
        Returns:
            DataFrame: dataframe with appropriate column formatting and inclusion of missing columns
        """        
        
        tags_required = DicomToFhirUtils.get_tags_required(mapping_config)
        
        normalize_dicom_tags_udf = udf(DicomToFhirUtils.normalize_dicom_tag_value)
        
        for tag in tags_required:
            df_col_name = tag.lower()
            if df_col_name in df.columns:
                continue
            
            #this is handling for the case when there are some tags required for conversion 
            # as per mapping file but are not present as columns in dataframe
            try:
                tag_str = DicomToFhirUtils.get_tag_for_keyword(tag)
                df = df.withColumn(df_col_name, expr(f"map_filter({C.TAGS_JSON_COLUMN_NAME}, (key, value) -> key == {tag_str})"))
                df = df.withColumn(df_col_name, normalize_dicom_tags_udf(col(f'{df_col_name}.{tag_str}.vr'), col(f'{df_col_name}.{tag_str}.Value').getItem(0)))
            except Exception as e:
                df = df.withColumn(df_col_name, lit(None))
             
        for tag in C.DEFAULT_TAGS_AS_COLUMN:
            #this is to normalize all the tag values which are by default present 
            # as column in dataframe
            df_col_name = tag.lower()
            try:
                tag_str = DicomToFhirUtils.get_tag_for_keyword(tag)
                df = df.withColumn(df_col_name, normalize_dicom_tags_udf(expr(f"map_filter({C.TAGS_JSON_COLUMN_NAME}, (key, value) -> key == {tag_str})").getItem(tag_str).getItem('vr'), col(f'{df_col_name}')))
            except Exception as e:
                continue
        return df