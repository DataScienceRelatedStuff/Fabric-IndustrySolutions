# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module defining constants for NLP TA4H
"""

# pylint: disable=R0903 # too-few-public-methods


class NLPConstants:
    """Constants used by NLP library"""
    # default batch size
    DEFAULT_BATCH_SIZE = 15
    # default recoverable error codes for the whole NLP results
    DEFAULT_RECOVERABLE_ERROR_CODES = {
        "429", "504", "408", "500", "503", "internalServerError", "serviceUnavailable"}
    # Retry policy status codes to retry on per request
    DEFAULT_RETRY_POLICY_STATUS_CODES = {
        "429", "504", "408", "500", "503"}
    # Retry policy back off factor by which the delay between retries increases
    DEFAULT_RETRY_POLICY_BACKOFF_FACTOR = 0.8
    # Retry policy total number of retries
    DEFAULT_RETRY_POLICY_TOTAL_RETRIES = 10
    # Default maximum number of documents to process for text analysis
    DEFAULT_MAX_DOC_LIMIT = 1000
    # Default level of parallelism
    DEFAULT_SPARK_PARALLELISM = 1
    # Default max level of parallelism to avoid rate limit failure
    DEFAULT_MAX_PARALLELISM = 100
    # NLP entity resource type
    NLP_ENTITY_RESOURCE_TYPE = "NLPEntity"
    # NLP entity relation resource type
    NLP_ENTITY_RELATION_RESOURCE_TYPE = "NLPRelationship"
    # NLP FHIR resource bundle type
    NLP_ENTITY_FHIR_RESOURCE_TYPE = "NLPFHIR"
    # Default maximum retry count for subset of recoverable errors
    DEFAULT_NLP_PIPELINE_MAX_RETRY_COUNT = 3
    # Default NLP column name mapping used to identify the various columns of the dataframe
    DEFAULT_NLP_COLUMNS_NAMING = {
        "Text": "content_attachment_data",
        "Id": "id",
        "LastUpdated": "meta_lastUpdated",
        "Result": "result"
    }
    # Default NLP column name mapping text key
    DEFAULT_NLP_COLUMNS_NAMING_TEXT_KEY = "Text"
    # Default NLP column name mapping id key
    DEFAULT_NLP_COLUMNS_NAMING_ID_KEY = "Id"
    # Default NLP column name mapping last updated key
    DEFAULT_NLP_COLUMNS_NAMING_LAST_UPDATED_KEY = "LastUpdated"
    # Default NLP column name mapping result key
    DEFAULT_NLP_COLUMNS_NAMING_RESULT_KEY = "Result"
    # Default text analytics display name to set for the requested analysis
    DEFAULT_TEXT_ANALYTICS_REQUEST_DISPLAY_NAME = "Text Analysis for Health NLP pipeline"
    # Default text analytics model version
    DEFAULT_TEXT_ANALYTICS_MODEL_VERSION = "latest"
    # Default text analytics FHIR version
    DEFAULT_TEXT_ANALYTICS_FHIR_VERSION = "4.0.1"
    # Default resource to process in the scope of preview
    DEFAULT_NLP_RESOURCE_TYPE_TO_ANALYZE = "DocumentReferenceContent"
    # Default unique columns used for saving NLP Entity and NLPRelationship in delta tables
    DEFAULT_NLP_OUTPUT_UNIQUE_COLUMNS = ["id"]
