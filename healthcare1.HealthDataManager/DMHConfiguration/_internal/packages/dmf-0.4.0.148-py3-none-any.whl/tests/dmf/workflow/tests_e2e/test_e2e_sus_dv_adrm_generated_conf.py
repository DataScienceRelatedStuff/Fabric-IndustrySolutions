from pathlib import Path
from typing import Tuple, Union

import pytest
from pyspark.sql import Column, DataFrame, SparkSession
from pyspark.sql import functions as F

from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.model.data_feed_configuration import DataFeedConfiguration
from dmf.model.source_configuration import SourceConfiguration
from dmf.transformations.reader.query_reader import QueryReader
from dmf.transformations.reader.storage_reader import StorageReader
from dmf.transformations.reader.table_reader import TableReader
from dmf.utils.dataframe_utils import DataFrameUtils
from dmf.utils.global_constants import GlobalConstants
from project_root import PROJECT_ROOT_DIR
from tests.conftest import clean_db_sink_tables_root, transformation_spec_file_name
from tests.utils.constants import Constants
from tests.utils.dmf_application_test_util import DMFApplicationTestUtil


@pytest.fixture(scope="function", autouse=True)
def clean_db_files_fixture():
    clean_db_sink_tables_root()


class TestE2ESusDvAdrmGeneratedConf:
    src_data_location = Path(PROJECT_ROOT_DIR, "tests", "data", "db", "dv_sus", "csv")

    def reduced_transformation_spec_path(self, test_name: str) -> Path:
        return Constants.GENERATED_TRANSFORMATION_SPECS_ROOT / test_name / transformation_spec_file_name

    def _get_source_config(self, config: DataFeedConfiguration, source_id: str) -> SourceConfiguration:
        for sc in config.source_configurations:
            if sc.source_id == source_id:
                return sc
        raise ValueError(f"source_id {source_id} not found in config")

    def _get_source_data_source_id(self, config: DataFeedConfiguration, source_id: str) -> Tuple[DataSourceTypeEnum, str]:
        data_access_definition = self._get_source_config(config, source_id).data_access_definition
        return data_access_definition.data_source_type, data_access_definition.data_source_id

    def _read_source_table(self, configuration, source_id, spark, db) -> DataFrame:
        data_source_type, table_expr = self._get_source_data_source_id(configuration, source_id)
        if data_source_type == DataSourceTypeEnum.TABLE:
            return TableReader(db, table_expr).read(spark)
        elif data_source_type == DataSourceTypeEnum.QUERY:
            return QueryReader(db, table_expr).read(spark)
        raise ValueError(f"Unsupported data source type {data_source_type}")

    def _read_target_table(self, spark, table_name):
        df = StorageReader(str(Constants.SINK_TABLES_ROOT / table_name), "delta").read(spark)
        assert df is not None
        return df

    def _read_mapping_table(self, spark, table_name: str) -> DataFrame:
        table_path = Path(spark.conf.get("spark.sql.warehouse.dir")) / GlobalConstants.ID_MAPPING_PATH / table_name
        mapping_table_df = StorageReader(str(table_path), "delta").read(spark)
        assert mapping_table_df is not None, f"Mapping table {table_name} not found"
        return mapping_table_df

    def _assert_column_data_transformed(self,
                                        spark: SparkSession,
                                        source_df: DataFrame,
                                        source_id_column_expr: Union[Column, str],
                                        source_column_expr: str,
                                        target_df: DataFrame,
                                        target_id_column_name: str,
                                        target_column_expr: str,
                                        mapping_table_name: str,
                                        fk: bool = False):

        if isinstance(source_id_column_expr, str):
            source_id_column_expr = F.expr(source_id_column_expr)
        if isinstance(source_column_expr, str):
            source_column_expr = F.expr(source_column_expr)
        if isinstance(target_column_expr, str):
            target_column_expr = F.expr(target_column_expr)
        mapping_df = self._read_mapping_table(spark, mapping_table_name)
        source_df = source_df.withColumn("JOIN_COLUMN", source_id_column_expr)
        joined_with_mapping_df = source_df \
            .join(mapping_df, source_df["JOIN_COLUMN"] == mapping_df.INTERNAL_ID, 'left')
        how_to_join = "inner" if fk else "left"
        data_df = joined_with_mapping_df \
            .join(target_df, joined_with_mapping_df.ADRM_ID == target_df[target_id_column_name], how_to_join) \
            .select([source_column_expr.alias("SOURCE_COLUMN_EXPR"),
                     target_column_expr.alias("TARGET_COLUMN_EXPR")])

        bool_column_name = "ASSERTION_RESULT"
        bool_df = data_df.select(
            F.col("SOURCE_COLUMN_EXPR") \
                .eqNullSafe(F.col("TARGET_COLUMN_EXPR")) \
                .alias(bool_column_name)
        )

        all_true = bool_df.agg(F.min(bool_df[bool_column_name])).first()[0]  # False is considered "smaller" than True in a boolean context
        assert all_true, f"Data in {source_column_expr} column is not transformed correctly to {target_column_expr} column"

    def assert_fk_transformed(self,
                              spark: SparkSession,
                              source_df: DataFrame,
                              source_id_column_expr: str,
                              target_df: DataFrame,
                              target_id_column_name: str,
                              mapping_table_name: str):

        mapping_df = self._read_mapping_table(spark, mapping_table_name)
        source_df = source_df.withColumn("JOIN_COLUMN", F.expr(source_id_column_expr))
        mapped_fks_df = source_df \
            .join(mapping_df, source_df["JOIN_COLUMN"] == mapping_df.INTERNAL_ID, 'left') \
            .select("ADRM_ID")
        missing_fks = mapped_fks_df.join(target_df, mapped_fks_df.ADRM_ID == target_df[target_id_column_name], 'left_anti')
        assert DataFrameUtils.is_empty(missing_fks), f"FKs in {source_id_column_expr} column are not transformed correctly to {target_id_column_name} column"

    def assert_column_data_transformed_water_utilization(self,
                                                         spark: SparkSession,
                                                         source_df: DataFrame,
                                                         source_column_expr: str,
                                                         target_df: DataFrame,
                                                         target_column_expr: str):
        self._assert_column_data_transformed(
            spark,
            source_df=source_df,
            source_id_column_expr="msdyn_waterquantityid",
            source_column_expr=source_column_expr,
            target_df=target_df,
            target_id_column_name='WaterUtilizationId',
            target_column_expr=target_column_expr,
            mapping_table_name="WATERUTILIZATION_ID_MAPPING")


    # @pytest.mark.long
    def test_all_hands_sus(self,
                           spark,
                           sus_config,
                           dataverse_db_name,
                           # disable_processors_parallelism
                           ):

        DMFApplicationTestUtil.start_dmf(sus_config, spark)

        waterquantity_df = self._read_source_table(sus_config, "msdyn_waterquantity_updated", spark, dataverse_db_name)
        msdyn_facility_df = self._read_source_table(sus_config, "msdyn_facility_updated", spark, dataverse_db_name)
        msdyn_sustainabilityorganizationalunit_df = self._read_source_table(sus_config, "msdyn_sustainabilityorganizationalunit", spark,
                                                                            dataverse_db_name)
        msdyn_organizationalprofile_df = self._read_source_table(sus_config, "msdyn_organizationalprofile", spark, dataverse_db_name)
        msdyn_sustainabilityorganizationalhierarchy_df = self._read_source_table(sus_config, "msdyn_sustainabilityorganizationalhierarchy",
                                                                                 spark, dataverse_db_name)

        water_utilization_df = self._read_target_table(spark, "WaterUtilization")
        party_organization_df = self._read_target_table(spark, "PartyOrganization")
        asset_df = self._read_target_table(spark, "Asset")
        facility_df = self._read_target_table(spark, "Facility")
        location_df = self._read_target_table(spark, "Location")
        party_df = self._read_target_table(spark, "Party")
        related_party_df = self._read_target_table(spark, "RelatedParty")
        process_df = self._read_target_table(spark, "Process")
        legal_entity_df = self._read_target_table(spark, "LegalEntity")
        self._assert_water_quantity_transformations(facility_df, party_organization_df, process_df, spark, water_utilization_df, waterquantity_df)
        self._assert_facility_transformations(facility_df, location_df, msdyn_facility_df, party_df, spark)
        self._assert_party_organization_data_transformed(location_df, msdyn_sustainabilityorganizationalunit_df, party_organization_df, spark)
        for source_column_expr, target_column_expr in [("msdyn_companyprofilelogobase64", "LegalEntityLogo"),
                                                       ("msdyn_countryisocode", "CountryOfLegalEntityEstablishment"),
                                                       ("msdyn_name", "LegalEntityName"),
                                                       ("msdyn_stateprovince", "StateOfLegalEntityEstablishment")
                                                       ]:
            self._assert_column_data_transformed(
                spark,
                source_df=msdyn_organizationalprofile_df,
                source_id_column_expr="msdyn_organizationalprofileid",
                source_column_expr=source_column_expr,
                target_df=legal_entity_df,
                target_id_column_name="LegalEntityId",
                target_column_expr=target_column_expr,
                mapping_table_name="LEGALENTITY_ID_MAPPING"
            )
        for source_column_expr, target_column_expr in [("msdyn_effectivestartdate", "PartyRelationshipPeriodStartTimestamp"),
                                                       (F.to_timestamp(F.lit("2100-01-01")), "PartyRelationshipPeriodEndTimestamp"),
                                                       ]:
            self._assert_column_data_transformed(
                spark,
                source_df=msdyn_sustainabilityorganizationalhierarchy_df,
                source_id_column_expr="msdyn_organizationalunitid",
                source_column_expr=source_column_expr,
                target_df=related_party_df,
                target_id_column_name="PartyId",
                target_column_expr=target_column_expr,
                mapping_table_name="PARTY_ID_MAPPING"
            )
        for source_id_expr, target_id_expr in [("msdyn_organizationalunitid", "PartyId"),
                                               ("msdyn_parentid", "RelatedPartyId")
                                               ]:
            self.assert_fk_transformed(
                spark,
                source_df=msdyn_sustainabilityorganizationalhierarchy_df,
                source_id_column_expr=source_id_expr,
                target_df=related_party_df,
                target_id_column_name=target_id_expr,
                mapping_table_name="PARTY_ID_MAPPING"
            )

    def _assert_party_organization_data_transformed(self, location_df, msdyn_sustainabilityorganizationalunit_df, party_organization_df, spark):
        self._assert_column_data_transformed(
            spark,
            source_df=msdyn_sustainabilityorganizationalunit_df,
            source_id_column_expr="msdyn_sustainabilityorganizationalunitid",
            source_column_expr="msdyn_description",
            target_df=party_organization_df,
            target_id_column_name="PartyOrganizationId",
            target_column_expr="OrganizationDescription",
            mapping_table_name="PARTYORGANIZATION_ID_MAPPING"
        )
        self._assert_column_data_transformed(
            spark,
            source_df=msdyn_sustainabilityorganizationalunit_df,
            source_id_column_expr="msdyn_sustainabilityorganizationalunitid",
            source_column_expr="msdyn_name",
            target_df=party_organization_df,
            target_id_column_name="PartyOrganizationId",
            target_column_expr="OrganizationName",
            mapping_table_name="PARTYORGANIZATION_ID_MAPPING"
        )
        party_org_with_location_df = party_organization_df.join(location_df, 'LocationId', 'inner')
        source_target_fields = [
            ("msdyn_addresscity", "LocationCity"),
            ("msdyn_addressstreet1", "LocationAddressLine1"),
            ("msdyn_addressstreet2", "LocationAddressLine2"),
            ("msdyn_addresszippostalcode", "LocationZipCode"),
            ("FLOAT(msdyn_latitude)", "FLOAT(LocationLatitude)"),
            ("FLOAT(msdyn_longitude)", "FLOAT(LocationLongitude)"),

        ]
        for source_field, target_field in source_target_fields:
            self._assert_column_data_transformed(
                spark,
                source_df=msdyn_sustainabilityorganizationalunit_df,
                source_id_column_expr="msdyn_sustainabilityorganizationalunitid",
                source_column_expr=source_field,
                target_df=party_org_with_location_df,
                target_id_column_name="PartyOrganizationId",
                target_column_expr=target_field,
                mapping_table_name="PARTYORGANIZATION_ID_MAPPING"
            )

    def _assert_water_quantity_transformations(self, facility_df, party_organization_df, process_df, spark, water_utilization_df, waterquantity_df):
        self._assert_watre_quantity_water_utilization_transformations(spark, water_utilization_df, waterquantity_df)
        # test fks
        self.assert_fk_transformed(
            spark,
            source_df=waterquantity_df,
            source_id_column_expr="msdyn_facility",
            target_df=facility_df,
            target_id_column_name='FacilityId',
            mapping_table_name="FACILITY_ID_MAPPING")
        self.assert_fk_transformed(
            spark,
            source_df=waterquantity_df,
            source_id_column_expr="msdyn_organizationalunit",
            target_df=party_organization_df,
            target_id_column_name='PartyOrganizationId',
            mapping_table_name="PARTYORGANIZATION_ID_MAPPING"
        )
        self._assert_water_quantity_process_transformations(process_df, spark, waterquantity_df)

    def _assert_water_quantity_process_transformations(self, process_df, spark, waterquantity_df):
        self._assert_column_data_transformed(
            spark,
            source_df=waterquantity_df,
            source_id_column_expr="concat_ws('_', msdyn_industrialprocesstype, msdyn_waterquantityid)",
            source_column_expr="msdyn_transactionstartdate",
            target_df=process_df,
            target_id_column_name="ProcessId",
            target_column_expr="ProcessStartTimestamp",
            mapping_table_name="PROCESS_ID_MAPPING",
            fk=True
        )
        self._assert_column_data_transformed(
            spark,
            source_df=waterquantity_df,
            source_id_column_expr="concat_ws('_', msdyn_industrialprocesstype, msdyn_waterquantityid)",
            source_column_expr="msdyn_transactionenddate",
            target_df=process_df,
            target_id_column_name="ProcessId",
            target_column_expr="ProcessEndTimestamp",
            mapping_table_name="PROCESS_ID_MAPPING",
            fk=True
        )
        self._assert_column_data_transformed(
            spark,
            source_df=waterquantity_df,
            source_id_column_expr="concat_ws('_', msdyn_industrialprocesstype, msdyn_waterquantityid)",
            source_column_expr="msdyn_transactionenddate",
            target_df=process_df,
            target_id_column_name="ProcessId",
            target_column_expr="ProcessEndTimestamp",
            mapping_table_name="PROCESS_ID_MAPPING",
            fk=True
        )
        self._assert_column_data_transformed(
            spark,
            source_df=waterquantity_df,
            source_id_column_expr="concat_ws('_', msdyn_industrialprocesstype, msdyn_waterquantityid)",
            source_column_expr="msdyn_transactionenddate",
            target_df=process_df,
            target_id_column_name="ProcessId",
            target_column_expr="ProcessEndTimestamp",
            mapping_table_name="PROCESS_ID_MAPPING",
            fk=True
        )

    def _assert_watre_quantity_water_utilization_transformations(self, spark, water_utilization_df, waterquantity_df):
        self.assert_column_data_transformed_water_utilization(
            spark,
            source_df=waterquantity_df,
            source_column_expr="date(msdyn_transactionstartdate)",
            target_df=water_utilization_df,
            target_column_expr='PeriodStartDate')
        self.assert_column_data_transformed_water_utilization(
            spark,
            source_df=waterquantity_df,
            source_column_expr="date(msdyn_transactionenddate)",
            target_df=water_utilization_df,
            target_column_expr='PeriodEndDate')
        self.assert_column_data_transformed_water_utilization(
            spark,
            source_df=waterquantity_df,
            source_column_expr="msdyn_quantity",
            target_df=water_utilization_df,
            target_column_expr='WaterUtilizationUnits')
        self.assert_column_data_transformed_water_utilization(
            spark,
            source_df=waterquantity_df,
            source_column_expr="msdyn_description",
            target_df=water_utilization_df,
            target_column_expr='PartyWaterUtilizationNote')

    def _assert_facility_transformations(self, facility_df, location_df, msdyn_facility_df, party_df, spark):
        facility_with_party_df = facility_df.join(party_df, 'PartyId', 'inner')
        self._assert_column_data_transformed(
            spark,
            source_df=msdyn_facility_df,
            source_id_column_expr="msdyn_facilityid",
            source_column_expr="msdyn_name",
            target_df=facility_df,
            target_id_column_name="FacilityId",
            target_column_expr="FacilityName",
            mapping_table_name="FACILITY_ID_MAPPING"
        )
        self._assert_column_data_transformed(
            spark,
            source_df=msdyn_facility_df,
            source_id_column_expr="msdyn_facilityid",
            source_column_expr="msdyn_name",
            target_df=facility_with_party_df,
            target_id_column_name="FacilityId",
            target_column_expr="PartyName",
            mapping_table_name="FACILITY_ID_MAPPING"
        )
        self._assert_facility_location_transformations(facility_df, location_df, msdyn_facility_df, spark)

    def _assert_facility_location_transformations(self, facility_df, location_df, msdyn_facility_df, spark):
        facility_with_location_df = facility_df.join(location_df, 'LocationId', 'inner')
        source_target_pairs = [
            ("msdyn_name", "LocationName"),
            ("msdyn_addresscity", "LocationCity"),
            ("msdyn_addressstreet1", "LocationAddressLine1"),
            ("msdyn_addressstreet2", "LocationAddressLine2"),
            ("msdyn_addresszippostalcode", "LocationZipCode"),
            ("FLOAT(msdyn_latitude)", "FLOAT(LocationLatitude)"),
            ("FLOAT(msdyn_longitude)", "FLOAT(LocationLongitude)"),

        ]
        for source_column_expr, target_column_expr in source_target_pairs:
            self._assert_column_data_transformed(
                spark,
                source_df=msdyn_facility_df,
                source_id_column_expr="msdyn_facilityid",
                source_column_expr=source_column_expr,
                target_df=facility_with_location_df,
                target_id_column_name="FacilityId",
                target_column_expr=target_column_expr,
                mapping_table_name="FACILITY_ID_MAPPING"
            )