from pathlib import Path
from typing import Set
from tests.utils.db.config_model.db_schema_config.ext_model import DBConfigModel
from tests.utils.db.config_model.db_schema.ext_model import DBSchemaModel
from tests.utils.db.config_model.semantics_config.ext_model import SemanticsConfigModel


from tests.utils.db.builder.schema_builder import SchemaBuilder
from tests.utils.constants import Constants
from tests.utils.db.model.column import Column
from tests.utils.db.model.table import Table

target_adrm_tables = {
    "Customer",
    "CustomerCharacteristic",
    "CustomerContactPurpose",
    "CustomerCurrencyUsage",
    "CustomerEducation",
    "CustomerEmail",
    "CustomerEmployment",
    "CustomerFinancialProfile",
    "CustomerLocation",
    "CustomerMaritalStatus",
    "CustomerStatus",
    "CustomerTelephoneNumber",
    "IndividualCustomer",
    "HouseholdRelatedCustomerAccount",
    "CustomerEvent",
    "CustomerGender",
    "Location",
    "UsaLocation",
    "Channel",
    "CustomerRelatedChannel",
    "Household",
    "HouseholdType",
    "HouseholdMember",
    "HouseholdMemberRole",
    "EventType",
    "CustomerEvent",
    "FinancialInstitution",
    "ChannelType",
    "Branch",
    "CustomerAccount",
    "CustomerRelatedParty",
    "CustomerPartyRelationshipType",
    "CustomerRelationshipType",
    "RelatedCustomer",
    "Country",
    "EducationAttainmentLevel",
}


class AdrmSchemaBuilder(SchemaBuilder):
    def __init__(self, spark, metadata_file, db, warehouse_location, schema_config_file_path,
                 semantics_config_file_path):
        super().__init__(spark, metadata_file, db, warehouse_location)
        self.schema_config_file_path = schema_config_file_path
        self.semantics_config_file_path = semantics_config_file_path

    def _used_tables(self) -> Set:
        return target_adrm_tables

    @staticmethod
    def _read_file(path) -> str:
        with open(path) as fh:
            return fh.read()

    def parse_tables(self):
        db_schema_model: DBSchemaModel = DBSchemaModel.from_str(AdrmSchemaBuilder._read_file(self.metadata_file))
        db_schema_config: DBConfigModel = DBConfigModel.from_str(AdrmSchemaBuilder._read_file(self.schema_config_file_path))
        db_schema_model: DBSchemaModel = db_schema_config.adapt_schema(db_schema_model)

        db_semantics_config: SemanticsConfigModel = SemanticsConfigModel.from_str(
            AdrmSchemaBuilder._read_file(self.semantics_config_file_path))

        for table_model in db_schema_model.tables:
            table_partition_rules = db_semantics_config.partition_rules_for_table(table_model.name)
            table = Table(name=table_model.name,
                          type=table_model.tableType,
                          format="parquet",
                          partition_columns=[pc.partition_col_name for pc in table_partition_rules],
                          additional_properties={},
                          location_root=self.data_location(),
                          db=self.db)
            for column in table_model.storageDescriptor.columns:
                table.columns.append(Column(name=column.name,
                                            type=column.originDataTypeName.typeName,
                                            precision=column.originDataTypeName.precision,
                                            scale=column.originDataTypeName.scale
                                            )
                                     )
            self.tables[table_model.name] = table

    @staticmethod
    def data_location() -> Path:
        return Path(Constants.SINK_TABLES_ROOT, "adrm")
