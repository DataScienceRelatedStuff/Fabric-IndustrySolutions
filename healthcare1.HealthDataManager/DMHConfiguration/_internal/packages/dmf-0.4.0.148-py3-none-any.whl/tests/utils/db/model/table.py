from pathlib import Path
import shutil
from dataclasses import dataclass, field
from typing import List, Dict
from tests.utils.db.model.column import Column
from abc import ABC
import os.path


@dataclass
class Table(ABC):
    name: str
    type: str
    format: str
    location_root: Path
    partition_columns: List[Column]
    db: str
    additional_properties: Dict
    columns: List[Column] = field(default_factory=list)

    @property
    def location(self) -> Path:
        return Path(os.path.join(self.location_root, self.name))

    def __str__(self):
        col_string = ",\n".join(str(column) for column in self.columns)

        string = f"""CREATE TABLE `{self.db}`.`{self.name}` (
                 {col_string})
                 USING {self.format}
                 LOCATION '{self.location}'
        """

        string += self._options_string()

        if self.partition_columns:
            partitions = ",".join(self.partition_columns)
            string += f"""
                    PARTITIONED BY ({partitions})
            """

        string += ";"

        return string

    def _options_string(self):
        options_string = ""

        if self.format == "csv":
            options_string = self._options_string_csv()

        return options_string

    def _options_string_csv(self):
        return f"""
                OPTIONS (
                `multiLine` '{self.additional_properties["multiLine"]}',
                `ignoreLeadingWhiteSpace` '{self.additional_properties["ignoreLeadingWhiteSpace"]}',
                `quote` '{self.additional_properties["quote"]}',
                `ignoreTrailingWhiteSpace` '{self.additional_properties["ignoreTrailingWhiteSpace"]}',
                `escape` '{self.additional_properties["escape"]}',
                `timestampFormat` '{self.additional_properties["timestampFormat"]}')
        """

    def del_contents(self, spark):
        dir_name = self.location
        if not dir_name.exists():
            return
        table_files = os.listdir(dir_name)

        had_files = False
        for item in table_files:
            had_files = True
            file_path = os.path.join(dir_name, item)
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        if had_files:
            spark.sql(f"refresh table {self.db}.{self.name}")
