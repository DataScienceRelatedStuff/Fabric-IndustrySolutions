# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class containing static methods used through out the package
"""

from datetime import datetime
from notebookutils import mssparkutils
from pyspark.sql import SparkSession
from pyspark.sql.streaming import DataStreamReader
from pyspark.sql.functions import *
from pyspark.sql.types import *
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C
from microsoft.fabric.hls.hds.utils.utils import Utils as CommonUtils

class Utils:
    """
    A class containing static methods used through out the package
    """

    @staticmethod
    def read_files_to_df_stream(spark: SparkSession, files_to_process_path: str) -> DataStreamReader:
        """
        This method is used to read files in binary format into a streaming dataframe

        Args:
            spark (SparkSession): spark session
            files_to_process_path (str): path where files are located

        Returns:
            DataStreamReader: streaming dataframe containing files details
        """
        df_schema = StructType([
            StructField(C.PATH_ATTR_NAME, StringType(), True),
            StructField(C.MODIFICATION_TIME_ATTR_NAME, TimestampType(), True),
            StructField(C.LENGTH_ATTR_NAME, LongType(), True),    
            StructField(C.DCM_FILE_CONTENT_ATTR_NAME, BinaryType(), True)
        ])
        
        return (
            spark.readStream.format('binaryFile')
            .schema(df_schema)
            .option("pathGlobFilter", '*.dcm')          
            .load(files_to_process_path)
            .drop(C.MODIFICATION_TIME_ATTR_NAME, C.LENGTH_ATTR_NAME)
            .withColumnRenamed(C.PATH_ATTR_NAME, C.FILE_PATH_COLUMN_NAME)
        )

    @staticmethod
    def get_hadoop_filesystem(spark: SparkSession):
        hadoop_conf = spark._jsc.hadoopConfiguration()
        hadoop_file_system = spark._jvm.org.apache.hadoop.fs.FileSystem.get(hadoop_conf)
        return hadoop_file_system

    @staticmethod
    def create_folders_if_not_exist(directory_path_to_check : str):
        if not CommonUtils.path_exists(directory_path_to_check):
            CommonUtils.create_folder(directory_path_to_check)

    @staticmethod
    def get_current_date_in_utc() -> str :
        return datetime.utcnow().strftime("%Y/%m/%d")

    @staticmethod
    def get_current_timestamp_in_utc() -> str :
        return str(datetime.utcnow().timestamp())

    @staticmethod
    def move_files(from_path: str, to_path: str, recursive : bool = False):
        mssparkutils.fs.mv(from_path, to_path, recursive)
        return from_path

    @staticmethod
    def set_hadoop_default_path(spark: SparkSession,lakehouse_path : str):
        spark._jsc.hadoopConfiguration().set("fs.defaultFS", lakehouse_path)
        
    @staticmethod
    def get_size_in_bytes(in_mb : int):
        return int(in_mb * (1024**2))