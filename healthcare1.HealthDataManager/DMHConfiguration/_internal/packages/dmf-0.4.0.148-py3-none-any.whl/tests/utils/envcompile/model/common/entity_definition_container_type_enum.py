from enum import Enum


class EntityDefinitionContainerTypeEnum(Enum):
    METASTORE = 1
    STORAGE = 2
