import os
from typing import List

import pytest

from rmt.core.values_mapping.reference_table import ReferenceTable
from rmt.file_model.values_mapping.mapping_definitions_file_reader import MappingDefinitionsFileReader
from tests.common.tester_file_system_client import TesterFileSystemClient
from tests.conftest import TESTS_ROOT_DIR


class TestMappingDefinitionsFileReader:

    @staticmethod
    def init_by_test_folder_names(mapping_definitions_test_folders_names: List[str]) -> MappingDefinitionsFileReader:
        reference_tables = {"Gender": ReferenceTable("Gender", "GenderId", "GenderName"), "concept": ReferenceTable("concept", "concept_id", "")}
        mapping_definitions_folders = [os.path.join(TESTS_ROOT_DIR, "data", "mapping_definitions", folder_name) for folder_name in mapping_definitions_test_folders_names]
        return MappingDefinitionsFileReader(TesterFileSystemClient("TestMappingDefinitionsFileReader"), mapping_definitions_folders, reference_tables)

    @staticmethod
    def read(mapping_definitions_reader: MappingDefinitionsFileReader, source: str):
        return mapping_definitions_reader.read(os.path.join(TESTS_ROOT_DIR, "data", "mapping_definitions", source))

    def test_sources(self):
        mapping_definitions_reader = TestMappingDefinitionsFileReader.init_by_test_folder_names(["concept_query", "concept_values"])
        sources = mapping_definitions_reader.sources
        assert sources == [os.path.join(TESTS_ROOT_DIR, "data", "mapping_definitions", "concept_query"),
                           os.path.join(TESTS_ROOT_DIR, "data", "mapping_definitions", "concept_values")]

    def test_read_mapping_definitions_1_source(self, spark):
        mapping_definitions_reader = TestMappingDefinitionsFileReader.init_by_test_folder_names(["concept_values"])
        mapping_definitions = TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "concept_values")
        assert len(mapping_definitions) == 1
        assert mapping_definitions[0].target_table_name == "concept"
        assert mapping_definitions[0].target_field_name == "concept_id"

    def test_read_mapping_definitions_2_sources(self, spark):
        mapping_definitions_reader = self.init_by_test_folder_names(["concept_query", "concept_values"])
        mapping_definitions = TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "concept_query")
        assert len(mapping_definitions) == 1
        assert mapping_definitions[0].target_table_name == "concept"
        assert mapping_definitions[0].target_field_name == "concept_id"
        assert "select" in mapping_definitions[0].sql
        mapping_definitions = TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "concept_values")
        assert len(mapping_definitions) == 1
        assert mapping_definitions[0].target_field_name == "concept_id"
        assert mapping_definitions[0].target_table_name == "concept"
        assert len(mapping_definitions[0].values) == 1

    def test_read_mapping_definitions_2_in_1_source(self, spark):
        mapping_definitions_reader = self.init_by_test_folder_names(["concept_query_and_gender_values"])
        mapping_definitions = TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "concept_query_and_gender_values")
        assert len(mapping_definitions) == 2
        if mapping_definitions[0].target_table_name == "concept":
            assert mapping_definitions[0].target_field_name == "concept_id"
            assert "select" in mapping_definitions[0].sql
            assert mapping_definitions[1].target_field_name == "GenderId"
            assert mapping_definitions[1].target_table_name == "Gender"
            assert len(mapping_definitions[1].values) == 4
        elif mapping_definitions[0].target_table_name == "Gender":
            assert mapping_definitions[0].target_field_name == "GenderId"
            assert len(mapping_definitions[0].values) == 4
            assert mapping_definitions[1].target_field_name == "concept_id"
            assert mapping_definitions[1].target_table_name == "concept"
            assert "select" in mapping_definitions[1].sql

    def test_read_mapping_definitions_invalid_folder(self, spark):
        mapping_definitions_reader = self.init_by_test_folder_names(["invalid_folder"])
        with pytest.raises(Exception, match="invalid_folder"):
            TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "invalid_folder")

    def test_read_mapping_definitions_invalid_values(self, spark):
        mapping_definitions_reader = self.init_by_test_folder_names(["invalid_values"])
        with pytest.raises(Exception, match="Gender"):
            TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "invalid_values")

    def test_read_mapping_definitions_not_exist_table(self, spark):
        mapping_definitions_reader = self.init_by_test_folder_names(["table_values"])
        with pytest.raises(Exception, match="is not a reference table"):
            TestMappingDefinitionsFileReader.read(mapping_definitions_reader, "table_values")
