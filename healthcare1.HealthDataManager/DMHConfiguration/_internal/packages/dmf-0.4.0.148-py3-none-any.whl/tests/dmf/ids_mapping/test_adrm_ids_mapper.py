import os

from delta import DeltaTable
from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.ids_mapping.adrm_ids_mapper import AdrmIdsMapper
from dmf.utils.global_constants import GlobalConstants
from tests.utils.constants import Constants
import tests.utils.dataframe_utils as dfu

SOURCE_INTERNAL_ID_COLUMN_NAME = "src_internal_id"
SOURCE_EXTERNAL_ID_COLUMN_NAME = "src_external_id"
IDS_MAPPING_TABLE = "DUMMY_IDS_MAPPING"
SCHEMA = StructType([
    StructField(SOURCE_INTERNAL_ID_COLUMN_NAME, StringType(), False),
    StructField(SOURCE_EXTERNAL_ID_COLUMN_NAME, StringType(), False),
])

SCHEMA_WITHOUT_EXTERNAL_ID = StructType([
    StructField(SOURCE_INTERNAL_ID_COLUMN_NAME, StringType(), False),
    StructField("some_string_field", StringType(), False)
])


class TestAdrmIdsMapper:

    def test_create_mappings_from_scratch_with_numbers(self, spark):
        data_str = [
            ("i1", "e1"),
            ("i2", "e2"),
        ]

        data_num = [
            (11, "e11"),
            (22, "e22"),
        ]

        feed_id = "feed_1"

        SCHEMA_NUM = StructType([
            StructField(SOURCE_INTERNAL_ID_COLUMN_NAME, IntegerType(), False),
            StructField(SOURCE_EXTERNAL_ID_COLUMN_NAME, StringType(), False),
        ])
        mapping_table_df = TestAdrmIdsMapper._map_once(spark, data_num, SCHEMA_NUM, feed_id,
                                                       clean_table=True)

        assert TestAdrmIdsMapper._are_all_mapped(data_str, mapping_table_df, feed_id)
        assert TestAdrmIdsMapper._are_all_mapped(data_num, mapping_table_df, feed_id)

    def test_create_mappings_from_scratch(self, spark):
        data = [
            ("i1", "e1"),
            ("i2", "e2")
        ]

        feed_id = "feed_1"
        mapping_table_df = TestAdrmIdsMapper._map_once(spark, data, SCHEMA, feed_id, clean_table=True)

        assert TestAdrmIdsMapper._are_all_mapped(data, mapping_table_df, feed_id)

    def test_create_different_mappings_for_multiple_feeds(self, spark):
        data_feed_1 = [
            ("if11", "ef11"),
            ("if12", "ef12")
        ]

        feed_id_1 = "feed_1"

        TestAdrmIdsMapper._map_once(spark, data_feed_1, SCHEMA, feed_id_1, clean_table=True)

        data_feed_2 = [
            ("if21", "ef21"),
            ("if22", "ef22")
        ]

        feed_id_2 = "feed_2"
        mapping_table_df = TestAdrmIdsMapper._map_once(spark, data_feed_2, SCHEMA, feed_id_2)

        assert TestAdrmIdsMapper._are_all_mapped(data_feed_1, mapping_table_df, feed_id_1)
        assert TestAdrmIdsMapper._are_all_mapped(data_feed_2, mapping_table_df, feed_id_2)

    def test_map_twice_same_feed(self, spark):
        common_rows = [("if11", "ef11")]
        data_1 = common_rows + [("if12", "ef12")]
        data_2 = common_rows + [("if22", "ef22")]
        feed_id = "feed_1"

        unique_data = set(data_1) | set(data_2)
        orig_data_len = len(data_1) + len(data_2) - len(common_rows)
        assert len(unique_data) == orig_data_len

        TestAdrmIdsMapper._map_once(spark, data_1, SCHEMA, feed_id, clean_table=True)
        mapping_table_df = TestAdrmIdsMapper._map_once(spark, data_2, SCHEMA, feed_id)

        combined_data = list(unique_data)
        assert TestAdrmIdsMapper._are_all_mapped(combined_data, mapping_table_df, feed_id)

        mapped_ids_df = mapping_table_df.select(
            F.col(GlobalConstants.INTERNAL_ID_COLUMN_NAME).alias(SOURCE_INTERNAL_ID_COLUMN_NAME),
            F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME).alias(SOURCE_EXTERNAL_ID_COLUMN_NAME))

        assert dfu.is_data_identical(mapped_ids_df, spark.createDataFrame(combined_data, SCHEMA))

    def test_null_ids_are_not_mapped(self, spark):
        data = [
            (None, "foo"),
            ("not None", "bar")
            ]
        SCHEMA_WITHOUT_EXTERNAL_ID_AND_NULLABLE_ID = StructType([
            StructField(SOURCE_INTERNAL_ID_COLUMN_NAME, StringType(), True),
            StructField("some_string_field", StringType(), False)
        ])
        feed_id = "feed_1"
        mapping_table_df = TestAdrmIdsMapper._map_once(
            spark, data, SCHEMA_WITHOUT_EXTERNAL_ID_AND_NULLABLE_ID, feed_id, clean_table=True, null_ext_id_col=True)
        non_null_data = list(filter(lambda x: x[0] is not None, data))
        assert TestAdrmIdsMapper._are_all_mapped(non_null_data, mapping_table_df, feed_id)

    def test_map_twice_same_feed_different_source_tables_no_external_id(self, spark):
        common_rows = [("if11", "ef11")]
        data_1 = common_rows + [("if12", "ef12")]
        data_2 = common_rows + [("if22", "ef22")]
        feed_id = "feed_1"

        unique_data = set(data_1) | set(data_2)
        orig_data_len = len(data_1) + len(data_2) - len(common_rows)
        assert len(unique_data) == orig_data_len

        mapping_table_df1 = TestAdrmIdsMapper._map_once(
            spark, data_1, SCHEMA_WITHOUT_EXTERNAL_ID, feed_id, clean_table=True, null_ext_id_col=True)
        assert TestAdrmIdsMapper._are_all_mapped(data_1, mapping_table_df1, feed_id)
        # assert not TestAdrmIdsMapper._are_all_mapped(data_2, mapping_table_df1, feed_id) # TODO: fix

        mapping_table_df2 = TestAdrmIdsMapper._map_once(
            spark, data_2, SCHEMA_WITHOUT_EXTERNAL_ID, feed_id, null_ext_id_col=True)

        combined_data = list(unique_data)
        assert TestAdrmIdsMapper._are_all_mapped(combined_data, mapping_table_df2, feed_id)

        mapped_ids_df = mapping_table_df2.select(
            F.col(GlobalConstants.INTERNAL_ID_COLUMN_NAME).alias(SOURCE_INTERNAL_ID_COLUMN_NAME))

        assert dfu.is_data_identical(mapped_ids_df, spark.createDataFrame(combined_data, SCHEMA_WITHOUT_EXTERNAL_ID).select(SOURCE_INTERNAL_ID_COLUMN_NAME))

    def test_map_from_another_feed(self, spark):

        common_external_id = "ef12"

        internal_id_1 = "if12"
        data_feed_1 = [
            ("if11", "ef11"),
            (internal_id_1, common_external_id)
        ]

        feed_id_1 = "feed_1"

        mapping_table_df1 = TestAdrmIdsMapper._map_once(spark, data_feed_1, SCHEMA, feed_id_1,
                                                        clean_table=True)

        adrm_id_df = mapping_table_df1. \
            select(GlobalConstants.ADRM_ID_COLUMN_NAME). \
            filter(mapping_table_df1[GlobalConstants.EXTERNAL_ID_COLUMN_NAME] == common_external_id). \
            distinct()

        internal_id_2 = "if21"
        data_feed_2 = [
            (internal_id_2, common_external_id),
            ("if22", "ef22")
        ]

        feed_id_2 = "feed_2"
        mapping_table_df2 = TestAdrmIdsMapper._map_once(spark, data_feed_2, SCHEMA, feed_id_2)

        assert TestAdrmIdsMapper._are_all_mapped(data_feed_1, mapping_table_df2, feed_id_1)
        assert TestAdrmIdsMapper._are_all_mapped(data_feed_2, mapping_table_df2, feed_id_2)

        adrm_entries_mapping_df = mapping_table_df2.join(adrm_id_df, GlobalConstants.ADRM_ID_COLUMN_NAME, how="inner")

        assert TestAdrmIdsMapper._row_with_values_exists(adrm_entries_mapping_df,
                                                         internal_id_1,
                                                         common_external_id,
                                                         feed_id_1)

        assert TestAdrmIdsMapper._row_with_values_exists(adrm_entries_mapping_df,
                                                         internal_id_2,
                                                         common_external_id,
                                                         feed_id_2)

    def test_not_existing_external_id_column(self, spark):

        data = [
            ("if1", "aaa"),
            ("if2", "bbb")
        ]

        mapping_table_df = TestAdrmIdsMapper._map_once(spark,
                                                     data,
                                                       SCHEMA_WITHOUT_EXTERNAL_ID,
                                                       "feed_1",
                                                       clean_table=True,
                                                       null_ext_id_col=True)

        assert mapping_table_df.filter(
            mapping_table_df[GlobalConstants.INTERNAL_ID_COLUMN_NAME] ==
            mapping_table_df[GlobalConstants.EXTERNAL_ID_COLUMN_NAME]).count() == 0

    def test_same_ids_from_different_feeds_mapped_separately(self, spark):

        data_from_feed_1 = [
            ("if1", "aaa"),
            ("if2", "bbb")
        ]

        TestAdrmIdsMapper._map_once(spark,
                                    data_from_feed_1,
                                    SCHEMA_WITHOUT_EXTERNAL_ID,
                                    "feed_1",
                                    clean_table=False,
                                    null_ext_id_col=True)

        data_from_feed_2 = [
            ("if1", "aaa"),
            ("if2", "bbb")
        ]

        mapping_table_df = TestAdrmIdsMapper._map_once(spark,
                                                       data_from_feed_2,
                                                       SCHEMA_WITHOUT_EXTERNAL_ID,
                                                       "feed_2",
                                                       clean_table=True,
                                                       null_ext_id_col=True)

        assert mapping_table_df.filter(f"{GlobalConstants.FEED_ID_COLUMN_NAME} = 'feed1'").join(
            mapping_table_df.filter(f"{GlobalConstants.FEED_ID_COLUMN_NAME} = 'feed2'"),
            GlobalConstants.ADRM_ID_COLUMN_NAME,
            "inner").count() == 0

    def test_when_1feed_has_ext_ids_and_2feed_does_not_then_different_long_ids_are_generated_for_same_internal_id(self,
                                                                                                                  spark):

        data_from_feed_1 = [
            ("if11", "ef11")
        ]

        TestAdrmIdsMapper._map_once(spark,
                                    data_from_feed_1,
                                    SCHEMA,
                                    "feed_1",
                                    clean_table=False,
                                    null_ext_id_col=False)

        data_from_feed_2 = [
            ("if1", "ef11")
        ]

        mapping_table_df = TestAdrmIdsMapper._map_once(spark,
                                                       data_from_feed_2,
                                                       SCHEMA_WITHOUT_EXTERNAL_ID,
                                                       "feed_2",
                                                       clean_table=False,
                                                       null_ext_id_col=True)

        assert mapping_table_df.filter(f"{GlobalConstants.FEED_ID_COLUMN_NAME} = 'feed1'").join(
            mapping_table_df.filter(f"{GlobalConstants.FEED_ID_COLUMN_NAME} = 'feed2'"),
            GlobalConstants.ADRM_ID_COLUMN_NAME,
            "inner").count() == 0

    @staticmethod
    def _row_with_values_exists(df: DataFrame,
                                internal_id: str,
                                external_id: str,
                                feed_id):
        return df.filter((df[GlobalConstants.INTERNAL_ID_COLUMN_NAME] == internal_id) &
                         (df[GlobalConstants.EXTERNAL_ID_COLUMN_NAME] == external_id) &
                         (df[GlobalConstants.FEED_ID_COLUMN_NAME] == feed_id)
                         ).count() == 1

    @staticmethod
    def _are_all_mapped(data, df: DataFrame, feed_id: str) -> bool:
        return TestAdrmIdsMapper._are_all_entries_in_df(data, df, feed_id) and \
            TestAdrmIdsMapper._are_all_entries_valid(df, feed_id)

    @staticmethod
    def _are_all_entries_valid(df: DataFrame, feed_id) -> bool:
        return \
            df.filter(
                (df[GlobalConstants.FEED_ID_COLUMN_NAME] == feed_id) &
                df[GlobalConstants.ADRM_ID_COLUMN_NAME].isNull()
            ).count() == 0

    @staticmethod
    def _are_all_entries_in_df(data, df: DataFrame, feed_id: str) -> bool:
        return df.filter(df[GlobalConstants.FEED_ID_COLUMN_NAME] == feed_id).count() == len(data)  # TODO fix this to not only check count

    @staticmethod
    def _map_once(spark, data, schema_param, feed_id: str, clean_table=False,
                  null_ext_id_col=False) -> DataFrame:

        df: DataFrame = spark.createDataFrame(data, schema_param)

        if clean_table:
            path = os.path.join(Constants.MAPPING_TABLES_LOCATION, IDS_MAPPING_TABLE)
            if os.path.exists(path):
                DeltaTable.forPath(spark, path).delete()

        external_id_column_name = SOURCE_EXTERNAL_ID_COLUMN_NAME
        if null_ext_id_col:
            external_id_column_name = None

        AdrmIdsMapper().map(spark=spark,
                            given_df=df,
                            feed_id=feed_id,
                            internal_id_column_name=SOURCE_INTERNAL_ID_COLUMN_NAME,
                            external_id_column_name=external_id_column_name,
                            id_mapping_table_name=IDS_MAPPING_TABLE,
                            id_mapping_table_db_name=None,
                            id_mapping_tables_location=Constants.MAPPING_TABLES_LOCATION,
                            id_mapping_table_entity_type=DataSourceTypeEnum.STORAGE
                            )

        return spark.read.format("delta").load(f"{Constants.MAPPING_TABLES_LOCATION}/{IDS_MAPPING_TABLE}")
