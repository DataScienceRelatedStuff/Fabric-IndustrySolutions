import os
import shutil

from pyspark import Row
from pyspark.sql import DataFrame

from rmt.core.values_mapping.mapping_schema import MappingSchema
from tests.conftest import REFERENCE_MAPPING_FOR_TESTS_FULL_PATH

SOURCE_DOMAIN = "HLC"


class TestCaseCommon:

    @staticmethod
    def assert_mapping_dataframe_columns_and_count(mapping_dataframe: DataFrame, count: int, source_domain, target_table: str,
                                                   target_field: str, source_value: str, target_value: str):
        assert mapping_dataframe.count() == count
        TestCaseCommon.assert_mapping_dataframe_columns(mapping_dataframe, source_domain, target_table, target_field, source_value, target_value)

    @staticmethod
    def assert_mapping_dataframe_columns(mapping_dataframe: DataFrame, source_domain, target_table: str,
                                         target_field: str, source_value: str, target_value: str):
        TestCaseCommon.assert_mapping_dataframe_common_columns(mapping_dataframe, source_domain, target_table, target_field)
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD] == source_value
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD] == target_value

    @staticmethod
    def assert_mapping_dataframe_common_columns_and_count(mapping_dataframe: DataFrame, count: int,
                                                          source_domain, target_table: str, target_field: str):
        assert mapping_dataframe.count() == count
        TestCaseCommon.assert_mapping_dataframe_common_columns(mapping_dataframe, source_domain, target_table, target_field)

    @staticmethod
    def assert_mapping_dataframe_common_columns(mapping_dataframe: DataFrame,
                                                source_domain, target_table: str, target_field: str):
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN] == source_domain
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE] == target_table
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD] == target_field

    @staticmethod
    def assert_mapping_row(mapping_row: Row, source_domain: str, target_table: str, target_field: str, source_value: str, target_value: int):
        assert mapping_row[MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN] == source_domain
        assert mapping_row[MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE] == target_table
        assert mapping_row[MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD] == target_field
        assert mapping_row[MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE] == source_value
        assert mapping_row[MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE] == target_value

    @staticmethod
    def assert_dataframe_equals_to_test_data(
        mapping_dataframe: DataFrame, test_sample_data_name: str
    ):
        if test_sample_data_name == "sample1":
            TestCaseCommon.assert_mapping_dataframe_columns_and_count(mapping_dataframe, 15, "HLC", "concept", "concept_id")
        elif test_sample_data_name == "sample2":
            TestCaseCommon.assert_dataframe_common_columns(mapping_dataframe, 3, "HLC", "concept", "concept_id")

    @staticmethod
    def assert_number_of_partition_files(
        mapping_output_full_path: str,
        source_domain: str,
        target_table: str,
        number_of_partition_files: int,
    ):
        parquet_path = os.path.join(
            mapping_output_full_path,
            f"{MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN}={source_domain}",
            f"{MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE}={target_table}",
        )
        parquet_files = [f for f in os.listdir(parquet_path) if f.endswith("parquet")]
        assert len(parquet_files) == number_of_partition_files

    @staticmethod
    def mapping_output_path_by_test_name(test_name: str):
        return os.path.join(REFERENCE_MAPPING_FOR_TESTS_FULL_PATH, test_name)

    @staticmethod
    def clean_mapping_output_for_test(test_name: str):
        mapping_output_full_path_for_test = TestCaseCommon.mapping_output_path_by_test_name(test_name)
        if os.path.exists(mapping_output_full_path_for_test):
            shutil.rmtree(mapping_output_full_path_for_test)
