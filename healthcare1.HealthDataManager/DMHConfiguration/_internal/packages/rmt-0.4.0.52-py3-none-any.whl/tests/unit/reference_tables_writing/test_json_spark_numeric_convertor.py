import json
from decimal import Decimal

import pytest
from pyspark.sql.types import BooleanType  # Represents boolean values (true or false).
from pyspark.sql.types import ByteType  # Represents 1-byte signed integer numbers. The range is from -128 to 127.
from pyspark.sql.types import DecimalType  # Represents arbitrary-precision signed decimal numbers
from pyspark.sql.types import DoubleType  # Represents 8-byte double-precision floating point numbers.
from pyspark.sql.types import FloatType  # Represents 4-byte single-precision floating point numbers.
from pyspark.sql.types import IntegerType  # Represents 4-byte signed integer numbers. The range is from -2,147,483,648 to 2,147,483,647.
from pyspark.sql.types import LongType  # Represents 8-byte signed integer numbers. The range is from -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807.
from pyspark.sql.types import ShortType  # Represents 2-byte signed integer numbers. The range is from -32,768 to 32,767.
from pyspark.sql.types import StringType, StructField, StructType

from rmt.core.tables_creating.json_spark_numeric_convertor import JSONToSparkTypeConvertor


class TestSparkAutoTypeCovertion:
    """
    This test asserts all known possible and impossible numric type conversions allowed by spark from python
    types that can be parse from JSON (int, float, string).
    If, for some reason any of the tests fails, it means that spark has changed the way it converts python types.
    This will probably requires a change in JSONToSparkTypeConvertor logic
    """

    def test_json_parsed_types(self):
        s = '{"str":"a string", "int":1, "float":1.1, "bool":true, "bool2":false, "null":null}'
        parsed = json.loads(s)
        assert isinstance(parsed["str"], str)
        assert isinstance(parsed["int"], int)
        assert isinstance(parsed["float"], float)
        assert isinstance(parsed["bool"], bool)
        assert isinstance(parsed["bool2"], bool)
        assert parsed["null"] is None

    @pytest.mark.parametrize("json_val", ["str"])
    @pytest.mark.parametrize("spark_type", [StringType()])
    def test_spark_can_convert_string_types_only_to_strings(self, spark_type, json_val, spark):
        schema = StructType([StructField("column", spark_type, False)])
        spark.createDataFrame([(json_val,)], schema)

    @pytest.mark.parametrize("json_val", ["str"])
    @pytest.mark.parametrize(
        "spark_type",
        [
            IntegerType(),
            ByteType(),
            ShortType(),
            LongType(),
            FloatType(),
            DoubleType(),
            DecimalType(10, 5),
            BooleanType(),
        ],
    )
    def test_spark_fails_to_converts_string_types(self, spark_type, json_val, spark):
        schema = StructType([StructField("column", spark_type, False)])
        with pytest.raises(TypeError):
            spark.createDataFrame([(json_val,)], schema)

    @pytest.mark.parametrize("json_val", [42])
    @pytest.mark.parametrize(
        "spark_type",
        [
            IntegerType(),
            ByteType(),
            ShortType(),
            LongType(),
        ],
    )
    def test_spark_can_convert_int_types_only_to_integral_types(self, spark_type, json_val, spark):
        assert isinstance(json_val, int)
        schema = StructType([StructField("column", spark_type, False)])
        spark.createDataFrame([(json_val,)], schema)

    @pytest.mark.parametrize("json_val", [42])
    @pytest.mark.parametrize(
        "spark_type",
        [
            FloatType(),
            DoubleType(),
            DecimalType(10, 5),
            BooleanType(),
        ],
    )
    def test_spark_fails_to_converts_int_types_to_non_integral_sypes(self, spark_type, json_val, spark):
        assert isinstance(json_val, int)
        schema = StructType([StructField("column", spark_type, False)])
        with pytest.raises(TypeError):
            spark.createDataFrame([(json_val,)], schema)

    @pytest.mark.parametrize("json_val", [42.42])
    @pytest.mark.parametrize(
        "spark_type",
        [
            FloatType(),
            DoubleType(),
        ],
    )
    def test_spark_can_convert_float_types_only_to_floats_and_double(self, spark_type, json_val, spark):
        assert isinstance(json_val, float)
        schema = StructType([StructField("column", spark_type, False)])
        spark.createDataFrame([(json_val,)], schema)

    @pytest.mark.parametrize("json_val", [42.42])
    @pytest.mark.parametrize(
        "spark_type",
        [
            IntegerType(),
            ByteType(),
            ShortType(),
            LongType(),
            DecimalType(10, 5),
            BooleanType(),
        ],
    )
    def test_spark_fails_to_converts_float_types_to_non_floating_point_numbers(self, spark_type, json_val, spark):
        assert isinstance(json_val, float)
        schema = StructType([StructField("column", spark_type, False)])
        with pytest.raises(TypeError):
            spark.createDataFrame([(json_val,)], schema)

    def test_spak_can_convert_decimal_types_to_decimal(self, spark):
        json_val = 42.42
        assert isinstance(json_val, float)
        json_val = Decimal(json_val)
        assert isinstance(json_val, Decimal)
        spark_type = DecimalType(10, 5)
        schema = StructType([StructField("column", spark_type, False)])
        spark.createDataFrame([(json_val,)], schema)


class TestJSONToSparkTypeConvertor:
    @pytest.mark.parametrize(
        "spark_type,should_succeed",
        [
            (StringType(), True),
            (IntegerType(), True),
            (ByteType(), True),
            (ShortType(), True),
            (LongType(), True),
            (FloatType(), True),
            (DoubleType(), True),
            (DecimalType(), True),
            (BooleanType(), False),
        ],
    )
    def test_convertor_can_convert_int_to_spark_types(self, spark_type, should_succeed, spark):
        schema = StructType([StructField("column", spark_type, True)])
        json_val = 42
        if should_succeed:
            converted_val = JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)
            spark.createDataFrame([(converted_val,)], schema)
        else:
            with pytest.raises(TypeError):
                JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, BooleanType())

    @pytest.mark.parametrize(
        "spark_type,should_succeed",
        [
            (StringType(), True),
            (FloatType(), True),
            (DoubleType(), True),
            (DecimalType(), True),
            (IntegerType(), False),
            (ByteType(), False),
            (ShortType(), False),
            (LongType(), False),
            (BooleanType(), False),
        ],
    )
    def test_convertor_can_convert_float_to_spark_types(self, spark_type, should_succeed, spark):
        schema = StructType([StructField("column", spark_type, True)])
        json_val = 42.42
        if should_succeed:
            converted_val = JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)
            spark.createDataFrame([(converted_val,)], schema)
        else:
            with pytest.raises(TypeError):
                JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)

    @pytest.mark.parametrize(
        "spark_type,should_succeed",
        [
            (StringType(), True),
            (IntegerType(), True),
            (ByteType(), True),
            (ShortType(), True),
            (LongType(), True),
            (DecimalType(), True),
            (BooleanType(), False),
        ],
    )
    def test_convertor_can_convert_string_of_int_to_spark_types(self, spark_type, should_succeed, spark):
        schema = StructType([StructField("column", spark_type, True)])
        json_val = "42"
        if should_succeed:
            converted_val = JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)
            spark.createDataFrame([(converted_val,)], schema)
        else:
            with pytest.raises(TypeError):
                JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, BooleanType())

    @pytest.mark.parametrize(
        "spark_type,should_succeed",
        [
            (StringType(), True),
            (FloatType(), True),
            (DoubleType(), True),
            (DecimalType(), True),
            (IntegerType(), False),
            (ByteType(), False),
            (ShortType(), False),
            (LongType(), False),
            (BooleanType(), False),
        ],
    )
    def test_convertor_cannot_convert_string_of_float_to_spark_types(self, spark_type, should_succeed, spark):
        json_val = "42.42"
        if should_succeed:
            schema = StructType([StructField("column", spark_type, True)])
            converted_val = JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)
            spark.createDataFrame([(converted_val,)], schema)
        else:
            with pytest.raises(TypeError):
                JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)

    @pytest.mark.parametrize(
        "spark_type,should_succeed",
        [
            (StringType(), False),
            (IntegerType(), False),
            (ByteType(), False),
            (ShortType(), False),
            (LongType(), False),
            (FloatType(), False),
            (DoubleType(), False),
            (DecimalType(), False),
            (BooleanType(), True),
        ],
    )
    def test_convertor_can_convert_bool_to_spark_types(self, spark_type, should_succeed, spark):
        json_val = False
        if should_succeed:
            schema = StructType([StructField("column", BooleanType(), True)])
            converted_val = JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, BooleanType())
            spark.createDataFrame([(converted_val,)], schema)
        else:
            with pytest.raises(TypeError):
                JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)

    @pytest.mark.parametrize(
        "spark_type",
        [
            StringType(),
            IntegerType(),
            ByteType(),
            ShortType(),
            LongType(),
            FloatType(),
            DoubleType(),
            DecimalType(),
            BooleanType(),
        ],
    )
    def test_convertor_can_convert_None_to_spark_types(self, spark_type, spark):
        schema = StructType([StructField("column", spark_type, True)])
        json_val = None
        converted_val = JSONToSparkTypeConvertor().convert_json_to_spark_compatible_type(json_val, spark_type)
        spark.createDataFrame([(converted_val,)], schema)
