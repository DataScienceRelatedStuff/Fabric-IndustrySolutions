from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, LongType, StringType, TimestampType, IntegerType, \
    Row

from dmf.transformations.steps.activeness_status_enricher import ActivenessStatusEnricher
from dmf.transformations.steps.range_manager import RangeManager
from dmf.utils.global_constants import GlobalConstants

OPEN_START = GlobalConstants.START_OF_TIME_PY_DT
OPEN_END = GlobalConstants.END_OF_TIME_PY_DT


def calculate_range(spark, data):
    schema = StructType([
        StructField("id", LongType(), True),
        StructField("data", StringType(), True),
        StructField("modified_on", TimestampType(), True),
        StructField("start", TimestampType(), True),
        StructField("end", TimestampType(), True),
        StructField(ActivenessStatusEnricher.CALCULATED_ACTIVENESS_STATUS_COLUMN_NAME, IntegerType(), True)
    ])
    df = spark.createDataFrame(data, schema)
    result_df = RangeManager.calculate_range(
        df, ["id"], ["data"], "modified_on", "start", "end")
    return result_df.collect()


def test_calculate_empty_df(spark: SparkSession):
    data = ()
    assert calculate_range(spark, data) == []


def test_disable_entry_with_new_data(spark: SparkSession):
    data = (
        [1, "a", datetime(2022, 9, 1, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [1, "aa", datetime(2022, 9, 2, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [2, "b", datetime(2022, 9, 1, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [2, "bb", datetime(2022, 9, 2, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [2, "bbb", datetime(2022, 9, 5, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_DISABLED]
    )
    assert calculate_range(spark, data) == [
        Row(id=1, data='a', start=OPEN_START, end=datetime(2022, 9, 1, 1), modified_on=datetime(2022, 9, 1, 1)),
        Row(id=1, data='aa', start=datetime(2022, 9, 2, 1), end=OPEN_END, modified_on=datetime(2022, 9, 2, 1)),
        Row(id=2, data='b', start=OPEN_START, end=datetime(2022, 9, 1, 1), modified_on=datetime(2022, 9, 1, 1)),
        Row(id=2, data='bb', start=datetime(2022, 9, 2, 1), end=datetime(2022, 9, 4, 1),
            modified_on=datetime(2022, 9, 2, 1)),
        Row(id=2, data='bbb', start=datetime(2022, 9, 5, 1), end=datetime(2022, 9, 5, 1),
            modified_on=datetime(2022, 9, 5, 1))
    ]


def test_partitioning_by_key_col_names(spark: SparkSession):
    data = (
        [1, "a", datetime(2022, 9, 1, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [1, "aa", datetime(2022, 9, 3, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [2, "b", datetime(2022, 9, 1, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [2, "bb", datetime(2022, 9, 2, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
    )
    assert calculate_range(spark, data) == [
        Row(id=1, data='a', start=OPEN_START, end=datetime(2022, 9, 2, 1), modified_on=datetime(2022, 9, 1, 1)),
        Row(id=1, data='aa', start=datetime(2022, 9, 3, 1), end=OPEN_END, modified_on=datetime(2022, 9, 3, 1)),
        Row(id=2, data='b', start=OPEN_START, end=datetime(2022, 9, 1, 1), modified_on=datetime(2022, 9, 1, 1)),
        Row(id=2, data='bb', start=datetime(2022, 9, 2, 1), end=OPEN_END, modified_on=datetime(2022, 9, 2, 1))]


def test_open_lines_are_closed(spark):
    data = (
        [1, "a", datetime(2022, 9, 1, 1), OPEN_START, OPEN_END, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [1, "b", datetime(2022, 9, 5, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
    )
    rows = calculate_range(spark, data)
    assert rows == [
        Row(id=1, data='a', start=OPEN_START, end=datetime(2022, 9, 4, 1), modified_on=datetime(2022, 9, 1, 1)),
        Row(id=1, data='b', start=datetime(2022, 9, 5, 1), end=OPEN_END, modified_on=datetime(2022, 9, 5, 1))
    ]


def test_new_lines_start_open(spark):
    data = (
        [1, "a", datetime(2022, 9, 1, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
    )
    rows = calculate_range(spark, data)
    assert rows == [
        Row(id=1, data='a', start=OPEN_START, end=OPEN_END, modified_on=datetime(2022, 9, 1, 1)),
    ]


def test_closed_lines_are_not_recalculated(spark):
    data = (
        [1, "a", datetime(2022, 9, 1, 1), OPEN_START, datetime(2022, 9, 2, 1),
         ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [1, "a", datetime(2022, 9, 3, 1), datetime(2022, 9, 3, 1), datetime(2022, 9, 5, 1),
         ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
        [1, "a", datetime(2022, 9, 20, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_ENABLED],
    )
    rows = calculate_range(spark, data)
    assert rows == [Row(id=1, data='a', start=OPEN_START,
                        end=datetime(2022, 9, 2, 1), modified_on=datetime(2022, 9, 1, 1)),
                    Row(id=1, data='a', start=datetime(2022, 9, 3, 1),
                        end=datetime(2022, 9, 5, 1), modified_on=datetime(2022, 9, 3, 1)),
                    Row(id=1, data='a', start=datetime(2022, 9, 20, 1),
                        end=OPEN_END, modified_on=datetime(2022, 9, 20, 1))]


def test_deleted_line_is_missing_and_does_not_affect_a_closed_line(spark):
    data = (
        [1, "a", datetime(2022, 9, 1, 1), OPEN_START, datetime(2022, 9, 5, 1), None],
        [1, "a", datetime(2022, 9, 20, 1), None, None, ActivenessStatusEnricher.ACTIVENESS_STATUS_DISABLED],
    )
    assert calculate_range(spark, data) == [
        Row(id=1, data='a', start=OPEN_START, end=datetime(2022, 9, 5, 1), modified_on=datetime(2022, 9, 1, 1))]
