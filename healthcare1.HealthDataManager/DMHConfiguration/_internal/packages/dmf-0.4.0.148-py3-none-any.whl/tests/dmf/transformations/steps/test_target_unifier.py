from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, StructType, StructField, TimestampType
from dmf.utils.global_constants import GlobalConstants
from dmf.transformations.steps.target_unifier import TargetUnifier

OPEN_START = GlobalConstants.START_OF_TIME_PY_DT
OPEN_END = GlobalConstants.END_OF_TIME_PY_DT


class TestTargetUnifier:
    
    def test_union(self, spark: SparkSession):
        
        target_schema = StructType(
            [
                StructField("key_col1", StringType(), True),
                StructField("key_col2", StringType(), True),
                StructField("data_col1", StringType(), True),
                StructField("data_col2", StringType(), True),
                StructField("from_col", TimestampType(), True),
                StructField("to_col", TimestampType(), True),
                StructField("modified_col", TimestampType(), True),
            ])

        target_unchanged_data = [
            ('a', '1', 'd1', 'd2', OPEN_START, datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('a', '1', 'd2', 'd3', datetime(2022, 9, 3), OPEN_END, datetime(2022, 9, 3)),
            ('a', '2', 'd1', 'd2', datetime(2022, 9, 1), datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('a', '2', 'd1', 'd2', datetime(2022, 9, 3), datetime(2022, 9, 4), datetime(2022, 9, 3))
           
        ]
        
        target_and_source_in_range_data = [
            ('b', '1', 'd1', 'd2', OPEN_START, datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('b', '1', 'd2', 'd3', datetime(2022, 9, 3), OPEN_END, datetime(2022, 9, 3)),
            ('b', '2', 'd1', 'd2', datetime(2022, 9, 1), datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('b', '2', 'd1', 'd2', datetime(2022, 9, 3), datetime(2022, 9, 4), datetime(2022, 9, 3))

        ]
        target_unchanged_data_df = spark.createDataFrame(
            target_unchanged_data, target_schema)
        target_and_source_in_range_data_df = spark.createDataFrame(
            target_and_source_in_range_data, target_schema)
        
        target_union_df = TargetUnifier.union(target_unchanged_data_df, target_and_source_in_range_data_df)
        
        rows = target_union_df.orderBy(["key_col1", "key_col2", "modified_col"]).collect()
        
        assert rows == [
            ('a', '1', 'd1', 'd2', OPEN_START, datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('a', '1', 'd2', 'd3', datetime(2022, 9, 3), OPEN_END, datetime(2022, 9, 3)),
            ('a', '2', 'd1', 'd2', datetime(2022, 9, 1), datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('a', '2', 'd1', 'd2', datetime(2022, 9, 3), datetime(2022, 9, 4), datetime(2022, 9, 3)),
            ('b', '1', 'd1', 'd2', OPEN_START, datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('b', '1', 'd2', 'd3', datetime(2022, 9, 3), OPEN_END, datetime(2022, 9, 3)),
            ('b', '2', 'd1', 'd2', datetime(2022, 9, 1), datetime(2022, 9, 2), datetime(2022, 9, 1)),
            ('b', '2', 'd1', 'd2', datetime(2022, 9, 3), datetime(2022, 9, 4), datetime(2022, 9, 3))
        ]

        