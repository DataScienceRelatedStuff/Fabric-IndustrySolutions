from pyspark.sql import DataFrame


def is_data_identical(df1: DataFrame, df2: DataFrame) -> bool:
    df2_aligned = df2.select(*df1.columns)
    return ((df1.exceptAll(df2_aligned).count() == 0) and
            (df2_aligned.exceptAll(df1).count() == 0))
