import json
from collections import defaultdict
from copy import deepcopy
from typing import Optional

from configuration_compiler.config_files_models.db_schema.ext_model import DBSchemaModel
from configuration_compiler.config_files_models.db_schema.model import (
    Column,
    FieldProperties,
    JoinPair,
    ModelItem,
    OriginDataTypeName,
    RelationShip,
)
from configuration_compiler.config_files_models.db_schema_config.model import (
    ConfigField,
    DBConfigExtra,
    ExcludedFields,
    PartitionField,
    PrimaryKey,
    RawDBConfigModel,
)
from configuration_compiler.config_files_models.semantics.ext_model import SemanticsModel


class DBConfigModel(RawDBConfigModel):
    @classmethod
    def from_str(cls, db_schema_config: str) -> "DBConfigModel":
        try:
            db_config_model = cls(**json.loads(db_schema_config))
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse DB schema config: {e}") from e
        db_config_model.verify_extra_config()
        db_config_model.verify_fields_are_present_in_config()
        return db_config_model

    @staticmethod
    def _filter_required_tables(db_schema: DBSchemaModel, required_tables: dict[str, ExcludedFields]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        db_schema.tables = [t for t in db_schema.tables if t.name in required_tables]
        return db_schema

    @staticmethod
    def _remove_fields(db_schema: DBSchemaModel, required_tables: dict[str, ExcludedFields]) -> None:
        if not required_tables:
            return
        excluded_columns: Optional[ExcludedFields] = None

        def should_keep(column: Column):
            return column.name not in excluded_columns.exclude

        for table_model in db_schema.tables:
            excluded_columns = required_tables.get(table_model.name)
            if not excluded_columns:
                continue
            existing_columns: list[Column] = table_model.storageDescriptor.columns
            table_model.storageDescriptor.columns = list(filter(should_keep, existing_columns))

    @staticmethod
    def _add_fields(
        db_schema: DBSchemaModel,
        fields_to_add: list[ConfigField],
        configuration: DBConfigExtra,
        ref_tables: list[str],
    ) -> None:
        if not fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for field in fields_to_add:
            if not field.enabled:
                continue
            config_field: ConfigField = deepcopy(field)
            config_field.tables = []
            relevant_tables = DBConfigModel._parse_required_tables_for_added_fields(
                configuration, db_schema, field, ref_tables
            )
            for table_name in relevant_tables:
                fields_grouped_by_table[table_name].append(config_field)
        fields_grouped_by_table = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: list = table_model.storageDescriptor.columns
            for config_field in fields_grouped_by_table.get(table_model.name, []):
                new_column = Column(
                    name=config_field.name,
                    originDataTypeName=OriginDataTypeName(
                        typeName=config_field.type,
                        isNullable=True,
                        properties=FieldProperties(
                            minValue=None,
                            maxValue=None,
                            description=config_field.description,
                            dateFormat=None,
                            timestampFormat=None,
                        ),
                        length=None,
                        scale=None,
                        precision=None,
                    ),
                )
                datatype_config: OriginDataTypeName = new_column.originDataTypeName
                if config_field.length is not None:
                    datatype_config.length = config_field.length
                if config_field.scale is not None:
                    datatype_config.scale = config_field.scale
                if config_field.precision is not None:
                    datatype_config.precision = config_field.precision
                existing_columns.append(new_column)

    @staticmethod
    def _parse_required_tables_for_added_fields(
        configuration: DBConfigExtra, db_schema: DBSchemaModel, field: ConfigField, ref_tables: list[str]
    ) -> list[str]:
        field_tables = field.tables
        if field_tables == ["*"]:
            if field.name not in (
                configuration.sourceTableField,
                configuration.modifiedOnTargetField,
            ):
                raise ValueError(
                    f"Table name ('*') in the dbSchemaConfig file is only supported for config field names, e.g., ModifiedDate "
                    f"{(configuration.sourceTableField, configuration.modifiedOnTargetField)}"
                )
            # reference tables are not not altered with '*'
            all_tables_names = [t.name for t in db_schema.tables if t.name not in ref_tables]
            relevant_tables = all_tables_names
        else:
            if "*" in field_tables:
                raise ValueError(
                    f"Invalid table name ('*') in dbSchemaConfig file for config field '{field.name}': in position: {field_tables.index('*')}"
                )
            relevant_tables = field_tables
        return relevant_tables

    @staticmethod
    def _add_partitions_fields(db_schema: DBSchemaModel, partition_fields_to_add: list[PartitionField]) -> None:
        if not partition_fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for partition_field in partition_fields_to_add:
            if not partition_field.enabled:
                continue
            new_partition_field: PartitionField = deepcopy(partition_field)
            new_partition_field.tables = []
            for table_name in partition_field.tables:
                fields_grouped_by_table[table_name].append(partition_field)
        fields_grouped_by_table: dict[str, list[PartitionField]] = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: list = table_model.storageDescriptor.columns
            if table_model.name in fields_grouped_by_table:
                for partition_field in fields_grouped_by_table[table_model.name]:
                    new_column = Column(
                        name=partition_field.name,
                        originDataTypeName=OriginDataTypeName(
                            typeName=partition_field.type,
                            isNullable=False,
                            properties=FieldProperties(
                                minValue=None,
                                maxValue=None,
                                description=partition_field.description,
                                dateFormat=None,
                                timestampFormat=None,
                            ),
                            length=None,
                            scale=None,
                            precision=None,
                        ),
                    )
                    existing_columns.append(new_column)

    @staticmethod
    def _remove_redundant_relations(db_schema: DBSchemaModel, required_tables: Optional[dict]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        for table_model in db_schema.tables:
            filtered_relationships = []
            for r in table_model.properties.relationships:
                to_entity = r.toEntity
                if to_entity in required_tables:
                    filtered_relationships.append(r)
            table_model.properties.relationships = filtered_relationships
        return db_schema

    def verify_fields_are_present_in_config(self):
        if not self.fields:
            return
        if not self.configuration:
            return

        fields_names = [field.name for field in self.fields if field.enabled]
        for field in [
            self.configuration.modifiedOnTargetField,
            self.configuration.sourceTableField,
        ]:
            if field is not None:
                if field not in fields_names:
                    raise ValueError(f"Field '{field}' is not present in the dbSchemaConfig file")

    @staticmethod
    def _update_primary_keys(db_schema: DBSchemaModel, primary_keys: list[PrimaryKey]) -> None:
        for primary_key in primary_keys:
            try:
                table_model: ModelItem = db_schema.tables_dict[primary_key.table]
            except KeyError as ke:
                raise ValueError(f"Table '{primary_key.table}' was not found in the target schema") from ke
            old_pks = table_model.properties.primaryKeys[:]  # copy
            new_pks = table_model.properties.primaryKeys[:]  # copy
            existing_fields = [column.name for column in table_model.storageDescriptor.columns]
            for key_to_remove in primary_key.config.remove:
                if key_to_remove not in old_pks:
                    raise ValueError(
                        f"PK field '{key_to_remove}' was not found in the target table '{primary_key.table}'[0]"
                    )
                new_pks.remove(key_to_remove)
            for key_to_add in primary_key.config.add:
                if key_to_add in old_pks:
                    raise ValueError(
                        f"PK field '{key_to_add}' is already present in the PK fields collection of the target table '{primary_key.table}'[1]"
                    )
                if key_to_add not in existing_fields:
                    raise ValueError(
                        f"PK field '{key_to_add}' was not found in the PK fields collection of the target table '{primary_key.table}'[2]"
                    )
                new_pks.append(key_to_add)
            for old_key, new_key in primary_key.config.replace.items():
                if old_key not in existing_fields:
                    raise ValueError(
                        f"PK field '{old_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[3]"
                    )
                if old_key not in old_pks:
                    raise ValueError(
                        f"PK field '{old_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[4]"
                    )
                if new_key not in existing_fields:
                    raise ValueError(
                        f"PK field '{new_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[5]"
                    )
                new_pks.remove(old_key)
                new_pks.append(new_key)
            table_model.properties.primaryKeys = new_pks
            DBConfigModel._update_primary_keys_in_relationships(db_schema, primary_key, table_model)

    @staticmethod
    def _update_primary_keys_in_relationships(
        db_schema: DBSchemaModel, primary_key: PrimaryKey, table_model: ModelItem
    ):
        # update all fks that reference this table
        for old_key, new_key in primary_key.config.replace.items():
            pointing_join_pairs: list[JoinPair] = db_schema.get_pointing_fks_on_field(table_model.name, old_key)
            for join_pair in pointing_join_pairs:
                join_pair.toAttribute = new_key
        for key_to_remove in primary_key.config.remove:
            pointing_relationships: list[RelationShip] = db_schema.get_pointing_relationships_on_field(
                table_model.name, key_to_remove
            )
            for rel in pointing_relationships:
                rel.joinPairs = list(filter(lambda jp: jp.toAttribute != key_to_remove, rel.joinPairs))

    def adapt_schema(self, db_schema: DBSchemaModel, db_semantics: SemanticsModel | None) -> DBSchemaModel:
        db_schema = DBConfigModel._filter_required_tables(db_schema, self.tables)
        db_schema = DBConfigModel._remove_redundant_relations(db_schema, self.tables)
        DBConfigModel._remove_fields(db_schema, self.tables)
        ref_tables = [t.table for t in db_semantics.referenceTables] if db_semantics else []
        DBConfigModel._add_fields(db_schema, self.fields, self.configuration, ref_tables)
        DBConfigModel._update_primary_keys(db_schema, self.primaryKeys)
        DBConfigModel._add_partitions_fields(db_schema, self.partitionFields)
        return db_schema

    def verify_extra_config(self):
        if bool(self.configuration.modifiedOnTargetField) ^ bool(self.configuration.sourceTableField):
            raise ValueError(
                "Both modifiedOnTargetField and sourceTableField must be specified, or neither of them. In the DB target schema config file"
            )

# SIG # Begin Windows Authenticode signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD0Mr7iU36GD/W6
# mS0WrUyGMg/dx9CWNJrDtpt1L+lyg6CCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIMJamEPkb8Km+6KyG6SE6spO
# KOiHfeVUmaIGz+4TQ7SFMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAG+EVYyg3tNeiUWUT6uS+9ZIe/0iz2vPzbLh2dQK5bbWSFd6onqzVnqdj
# yQhhzxJX6dwEohtxmwvOU587LLAvvyLbzcs30coTz2ndQCZO4k1/Wba6b1T6SIko
# VanZuzDkG7acC4qSlieCgJCnJsEbOtEFWvDfmw8tHVUB01u6rEJ8L2BPeyNZtFXr
# toQ12nTDdiSAQhQ2wJN0aGqWT1dliUfzqcZKH8Jsih/EfOj6gFq2idnQEO7GOJ41
# W6C//qx9b0YTohTYoDDSnJeOJEA1XbnXl+mrjD6R1foEqxFXjO5tRD1chigNrtOw
# zggnD6XeKm3O21U6fkEn/IXCaDF38aGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCTvw+gtgo1MJIRylPOEwdhQMG9z1g4jFw1O11S+ZquYwIGZXsgo9jU
# GBMyMDI0MDExMTEyMjE1OC45MzhaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046RjAwMi0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAc4PGPdFl+fG/wABAAABzjANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzA1MjUxOTEy
# MDhaFw0yNDAyMDExOTEyMDhaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046RjAwMi0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC5CkwZ1yjYx3fnKTw/VnzwGGhKOIjqMDSuHdGg8JoJ
# 2LN2nBUUkAwxhYAR4ZQWg9QbjxZ/DWrD2xeUwLnKOKNDNthX9vaKj+X5Ctxi6ioT
# VU7UB5oQ4wGpkV2kmfnp0RYGdhtc58AaoUZFcvhdBlJ2yETwuCuEV6pk4J7ghGym
# szr0HVqR9B2MJjV8rePL+HGIzIbYLrk0jWmaKRRPsFfxKKw3njFgFlSqaBA4SVuV
# 0FYE/4t0Z9UjXUPLqw+iDeLUv3sp3h9M4oNIZ216VPlVlf3FOFRLlZg8eCeX4xla
# BjWia95nXlXMXQWqaIwkgN4TsRzymgeWuVzMpRPBWk6gOjzxwXnjIcWqx1lPznIS
# v/xtn1HpB+CIF5SPKkCf8lCPiZ1EtB01FzHRj+YhRWJjsRl1gLW1i0ELrrWVAFrD
# PrIshBKoz6SUAyKD7yPx649SyLGBo/vJHxZgMlYirckf9eklprNDeoslhreIYzAJ
# rMJ+YoWn9Dxmg/7hGC/XH8eljmJqBLqyHCmdgS+WArj84ciRGsmqRaUB/4hFGUkL
# v1Ga2vEPtVByUmjHcAppJR1POmi1ATV9FusOQQxkD2nXWSKWfKApD7tGfNZMRvku
# fHFwGf5NnN0Aim0ljBg1O5gs43Fok/uSe12zQL0hSP9Jf+iCL+NPTPAPJPEsbdYa
# vQIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFDD7CEZAo5MMjpl+FWTsUyn54oXFMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQCXIBYW/0UVTDDZO/fQ2XstNC4DZG8RPbrl
# ZHyFt57z/VWqPut6rugayGW1UcvJuxf8REtiTtmf5SQ5N2pu0nTl6O4BtScIvM/K
# 8pe/yj77x8u6vfk8Q6SDOZoFpIpVkFH3y67isf4/SfoN9M2nLb93po/OtlM9AcWT
# JbqunzC+kmeLcxJmCxLcsiBMJ6ZTvSNWQnicgMuv7PF0ip9HYjzFWoNq8qnrs7g+
# +YGPXU7epl1KSBTr9UR7Hn/kNcqCiZf22DhoZPVP7+vZHTY+OXoxoEEOnzAbAlBC
# up/wbXNJissiK8ZyRJXT/R4FVmE22CSvpu+p5MeRlBT42pkIhhMlqXlsdQdT9cWI
# tiW8yWRpaE1ZI1my9FW8JM9DtCQti3ZuGHSNpvm4QAY/61ryrKol4RLf5F+SAl4o
# zVvM8PKMeRdEmo2wOzZK4ME7D7iHzLcYp5ucw0kgsy396faczsXdnLSomXMArstG
# kHvt/F3hq2eESQ2PgrX+gpdBo8uPV16ywmnpAwYqMdZM+yH6B//4MsXEu3Rg5QOo
# OWdjNVB7Qm6MPJg+vDX59XvMmibAzbplxIyp7S1ky7L+g3hq6KxlKQ9abUjYpaOF
# nHtKDFJ+vxzncEMVEV3IHQdjC7urqOBgO7vypeIwjQ689qu2NNuIQ6cZZgMn8EvS
# SWRwDG8giTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkYwMDItMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBd
# jZUbFNAyCkVE6DdVWyizTYQHzKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6UnfkzAiGA8yMDI0MDExMTAzMzEz
# MVoYDzIwMjQwMTEyMDMzMTMxWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDpSd+T
# AgEAMAoCAQACAiiZAgH/MAcCAQACAhRlMAoCBQDpSzETAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBALwbxvBFrpP/LzXrJyBi9pDV9c4adUNR2DPWv41yevHx
# 8PYA89fh2rx4SBneS62iAoJ0ja+SGS4wBO0Grq63AhUf+cyomrWHlEPUpY3QT0Yu
# 5gOJlCrx+nfuQqh/FZJgoB8Z4uge/qDiMGt4url+/+rlauoDDg8K4e/NEYoO7JZJ
# IL06msxhoj8a/kIShZfQjzhsHaz8izSVq4jknZomL6Dz4FfVIjgT7xzuOiPsEnmX
# VBKlioKp4m73S3gKLlb6UNENjYxtKFv+rTwc1J8hMl1fosbES4rBCo0u5Z6JdnJU
# HD7pq98w0Xaj17qOj2T0Hm3dytwE9fD34k86/urE+eoxggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAc4PGPdFl+fG/wABAAAB
# zjANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCBKodaWYi0adkbhbKdRcgdJSWfrYN7dssCjdMPAYWy3
# SjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIDJsz0F6L0XDUm53JRBfNMZs
# zKsllLDMiaFZ3PL/LqxnMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAHODxj3RZfnxv8AAQAAAc4wIgQgYGqdQLkagh8R6xzPn5/qWhHP
# OAAyGgL9Qts0N+v9I4wwDQYJKoZIhvcNAQELBQAEggIAl3F71POwAYTljvzP1o7+
# URIx9hvU9+K0DJYfFZ4w5eubxPSbJK3MfKHfz1Aa0dz0b8TnZ1HArnM4ypoUKWkZ
# gQHn13RgQZC76hzFtBm6sN/d+o7nPQKAOn12d4Ub1kT6vdBqsEq8r/HSVht4bBgC
# NRaHIl40F/YTxkU9l4LuklV0oTCP+Ao7HmK36rk5cCwIzzlnP2lk8cxX/aUSLUNH
# VvP9I/8rqBqQeM1zJHlWImPpSHGo+ch1de8ex0fcrBQ2FNl+amLwV3pvkvCNINqr
# hoyksiMKZ/fF742mvP/FP0OISSYLvenULT3mVT8dyvNZMlw5cEiWnL98OY5rLTIj
# pjWx2IoSBQgWMzjMN2YHhdLIU7zFBnMJH/x20pYeVvraWvQ9zritRbpPXte2SqAC
# rIQZh0PGXrckA1qiaqruJJhHR/7bu1VAt9GeBHg1CuMpjZXbWG5JWBotItktdQlf
# 4s8tjFyolgWWwmbWC3NwHzqnvJsGVC7QIs70/osowe2F2gBnEoQZDUD1k8F1CtYq
# XUXhOWfAelSFp6Hu6sDjBpsKw1CME5bbUopD1iH35rhtmY7FFiRWf4k+MaCwprIp
# ikQwjsJsmOfHhngOlQHthfB+4l3saSttwqk5u1NjW3S64rsdwg+zXYPLayl4e0cP
# 3A2idCDoMeOh9WVXpkgObbQ=
# SIG # End Windows Authenticode signature block