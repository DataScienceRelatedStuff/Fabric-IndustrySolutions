import random
import shutil

from pandas import BooleanDtype
import pytest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Dict
from numpy import partition
from unittest.mock import MagicMock
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType,
    TimestampType,
    StructField,
    LongType,
    DateType,
    IntegerType,
    StringType,
    DecimalType,
)

from dmf.last_processed_line_computer.last_processed_lines import LastProcessedLineCalculator as lpl

from dmf.model.common.data_access_definition import DataAccessDefinition
from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.model.common.data_access_definition import DataSourceId
from dmf.model.data_feed_configuration import DataFeedConfiguration
from dmf.model.source_configuration import SourceConfiguration
from dmf.model.target_configuration.target_configuration import TargetConfiguration
from dmf.model.target_configuration.target_table_schema import TargetTableSchema
from dmf.model.target_configuration.target_transformation import ColumnTransformation
from dmf.transformations.model.transformation_types import PartitionConfig
from dmf.utils.global_constants import GlobalConstants
from tests.utils.constants import Constants
from tests.utils.db.model import column

source_table_column_name = "SourceTable"


def _create_df(spark, source_table: str = "source_table_1"):
    df_schema = StructType(
        [
            StructField("SourceModifiedOn", TimestampType(), True),
            StructField(source_table_column_name, StringType(), True),
        ]
    )
    df_data = [
        (datetime(year=2022, month=1, day=3, hour=10), source_table),
        (datetime(year=2022, month=1, day=2, hour=10), source_table),
        (datetime(year=2022, month=1, day=3, hour=11), source_table),
        (datetime(year=2022, month=9, day=9, hour=19), "source_table_999"),
    ]
    random.shuffle(df_data)
    df = spark.createDataFrame(data=df_data, schema=df_schema)
    return df


def test_compute_last_processed_line(spark):
    source_table = "mySourceTable"
    df = _create_df(spark, source_table=source_table)
    assert datetime(2022, 1, 3, 11, 0) == lpl(spark)._compute_last_processed_line(
        source_table, df, source_table_column_name
    )


def test_compute_last_processed_line_returns_min_on_empty_dataframe(spark):
    df_schema = StructType(
        [
            StructField("SourceModifiedOn", TimestampType(), True),
            StructField(source_table_column_name, StringType(), True),
        ]
    )
    empty_df = spark.createDataFrame(data=[], schema=df_schema)
    assert datetime.min == lpl(spark)._compute_last_processed_line("source_table_1", empty_df, source_table_column_name)


def test_compute_last_processed_line_in_source_table(spark, mocker):
    def gen_target_config(target_id: DataSourceId):
        mocker = MagicMock(spec=TargetConfiguration)
        mocker.data_access_definition = DataAccessDefinition(
            data_source_id=target_id,
            data_source_type=DataSourceTypeEnum.TABLE,
            data_source_owner_id=GlobalConstants.SINK_DB_NAME,
        )
        mocker.target_id = target_id
        mocker.target_modified_date_column_name = "SourceModifiedOn"
        return mocker

    source_table_name = "source_table"
    target_tables = {"target_table1", "target_table2", "target_table3"}
    target_configurations = [
        gen_target_config("target_table1"),
        gen_target_config("target_table2"),
        gen_target_config("target_table3"),
    ]
    source_config = SourceConfiguration(
        source_id=source_table_name,
        feed_id="dummy_feed",
        data_access_definition=DataAccessDefinition(
            data_source_id=source_table_name,
            data_source_type=DataSourceTypeEnum.TABLE,
            data_source_owner_id=GlobalConstants.SOURCE_DB,
        ),
        table_schema=None,
        target_configurations=frozenset(target_configurations),
        mapping_definitions=frozenset(),
        create_view_only=False,
        view_alias=None,
        source_to_reference_mappings=frozenset(),
        source_table_column_name=source_table_column_name,
    )

    def _read_table_mock(self, data_access_definition: DataAccessDefinition):
        assert data_access_definition.data_source_id in target_tables
        return _create_df(self.spark, source_table=source_config.unique_id)

    target = "dmf.last_processed_line_computer.last_processed_lines.LastProcessedLineCalculator._read_table"
    mocker.patch(target, new=_read_table_mock)
    expected = datetime(2022, 1, 3, 11, 0)  # see _create_df
    with ThreadPoolExecutor(thread_name_prefix="lpl_computer") as executor:
        result = lpl(spark).compute_last_processed_line_in_source_table(executor, source_config)
    assert expected == result


def test_compute_last_processed_line_for_empty_db_returns_min_datetime(spark, fhir_omop_config, cleanup):
    result = compute_last_processed_line_for_all_source_tables(spark, fhir_omop_config)
    assert all(val == GlobalConstants.MIN_DATE for val in result.values())


def test_compute_last_processed_line_returns_correct_max_datetime(spark, fhir_omop_config, cleanup):

    df_schema = StructType(
        [
            StructField("observation_id", LongType(), True),
            StructField("observation_event_id", LongType(), True),
            StructField("observation_type_concept_id", LongType(), True),
            StructField("observation_date", DateType(), True),
            StructField("qualifier_source_value", StringType(), True),
            StructField("visit_occurrence_id", LongType(), True),
            StructField("SourceTable", StringType(), True),
            StructField("visit_detail_id", LongType(), True),
            StructField("observation_source_value", StringType(), True),
            StructField("obs_event_field_concept_id", LongType(), True),
            StructField("provider_id", LongType(), True),
            StructField("value_as_string", StringType(), True),
            StructField("qualifier_concept_id", LongType(), True),
            StructField("person_id", LongType(), True),
            StructField("observation_source_concept_id", LongType(), True),
            StructField("observation_datetime", TimestampType(), True),
            StructField("unit_source_value", StringType(), True),
            StructField("value_as_concept_id", LongType(), True),
            StructField("observation_concept_id", LongType(), True),
            StructField("value_source_value", StringType(), True),
            StructField("SourceModifiedOn", TimestampType(), True),
            StructField("unit_concept_id", LongType(), True),
            StructField("value_as_number", DecimalType(), True),
        ]
    )

    expected_datetime = datetime(year=2023, month=12, day=3, hour=10)
    df_data = [
        (
            1,
            None,
            None,
            None,
            None,
            None,
            "Observation_fhir",
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            expected_datetime,
            None,
            None,
        ),
        (
            2,
            None,
            None,
            None,
            None,
            None,
            "Observation_fhir",
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            expected_datetime,
            None,
            None,
        ),
    ]
    df = spark.createDataFrame(data=df_data, schema=df_schema)
    df.write.format("delta").save(f"{Constants.SINK_TABLES_ROOT}/observation")
    result = compute_last_processed_line_for_all_source_tables(spark, fhir_omop_config)
    key_for_target_table = next(k for k in result.keys() if "Observation" in k)
    assert result[key_for_target_table] == expected_datetime


def compute_last_processed_line_for_all_source_tables(
    spark: SparkSession, config: DataFeedConfiguration, max_workers=3
) -> Dict[str, datetime]:
    result: Dict[str, datetime] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        for source_config in config.source_configurations:
            if source_config.target_configurations:
                last_processed = lpl(spark).compute_last_processed_line_in_source_table(executor, source_config)
                result[source_config.data_access_definition.data_source_id] = last_processed
    return result
