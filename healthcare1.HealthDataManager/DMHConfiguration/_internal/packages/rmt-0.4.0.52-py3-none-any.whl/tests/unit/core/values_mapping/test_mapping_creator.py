from pyspark.sql import SparkSession

from rmt.core.values_mapping.mapping_creator import MappingCreator
from rmt.core.values_mapping.mapping_schema import MappingSchema
from rmt.core.values_mapping.mapping_values_definition import MappingValuesDefinition


class TestMappingCreator:

    def test_create_with_empty_mapping_definitions(self, spark: SparkSession):
        mapping_dataframe = MappingCreator.create(spark, "", [])
        assert mapping_dataframe.collect() == []
        assert mapping_dataframe.schema == MappingSchema.schema

    def test_create_with_one_mapping_definitions(self, spark: SparkSession, mocker):
        row1 = ("Test", "male", "gender", "genderId", 1)
        row2 = ("Test", "female", "gender", "genderId", 2)
        mapping_definition_mock_1 = mocker.Mock(spec=MappingValuesDefinition)
        mapping_definition_mock_1.to_mapping_dataframe.return_value = \
            spark.createDataFrame([row1], MappingSchema.schema)
        mapping_definition_mock_2 = mocker.Mock(spec=MappingValuesDefinition)
        mapping_definition_mock_2.to_mapping_dataframe.return_value = \
            spark.createDataFrame([row2], MappingSchema.schema)
        mocker.patch("rmt.core.values_mapping.mapping_adder.MappingAdder.add").return_value = \
            spark.createDataFrame([row1, row2], MappingSchema.schema)

        mapping_dataframe = MappingCreator.create(spark, "Test", [mapping_definition_mock_1, mapping_definition_mock_2])
        assert mapping_dataframe.count() == 2
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN] == "Test"
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE] == "male"
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE] == "gender"
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD] == "genderId"
        assert mapping_dataframe.first()[MappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE] == 1
