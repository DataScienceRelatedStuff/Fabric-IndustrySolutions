import logging
from pyspark.sql.session import SparkSession
from microsoft.fabric.hls.hds.utils.data_manager_logger import DataManagerLogger
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC


class LoggingHelper:
    """
    Class to generate named instances of the DataManagerLogger
    """

    @staticmethod
    def get_imaging_metadata_extraction_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DICOM_IMAGING}.{logger_name}",
            log_level)
    
    @staticmethod
    def get_imaging_metadata_to_fhir_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DICOM_IMAGING}.{logger_name}",
            log_level)
        
    @staticmethod
    def get_imaging_bronze_ingestion_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DICOM_IMAGING}.{logger_name}",
            log_level)
        
    @staticmethod
    def get_fhirtoomop_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.FHIR_TO_OMOP}.{logger_name}",
            log_level)

    @staticmethod
    def get_deployment_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DATA_MANAGER_DEPLOYMENT}.{logger_name}",
            log_level)
    
    @staticmethod
    def get_fhirexport_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DATA_MANAGER_FHIR_EXPORT}.{logger_name}",
            log_level)

    @staticmethod
    def get_bronzeingestion_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DATA_MANAGER_BRONZE_INGESTION}.{logger_name}",
            log_level)
        
    @staticmethod
    def get_silveringestion_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DATA_MANAGER_SILVER_INGESTION}.{logger_name}",
            log_level)


    @staticmethod
    def get_nlpingestion_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DATA_MANAGER_NLP_INGESTION}.{logger_name}",
            log_level)
        
    @staticmethod
    def get_omopingestion_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{GC.DATA_MANAGER_OMOP_INGESTION}.{logger_name}",
            log_level)
        
    @staticmethod
    def get_generic_logger(
        spark: SparkSession,
        logger_name: str,
        log_level: int = logging.DEBUG
    ) -> DataManagerLogger:
        """
        :param: spark -- Current spark session
        :param: logger_name -- Name of the logger
        :param: log_level -- Only events of this level and above will be tracked 
        """
        return DataManagerLogger(
            spark,
            f"{GC.DATA_MANAGER_LOGGER}.{logger_name}",
            log_level)
