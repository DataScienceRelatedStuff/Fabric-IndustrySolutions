from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, StructType, StructField, TimestampType, LongType, Row

from dmf.transformations.steps.intra_day_latest_changes_filter import \
    IntraDayLatestChangeFilter


class TestIntraDayLatestChangeFilter:
    def test_intra_day_latest_change_filter(self, spark: SparkSession):
        schema = StructType(
            [
                StructField("key1", StringType(), True),
                StructField("key2", LongType(), True),
                StructField("SourceModifiedOn", TimestampType(), True),
            ]
        )
        data = [
            ("a", 1, datetime(2022, 9, 1, 12)),
            ("a", 1, datetime(2022, 9, 1, 13)),
            ("a", 1, datetime(2022, 9, 2, 13)),
            ("a", 2, datetime(2022, 9, 2, 13)),
            ("a", 2, datetime(2022, 9, 2, 14)),
            ("c", 1, datetime(2022, 9, 3)),
            ("d", 1, datetime(2022, 9, 4)),
        ]
        source_df = spark.createDataFrame(data, schema)
        df = IntraDayLatestChangeFilter.filter(source_df, ["key1", "key2"], "SourceModifiedOn")
        rows = df.collect()
        assert rows == [Row(key1='a', key2=1, SourceModifiedOn=datetime(2022, 9, 1, 13)),
                        Row(key1='a', key2=1, SourceModifiedOn=datetime(2022, 9, 2, 13)),
                        Row(key1='a', key2=2, SourceModifiedOn=datetime(2022, 9, 2, 14)),
                        Row(key1='c', key2=1, SourceModifiedOn=datetime(2022, 9, 3, 0)),
                        Row(key1='d', key2=1, SourceModifiedOn=datetime(2022, 9, 4, 0))]
