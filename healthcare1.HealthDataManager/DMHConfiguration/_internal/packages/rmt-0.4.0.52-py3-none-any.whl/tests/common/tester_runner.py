from typing import List

from pyspark.sql import SparkSession

from rmt.runners.runner import Runner
from tests.common.tester_file_system_client import TesterFileSystemClient


class TesterRunner:
    def __init__(
        self,
        spark: SparkSession,
        test_name: str,
        rmt_spec_path: str,
    ) -> None:
        self._spark = spark
        self._test_name = test_name
        self._rmt_spec_path = rmt_spec_path

    def create_reference_values_mapping(
        self,
        ordered_mapping_definitions_folders: List[str],
        number_of_partition_files: int = -1,
    ):
        file_system_client = TesterFileSystemClient(self._test_name)

        Runner(self._spark, file_system_client, self._rmt_spec_path).create_reference_values_mapping(
            ordered_mapping_definitions_folders, number_of_partition_files
        )

    def create_reference_data_tables(self, target_path: str, reference_tables_folders_paths: list[str]):
        file_system_client = TesterFileSystemClient(self._test_name)
        Runner(
            spark=self._spark, file_system_client=file_system_client, rmt_spec_path=self._rmt_spec_path
        ).create_reference_data_tables(target_path, reference_tables_folders_paths)
