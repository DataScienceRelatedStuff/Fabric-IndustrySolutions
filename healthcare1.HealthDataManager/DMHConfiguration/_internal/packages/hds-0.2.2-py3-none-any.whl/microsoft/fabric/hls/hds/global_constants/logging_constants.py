# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module defining logging constants
"""

# pylint: disable=R0903 # too-few-public-methods
# pylint: disable=C0301 # line-too-long


class LoggingConstants:
    """Logging constants"""
    
    NULL_ARGUMENT_ERR_MSG = "{argument_name} cannot be empty. Please set a value."
    TABLE_EXISTS = "{table_name} exists in {lakehouse}"
    STREAMING_PATH_DOES_NOT_EXIST_INFO_MSG = "Streaming path {streaming_path} does not exist. Skipping streaming on this path."
    
    # Invalid arguments
    INVALID_ARGUMENT = "Invalid Argument."
    BRONZE_SOURCE_PATH_PATTERN_MUST_CONTAIN_SUBSTRING = "source_path_pattern must contain the substring <resource_name>."
    
    # Flattening logging messages
    INVALID_CONFIG_FORMAT_ERR_MSG = "Invalid configuration format. Should be [{{\"resourceType\":\"Patient\",\"path\":\"ndjson file path\"}}] but instead is:"
    MISSING_CONFIGURATION_ERR_MSG = "Can't find configuration for resource_type"
    FLATTENING_ALL_RESOURCES_START_INFO_MSG = "Flattening all resources started"
    FLATTENING_ALL_RESOURCES_END_INFO_MSG = "Flattening all resources completed"
    FLATTENING_RESOURCE_START_INFO_MSG = "Flattening started for resource:"
    FLATTENING_RESOURCE_END_INFO_MSG = "Flattening completed for resource:"
    FLATTENING_NONE_DATAFRAME = "A None dataframe was passed. Creating an empty dataframe with given schema in config and continue to process the resulting dataframe."
    FLATTENING_RESOURCE_ERR_MSG = "Error occurred while flattening resource"
    SAVING_FLATTENED_RESOURCE_START_INFO_MSG = "Saving flattened resource:"
    SAVING_FLATTENED_RESOURCE_END_INFO_MSG = "Successfully saved flattened resource:"
    SAVING_FLATTENED_RESOURCE_ERR_MSG = "Error occurred while saving flattened resource:"
    UNSUPPORTED_RESOURCE_STATUS_DETAILS = "Resource type validation unsuccessful: {0} is not supported."
    SUPPORTED_RESOURCE_STATUS_DETAILS = "Resource type validation successful: {0} is supported."
    FLATTENING_INVALID_COLUMN_CONFIGURATION = "Resource {resource_type} column configuration path is invalid: {config_path}. Generating column config from schema: {ex_message}"
    FLATTENING_LOADING_CONFIGURATION_AT_PATH = "Loading column config at: {config_path} for resource: {resource_type}"
    FLATTENING_GENERATING_CONFIGURATION = "Column configuration path is not defined. Generating column config from schema for: {resource_type}"
    FLATTENING_EMPTY_CONFIG_FILE = "No entities in config file: {config_path} to flatten."
    FLATTENING_SOURCE_RESOURCES_WITH_NO_DATA = "{resources_with_no_source_data} have no data in bronze. Flatten using empty dataframes."
    
    # creating empty tables logging messages
    CREATING_TABLE_START_INFO_MSG = "Creating delta table for resource:"
    CREATING_TABLE_ERR_MSG = "Error occurred while creating delta table for resource:"
    SCHEMA_NOT_FOUND_ERR_MSG = "Avro schema not found for this resource"
    CREATING_TABLE_END_INFO_MSG = "Successfully created delta table for resource:"
    CREATING_TABLE_SKIPPED_INFO_MSG = "Skipping creating delta table, as it already exists for resource:"
    CREATING_EMPTY_SILVER_TABLES_ERR_MSG = "Error occurred while creating empty silver tables: {exception_details}"
    CREATE_SILVER_TABLES_INFO_MSG = "Creating silver tables for resources in config."
    CREATE_SILVER_TABLES_ERR_MSG = "Failed to create silver tables. Exception details: {exception_details}"
    
    CREATING_EMPTY_TABLES_ERR_MSG = "Error occurred while creating empty tables in {lakehouse}. Exception Details: {exception_details}"

    # utils append_unique_to_delta_managed logging messages
    CREATING_AND_FINDING_DATABASE_ERR_MSG = "Unable to find and create delta table"
    EMPTY_UNIQUE_COLUMNS_INPUT_ERR_MSG = "Invalid 'unique_columns' input. Unique columns cannot be empty."

    # NLPService logging messages
    INVALID_BATCHING_INPUT_DF_ERR_MSG = "Batching the input dataframe failed. 'input_df', must be a DataFrame"
    INVALID_BATCHING_INPUT_BATCH_SIZE_ERR_MSG = "Batching the input dataframe failed. 'batch_size' must be a positive integer"
    FINAL_BATCHED_DATAFRAME_INFO_MSG = "NLP service batched the input dataframe. Batched dataframe has a count of:"
    INVALID_REPARTITION_INPUT_DF_ERR_MSG = "Repartitioning the input dataframe failed. 'input_df', must be a DataFrame"
    FINAL_REPARTITION_INFO_MSG = "Batched dataframe has been repartitioned to have partition/s:"
    ANALYZED_DATAFRAME_REORDERING_INFO_MSG = "The analyzed dataframe count after exploding during reordering:"
    FINAL_REORDER_ANALYZED_DATAFRAME_INFO_MSG = "Reordered/final text analysis results dataframe has a count of:"
    FINAL_ANALYZED_DATAFRAME_INFO_MSG = "NLP service analyzed dataframe has a count of:"
    INVALID_NLP_ANALYSIS_INPUT_DF_ERR_MSG = "NLPService failed to process the source datataframe for Text Analysis. The source_df parameter must be a valid DataFrame."
    NLP_SERVICE_VALUE_ERR_MSG = "An error occurred while validating inputs:"
    NLP_SERVICE_PARSE_ERR_MSG = "An error occurred while parsing a Dataframe:"
    NLP_SERVICE_ANALYSIS_ERR_MSG = "An error occurred while analyzing a Dataframe:"
    NLP_SERVICE_UNEXPECTED_ERR_MSG = "NLP analysis failed due to an unknown error:"

    # Flatten NLP Results logging messages
    FLATTEN_NLP_RESULTS_CALLING_FLATTENING_INFO_MSG = "Flattening NLP resource: {resource}"
    FLATTEN_NLP_RESULTS_FAILED_ERROR_MSG = "NLP Flattening Failed for resource {resource}. Exception details: {exception_details}"
    
    # NLPManager logging messages
    NLP_MANAGER_DATA_LOAD_ERR_MSG = "Error while reading data from table:"
    NLP_MANAGER_DATA_LOAD_SUFFIX_ERR_MSG = "to get the latest meta_lastUpdated."
    NLP_MANAGER_DATA_FILTERING_INFO_MSG = "Successfully filtered data from table whose timestamp column is greater than"
    NLP_MANAGER_DATA_TABLE_INFO_MSG = "Data from table:"
    NLP_MANAGER_DATA_LOAD_PROCEED_INFO_MSG = "Proceeding to load data from table without filtering."
    NLP_MANAGER_DOCUMENT_COUNT_INFO_MSG = "The document count is:"
    NLP_MANAGER_DATA_LOAD_ORDERING_INFO_MSG = "Successfully ordered the dataframe in ascending order using the"
    NLP_MANAGER_DATA_LOAD_DOCUMENT_COUNT_LIMITING_INFO_MSG = "Successfully limited the document. The document count is:"
    NLP_MANAGER_RETRY_INPUT_DF_INFO_MSG = "The initial results dataframe to retry on recoverable errors has an initial count of:"
    NLP_MANAGER_RETRY_TERMINATED_INFO_MSG = "Retry terminated since there were no recoverable errors with a retry count of:"
    NLP_MANAGER_RETRY_SUCCESSFUL_INFO_MSG = "Successfully retried recoverable errors with a retry count of:"
    NLP_MANAGER_PIPELINE_START_INFO_MSG = "NLP pipeline started running."
    NLP_MANAGER_PIPELINE_END_INFO_MSG = "NLP pipeline finished running."
    NLP_MANAGER_PIPELINE_NO_NEW_RECORDS_INFO_MSG = "NLP pipeline did not find any new records to process."
    NLP_MANAGER_PIPELINE_SUCCESS_NO_NEW_RECORDS_INFO_MSG = "NLP pipeline succeeded with no new records to process."
    NLP_MANAGER_PIPELINE_LOAD_DF_INFO_MSG = "NLP pipeline loaded the dataframe with a count of:"
    NLP_MANAGER_PIPELINE_CUSTOM_ERR_MSG = "NLP pipeline failed due to an error:"
    NLP_MANAGER_PIPELINE_UNKNOWN_ERR_MSG = "NLP pipeline failed due to an unknown error:"
    NLP_MANAGER_PIPELINE_SUCCESS_INFO_MSG = "NLP pipeline succeeded performing text analysis and saving the NLP outputs."
    NLP_MANAGER_TOTAL_ANALYZED_RECORDS_INFO_MSG = "Total number of records analyzed:"
    NLP_MANAGER_TOTAL_SUCCESSFULLY_ANALYZED_RECORDS_INFO_MSG = "Total number of records successfully analyzed:"
    NLP_MANAGER_TOTAL_ERROR_ANALYZED_RECORDS_INFO_MSG = "Total number of records failed to analyze:"
    NLP_MANAGER_PIPELINE_UNRECOVERABLE_ERRORS_INFO_MSG = "There were no successful records to save due to unrecoverable errors."
    NLP_MANAGER_FINAL_ANALYZED_DATAFRAME_INFO_MSG = "The final results dataframe count before saving is:"
    NLP_MANAGER_LOADING_DATA_FROM_TABLE_INFO_MSG = "Loading data from table: {table_name}"
    NLP_MANAGER_CALLING_NLPSERVICE_INFO_MSG = "Calling NLPService to analyze the unstructured data."
    NLP_MANAGER_CHECKING_RECOVERABLE_ERRORS_INFO_MSG = "Checking for errors to retry on recoverable errors."
    NLP_MANAGER_PIPELINE_INDIVIDUAL_CUSTOM_ERR_MSG = "Document Id: {doc_id}, Error Code: {error_code}, Error Message: {error_message}"
    
    # fhirtoomop logging messages
    MAIN_ORCH_CHECK_DB_INFO_MSG = "Database `{0}` verified at '{1}'."
    BEGAN_EXECUTION_INFO_MSG = "Began execution"
    COMPLETED_EXECUTION_INFO_MSG = "Completed execution"
    MAIN_ORCH_NO_FILES_FOUND_DEBUG_MSG = "No files to process for FHIR to OMOP transformation. Please ensure files to process are located in {0}."
    MAIN_ORCH_OBTAIN_FILE_LOCK_INFO_MSG = "Document {0} obtained from {1}."
    MAIN_ORCH_SUCCESS_TRANSFORMATION_INFO_MSG = "Successfully transformed file: {0}."
    MAIN_ORCH_FLATTENING_FAILURE_ERROR_MSG = "Flattening failed. Returned with status: {0}."
    MAIN_ORCH_FLATTENING_QUALIFIED_INFO_MSG = "Flatten qualified to run."
    MAIN_ORCH_FLATTENING_UNQUALIFIED_INFO_MSG = "Flatten did not qualify to run."
    MAIN_ORCH_NLP_QUALIFIED_INFO_MSG = "NLP qualified to run."
    MAIN_ORCH_NLP_UNQUALIFIED_INFO_MSG = "NLP did not qualify to run."
    MAIN_ORCH_NLP_EXCEPTION_ERROR_MSG = "NLP Exception {0} raised. Details: {1}."
    MAIN_ORCH_NLP_ERROR_MSG = "NLP failed. Details: {0}"
    MAIN_ORCH_DTT_QUALIFIED_INFO_MSG = "DTT qualified to run. Workflow invoked."
    MAIN_ORCH_DTT_UNQUALIFIED_INFO_MSG = "DTT did not qualify to run."
    OMOP_TRANSFORMATION_EXCEPTION_ERROR_MSG = "OMOP transformation failed. {0} raised. Details: {1}."
    RMT_CREATED_CONCEPT_FILE = "Concept.json file was successfully created at: {0}."
    SUCCESSFULLY_MOUNTED_PATH = "Successfully mounted path: {0} at {1}"
    DTT_SUCCESS_INFO_MSG = "DTT workflow completed."
    RMT_SUCCESS_INFO_MSG = "RMT workflow completed."
    MAIN_ORCH_GET_NEXT_MSG_INFO_MSG = "Began process to return the least recently returned file."
    DTT_APP_INSIGHTS_SET_INFO_MSG = "Set DTT application insights connection string in spark setting"    
    
    # Drug_Era generation logging messages
    NORMALIZE_DRUG_EXPOSURE_START_INFO_MSG = "Normalizing drug exposure end dates for '{0}.{1}'."
    NORMALIZE_DRUG_EXPOSURE_END_INFO_MSG = "Succefully normalized '{0}.{1}' end dates and ingredient concept ids."
    GROUP_OVERLAPPING_EXPOSURES_START_INFO_MSG = "Grouping overlapping drug exposures."
    GROUP_OVERLAPPING_EXPOSURES_END_INFO_MSG = "Successfully grouped overlapping drug exposures."
    CALCULATE_FINAL_DRUG_ERAS_START_INFO_MSG = "Calculating final drug eras with gap days/persistence window."
    CALCULATE_FINAL_DRUG_ERAS_END_INFO_MSG = "Successfully calculated final drug eras with gap days/persistence window."
    GENERATE_DRUG_ERAS_START_INFO_MSG = "Generating '{0}.{1}' table."
    GENERATE_DRUG_ERAS_END_INFO_MSG = "Successfully generated and saved '{0}.{1}' table."
    DELETE_EXISTING_DRUG_ERAS_INFO_MSG = "Succesfully deleted existing drug_era table records."
    DRUG_ERA_TABLE_DOES_NOT_EXIST_INFO_MSG = "Drug era table does not exist. Creating new table '{0}.{1}'"
    GENERATE_DRUG_ERAS_SKIPPED_INFO_MSG = "Skipped drug era generation. No data to process."
    TABLE_OR_VIEW_NOT_FOUND_ERR_MSG = "Please ensure that the tables '{db}.drug_exposure', '{db}.concept_ancestor', and '{db}.concept' exist in the database. Failed in executing SQL query for retrieving drug exposure information."
    GENERATE_DRUG_ERAS_UNEXPECTED_ERR_MSG = "An unexpected error occurred while generating the drug era table"
    
    # Bronze ingestion service logging messages
    BRONZE_INGESTION_START_INFO_MSG = 'Bronze ingestion started.'
    BRONZE_INGEST_RSC_LIST_INFO_MSG = 'Bronze ingestion will stream on the following resources: {0}.'
    SET_STRUCTURED_STREAMING_INFO_MSG = 'Setting structured streaming on the following path: {0}.'
    BRONZE_INGESTION_START_LOAD_INFO_MSG = 'Loading Schema at: {path}'
    BRONZE_INGESTION_END_LOAD_INFO_MSG = 'All resource schemas completed loading.'
    INGESTION_START_STREAM_INFO_MSG = 'Ingestion began streaming for path: {0}.'
    BRONZE_INGESTION_PATH_NOT_FOUND_INFO_MSG = 'Streaming path {path} does not exist. Create an empty table for {resource_name} if table does not exist.'
    STREAM_ORCHESTRATOR_END_QUERIES_INFO_MSG = 'All queries completed and streams terminated.'
    FILTERING_BRONZE_DF_ON_RESOURCE_TYPE_INFO_MSG = 'Filtering bronze source df where resourceType == {resource_name}'

    # Silver Ingestion Service logging messages
    LAKEHOUSE_DOES_NOT_EXIST = "The lakehouse with name {lakehouse_name} does not exist."
    SILVER_INGESTION_SOURCE_TABLE_DOES_NOT_EXIST_OR_EMPTY = "The source table at {source_table_path} either does not exist or is empty and the target table {target_table_path} does not exist. Calling transformation function with None Dataframe."
    SILVER_INGESTION_SOURCE_TABLE_DOES_EXIST = "The source table at {table_path} does exist. Setting up structured streaming on the source table."
    SILVER_INGESTION_SETUP_TABLE_DOES_NOT_EXIST = "The target table at {table_path} does not exist. It has been marked for creation"
    SILVER_INGESTION_SETUP_TABLE_EVOLVED_SCHEMA = "Incoming schema has evolved. The target table at {table_path} has been marked for creation"
    SILVER_INGESTION_SETUP_TABLES_SKIPPED = "Silver tables setup skipped. All the tables are up to date."
    SILVER_INGESTION_TRANSFORMATION_SKIPPED = "Skipping silver transformation for source table at {source_table_path}. There is no new data and the target table already exists at {target_table_path}"
    
    
    # Normalization error message
    REFERENCE_NORMALIZATION_INFO_MSG = "Skipping {column}.{nested_ref_name} reference normalization. Unsupported schema: {schema}. "
    REFERENCE_NORMALIZATION_ERR_MSG= "Reference normalization error when processing data column: '{column}'. "
    NORMALIZATION_INVALID_CONFIG = "Invalid normalization configuration. Column name '{column}' does not exist. "
    REFERENCE_NORMALIZATION_INVALID_CONFIG = "Invalid normalization configuration. '{nested_ref_name}' not found in the provided data column. "
    
    # Utils logging messages
    SAVE_DELTA_TABLE_TO_PATH_INFO_MSG = "Saving dataframe to delta table at path: {table_path}"
    UPSERT_UNIQUE_TO_DELTA_MANAGED_INFO_MSG = "The number of records pre-filtered out before upserting into {delta_table_path}: {record_count}"
    UPSERT_UNIQUE_TO_DELTA_MANAGED_ERR_MSG = "The provided object is not a DataFrame."
    
    # Folder utils logging message
    FABRIC_MISMATCHED_IDENTIFIERS_ERR_MSG = "Mismatched artifact identifiers:  workspace_name ({workspace_name}) and lakehouse_name ({lakehouse_name}) should both be either Artifact `GUIDs` or `names`."
    WORKLOAD_MISMATCHED_IDENTIFIERS_ERR_MSG = "Mismatched artifact identifiers:  workspace_name ({workspace_name}) and solution_name ({solution_name}) should both be either Artifact `GUIDs` or `names`."
    
    # FHIRExportService logging messages
    FHIREXPORTSERVICE_RESPONSE_INFO_MSG = "The {trigger_type} HTTP call returned response code {code}"
    FHIREXPORTSERVICE_TRIGGER_SUCCESS_INFO_MSG = "Azure Function triggered. Polling status..."
    FHIREXPORTSERVICE_TRIGGER_ERR_MSG = "Failed to trigger Azure Function. Response code {code}"
    FHIREXPORTSERVICE_EXCEPTION_ERR_MSG = "An exception occured while polling. {exception_message}"
    FHIREXPORTSERVICE_SUCCESS_INFO_MSG = "FHIRExportService completed successfully."
    FHIREXPORTSERVICE_FAILURE_ERR_MSG = "FHIRExportService did not complete as expected."
    FHIREXPORTSERVICE_IN_PROGRESS_DEBUG_MSG = "Azure Function still running..."
    FHIREXPORTSERVICE_POLLING_ERR_MSG = "Polling failed or encountered an error. Response code: {code}. Error message: {message}"
    FHIREXPORTSERVICE_MAX_DURATION_ERR_MSG = "Max polling duration ({max_days} days) reached. Exiting polling loop."
    FHIREXPORTSERVICE_PIPELINE_STATUS_MSG = "Pipeline Success: {result}"
    FHIREXPORTSERVICE_UNABLE_TO_PARSE_ERR_MSG = "Unable to parse error message from output"
    FHIREXPORTSERVICE_NO_ERROR_MSG = "No error message available"

    # Logger name constants
    LogAnalyticsSparkLoggerName = "{logger_name}_LogAnalytics"
    AppInsightsSparkLoggerName = "{logger_name}_AppInsights"
    ConsoleLoggerName = "{logger_name}_Console"
    RunId = "RunId"
    
    # Dicom imaging logging messages
    PROCESSING_STATE_INFO_MSG = "{process_name} process {state} at {timestamp} for DCM imaging files located at {dcm_files_path}."
    PATH_NOT_EXIST_ERR_MSG = "{process_name} process ended because the following path doesn't exist : {path}"
    FAILED_FILES_NOT_MOVED_ERR_MSG = "Unable to move failed files due to following error: {error_msg}"
    PATH_NOT_REMOVED_ERR_MSG = "The path '{path}' could not be removed. {exception}"
    RETRY_INFO_MSG = "{process_name} process attempt: {retry_attempt}"
    TAGS_EXTRACTION_FAILED_MSG = "Dicom metadata tags extraction in dcm file: {dcm_file_name} failed for the following tags : {failed_tags}"
    PROCESSING_FAILED_ERR_MSG = "{process_name} process failed for dcm file : {dcm_file_name} due to following error : {error_mssg}"
    PROCESSING_STATUS_INFO_MSG = "Total DCM files : {total_dcm_files}, Successful files count : {success_files_count}, Successful files with warnings count : {success_with_warn_count}, Failed files count : {failed_files_count}"
    ARCHIVE_EXTRACT_FOLDER_EMPTY_INFO_MSG = "{process_name} process ended with no pending dcm or archive files to process in the drop location : {dcm_files_path}"
    ARCHIVE_EXTRACT_STATE_INFO_MSG = "{process_name} process {state} at {timestamp} for archive files located at {files_path}"
    ARCHIVE_EXTRACT_FAILED_ERR_MSG = "Error occurred while extracting archive files for file {archive_file_name}"    
    DROP_FILES_MOVEMENT_FAILED_ERR_MSG = "Error occurred while moving dcm files {dcm_files}"
    DROP_FILES_MOVEMENT_PROCESSED_INFO_MSG = "Total dcm files succeeded {total_files_succeeded} and failed {failed}"
    ARCHIVE_EXTRACT_FILES_PROCESSED_INFO_MSG = "Total archive files succeeded : {total_files_succeeded} and failed : {failed}"
    ARCHIVE_EXTRACT_FILES_INFO_MSG = "Archive filename : {archive_file_name} , Total files extracted successfully : {total_files_succeeded} and failed : {failed}"
    
    #Dicom Metadata to fhir ImagingStudy conversion logging messages
    NO_NEW_DATA_FOUND_INFO_MSG = "No new data found in dicomimagingmetastore table for processing."
    SAVING_NDJSON_FILE_INFO_MSG = "Saving fhir ndjson file with {num_records} records at {file_path}."
    FHIR_CONVERSION_PROCESS_STATE_INFO_MSG = "DICOM Metadata to FHIR conversion process (Epoch id: {epoch_id}) {state} at {timestamp} for dicomimagingmetastore table located at : {table_loc}"
    RECORDS_NUM_PROCESSED_INFO_MSG = "From the previous run, total number of {records_num} new records found in dicomimagingmetastore table for conversion."
    FHIR_ELEMENT_COUNT_AFTER_GROUPING_INFO_MSSG = "As part of conversion process, total number of {count} '{fhir_element_name}' objects are formed."
    SPARK_STREAM_READ_ERR_MSG = "Failed to read dicomimagingmetastore table located at : {table_path} due to following error : {error_msg}"