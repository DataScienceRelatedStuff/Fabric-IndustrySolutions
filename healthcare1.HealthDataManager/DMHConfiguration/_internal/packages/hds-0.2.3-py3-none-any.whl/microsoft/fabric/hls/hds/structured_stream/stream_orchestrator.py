import time
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.errors.streaming_queries_failed_error import StreamingQueriesFailedError

class StreamOrchestrator:

    def __init__(self, spark: SparkSession):
        """
            Args:
            spark: spark session
        """
        self.spark: SparkSession = spark
        self._logger = LoggingHelper.get_generic_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL)
        
    def await_all_termination(self, streaming_queries):
        """Block until all active queries have been terminated

        Args:
            streaming_queries (_type_): List of streaming queries to monitor

        Raises:
            StreamingQueriesFailedError: Raise an exception if any of the queries terminate in error
        """
        # We need to block until all queries are terminated
        while self.spark.streams.active:
            try:
                self.spark.streams.awaitAnyTermination() # block until any of the queries on the associated SQLContext has terminated
                self.spark.streams.resetTerminated() # Need to reset to clear past terminations and wait for new terminations
                time.sleep(GlobalConstants.STREAM_ORCHESTRATOR_SLEEP_IN_SECONDS)
            except Exception as streaming_exception:
                self.spark.streams.resetTerminated()
        
        exceptions = [
            str(streaming_query.exception())
            for streaming_query in streaming_queries
            if streaming_query.exception() is not None
        ]
        
        if exceptions:
            raise StreamingQueriesFailedError(f"The following queries failed: {exceptions}")

        self._logger.info(f"{LC.STREAM_ORCHESTRATOR_END_QUERIES_INFO_MSG}")