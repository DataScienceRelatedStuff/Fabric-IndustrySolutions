from datetime import datetime
from typing import List
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StringType, StructType, StructField, TimestampType, BooleanType, IntegerType, LongType

from dmf.transformations.model.transformation_types import PartitionConfig, \
    Source2TargetIdMapping, TransformationMetaData, TransformationData
from dmf.transformations.transformer.duration_transformer import DurationTransformer
from dmf.utils.global_constants import GlobalConstants as GConstants
from tests.utils.dataframe_utils import is_data_identical

OPEN_START = GConstants.START_OF_TIME_PY_DT
OPEN_END = GConstants.END_OF_TIME_PY_DT


class TestDurationTransformer:
    source_modified_on_col_name = "source_modified_on"
    source_is_deleted_col_name = "source_is_deleted"
    source_active_status_col_name = "source_active_status"
    _target_modified_on_col_name = "target_modified_on"
    target_start_col_name = "target_start"
    target_end_col_name = "target_end"
    _target_key_col_name = "target_key"
    target_partition_col_name = "target_partition"
    source_key1_col_name = "source_key1"
    source_data1_col_name = "source_data1"
    source_data2_col_name = "source_data2"
    target_data1_col_name = "target_data1"
    target_data2_col_name = "target_data2"
    _feed_id = "Dataverse"

    source_to_target_col_names_mapping = {
        source_data1_col_name: [target_data1_col_name],
        source_data2_col_name: [target_data2_col_name],
        source_modified_on_col_name: [_target_modified_on_col_name]}
    _source_schema = StructType([
        StructField(source_key1_col_name, StringType(), True),
        StructField(source_data1_col_name, StringType(), True),
        StructField(source_data2_col_name, StringType(), True),
        StructField("source_other", StringType(), True),
        StructField(source_modified_on_col_name, TimestampType(), True),
        StructField(source_is_deleted_col_name, BooleanType(), True),
        StructField(source_active_status_col_name, IntegerType(), True)])

    _target_schema = StructType([
        StructField(_target_key_col_name, LongType(), True),
        StructField(target_data1_col_name, StringType(), True),
        StructField(target_data2_col_name, StringType(), True),
        StructField("target_other", StringType(), True),
        StructField(_target_modified_on_col_name, TimestampType(), True),
        StructField(target_start_col_name, TimestampType(), True),
        StructField(target_end_col_name, TimestampType(), True),
        StructField(target_partition_col_name, LongType(), True)])

    _expected_target_schema = StructType([
        StructField(_target_key_col_name, LongType(), True),
        StructField(target_partition_col_name, LongType(), True),
        StructField(target_data1_col_name, StringType(), True),
        StructField(target_data2_col_name, StringType(), True),
        StructField("target_other", StringType(), True),
        StructField(_target_modified_on_col_name, TimestampType(), True),
        StructField(target_start_col_name, TimestampType(), True),
        StructField(target_end_col_name, TimestampType(), True)])

    _id_mapping_schema = StructType(
        [
            StructField(GConstants.INTERNAL_ID_COLUMN_NAME, StringType(), True),
            StructField(GConstants.EXTERNAL_ID_COLUMN_NAME, StringType(), True),
            StructField(GConstants.ADRM_ID_COLUMN_NAME, LongType(), True),
            StructField(GConstants.FEED_ID_COLUMN_NAME, StringType(), True),
        ])
    # GConstants.FEED_ID_COLUMN_NAME
    partition_config = PartitionConfig(_target_key_col_name, target_partition_col_name, '{0}/2', LongType())
    source_to_target_id_mapping = Source2TargetIdMapping(
        source_id_col_name=source_key1_col_name,
        target_id_col_name=_target_key_col_name,
        id_mapping_df_name="id_mapping")
    _metadata = TransformationMetaData(
        source_partitions_configs=[partition_config],
        source_modified_date_col_name=source_modified_on_col_name,
        source_key_col_names=[source_key1_col_name],
        source_data_col_names=frozenset([source_data1_col_name, source_data2_col_name]),
        source_deleted_status_col_name=source_is_deleted_col_name,
        source_active_status_col_name=source_active_status_col_name,
        target_key_col_names=[_target_key_col_name],
        target_data_col_names=frozenset([target_data1_col_name, target_data2_col_name]),
        synthetically_nulled_primary_keys=frozenset([]),
        target_modified_date_col_name=_target_modified_on_col_name,
        target_period_start_col_name=target_start_col_name,
        target_period_end_col_name=target_end_col_name,
        source_ids_with_conditions=[],
        source_to_target_ids_mapping=[source_to_target_id_mapping],
        source_to_target_col_names_mapping=source_to_target_col_names_mapping,
        feed_id=_feed_id)

    def run_test(self, spark: SparkSession, id_mapping_data: List, source_data: List, target_data: List,
                 expected_df: DataFrame):
        source_df = spark.createDataFrame(source_data, self._source_schema)
        target_df = spark.createDataFrame(target_data, self._target_schema)
        id_mapping_df = spark.createDataFrame(id_mapping_data, self._id_mapping_schema)
        data = TransformationData(source_df, target_df, {"id_mapping": id_mapping_df})
        result_df = DurationTransformer("", "target_id").transform(data, self._metadata)

        if not is_data_identical(result_df, expected_df):
            print(" \nResult:")
            result_df.select(sorted(result_df.columns)).show()
            print(" \nExpected:")
            expected_df.select(sorted(expected_df.columns)).show()
            assert False

    # todo add more tests, use dataframe_utils::is_data_identical
    def test_one_source_key_to_target(self, spark: SparkSession):
        id_mapping_data = [("keya", "keya", 2, self._feed_id)]

        source_data = [
            ("keya", "data7a", "data7b", "other7", datetime(2022, 1, 7, 3), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1", "filtered12", "other7", datetime(2022, 1, 7, 2), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1a1", "filtered12", "other7", datetime(2022, 1, 7, 1), False, GConstants.ACTIVE_VALUE),
            ("keya", "data5a", "data5b", "other5", datetime(2022, 1, 5, 3), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1", "filtered12", "other5", datetime(2022, 1, 5, 2), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1a1", "filtered12", "other5", datetime(2022, 1, 5, 1), False, GConstants.ACTIVE_VALUE)
        ]

        target_data = [
            (2, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3),
             OPEN_END, 1),
            (2, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START,
             datetime(2022, 1, 2), 1),
            (3, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3),
             OPEN_END, 1),
            (3, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START,
             datetime(2022, 1, 2), 1),
            (4, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3),
             OPEN_END, 2),
            (4, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START,
             datetime(2022, 1, 2), 2)
        ]

        expected_rows = [
            (2, 1, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START,
             datetime(2022, 1, 2)),
            (2, 1, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3),
             datetime(2022, 1, 4, 3)),
            (2, 1, "data5a", "data5b", None, datetime(2022, 1, 5, 3),
             datetime(2022, 1, 5, 3), datetime(2022, 1, 6, 3)),
            (2, 1, "data7a", "data7b", None, datetime(2022, 1, 7, 3),
             datetime(2022, 1, 7, 3), OPEN_END),
            (3, 1, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START,
             datetime(2022, 1, 2)),
            (3, 1, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3),
             OPEN_END)
        ]

        expected_df = spark.createDataFrame(data=expected_rows, schema=TestDurationTransformer._expected_target_schema)

        self.run_test(spark, id_mapping_data, source_data, target_data, expected_df)

    def test_two_source_keys_to_target(self, spark: SparkSession):
        id_mapping_data = [
            ("keya", "keya", 2, self._feed_id),
            ("keyb", "keyb", 4, self._feed_id)
        ]

        source_data = [
            ("keya", "data7a", "data7b", "other7", datetime(2022, 1, 7, 3), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1", "filtered12", "other7", datetime(2022, 1, 7, 2), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1a1", "filtered12", "other7", datetime(2022, 1, 7, 1), False, GConstants.ACTIVE_VALUE),
            ("keya", "data5a", "data5b", "other5", datetime(2022, 1, 5, 3), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1", "filtered12", "other5", datetime(2022, 1, 5, 2), False, GConstants.ACTIVE_VALUE),
            ("keya", "filtered1a1", "filtered12", "other5", datetime(2022, 1, 5, 1), False, GConstants.ACTIVE_VALUE),
            ("keyb", "data5a", "data5b", "other5", datetime(2022, 1, 5, 3), False, GConstants.ACTIVE_VALUE),
            ("keyb", "filtered1", "filtered12", "other5", datetime(2022, 1, 5, 2), False, GConstants.ACTIVE_VALUE),
            ("keyb", "filtered1a1", "filtered12", "other5", datetime(2022, 1, 5, 1), False, GConstants.ACTIVE_VALUE)
        ]

        target_data = [
            (2, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3), OPEN_END, 1),
            (2, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2), 1),
            (3, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3), OPEN_END, 1),
            (3, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2), 1),
            (4, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3), OPEN_END, 2),
            (4, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2), 2)
        ]

        expected_rows = [
            (2, 1, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2)),
            (2, 1, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3), datetime(2022, 1, 4, 3)),
            (2, 1, "data5a", "data5b", None, datetime(2022, 1, 5, 3), datetime(2022, 1, 5, 3), datetime(2022, 1, 6, 3)),
            (2, 1, "data7a", "data7b", None, datetime(2022, 1, 7, 3), datetime(2022, 1, 7, 3), OPEN_END),
            (3, 1, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2)),
            (3, 1, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3), OPEN_END),
            (4, 2, "data1a", "data1b", "other1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2)),
            (4, 2, "data3a", "data3b", "other3", datetime(2022, 1, 3), datetime(2022, 1, 3), datetime(2022, 1, 4, 3)),
            (4, 2, "data5a", "data5b", None, datetime(2022, 1, 5, 3), datetime(2022, 1, 5, 3), OPEN_END),
        ]

        expected_df = spark.createDataFrame(data=expected_rows,
                                            schema=TestDurationTransformer._expected_target_schema)
        self.run_test(spark, id_mapping_data, source_data, target_data, expected_df)

    def test_duplicates_on_source_and_target(self, spark: SparkSession):
        id_mapping_data = [("keya", "keya", 2, self._feed_id)]

        source_data = [
            ("keya", "dataa2", "datab2", "sother3", datetime(2022, 1, 6), False, GConstants.ACTIVE_VALUE),
            ("keya", "dataa2", "datab2", "sother2", datetime(2022, 1, 5), False, GConstants.ACTIVE_VALUE),
            ("keya", "dataa1", "datab1", "sother1", datetime(2022, 1, 4), False, GConstants.ACTIVE_VALUE),
        ]

        target_data = [
            (2, "dataa1", "datab1", "tother2", datetime(2022, 1, 3), datetime(2022, 1, 3), OPEN_END, 1),
            (2, "dataa0", "datab0", "tother1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2), 1),
        ]

        expected_rows = [
            (2, 1, "dataa0", "datab0", "tother1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2)),
            (2, 1, "dataa1", "datab1", "tother2", datetime(2022, 1, 3), datetime(2022, 1, 3), datetime(2022, 1, 4)),
            (2, 1, "dataa2", "datab2", None, datetime(2022, 1, 5), datetime(2022, 1, 5), OPEN_END),
        ]

        expected_df = spark.createDataFrame(data=expected_rows,
                                            schema=TestDurationTransformer._expected_target_schema)
        self.run_test(spark, id_mapping_data, source_data, target_data, expected_df)

    def test_duplicates_on_source_and_target_with_status_cols(self, spark: SparkSession):
        id_mapping_data = [("keya", "keya", 2, self._feed_id)]

        source_data = [
            ("keya", "dataa2", "datab2", "sother3", datetime(2022, 1, 8), False, GConstants.ACTIVE_VALUE),
            ("keya", "dataa2", "datab2", "sother3", datetime(2022, 1, 7), False, GConstants.INACTIVE_VALUE),
            ("keya", "dataa2", "datab2", "sother3", datetime(2022, 1, 6), False, GConstants.ACTIVE_VALUE),
            ("keya", "dataa2", "datab2", "sother2", datetime(2022, 1, 5), False, GConstants.ACTIVE_VALUE),
            ("keya", "dataa1", "datab1", "sother1", datetime(2022, 1, 4), False, GConstants.ACTIVE_VALUE),
        ]

        target_data = [
            (2, "dataa1", "datab1", "tother2", datetime(2022, 1, 3), datetime(2022, 1, 3), OPEN_END, 1),
            (2, "dataa0", "datab0", "tother1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2), 1),
        ]

        expected_rows = [
            (2, 1, "dataa0", "datab0", "tother1", datetime(2022, 1, 1), OPEN_START, datetime(2022, 1, 2)),
            (2, 1, "dataa1", "datab1", "tother2", datetime(2022, 1, 3), datetime(2022, 1, 3), datetime(2022, 1, 4)),
            (2, 1, "dataa2", "datab2", None, datetime(2022, 1, 5), datetime(2022, 1, 5), datetime(2022, 1, 6)),
            (2, 1, "dataa2", "datab2", None, datetime(2022, 1, 8), datetime(2022, 1, 8), OPEN_END),
        ]

        expected_df = spark.createDataFrame(data=expected_rows,
                                            schema=TestDurationTransformer._expected_target_schema)

        self.run_test(spark, id_mapping_data, source_data, target_data, expected_df)
