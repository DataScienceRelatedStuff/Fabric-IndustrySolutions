"""
response.py
-----------

This module defines the data models used for the response of the `get_proposed_paths` API. 

Classes
-------
LinkedTable/Table:
    Represents a table and a field in that table.

Link:
    Represents a link between two LinkedTables.

TableField:
    Represents a field in a table.

Result:
    Represents a result containing a list of tables, a list of links, and a score.

Source:
    Represents the source table and field.

Target:
    Represents the target table and field.

Response:
    Represents the response of the `get_proposed_paths` API.

Functions
---------
_table_type(table: TargetTableSchema) -> str:
    Returns the type of the given table.

"""
from collections import defaultdict
from dataclasses import dataclass
import re
from typing import Tuple
from configuration_compiler.column_transformation.proposed_paths_generator import ProposedPathsResponse
from configuration_compiler.column_transformation.relationships_generator import Relationship
from configuration_compiler.spec_models.target_table_schema import TableColumnExt, TargetTableSchemaExt
from dmf.model.target_configuration.target_table_schema import ForeignKey, TableRelation, TargetTableSchema
from pydantic import BaseModel


class LinkedTable(BaseModel):
    table: str
    field: str


class Link(BaseModel):
    src: LinkedTable
    dst: LinkedTable

    @classmethod
    def from_foreign_key(cls, relationship: TableRelation, fk: ForeignKey):
        return cls(
            src=LinkedTable(table=relationship.from_entity, field=fk.from_attribute),
            dst=LinkedTable(table=relationship.to_entity, field=fk.to_attribute),
        )


class TableField(BaseModel):
    name: str
    description: str

    @classmethod
    def from_column(cls, column: TableColumnExt):
        return cls(name=column.name, description=column.description)


class Table(BaseModel):
    name: str
    description: str
    type: str
    fields: list[TableField]
    groupedBy: list[str] | None
    durationEndColumn: str | None
    durationStartColumn: str | None

    @classmethod
    def from_schema(cls, schema: TargetTableSchemaExt):
        if schema.duration_semantics is None:
            grouped_by, duration_start_column, duration_end_column = None, None, None
        else:
            grouped_by = list(schema.duration_semantics.group_by_cols)
            duration_start_column = schema.duration_semantics.start_col_name
            duration_end_column = schema.duration_semantics.end_col_name

        return cls(
            name=schema.id,
            description=schema.description,
            type=_table_type(schema),
            fields=[TableField.from_column(column) for column in schema.columns],
            groupedBy=grouped_by,
            durationStartColumn=duration_start_column,
            durationEndColumn=duration_end_column,
        )


class Path(BaseModel):
    tables: list[Table]
    links: list[Link]
    score: int
    encodedString: str
    actualMappedField: str
    actualMappedTable: str

    @classmethod
    def from_table_list(
        cls,
        table_list: list[TargetTableSchemaExt],
        relationships: list[Relationship],
        score: int,
        target_field_name: str,
    ):
        actual_mapped_field, actual_mapped_table = cls.find_actually_mapped_table_and_field(
            table_list, relationships, target_field_name
        )
        return cls(
            tables=[Table.from_schema(table) for table in table_list],
            links=cls.create_links(relationships),
            score=score,
            encodedString=cls._gen_encoded_string(table_list, relationships),
            actualMappedField=actual_mapped_field,
            actualMappedTable=actual_mapped_table,
        )

    @classmethod
    def find_actually_mapped_table_and_field(
        cls, table_list: list[TargetTableSchemaExt], relationships, target_field_name
    ) -> Tuple[str, str]:
        actual_mapped_field = None
        actual_mapped_table = None
        if table_list[-1].is_ref_table:
            if len(table_list) < 2:
                raise ValueError("A path with a reference table should have at least 2 tables.")
            for rs in relationships:
                if rs.relation.from_entity == table_list[-2].id and rs.relation.to_entity == table_list[-1].id:
                    for fk in rs.relation.foreign_keys:
                        if fk.to_attribute == target_field_name:
                            actual_mapped_field = fk.from_attribute
                            actual_mapped_table = rs.relation.from_entity
                            break
                    if actual_mapped_field is not None:
                        break
            else:
                raise ValueError("Could not find a relationship between the last 2 tables.")
        else:
            if len(table_list) == 1:
                actual_mapped_field = target_field_name
                actual_mapped_table = table_list[0].id
            else:
                for column in table_list[-1].columns:
                    if column.name == target_field_name:
                        actual_mapped_field = target_field_name
                        actual_mapped_table = table_list[-1].id
                        break
                else:
                    raise ValueError("Could not find a relationship between the last 2 tables.")
        if actual_mapped_field is None:
            raise ValueError("Could not compute actual mapped field")
        if actual_mapped_table is None:
            raise ValueError("Could not compute actual mapped table")
        return actual_mapped_field, actual_mapped_table

    @classmethod
    def create_links(cls, relationships: list[Relationship]) -> list[Link]:
        links = []
        for rs in relationships:
            for fk in rs.relation.foreign_keys:
                links.append(Link.from_foreign_key(rs.relation, fk))
        return links

    @classmethod
    def _gen_encoded_string(cls, table_list: list[TargetTableSchemaExt], relationships: list[Relationship]) -> str:
        """generates a string that represents the path in a human readable way
        for exmaple table1<-table2->table3
        """
        if not relationships:
            return ""

        relationships = cls._sort_relationships_for_encoding(table_list, relationships)
        anchor_id = table_list[0].id
        if relationships[0].origin.id == anchor_id:
            result = f"{anchor_id}->{relationships[0].destination.id}"
        else:
            result = f"{anchor_id}<-{relationships[0].origin.id}"
        for rs in relationships[1:]:
            last_table = re.split(r"->|<-", result)[-1]
            if rs.origin.id == last_table:
                result += f"->{rs.destination.id}"
            elif rs.destination.id == last_table:
                result += f"<-{rs.origin.id}"
            else:
                raise ValueError("table not found in relationships")
        return result

    @classmethod
    def _sort_relationships_for_encoding(
        cls, table_list: list[TargetTableSchemaExt], relationships: list[Relationship]
    ) -> list[Relationship]:
        """sorts the relationships in a way that the anchor is the first table"""
        sorted_relationships: list[Relationship] = []
        for i in range(len(table_list) - 1):
            for rs in relationships:
                if (
                    rs.origin.id == table_list[i].id
                    and rs.destination.id == table_list[i + 1].id
                    or rs.origin.id == table_list[i + 1].id
                    and rs.destination.id == table_list[i].id
                ):
                    sorted_relationships.append(rs)
                    break # found the relationship (there might be more than one, but we only need one)
        if len(sorted_relationships) != len(table_list) - 1:
            raise ValueError("not all relationships found")
        return sorted_relationships


class Source(BaseModel):
    name: str
    field: str


class Target(BaseModel):
    name: str
    field: str
    type: str
    description: str
    fields: list[TableField]

    @classmethod
    def from_schema(cls, table: TargetTableSchemaExt, target_field_name: str):
        return cls(
            name=table.id,
            field=target_field_name,
            type=_table_type(table),
            description=table.description,
            fields=[TableField.from_column(column) for column in table.columns],
        )


@dataclass
class SinglePath:
    tables: list[TargetTableSchemaExt]
    links: list[Relationship]
    score: int


class AnchorResult(BaseModel):
    anchorName: str
    paths: list[Path]

    @classmethod
    def from_single_path(cls, anchor_id: str, paths: list[SinglePath], target_field_name: str):
        return cls(
            anchorName=anchor_id,
            paths=[
                Path.from_table_list(
                    table_list=p.tables, relationships=p.links, target_field_name=target_field_name, score=p.score
                )
                for p in paths
            ],
        )


class Response(BaseModel):
    source: Source
    results: list[AnchorResult]
    target: Target

    @classmethod
    def from_raw_reuslt(cls, raw_result: ProposedPathsResponse):
        first_target = raw_result.tables[0][-1]
        if not all([path[-1] == first_target for path in raw_result.tables]):
            raise ValueError("All paths should have the same target")

        paths_by_anchor: dict[str, list[SinglePath]] = defaultdict(list)
        for tables, links, path_score in zip(raw_result.tables, raw_result.links, raw_result.paths_scores):
            paths_by_anchor[tables[0].id].append(SinglePath(tables, links, path_score))
        paths_by_anchor = dict(paths_by_anchor)
        for paths in paths_by_anchor.values():
            paths.sort(key=lambda x: x.score)

        return cls(
            source=Source(name=raw_result.source_table_name, field=raw_result.source_field_name),
            results=[
                AnchorResult.from_single_path(achor_id, paths, raw_result.target_field_name)
                for achor_id, paths in paths_by_anchor.items()
            ],
            target=Target.from_schema(first_target, raw_result.target_field_name),
        )


def _table_type(table: TargetTableSchema) -> str:
    if table.is_ref_table:
        return "reference"
    elif table.is_duration_table:
        return "duration"
    else:
        return "regular"

# SIG # Begin Windows Authenticode signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCvCZU3qcZIV1nT
# EBM941/omM7nsU07D3K/lcVpsJxd9aCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPE15m9tVXNYT3NAI9tf9jQT
# 23HYo2MzdcH00vDIQZr6MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAhtXSrKp0INZ1Uc1GwI+iNmYhok+1mYfP/S/zIv7m+oE3haGm/kbT2UtD
# oR7pHPa1Ed371zkR6CFOPWijOAXMDAAdYGv70knDnEkCpwwWcnXtW5pa+EVXktRL
# pkXUb3KIMfKbKhxo96KM248oUEc6K0FCneTGceGTtfrPenc6nIH/8HPj15/DpbON
# xmvLzm1Xwm7cSvU0Sn/9ytu70iaF5pxXnpv3XNRzSdA5H1YiJ0XWeFK7JrFlBmf6
# 7HRv/nOAIZX0DfysoccBi99OYGK+CYbzcoeoqlXOelusb0GHxGBoD2iDym8ZDmz1
# YPFNABvG3JjIPZ6nLd28SrjscAqTFKGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBym/nQy6GSLmNPT6Rq9sBCoVZs2Cv5Vw/2ptKWDAovQwIGZXsGpqzm
# GBMyMDI0MDExMTEyMjE1OC45NjZaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046REMwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAdIhJDFKWL8tEQABAAAB0jANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzA1MjUxOTEy
# MjFaFw0yNDAyMDExOTEyMjFaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046REMwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDcYIhC0QI/SPaT5+nYSBsSdhBPO2SXM40Vyyg8Fq1T
# PrMNDzxChxWUD7fbKwYGSsONgtjjVed5HSh5il75jNacb6TrZwuX+Q2++f2/8CCy
# u8TY0rxEInD3Tj52bWz5QRWVQejfdCA/n6ZzinhcZZ7+VelWgTfYC7rDrhX3TBX8
# 9elqXmISOVIWeXiRK8h9hH6SXgjhQGGQbf2bSM7uGkKzJ/pZ2LvlTzq+mOW9iP2j
# cYEA4bpPeurpglLVUSnGGQLmjQp7Sdy1wE52WjPKdLnBF6JbmSREM/Dj9Z7okxRN
# UjYSdgyvZ1LWSilhV/wegYXVQ6P9MKjRnE8CI5KMHmq7EsHhIBK0B99dFQydL1vd
# uC7eWEjzz55Z/DyH6Hl2SPOf5KZ4lHf6MUwtgaf+MeZxkW0ixh/vL1mX8VsJTHa8
# AH+0l/9dnWzFMFFJFG7g95nHJ6MmYPrfmoeKORoyEQRsSus2qCrpMjg/P3Z9WJAt
# FGoXYMD19NrzG4UFPpVbl3N1XvG4/uldo1+anBpDYhxQU7k1gfHn6QxdUU0TsrJ/
# JCvLffS89b4VXlIaxnVF6QZh+J7xLUNGtEmj6dwPzoCfL7zqDZJvmsvYNk1lcbyV
# xMIgDFPoA2fZPXHF7dxahM2ZG7AAt3vZEiMtC6E/ciLRcIwzlJrBiHEenIPvxW15
# qwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFCC2n7cnR3ToP/kbEZ2XJFFmZ1kkMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQCw5iq0Ey0LlAdz2PcqchRwW5d+fitNISCv
# qD0E6W/AyiTk+TM3WhYTaxQ2pP6Or4qOV+Du7/L+k18gYr1phshxVMVnXNcdjecM
# tTWUOVAwbJoeWHaAgknNIMzXK3+zguG5TVcLEh/CVMy1J7KPE8Q0Cz56NgWzd9ur
# G+shSDKkKdhOYPXF970Mr1GCFFpe1oXjEy6aS+Heavp2wmy65mbu0AcUOPEn+hYq
# ijgLXSPqvuFmOOo5UnSV66Dv5FdkqK7q5DReox9RPEZcHUa+2BUKPjp+dQ3D4c9I
# H8727KjMD8OXZomD9A8Mr/fcDn5FI7lfZc8ghYc7spYKTO/0Z9YRRamhVWxxrIsB
# N5LrWh+18soXJ++EeSjzSYdgGWYPg16hL/7Aydx4Kz/WBTUmbGiiVUcE/I0aQU2U
# /0NzUiIFIW80SvxeDWn6I+hyVg/sdFSALP5JT7wAe8zTvsrI2hMpEVLdStFAMqan
# FYqtwZU5FoAsoPZ7h1ElWmKLZkXk8ePuALztNY1yseO0TwdueIGcIwItrlBYg1Xp
# Pz1+pMhGMVble6KHunaKo5K/ldOM0mQQT4Vjg6ZbzRIVRoDcArQ5//0875jOUvJt
# Yyc7Hl04jcmvjEIXC3HjkUYvgHEWL0QF/4f7vLAchaEZ839/3GYOdqH5VVnZrUIB
# QB6DTaUILDCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkRDMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCJ
# ptLCZsE06NtmHQzB5F1TroFSBqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6UnFuTAiGA8yMDI0MDExMTAxNDEx
# M1oYDzIwMjQwMTEyMDE0MTEzWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDpScW5
# AgEAMAoCAQACAiOtAgH/MAcCAQACAhN1MAoCBQDpSxc5AgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBABZf+tJ+PbXKLeMQDAzM7FaUWkeWZpNGyC4B81H0Xdb/
# rKOgKmtYrZuqSW4jsBYY3mbIZruRqfMZz2JA4epgndMhMaiKzN+O7mJ5SQxdJ0gi
# bLloB7I566dqBcndd/JMXzDmInhEWtH3N8rJtj6H20ku6Ysy788wp7sQvd8Rz0r9
# mvVY9X1IC8eLuhJMLPjlHey1AWpP+MORsdeZ/Yi8XYV5x1v65B7dgyp4VST1D3df
# x69ABKd92TvuUwX/hV1CW7PdlJzZNUBL3lAuszUnMmQP5EQWokvRkwQeYqwYxvAb
# ipqakQZ3ujJrfkH9wB0cdmWnMOdXXS2hi5DsMeMVY2oxggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAdIhJDFKWL8tEQABAAAB
# 0jANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCAl4z6Sy7lygoDaZo6ejSk2tysbRRFOqnS5zlYug9LU
# lzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIMeAIJPf30i9ZbOExU557GwW
# NaLH0Z5s65JFga2DeaROMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAHSISQxSli/LREAAQAAAdIwIgQg/J8Kyr+Nnhf9B1LzDrU2UmrV
# PVoK2gk5DeDxeAMOkOkwDQYJKoZIhvcNAQELBQAEggIAzEXz6YRMNJxpKk5QPP7d
# HQiE/ZLKicwbRRxWr1v5ct9M51JAUeSYNcrxy5cui67RDEvy9F1+OFpJg9SMXJpu
# 2V8EEoFaFotrvdwPc4syagXVhYQHplcTsbgPGbnnC7Ud5WzfsYtskY9T+lcDBLOj
# GGkmQ+a8SN+sRmcQvEl7I9KP3uf2ydkBxGQwjggDSew3xdOCWJdGnZC4vAa81WUN
# C3alDnYcH3w5IgVuGviOO7Q4Jrf20SiBbAqJ6ce6E8ISctiVAHOn55vlZBGSpRPJ
# 9oznX0+e0Q4rbqlX1txpWruj+jN97N2zYoBLvgx5h+0Li6muU4NprTXZZgCZ75vn
# 7NjRZKEKnMsvAeFDcmnG1idzdb/ABePdngftDfD6/bli1CsJNbuE4uT4ONLE8+VF
# AwFMssUyj7UsupMdg6vwOIh5Mj+9myXYbI8ZFwbOeBzQUig2s3IDl/F+cN5p/Yro
# cmHzpoZ07jFHanA9fmY/pRZf7xKS/I+UhOtTWHJY7GRloTWaQiLugmMhjccYFSsq
# 3ziJvJuOz1NZgAC+Bm88f4Ri1TjbHqlIuNGauRTsJAdwuToZ6gWlK9rac56nbRNz
# qMMmIXb7pzjvJh9Kv4C0KZUrzHkvBDLNydlKrmT8WZWBOsErkY9zsHtmXz4LYzkj
# m3I01GrM3r9mTlNoznRgnWU=
# SIG # End Windows Authenticode signature block