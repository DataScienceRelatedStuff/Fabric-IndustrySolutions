import abc

class ABCSparkLogger(abc.ABC):
    """
    Abstract base class for Spark Logging
    """
    @abc.abstractmethod
    def info(self, message: str):
        pass

    @abc.abstractmethod
    def error(self, message: str):
        pass

    @abc.abstractmethod
    def debug(self, message: str):
        pass

    @abc.abstractmethod
    def warning(self, message: str):
        pass

    @abc.abstractmethod
    def critical(self, message: str):
        pass
