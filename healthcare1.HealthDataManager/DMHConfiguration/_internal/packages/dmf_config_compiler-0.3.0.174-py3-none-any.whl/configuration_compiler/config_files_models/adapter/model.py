import re
from enum import Enum
from typing import Any, Optional, Union

from configuration_compiler.config_files_models.models_base import FieldTypeEnum, NoExtrasBaseModel
from pydantic import Field, field_validator
from pydantic.functional_validators import model_validator


class DataFormatEnum(str, Enum):
    parquet = "parquet"
    delta = "delta"
    csv = "csv"


class DeleteBehaviorEnum(str, Enum):
    hard = "hard"
    soft = "soft"
    de_id = "de-id"


class Storage(NoExtrasBaseModel):
    dataFormat: DataFormatEnum = Field(..., description="The format of data in storage, e.g., delta.")
    connectionStringUri: str = Field(
        ...,
        description="The path to the root folder of the data in storage, or a path to a file describing for each table a different path.",
    )
    lakeDBName: Optional[str] = Field(
        None,
        description="The name of the database in the lake. "
        "If Fabric Lakehouse is used as a source, the lakeDBName will be used as the source database name, e.g., a Fabric Lakehouse name.",
    )


class FieldReplacementKey(NoExtrasBaseModel):
    field: str = Field(..., description="The internal field that is used as PK, e.g., contactid.")
    keyField: str = Field(
        ...,
        description="The external field that is used as keyring between multiple data sources, e.g., integrationKey.",
    )


class QueryTable(NoExtrasBaseModel):
    name: str = Field(..., description="A table name that is used in a source query, e.g., in a join.")
    alias: Optional[str] = Field(None, description="An alias to be used in the source query for that table.")


class TargetAnchorTable(NoExtrasBaseModel):
    tableName: str = Field(..., description="A target table which the source writes to its single PK field.")


class IntermediateTable(NoExtrasBaseModel):
    intermediateTable: str = Field(
        ...,
        description="Table that is used by DMF to create a relationship graph between anchor table and a target table.",
    )


class TargetTable(NoExtrasBaseModel):
    targetTable: str = Field(..., description="An anchor table.")
    intermediateTables: list[IntermediateTable] = Field(
        ...,
        description="Collection of tables in the graph between an anchor table and the last table in the collection.",
    )


class TargetField(NoExtrasBaseModel):
    enabled: Optional[bool] = Field(
        True,
        description="A flag to indicate if the target field should be processed by DMF and validated in the DTT VS Extension.",
    )
    tableName: str = Field(
        ...,
        description="The table DMF uses to decide what table(s) to write to. "
        "\nIf the source field is a FK, The tableName should NOT be the real target table, "
        "but either a reference table or a regular table that the FK relates to. "
        "\nThen, the fieldName should be the PK field of that table. "
        "\nDMF will find the actual tables and fields to write to, "
        "by searching for valid table paths from anchor tables to tableName, "
        "e.g., 'contact.maritalstatusstate' target should be 'MaritalStatus.MaritalStatusId'. "
        "\nIn all other cases, the target table should be the real target table.",
    )
    fieldName: str = Field(..., description="The name the field in the target table.")
    condition: Optional[str] = Field(
        None,
        description="The target field will be processed if the condition, a Spark SQL scalar expression evaluates to true.",
    )
    fieldValue: Optional[Union[str, float, int, bool]] = Field(
        None,
        description="When specified, the Spark SQL expression will be evaluated and used instead of the source field value.",
    )
    targetField: Optional[str] = Field(
        None,
        description="When the source field is a FK and the tableName specified is a FK related table (e.g. Customer), "
        "\nnthen, DMF resolves the actual tables and fields to write to, "
        "it may find ambguities that require additional information from the author, e.g., "
        "a RelatedCustomer table has two FK to Customer (from, to). "
        "In this case, the author should specify the target field name in the target table, e.g., 'FromCustomerId'.",
    )
    paths: Optional[list[str]] = Field(
        None,
        description="In the rare cases in which DMF cannot decipher a non ambiguous graph path, the adapter should provide the correct path.",
    )
    _paths_split_pattern = re.compile(r"<-|->")

    description: Optional[str] = Field(None, description="A description of the target field.")
    # TODO: remove? isLookup is currently not used
    isLookup: Optional[bool] = Field(False, description="A flag to indicate that the target field is a lookup field")

    @field_validator("paths", mode="before")
    @classmethod
    def split(cls, s):
        if s is None:
            return None
        if not re.search(cls._paths_split_pattern, s):
            raise ValueError(f"paths {s} should contain at least one '<-' or '->' arrow")
        return re.split(cls._paths_split_pattern, s)

    @field_validator("paths", mode="after")
    @classmethod
    def path_len_is_more_than_1(cls, paths):
        if paths is None:
            return None
        for path in paths:
            if len(path) < 2:
                raise ValueError("paths should have more than one table")
        return paths

    @model_validator(mode="after")
    def field_value_and_condition_mutually_exclusive(self) -> "TargetField":
        if not self.enabled:
            return self
        condition = self.condition
        fieldValue = self.fieldValue
        if condition and fieldValue:
            raise ValueError(
                f"Cannot define both 'fieldValue' and 'condition' properties for a target field:'{self.fieldName}' in table '{self.tableName}' in the adpater file. fieldValue='{fieldValue}', condition='{condition}'"
            )
        return self


class UniqueKeyItem(NoExtrasBaseModel):
    fieldName: str = Field(
        ...,
        description="A target field name that is part of the uniquely collection of target fields.",
    )


class TargetFields(NoExtrasBaseModel):
    fields: list[TargetField] = Field(
        None, description="A collection of target fields which may be in multiple tables."
    )
    uniqueKey: Optional[list[UniqueKeyItem]] = Field(
        None,
        description="A collection of some target fields that defines the uniqueness of record to be written, e.g., create "
        "history records for each email type (work/home).",
    )


class SourceField(NoExtrasBaseModel):
    fieldName: str = Field(
        ...,
        description="A source field name or a calculation name. A Calculation name should not be an existing field name.",
    )
    fieldType: FieldTypeEnum = Field(..., description="The source field type.")
    enabled: Optional[bool] = Field(
        True,
        description="Defines whether DMF should process the field or skip it. \nAlso, whether the DTT VS Extension should validate the field.",
    )
    targetFields: TargetFields = Field(
        ...,
        description="The Fields the data is written to. A source field may write to multiple target fields in different tables.",
    )
    isPrimaryKey: bool = Field(False, description="Set this property to make the source field part of the fields collection that makes a record unique in the source system.\n"
                               "At least one field in the source table must to be defined as such, e.g., contactid\n"
                               "DMF groups records in the bronze lake by these fields, ordered by modifiedon field, and processes the last record in each group\n"
                               "i.e., the last record in the group for each day")
    fieldCalculatedValue: Optional[str] = Field(None, description="A spark SQL scalar expression.")
    description: Optional[str] = Field(None, description="A description of the source field.")
    enforceKeyHarmonization: Optional[bool] = Field(
        False,
        description="Set the property to true when:\n"
        "\t1. bypassHarmonization property on the parent table is set to True\n"
        "\t2. There is a  need for DMF to override the table definition and harmonize "
        "the current field, e.g., a field was introduced in a query (based on the "
        "parent table) so it should not be bypassed",
    )


class SourceTable(NoExtrasBaseModel):
    """Source table to map into target"""

    description: Optional[str] = Field(None, description="A description of the source table.")
    tableName: str = Field(
        ...,
        description="The name of the source table. If query is defined, "
        "the name provides additional semantics and cannot be the same as an existing table.",
    )
    query: Optional[str] = Field(
        None,
        description="Spark SQL query to use as a source, .e.g., performing join with between two or more tables. The result fields "
        "can be mapped to target tables and fields..",
    )
    modifiedonField: str = Field(
        ...,
        description="The field used to identify data updates when performing incremental updates.",
    )
    stateField: Optional[str] = Field(
        None,
        description="The field used to identify state changes, e.g., customer becomes inactive/active.",
    )
    deletedField: Optional[str] = Field(
        None,
        description="The field used to identify that record was deleted in the source system.",
    )
    deleteBehavior: Optional[DeleteBehaviorEnum] = Field(
        None,
        description="Delete behavior defines whether to hard delete these records\\tag them as deleted\\tag as deleted "
        "and de-id target fields.",
    )
    targetAnchorTables: list[TargetAnchorTable] = Field(
        ...,
        description="Target Tables to be used as anchors. A source table can have multiple target anchor tables, "
        "e.g., contact->Customer, Location. "
        "\nDMF will resolve all valid tables paths from anchor tables to all target tables "
        "and write to intermeidate tables as needed.",
    )
    fieldReplacementKeys: list[FieldReplacementKey] = Field(
        [],
        description="Field pairs that define strong relationship between two field, .e.g contactId and intergrationKey "
        "defined respectively, specify that the same mapping value (number) created for the integrationKey (string) will be "
        "used also for contactId.",
    )
    enabled: Optional[bool] = Field(
        True,
        description="Defines whether DMF will process all fields in this table or skip them. "
        "\nAlso, whether the DTT VS Extension should validate the table and its source fields.",
    )
    sourceFields: list[SourceField] = Field(..., description="Collection of source fields to be processed.")
    bypassKeysHarmonization: Optional[bool] = Field(
        False,
        description="When set to True, DMF will use, as is, values that are mapped "
        "to PK/FKs in target tables (with no harmonization).\nApplies to both target "
        "standard tables and reference tables",
    )

    @model_validator(mode="after")
    def paths_mis_definition(self) -> "SourceTable":
        if not self.enabled:
            return self
        paths_by_target_table = {}
        for source_field in self.sourceFields:
            if not source_field.enabled:
                continue
            for target_field in source_field.targetFields.fields:
                if not target_field.enabled:
                    continue
                paths = target_field.paths
                if paths:
                    if target_field.tableName in paths_by_target_table:
                        raise ValueError(
                            f"paths are defined for target table {target_field.tableName} more than once in source table {self.tableName}"
                        )
                    paths_by_target_table[target_field.tableName] = paths

        return self

    @model_validator(mode="after")
    def validate_paths_have_valid_tables(self) -> "SourceTable":
        if not self.enabled:
            return self
        anchors = [anchor.tableName for anchor in self.targetAnchorTables]
        for source_field in self.sourceFields:
            if not source_field.enabled:
                continue
            for target_field in source_field.targetFields.fields:
                if not target_field.enabled:
                    continue
                paths = target_field.paths
                if paths:
                    paths_anchors = []
                    for path in paths:
                        anchor_table, target_table = path[0], path[-1]
                        if anchor_table not in anchors:
                            raise ValueError(
                                f"first table {anchor_table} in path {path} is not defined as a target anchor table in source table {self.tableName}"
                            )
                        if target_table != target_field.tableName:
                            raise ValueError(
                                f"last table {target_table} in path {path} is not the same as the target table {target_field.tableName} in source table {self.tableName}"
                            )
                        paths_anchors.append(anchor_table)

                    if len(paths_anchors) != len(set(paths_anchors)):
                        raise ValueError(
                            f"paths {paths} in source table {self.tableName} should have only one path for every anchor table"
                        )
        return self


def json_schema_extra(schema: dict[str, Any], model) -> None:
    for prop in schema.get("properties", {}).values():
        prop.pop("title", None)


class RawAdapterModel(NoExtrasBaseModel, json_schema_extra=json_schema_extra):
    name: str = Field(..., description="Name of the adapter")
    description: str = Field("", description="Description of the adapter")
    version: str = Field(..., description="Version of the adapter")
    sourceDomain: str = Field(
        "",
        description="Define one or more source mapping domains to use for reference data mappings, e.g., Healthcare,Shared. "
        "\nWhen DMF resolves a reference value, "
        "it will first filter the reference data mapping table by the sourceDomain entries.",
    )
    source: Optional[Storage] = Field(None, description="Source data storage")
    target: Optional[Storage] = Field(None, description="Target data storage")
    dbSourceSchema: Optional[str] = Field(
        None,
        description="Path or content of the source schema (tables/fields names/types/descriptions).",
    )
    dbTargetSchema: Optional[str] = Field(
        None,
        description="Path or content of the source schema (tables/fields names/types/descriptions, relationships and primary keys...).",
    )
    dbTargetSchemaConfig: Optional[str] = Field(
        None,
        description="Path of the target schema configuration, which states which changes need to be applied to the target schema",
    )
    dbSemantics: Optional[str] = Field(
        None,
        description="Path or content of the target semantics, e.g. what tables are reference/temporal/extensions.",
    )
    dbSemanticsConfig: Optional[str] = Field(None, description="Path of the semantics configuration")
    dmfEnvConfig: Optional[str] = Field(None, description="Path or content of the DMF environment configuration")
    defaultReferenceValue: Optional[Union[int, None]] = Field(
        None,
        description="When reference value is not found during transformation "
        "and 'UponMissingReferenceValues' is false, DMF will use this value instead .",
    )
    failUponMissingReferenceValues: bool = Field(
        False,
        description="If false, DMF will fail during transformation when a reference value is missing in the mapping table. "
        "\nIf true, DMF will use the defaultReferenceValue instead.",
    )
    queryTables: list[QueryTable] = Field(
        [],
        description="Tables used in source tables queries, e.g., when joining two or more tables. Optional, "
        "relevant only if the source is defined as an ADLS storage and not as a Database "
        "Database may be a Fabric Lakehouse.",
    )
    sourceTables: list[SourceTable] = Field(..., description="Tables and fields mappings between source and target.")
    jsonSchema_: str = Field(
        "",
        description="The json schema of the adapter. Used by the DTT VS Extension to validate and autocomplete the adapter properties",
        alias="$schema",
    )

# SIG # Begin Windows Authenticode signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCATu7sx6wfTBlP+
# Ry5LcHXYmidYAHCRcqCf0cqa8RihQKCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEII+28kfMDtGWq/5AuROAIQ8v
# 1zd2ysHUs/oKymMIrJ3CMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEANZSRKkobYIt/KzFoz4ux/AYEEe4n0YOuBB25AEuH7RG5vJz1wdHBhWR0
# WWTl11Sz0k7ulNhPXs567OGT4jCs4ronC8fwo851dac/d3m1FytnF8tmk05i5N1q
# KwOZ/r5bzj48IDBd9dj4QtFl9TU+IS5JYAXUm64+WFe2V7Y5TUSr4oC3lh26G9TO
# klZ8anqEOuKO0/jOthxABxRUPi85f9b278La9+upF5vijXEq2bwLurW7+iiPL3+K
# uBHDldLlsEN7CFZ0FSyF/PyXl6rTQ5V03XrgdeHVceowLceY5eiOEmbFDfNxSIuX
# Wc+2X7y9R5js17NSBGgZTvwnlNIQ1aGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCyLWKjxFG844vM+uM5K/Er1q5+YxPC0iKE6JLHOM2krAIGZXscRTvM
# GBMyMDI0MDExMTEyMjE1OS4zNDlaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAdj8SzOlHdiFFQABAAAB2DANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzA1MjUxOTEy
# NDBaFw0yNDAyMDExOTEyNDBaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDNeOsp0fXgAz7GUF0N+/0EHcQFri6wliTbmQNmFm8D
# i0CeQ8n4bd2td5tbtzTsEk7dY2/nmWY9kqEvavbdYRbNc+Esv8Nfv6MMImH9tCr5
# Kxs254MQ0jmpRucrm3uHW421Cfva0hNQEKN1NS0rad1U/ZOme+V/QeSdWKofCThx
# f/fsTeR41WbqUNAJN/ml3sbOH8aLhXyTHG7sVt/WUSLpT0fLlNXYGRXzavJ1qUOe
# Pzyj86hiKyzQJLTjKr7GpTGFySiIcMW/nyK6NK7Rjfy1ofLdRvvtHIdJvpmPSze3
# CH/PYFU21TqhIhZ1+AS7RlDo18MSDGPHpTCWwo7lgtY1pY6RvPIguF3rbdtvhoyj
# n5mPbs5pgjGO83odBNP7IlKAj4BbHUXeHit3Da2g7A4jicKrLMjo6sGeetJoeKoo
# j5iNTXbDwLKM9HlUdXZSz62ftCZVuK9FBgkAO9MRN2pqBnptBGfllm+21FLk6E3v
# VXMGHB5eOgFfAy84XlIieycQArIDsEm92KHIFOGOgZlWxe69leXvMHjYJlpo2VVM
# tLwXLd3tjS/173ouGMRaiLInLm4oIgqDtjUIqvwYQUh3RN6wwdF75nOmrpr8wRw1
# n/BKWQ5mhQxaMBqqvkbuu1sLeSMPv2PMZIddXPbiOvAxadqPkBcMPUBmrySYoLTx
# wwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFPbTj0x8PZBLYn0MZBI6nGh5qIlWMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQCunA6aSP48oJ1VD+SMF1/7SFiTGD6zyLC3
# Ju9HtLjqYYq1FJWUx10I5XqU0alcXTUFUoUIUPSvfeX/dX0MgofUG+cOXdokaHHS
# lo6PZIDXnUClpkRix9xCN37yFBpcwGLzEZlDKJb2gDq/FBGC8snTlBSEOBjV0eE8
# ICVUkOJzIAttExaeQWJ5SerUr63nq6X7PmQvk1OLFl3FJoW4+5zKqriY/PKGssOa
# A5ZjBZEyU+o7+P3icL/wZ0G3ymlT+Ea4h9f3q5aVdGVBdshYa/SehGmnUvGMA8j5
# Ct24inx+bVOuF/E/2LjIp+mEary5mOTrANVKLym2kW3eQxF/I9cj87xndiYH55Xf
# rWMk9bsRToxOpRb9EpbCB5cSyKNvxQ8D00qd2TndVEJFpgyBHQJS/XEK5poeJZ5q
# gmCFAj4VUPB/dPXHdTm1QXJI3cO7DRyPUZAYMwQ3KhPlM2hP2OfBJIr/VsDsh3sz
# LL2ZJuerjshhxYGVboMud9aNoRjlz1Mcn4iEota4tam24FxDyHrqFm6EUQu/pDYE
# DquuvQFGb5glIck4rKqBnRlrRoiRj0qdhO3nootVg/1SP0zTLC1RrxjuTEVe3PKr
# ETbtvcODoGh912Xrtf4wbMwpra8jYszzr3pf0905zzL8b8n8kuMBChBYfFds916K
# Tjc4TGNU9TCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjk2MDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBI
# p++xUJ+f85VrnbzdkRMSpBmvL6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA6UnaMzAiGA8yMDI0MDExMTAzMDgz
# NVoYDzIwMjQwMTEyMDMwODM1WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDpSdoz
# AgEAMAoCAQACAgoaAgH/MAcCAQACAhOaMAoCBQDpSyuzAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBAAOxpR5w2dlQ03TRpZN8DJX+1Fs5SYgkej95jDHyR/Ep
# Zr9p7jtF/c1ePGQyN0bfh//+3fWk3bpmiz7+47o+l9t70jXBb75ODB+VRjTaFE4k
# X7VUejFUKSVHKUtiDyKokLUCAYMOxYMV1szOmpfuDtZ5iK4iQj/c62Sg64FOdJny
# 37eLvN6h0qJhyma/SY0ogntDz4i7BLOdxeQAL5I0r8FhjZqOs19F76hcvZNVOIE5
# rUZRLLg/J1FZV8zUR/AzkdAkbIukfrt8jF6iBG9X8NRTCxvLrZ3QRCcaWdqBXgtp
# ke0/wR58KUF+TRCLvV3LmOSMa4AMwRj3WJgPGHwjProxggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAdj8SzOlHdiFFQABAAAB
# 2DANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCCcMhl+PHCRNT015Kf2NA9lEwpqFqwJWhvPPLr2jfW8
# /DCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIDrjIX/8CZN3RTABMNt5u73M
# i3o3fmvq2j8Sik+2s75UMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAHY/EszpR3YhRUAAQAAAdgwIgQg/XrmD430BbyCrSMXPgfcG9gf
# SqY3jPTouqajUGFqc3QwDQYJKoZIhvcNAQELBQAEggIAmOljHSQcPLBybEU0lqka
# qbLdgmfsI9R+DfmBJVBDvBgyJrGgOxRd7gJ9svjAYqjADkcVwV6Sj2tXS06PQEN+
# tZeGD7xmYaRdBb2ABhgqG5PcGyfSm8hhoipe1y2JQaqwBOsU6AzQ4wqodDTbUoXc
# r7q8eZBi+StQ0NAGDNTY3CwcT+iX2NAZpVtYdFnN+9CceSzvb0w+gNsHTydTsi5I
# 4qUGS0i1+3wvTBZznu235RnwxMSFxTYRgMCQmoeG8/LvijxpaJwBitfBVXgUR/J6
# eW22Q7AWPbAXEwyOSVprbOqHNSzn+OCNT2KJQe2x0yaHdlnbxAAMCMQyQzqN70c7
# RWD6b20PHYxi0Pz05gaoeSnxOI7akj6qNRHfFdUwmO3eLC14LE1RIx+pNsTDy295
# g9nrt7WuE/irS9tdZ0pAHj7dXj5pn02oX8qIlCYRP/fxx2rmjTo9mfHdYL9HsZ2G
# hYfxuconDW48Jj/ET+r8OClKeZy59mSd+QaOS6qiZHzDqaE5w6YZxdUGVD3/uDNl
# sa6F3zYvAeQyPFwfKu6os7MIEmp+t8TnlHUllyVim3U3sGAcp/v563aph0gG29TL
# mETN1H/22CgZ1vqTkuw6F+NVbn7gGldBeLZBEJ6wD/6yK2ojf2ZKrjfxkjlswWvB
# J8110lSYsC8u9ZR/l5ZXtUs=
# SIG # End Windows Authenticode signature block