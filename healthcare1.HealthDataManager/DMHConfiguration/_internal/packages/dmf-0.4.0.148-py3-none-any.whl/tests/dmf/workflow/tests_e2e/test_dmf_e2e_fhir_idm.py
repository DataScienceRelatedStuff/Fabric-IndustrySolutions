from pathlib import Path
from typing import Tuple, Union

import pytest
from pyspark.sql import DataFrame, SparkSession, Column
from pyspark.sql import functions as F

from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.model.data_feed_configuration import DataFeedConfiguration
from dmf.model.source_configuration import SourceConfiguration
from dmf.transformations.reader.query_reader import QueryReader
from dmf.transformations.reader.storage_reader import StorageReader
from dmf.transformations.reader.table_reader import TableReader
from dmf.utils.dataframe_utils import DataFrameUtils
from project_root import PROJECT_ROOT_DIR
from tests.conftest import clean_db_sink_tables_root
from tests.utils.constants import Constants
from tests.utils.dmf_application_test_util import DMFApplicationTestUtil

src_data_location = Path(PROJECT_ROOT_DIR, "tests", "data", "db", "fhir", "parquet")

@pytest.fixture(scope="function", autouse=True)
def clean_db_files_fixture():
    clean_db_sink_tables_root()


class TestE2EHcFhirAdrmGeneratedConf:


    def reduced_contract_path(self, test_name: str) -> Path:
        return Constants.GENERATED_TRANSFORMATION_SPECS_ROOT / test_name / "ts.json"

    def _get_source_config(self, config: DataFeedConfiguration, source_id: str) -> SourceConfiguration:
        for sc in config.source_configurations:
            if sc.source_id == source_id:
                return sc
        raise ValueError(f"source_id {source_id} not found in config")

    def _get_source_data_source_id(self, config: DataFeedConfiguration, source_id: str) -> Tuple[DataSourceTypeEnum, str]:
        data_access_definition = self._get_source_config(config, source_id).data_access_definition
        return data_access_definition.data_source_type, data_access_definition.data_source_id

    def _read_target_table(self, spark, table_name):
        df = StorageReader(str(Constants.SINK_TABLES_ROOT / table_name), "delta").read(spark)
        assert df is not None
        return df

    def _read_mapping_table(self, spark, table_name: str) -> DataFrame:
        table_path = Path(spark.conf.get("spark.sql.warehouse.dir")) / GlobalConstants.ID_MAPPING_PATH / table_name
        mapping_table_df = StorageReader(str(table_path), "delta").read(spark)
        assert mapping_table_df is not None, f"Mapping table {table_name} not found"
        return mapping_table_df

    def _assert_column_data_transformed(self,
                                        spark: SparkSession,
                                        source_df: DataFrame,
                                        source_id_column_expr: Union[Column, str],
                                        source_column_expr: str,
                                        target_df: DataFrame,
                                        target_id_column_name: str,
                                        target_column_expr: str,
                                        mapping_table_name: str,
                                        fk: bool = False):

        if isinstance(source_id_column_expr, str):
            source_id_column_expr = F.expr(source_id_column_expr)
        if isinstance(source_column_expr, str):
            source_column_expr = F.expr(source_column_expr)
        if isinstance(target_column_expr, str):
            target_column_expr = F.expr(target_column_expr)
        mapping_df = self._read_mapping_table(spark, mapping_table_name)
        source_df = source_df.withColumn("JOIN_COLUMN", source_id_column_expr)
        joined_with_mapping_df = source_df \
            .join(mapping_df, source_df["JOIN_COLUMN"] == mapping_df.INTERNAL_ID, 'left')
        how_to_join = "inner" if fk else "left"
        data_df = joined_with_mapping_df \
            .join(target_df, joined_with_mapping_df.ADRM_ID == target_df[target_id_column_name], how_to_join) \
            .select([source_column_expr.alias("SOURCE_COLUMN_EXPR"),
                     target_column_expr.alias("TARGET_COLUMN_EXPR")])

        bool_column_name = "ASSERTION_RESULT"
        bool_df = data_df.select(
            F.col("SOURCE_COLUMN_EXPR")
            .eqNullSafe(F.col("TARGET_COLUMN_EXPR"))
            .alias(bool_column_name)
        )

        # False is considered "smaller" than True in a boolean context
        all_true = bool_df.agg(F.min(bool_df[bool_column_name])).first()[0]
        assert all_true, f"Data in {source_column_expr} column is not transformed correctly to {target_column_expr} column"

    def assert_fk_transformed(self,
                              spark: SparkSession,
                              source_df: DataFrame,
                              source_id_column_expr: str,
                              target_df: DataFrame,
                              target_id_column_name: str,
                              mapping_table_name: str):

        mapping_df = self._read_mapping_table(spark, mapping_table_name)
        source_df = source_df.withColumn("JOIN_COLUMN", F.expr(source_id_column_expr))
        mapped_fks_df = source_df \
            .join(mapping_df, source_df["JOIN_COLUMN"] == mapping_df.INTERNAL_ID, 'left') \
            .select("ADRM_ID")
        missing_fks = mapped_fks_df.join(target_df, mapped_fks_df.ADRM_ID ==
                                         target_df[target_id_column_name], 'left_anti')
        assert DataFrameUtils.is_empty(
            missing_fks), f"FKs in {source_id_column_expr} column are not transformed correctly to {target_id_column_name} column"

    @pytest.mark.long
    def test_all_hands_fhir_idm(self,
                                spark,
                                fhir_idm_config,
                                ):



        DMFApplicationTestUtil.start_dmf(fhir_idm_config, spark)
        patient_df = spark.read.format("delta").load(str(Constants.SINK_TABLES_ROOT/"Patient"))
        location_df = spark.read.format("delta").load(str(Constants.SINK_TABLES_ROOT/"Location"))
        patient_location_df = spark.read.format("delta").load(str(Constants.SINK_TABLES_ROOT/"PatientLocation"))
        source_patient_df = spark.read.format("delta").load(str(src_data_location/"Patient"))
        source_patient_adderss_df = spark.read.format("delta").load(str(src_data_location/"PatientAddress"))
        source_patient_df.createOrReplaceTempView("Patient")
        source_patient_adderss_df.createOrReplaceTempView("PatientAddress")
        # join: patient<-patient_location->location
        # see that there are same amount of people as in source
        target = patient_df.join(patient_location_df, "PatientId",  how="left")
        target = target.join(location_df, "LocationId", how="left")
        distinct_patients_source = source_patient_df.select("id").distinct().count()
        distinct_locations_source = source_patient_adderss_df.select("id").distinct().count()
        distinct_locations_target = target.select("LocationId").distinct().count()
        distinct_patients_target = target.select("PatientId").distinct().count()
        assert distinct_patients_source == distinct_patients_target
        assert distinct_locations_source == distinct_locations_target
