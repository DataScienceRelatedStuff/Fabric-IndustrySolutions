# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from typing import Dict
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.structured_stream.file_stream_reader import FileStreamReader
from microsoft.fabric.hls.hds.structured_stream.stream_orchestrator import StreamOrchestrator
from microsoft.fabric.hls.hds.utils.dataframe_utils import append_to_delta_table_using_path
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import Utils
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter

telemetry_reporter = TelemetryReporter()

# Report VocabularyIngestionService module import
telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
                                activity_name=GlobalConstants.OMOP_VOCAB_INGESTION_ACTIVITY_NAME)

class VocabularyIngestionService:
    def __init__(
        self,
        spark: SparkSession,
        target_tables_path: str,
        vocabulary_path: str,
        checkpoint_path: str,
    ):
        """Ingest vocabulary data into target tables

        Args:
            spark (SparkSession): Spark Session
            target_tables_path (str): The absolute abfss URL of the tables location
            vocabulary_path (str): The path where vocab is located
            checkpoint_path (str): The path where the checkpoint information for spark structured streaming is stored
        """
        self.spark = spark
        self.target_tables_path = target_tables_path
        self.vocabulary_path = vocabulary_path
        self.checkpoint_path = checkpoint_path
        self._logger = LoggingHelper.get_generic_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )

    def ingest_vocab_data(self, vocab_schema: Dict):
        """Set up spark structured streaming on the vocab data

        Args:
            vocab_schema (Dict): THe key is the table_name (str) and the value is the schema of the table
        """
        # Report Vocabulary Ingestion Pipeline Usage
        telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
                                        activity_name=GlobalConstants.OMOP_VOCAB_INGESTION_ACTIVITY_NAME)
        
        file_stream_reader = FileStreamReader(self.spark)
        streaming_queries = []

        for table_name, schema in vocab_schema.items():
            streaming_path = f"{self.vocabulary_path}/*{table_name}.csv"

            # If there is no data in the streaming, do nothing
            if not Utils.is_files_in_path(spark=self.spark, path=streaming_path):
                self._logger.info(
                    f"{LC.STREAMING_PATH_DOES_NOT_EXIST_INFO_MSG.format(streaming_path=streaming_path)}"
                )
            else:
                self._logger.info(
                    f"{LC.SET_STRUCTURED_STREAMING_INFO_MSG.format(streaming_path)}"
                )
                df = file_stream_reader.set_up_streaming_csv(schema, streaming_path)
                query = self.start_streaming(df, table_name.lower())
                streaming_queries.append(query)

        # Block until all queries have completed streaming
        stream_orchestrator = StreamOrchestrator(self.spark)
        stream_orchestrator.await_all_termination(streaming_queries)

    def start_streaming(self, df, table_name):
        """
        The query to start the ingestion into target tables.

        Args:
            df (DataFrame): the DataFrame passed from the initial ingest call
            table_name (str): the name of the table to target
        Returns:
            StreamingQuery: a query object for each resource
        """
        self._logger.info(f"{LC.INGESTION_START_STREAM_INFO_MSG.format(table_name)}")
        return (
            df.writeStream.format("delta")
            .trigger(availableNow=True)
            .option("checkpointLocation", f"{self.checkpoint_path}/{table_name}")
            .foreachBatch(
                lambda df, epochId: append_to_delta_table_using_path(
                    df_to_process=df,
                    delta_table_path=f"{self.target_tables_path}/{table_name}",
                    logger=self._logger,
                )
            )
            .queryName(f"{ self.__class__.__name__}.{table_name}")
            .start()
        )
