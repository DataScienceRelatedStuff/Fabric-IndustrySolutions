import logging
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType


class GlobalConstants:
    # DB Constants
    OMOP_FHIR_POC_DB: str = "omoponfhir_poc_db"

    # OMOP Id Mapping table
    OMOP_ID_MAPPING_TABLE: str = "omop_id_mappings"
    OMOP_ID_MAPPING_TABLE_RESOURCE_TYPE_FIELD: str = "RESOURCE_TYPE"
    OMOP_ID_MAPPING_TABLE_EXTERNAL_ID_FIELD: str = "EXTERNAL_ID"
    OMOP_ID_MAPPING_TABLE_SOURCE_ID_FIELD: str = "SOURCE_ID"
    OMOP_ID_MAPPING_TABLE_ADRM_ID_FIELD: str = "ADRM_ID"

    # Concept table
    CONCEPT_TABLE: str = "concept"
    CONCEPT_TABLE_START_DATE_FIELD: str = "valid_start_date"
    CONCEPT_TABLE_END_DATE_FIELD: str = "valid_end_date"
    CONCEPT_TABLE_CONCEPT_ID_FIELD: str = "concept_id"
    CONCEPT_TABLE_CONCEPT_CODE_FIELD: str = "concept_code"
    CONCEPT_TABLE_CONCEPT_NAME_FIELD: str = "concept_name"
    CONCEPT_TABLE_STANDARD_CONCEPT_FIELD: str = "standard_concept"
    CONCEPT_TABLE_DOMAIN_ID_FIELD: str = "domain_id"

    # Concept relationship table
    CONCEPT_RELATIONSHIP_TABLE: str = "concept_relationship"
    CONCEPT_RELATIONSHIP_TABLE_START_DATE_FIELD: str = "valid_start_date"
    CONCEPT_RELATIONSHIP_TABLE_END_DATE_FIELD: str = "valid_end_date"
    CONCEPT_RELATIONSHIP_TABLE_RELATION_ID_FIELD: str = "relationship_id"
    CONCEPT_RELATIONSHIP_TABLE_CONCEPT_ID1_FIELD: str = "concept_id_1"
    CONCEPT_RELATIONSHIP_TABLE_CONCEPT_ID2_FIELD: str = "concept_id_2"

    # Omop fhir vocab mapping table
    VOCAB_MAPPING_TABLE: str = "fhiromopvocabmapping"
    VOCAB_MAPPING_TABLE_FHIR_FIELD: str = "fhir_uri"
    VOCAB_MAPPING_TABLE_DOMAIN_FIELD: str = "domain"
    VOCAB_MAPPING_TABLE_VOCAB_ID_FIELD: str = "vocabulary_id"

    # Folder paths
    FILES_FOLDER_FABRIC = "Files"
    BRONZE_CONTAINER = "bronze"
    PROCESSING_STATUS_FOLDER = "processing_status"
    FHIR_2_OMOP_FOLDER = "fhir_2_omop"
    TO_PROCESS_FOLDER = "to_process"
    PROCESSED_FOLDER = "processed"
    HEALTHCARE_DATA_MANAGER_CONFIGURATION_CONTAINER = "datamanager"
    FHIR_TO_OMOP_CONFIGURATION_FOLDER = "fhir_2_omop"
    FLATTEN_CONFIG_FOLDER = "flatten"
    NLP_CONFIG_FOLDER = "nlp"
    TA4H_CONFIG_FOLDER = "ta4h"
    NLP_CONFIG_NAME = "nlp_config.json"
    DTT_CONFIG_FOLDER = "dtt"
    DTT_STATE_DB = "dtt_state_db"
    INTERNAL_FOLDER = "_internal"
    SCHEMA_CONFIGURATION_FOLDER = "schema"
    TRANSFORMATION_CONFIGURATION_FOLDER = "transformation"
    FLATTEN_CONFIG_NAME = "flatten_config.json"
    DMF_ADAPTER_FILE = "dmfAdapter.json"
    DB_TARGET_SCHEMA = "dbTargetSchema.json"
    DB_TARGET_SCHEMA_CONFIG = "dbTargetSchemaConfig.json"
    DB_SEMANTICS_CONFIG = "dbSemanticsConfig.json"
    DB_SEMANTICS = "dbSemantics.json"
    SILVER_CONTAINER = "silver"
    GOLD_CONTAINER = "gold"
    OMOP_DB_FOLDER = "omop_db"
    FLATTENED_DATA_FOLDER = "flattened_data"
    FHIR_43 = "fhir4_3"
    MEDICAL_IMAGING_FOLDER = "medical_imaging"
    DICOM_FOLDER = "dicom"
    IDM_DMF_ADAPTER_FILE = "adapter.json"
    IDM_DB_TARGET_SCHEMA = "dbTargetSchema.json"
    IDM_DB_TARGET_SCHEMA_CONFIG = "dbConfig.json"
    IDM_DB_SEMANTICS_CONFIG = "dbSemanticsConfig.json"
    IDM_DB_SEMANTICS = "dbSemantics.json"
    IDM_FOLDER="idm"
    IDM_RMT_REFERENCE_TABLES_FOLDER ="reference_tables"
    IDM_RMT_REFERENCE_TABLES_MAPPING_FOLDER ="mapping"
    IDM_RMT_REFERENCE_TABLES_DATA_FOLDER ="data"
    IDM_RMT_REFERENCE_TABLES_DATA_COMMON_FOLDER ="Common"
    IDM_RMT_REFERENCE_TABLES_DATA_HEALTHCARE_FOLDER ="Healthcare"
    IDM_RMT_REFERENCE_TABLES_DOMAIN_FOLDER ="HLC-IDM"

    # Silver
    DEFAULT_SILVER_DATABSE_NAME = "silver_db"
    DEFAULT_SILVER_UNIQUE_COLUMNS: list = ["id"]
    DEFAULT_SOURCE_MODIFIED_ON_COLUMN: str = "meta_lastUpdated"
    DEFAULT_SILVER_MODIFIED_DATE_COL: str = "modified_date"

    # Bronze
    DEFAULT_BRONZE_LAKEHOUSE_NAME = "bronze"
    DEFAULT_NUMBER_OF_FILES_PER_TRIGGER_BRONZE = 1000
    DEFAULT_LANDINGZONE_SOURCE_PATTERN = "landing_zone/**/**/**/<resource_name>[^a-zA-Z]*ndjson"
    DEFAULT_BRONZE_CREATED_DATE_COL: str = "created_date"
    DEFAULT_ONE_LAKE_ENDPOINT: str = "onelake.dfs.fabric.microsoft.com"
    
    #spark config keys
    SPARK_KEY_VAULT_NAME = "spark.key_vault_name"
    SPARK_DTT_APP_INSIGHTS_CONNECTION_STRING = "spark.dtt.application_insights.instrumentation_key"
    SPARK_APP_INSIGHTS_INGESTION_ENDPOINT_KEY_SECRET_NAME = "spark.appinsights.appinsights_ingestion_endpoint_key_secret_name"
    
    # to_process file
    TIMESTAMP = "timestamp"
    FLATTEN_STATUS = "flattenStatus"
    STATUS = "status"
    STATUS_DETAIL = "statusDetail"
    ERROR = "error"
    NLP_STATUS = "nlpStatus"
    RESOURCES_TO_TRANSFORM = "resourcesToTransform"
    RESOURCE_TYPE = "resourceType"
    RESOURCE_PATH_TO_FOLDER = "path"
    DTT_STATUS = "dttStatus"

    # token
    STORAGE_AUDIENCE_TYPE = "Storage"
    TOKEN_EXPIRATION_IN_SECONDS = 600

    # Blob Client Lease
    # Anthing more than 60 seconds is throwing HttpResponseError
    LEASE_EXPIRATION_IN_SECONDS = 60
    LEASE_RENEWAL_IN_SECONDS = 30

    # text analytics
    DOCUMENT_LIMIT = 1000
    RETRY_COUNT = 3
    NLP_COLUMNS_MAPPING = {
        "column_with_id_name": "id",
        "column_with_text_name": "content_attachment_data",
        "output_column_Name": "nlp_outputs",
    }
    ENABLE_TEXT_ANALYTICS_LOGS = False
    NLP_LANGUAGE_SERVICE_TOKEN_INVALID = "NLP - Language Service Token is not valid."

    # resource folder names
    DOCUMENT_REFERENCE_CONTENT_FOLDER = "documentreferencecontent"

    # NLP preview resource type to analyze
    DOCUMENT_REFERENCE_CONTENT_RESOURCE = "DocumentReferenceContent"
    
    # Source modified on NLP tables timestamp column
    DEFAULT_NLP_SOURCE_MODIFIED_ON_COLUMN = "parent_meta_lastUpdated"
    
    # logging
    DATA_MANAGER_LOGGER: str = "Healthcaredatasolutions"
    FHIR_TO_OMOP: str = "fhirtoomop"
    LOGGING_LEVEL: int = logging.INFO
    
    DICOM_IMAGING: str = "DicomImaging"
 
    DATA_MANAGER_DEPLOYMENT: str = "HealthcaredatasolutionsDeployment"
    DATA_MANAGER_BRONZE_INGESTION: str = "HealthcaredatasolutionsBronzeIngestion"
    DATA_MANAGER_SILVER_INGESTION: str = "HealthcaredatasolutionsSilverIngestion"
    DATA_MANAGER_NLP_INGESTION: str = "HealthcaredatasolutionsNLPIngestion"
    DATA_MANAGER_OMOP_INGESTION: str = "HealthcaredatasolutionsOMOPIngestion"
    DATA_MANAGER_FHIR_EXPORT: str = "HealthcaredatasolutionsFHIRExport"
    DATA_MANAGER_PATIENT_OUTREACH_GOLD_INGESTION: str = "HealthcaredatasolutionsPatientOutreachGoldIngestion"
    DATA_MANAGER_IDM_SILVER_INGESTION: str = "HealthcaredatasolutionsIDMSilverIngestion"

    DEFAULT_BRONZE_LAKEHOUSE_NAME = "bronze"
    DEFAULT_SILVER_LAKEHOUSE_NAME = "silver"
    DEFAULT_OMOP_LAKEHOUSE_NAME = "omop"
    DATA_MANAGER_CONFIGURATION_FOLDER_ROOT = "DMHConfiguration"
    DATA_MANAGER_CHECKPOINT_FOLDER_ROOT = "DMHCheckpoint"
    DMF_CONFIG_PATH = "dmfConfig.json"
    RMT_CONFIG_PATH = "rmtConfig.json"
    ENV_CONFIG_PATH = "environment.json"
    DATA_MANAGER_SAMPLE_DATA_FOLDER_ROOT = "DMHSampleData"
    
    DEFAULT_OMOP_AND_SAMPLE_DATA_ROOT_FOLDER = "healthcare-sampledata"
    OMOP_CONFIG_FOLDER = "omop"
    VOCAB_CHECKPOINT_FOLDER = "vocab"
    VOCAB_DATA_FOLDER = "msft_dmh_omop_vocab_data"
    SCRIPTS_FOLDER = "scripts"
    OMOP_VERSION_54 = "5_4"
    
    
    
    # Schema and config paths
    DATA_MANAGER_INTERNAL_FOLDER_PATH = f"{DATA_MANAGER_CONFIGURATION_FOLDER_ROOT}/{INTERNAL_FOLDER}"
    DATA_MANAGER_FHIR43_CONFIGURATION_FOLDER_PATH = f"{DATA_MANAGER_INTERNAL_FOLDER_PATH}/{FHIR_43}"
    DATA_MANAGER_FHIR43_TRANSFORMATION_CONFIGURATION_FOLDER_PATH = f"{DATA_MANAGER_FHIR43_CONFIGURATION_FOLDER_PATH}/{TRANSFORMATION_CONFIGURATION_FOLDER}"
    
    
    PATIENT_OUTREACH_GOLD_CONFIG_PATH = "poagold"
    PATIENT_OUTREACH_RMT_REFERENCE_FOLDER = "reference_tables"
    PATIENT_OUTREACH_RMT_REFERENCE_DATA_FOLDER = "data"
    PATIENT_OUTREACH_RMT_REFERENCE_MAPPING_FOLDER = "mapping"
    PATIENT_OUTREACH_DTT_ADAPTER_FILE = "adapter.json" 
    PATIENT_OUTREACH_FOLDER = "poa"
    
    DEFAULT_PATIENT_OUTREACH_CONFIG_PATH=f"{DATA_MANAGER_INTERNAL_FOLDER_PATH}/{PATIENT_OUTREACH_FOLDER}"
    DEFAULT_PATIENT_OUTREACH_DTT_SECONDARY_LAKE_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{PATIENT_OUTREACH_FOLDER}/{DTT_CONFIG_FOLDER}/{DTT_STATE_DB}"
    DEFAULT_IDM_CONFIG_PATH=f"{DATA_MANAGER_INTERNAL_FOLDER_PATH}/{IDM_FOLDER}"
    
    DEFAULT_SCHEMA_PATH = f"{DATA_MANAGER_FHIR43_CONFIGURATION_FOLDER_PATH}/schema"

    DEFAULT_FLATTEN_CONFIG_DIR = f"{DATA_MANAGER_FHIR43_TRANSFORMATION_CONFIGURATION_FOLDER_PATH}/{FLATTEN_CONFIG_FOLDER}"
    DEFAULT_FLATTEN_CONFIG_PATH = f"{DEFAULT_FLATTEN_CONFIG_DIR}/{FLATTEN_CONFIG_NAME}"
    DEFAULT_NLP_CONFIG_DIR = f"{DATA_MANAGER_FHIR43_TRANSFORMATION_CONFIGURATION_FOLDER_PATH}/{NLP_CONFIG_FOLDER}"
    DEFAULT_OMOP_CONFIG_PATH = f"{DATA_MANAGER_FHIR43_TRANSFORMATION_CONFIGURATION_FOLDER_PATH}/{OMOP_CONFIG_FOLDER}"
    DEFAULT_OMOP_VOCABULARY_PATH = (
        f"{DEFAULT_OMOP_AND_SAMPLE_DATA_ROOT_FOLDER}/{VOCAB_DATA_FOLDER}"
    )
    
    DEFAULT_DICOM_TO_FHIR_CONFIG_PATH = f"{DATA_MANAGER_INTERNAL_FOLDER_PATH}/{MEDICAL_IMAGING_FOLDER}/{DICOM_FOLDER}"
    
    DEFAULT_OMOP_SCRIPTS_PATH = f"{DATA_MANAGER_CONFIGURATION_FOLDER_ROOT}/{INTERNAL_FOLDER}/{OMOP_CONFIG_FOLDER}/{SCRIPTS_FOLDER}"
    DEFAULT_RMT_MAPPING_FOLDER = "mapping"
    DEFAULT_RMT_MAPPING_FOLDER_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{DTT_CONFIG_FOLDER}/{DEFAULT_RMT_MAPPING_FOLDER}"
    DEFAULT_DTT_SECONDARY_LAKE_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{DTT_CONFIG_FOLDER}/{DTT_STATE_DB}"
    DEFAULT_DTT_FILE_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{DTT_CONFIG_FOLDER}"
    DEFAULT_DMF_CONFIG_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{DTT_CONFIG_FOLDER}/{DMF_CONFIG_PATH}"
    DEFAULT_RMT_CONFIG_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{DTT_CONFIG_FOLDER}/{RMT_CONFIG_PATH}"
    DEFAULT_IDM_DTT_SECONDARY_LAKE_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{IDM_FOLDER}/{DTT_CONFIG_FOLDER}/{DTT_STATE_DB}"
    DEFAULT_IDM_DMF_CONFIG_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{IDM_FOLDER}/{DTT_CONFIG_FOLDER}/{DMF_CONFIG_PATH}"
    DEFAULT_IDM_RMT_CONFIG_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{IDM_FOLDER}/{DTT_CONFIG_FOLDER}/{RMT_CONFIG_PATH}"
    DEFAULT_IDM_ENV_CONFIG_PATH = f"{DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{IDM_FOLDER}/{DTT_CONFIG_FOLDER}/{ENV_CONFIG_PATH}"
    DEFAULT_IDM_RMT_REFERENCE_DATA_FOLDER = f"{DATA_MANAGER_CONFIGURATION_FOLDER_ROOT}/{INTERNAL_FOLDER}/{IDM_FOLDER}/{IDM_RMT_REFERENCE_TABLES_FOLDER}"
    DEFAULT_IDM_RMT_REFERENCE_MAPPING_FOLDER = f"{DEFAULT_IDM_RMT_REFERENCE_DATA_FOLDER}/{IDM_RMT_REFERENCE_TABLES_MAPPING_FOLDER}/{IDM_RMT_REFERENCE_TABLES_DATA_HEALTHCARE_FOLDER}/{IDM_RMT_REFERENCE_TABLES_DOMAIN_FOLDER}"

    STREAM_ORCHESTRATOR_SLEEP_IN_SECONDS = 10
    
    # OMOP VOCAB SCHEMA
    OMOP_VOCAB_SCHEMA = {
        "CONCEPT": StructType(
            [
                StructField("concept_id", IntegerType()),
                StructField("concept_name", StringType()),
                StructField("domain_id", StringType()),
                StructField("vocabulary_id", StringType()),
                StructField("concept_class_id", StringType()),
                StructField("standard_concept", StringType()),
                StructField("concept_code", StringType()),
                StructField("valid_start_date", DateType()),
                StructField("valid_end_date", DateType()),
                StructField("invalid_reason", StringType()),
            ]
        ),
        "CONCEPT_RELATIONSHIP": StructType(
            [
                StructField("concept_id_1", IntegerType()),
                StructField("concept_id_2", IntegerType()),
                StructField("relationship_id", StringType()),
                StructField("valid_start_date", DateType()),
                StructField("valid_end_date", DateType()),
                StructField("invalid_reason", StringType()),
            ]
        ),
        "VOCABULARY": StructType(
            [
                StructField("vocabulary_id", StringType()),
                StructField("vocabulary_name", StringType()),
                StructField("vocabulary_reference", StringType()),
                StructField("vocabulary_version", StringType()),
                StructField("vocabulary_concept_id", IntegerType()),
            ]
        ),
        "CONCEPT_ANCESTOR": StructType(
            [
                StructField("ancestor_concept_id", IntegerType()),
                StructField("descendant_concept_id", IntegerType()),
                StructField("min_levels_of_separation", IntegerType()),
                StructField("max_levels_of_separation", IntegerType()),
            ]
        ),
        "CONCEPT_CLASS": StructType(
            [
                StructField("concept_class_id", StringType()),
                StructField("concept_class_name", StringType()),
                StructField("concept_class_concept_id", IntegerType()),
            ]
        ),
        "CONCEPT_SYNONYM": StructType(
            [
                StructField("concept_id", IntegerType()),
                StructField("concept_synonym_name", StringType()),
                StructField("language_concept_id", IntegerType()),
            ]
        ),
        "FHIR_SYSTEM_TO_OMOP_VOCAB_MAPPING": StructType(
            [
                StructField("fhir_uri", StringType()),
                StructField("vocabulary_id", StringType())
            ]
        )
    }

    CHECKPOINT_LOCATION_OPTION_NAME = "checkpointLocation"
    SILVER_CONFIG_RESOURCES_KEY: str = "resources"
    SILVER_CONFIG_NAME_KEY: str = "name"
    
    # public UDF function names
    PARSE_EXTENSION_UDF = "parse_extension"
    
    # Library telemetry usage
    LIBRARY_IMPORT_FEATURE_NAME = "HDSLibraryImport"
    LIBRARY_USAGE_FEATURE_NAME = "HDSLibraryUsage"
    
    # Library telemetry usage activity name
    BRONZE_INGESTION_ACTIVITY_NAME = "raw-bronze-ingestion"
    SILVER_INGESTION_ACTIVITY_NAME = "bronze-silver-ingestion"
    OMOP_INGESTION_ACTIVITY_NAME = "silver-omop-ingestion"
    NLP_ENRICHMENT_ACTIVITY_NAME = "silver-nlp-enrichment"
    FHIR_EXPORT_ACTIVITY_NAME = "fhir-export"
    OMOP_DRUG_ERA_GENERATOR_ACTIVITY_NAME = "omop-drug-era-table-generator"
    OMOP_VOCAB_INGESTION_ACTIVITY_NAME = "omop-vocabulary-ingestion"
    IMAGING_BRONZE_INGESTION_ACTIVITY_NAME = "imaging-raw-bronze-ingestion"
    DTT_WORKFLOW_ACTIVITY_NAME = "dtt-workflow"
    PATIENT_OUTREACH_SHORTCUTS_CREATION_ACTIVITY_NAME = "patientoutreach-shortcuts-creation"
    PATIENT_OUTREACH_GOLD_INGESTION_ACTIVITY_NAME = "patientoutreach-gold-ingestion"
    PATIENT_OUTREACH_SILVER_INGESTION_ACTIVITY_NAME = "patientoutreach-bronze-silver-ingestion"
    