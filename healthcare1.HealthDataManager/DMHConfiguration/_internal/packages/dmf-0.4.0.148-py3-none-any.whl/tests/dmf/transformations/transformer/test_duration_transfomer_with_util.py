import datetime
from typing import List
from pyspark.sql import SparkSession
from dmf.transformations.transformer.duration_transformer import DurationTransformer
from dmf.utils.global_constants import GlobalConstants as GConstants
from tests.dmf.transformations.transformer.transfomer_test_util.transfomer_test_util import TransfomerTestUtil
from tests.dmf.transformations.transformer.transfomer_test_util.transfomer_test_util_data import DurationShortSourceRow as SourceRow, DurationShortTargetRow as TargetRow


"""
Those tests are based on the following cases:

Combing the following cases:

    Source Data:
        1.new active row
        2.new inactive row
        3.new rows both active
        4.new rows first row is inactive with same data of the source
        5.new rows first row is inactive with different data of the source
        6.new rows last row is inactive with same data of the source
        7.new rows last row is inactive with different data of the source
        8.new rows both inactive with same data of the source
        9.new rows both inactive with different data of the source

    Target Data:
        1.empty
        2.one active row with same data (as the first new row of the source)
        3.one active row with different data (from the first new row of the source)
        4.one inactive row with same data (as the first new row of the source)
        5.one inactive row with different data (from the first new row of the source)

        
The tests are implemented using TransfomerTestUtil which simplfies combing those cases with other cases (like adding additional key or type),
as well as testing other steps of the transfomer (like duplicates in same day, duplicates in different days, null ids, unrelated partitions)


"""
# values to be used by tests

OPEN_START = GConstants.START_OF_TIME_PY_DT
OPEN_END = GConstants.END_OF_TIME_PY_DT
DATE1 = datetime.datetime(2023, 10, 7, 6)
DATE2 = datetime.datetime(2023, 10, 9, 6)
DATE3 = datetime.datetime(2023, 10, 11, 6)
ACTIVE =GConstants.ACTIVE_VALUE
INACTIVE = GConstants.INACTIVE_VALUE
SINGLE = "single"
MARRIED = "married"
DIVORCED ="divorced"


class TestDurationTransformerWithUtil:
        
    def minus_day(self, date: datetime.datetime) -> datetime.datetime:
        return date - datetime.timedelta(days=1) 
    
    def run_test(self, spark: SparkSession, 
                 source_data: List[SourceRow], 
                 target_data: List[TargetRow], 
                 expected_data: List[TargetRow]):
        
        test_util = TransfomerTestUtil(DurationTransformer("id", "target_id"))
        test_util.run_test(spark, source_data, target_data, expected_data, True, True)

    def test_one_active_row_to_empty_target(self, spark: SparkSession):
        
         source_data = [SourceRow(data=SINGLE, modified=DATE1, active=True)]

         target_data = []

         expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]
        
         self.run_test(spark, source_data, target_data, expected_data)
                              
    
    def test_one_inactive_row_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=False)]

        target_data = []

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        self.run_test(spark, source_data, target_data, expected_data)
    
    def test_new_rows_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=True),
                       SourceRow(data=MARRIED, modified=DATE2, active=True)]

        target_data = []

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=OPEN_END)]

        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_last_inactive_different_data_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=True),
                       SourceRow(data=MARRIED, modified=DATE2, active=False)]

        target_data = []
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2)] 

        self.run_test(spark, source_data, target_data, expected_data)
    
    def test_new_rows_last_inactive_same_data_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=True),
                       SourceRow(data=SINGLE, modified=DATE2, active=False)]

        target_data = []

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2))]

        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_first_inactive_different_data_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=False),
                       SourceRow(data=MARRIED, modified=DATE2, active=True)]

        target_data = []

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=OPEN_END)] 

        self.run_test(spark, source_data, target_data, expected_data)       
    
    def test_new_rows_first_inactive_same_data_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=False),
                       SourceRow(data=SINGLE, modified=DATE2, active=True)]

        target_data = []

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=SINGLE, modified=DATE2, start=DATE2, end=OPEN_END)] 

        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_same_data_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=False),
                       SourceRow(data=SINGLE, modified=DATE2, active=False)]

        target_data = []
 
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)] 

        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_different_data_to_empty_target(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE1, active=False),
                       SourceRow(data=MARRIED, modified=DATE2, active=False)]

        target_data = []
 
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2)] 

        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_one_active_row_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_one_active_row_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_one_active_row_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=SINGLE, modified=DATE2, start=DATE2, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
    
    def test_one_active_row_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    
    def test_one_inactive_row_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2))]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_one_inactive_row_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2)]
        
        self.run_test(spark, source_data, target_data, expected_data)
    
    def test_one_inactive_row_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)] #todo check
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    
    def test_one_inactive_row_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                        TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2)]
        
        self.run_test(spark, source_data, target_data, expected_data)
    
    def test_new_rows_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=True),
                       SourceRow(data=MARRIED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE3)),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=True),
                       SourceRow(data=DIVORCED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=self.minus_day(DATE3)),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
    
    def test_new_rows_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=True),
                       SourceRow(data=DIVORCED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=self.minus_day(DATE3)),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=True),
                       SourceRow(data=MARRIED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=SINGLE, modified=DATE2, start=DATE2, end=self.minus_day(DATE3)),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=OPEN_END)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_last_inactive_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=True),
                       SourceRow(data=DIVORCED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=self.minus_day(DATE3)),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_last_inactive_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=True),
                       SourceRow(data=MARRIED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE3)),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_last_inactive_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=True),
                       SourceRow(data=DIVORCED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=self.minus_day(DATE3)),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_last_inactive_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=True),
                       SourceRow(data=MARRIED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                       TargetRow(data=SINGLE, modified=DATE2, start=DATE2, end=self.minus_day(DATE3)),
                       TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
        
    def test_new_rows_first_inactive_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False),
                       SourceRow(data=DIVORCED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=OPEN_END)] 
        
       
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_first_inactive_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False),
                       SourceRow(data=MARRIED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=OPEN_END)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_first_inactive_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False),
                       SourceRow(data=DIVORCED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=OPEN_END)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_first_inactive_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False),
                       SourceRow(data=MARRIED, modified=DATE3, active=True)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=OPEN_END)]
        
        self.run_test(spark, source_data, target_data, expected_data) #checkt
        
    def test_new_rows_both_inactive_different_data_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False),
                       SourceRow(data=DIVORCED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_different_data_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False),
                       SourceRow(data=MARRIED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_different_data_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False),
                       SourceRow(data=DIVORCED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2),
                         TargetRow(data=DIVORCED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_different_data_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False),
                       SourceRow(data=MARRIED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE3, start=DATE3, end=DATE3)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_same_data_to_active_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False),
                       SourceRow(data=MARRIED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2)),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2)] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_same_data_to_active_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False),
                       SourceRow(data=SINGLE, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=OPEN_END)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=self.minus_day(DATE2))] 
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_same_data_to_inactive_target_with_different_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=MARRIED, modified=DATE2, active=False),
                       SourceRow(data=MARRIED, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]
        
        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1),
                         TargetRow(data=MARRIED, modified=DATE2, start=DATE2, end=DATE2)]
        
        self.run_test(spark, source_data, target_data, expected_data)
        
    def test_new_rows_both_inactive_same_data_to_inactive_target_with_same_data(self, spark: SparkSession):
        
        source_data = [SourceRow(data=SINGLE, modified=DATE2, active=False),
                       SourceRow(data=SINGLE, modified=DATE3, active=False)]

        target_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]

        expected_data = [TargetRow(data=SINGLE, modified=DATE1, start=OPEN_START, end=DATE1)]
        
        self.run_test(spark, source_data, target_data, expected_data) # checkt
        
    
        
    
    
        

