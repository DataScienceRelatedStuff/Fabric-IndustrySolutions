"""
api.py
-------

This module provides the main API for generating and persisting DTT and RMT specifications from given configuration files. 
It also provides an API for getting proposed paths for a given source table and target field.

Functions
---------
persist_dtt_spec
    Generates a DTT spec from the given configuration files and persists it to the given path.

persist_rmt_spec
    Generates an RMT spec from the given configuration files and persists it to the given path.

generate_dtt_specs
    Generates DTT and RMT specs from the given configuration files and persists them to the given paths.
    merely calls persist_dtt_spec and persist_rmt_spec.

get_proposed_paths
    Returns a ProposedPathsResponse object containing the proposed paths from the source table to the target field.
    used by the VsCode extension UI to get proposed paths for a given source table and target field.

_persist_model(config, out_path, exclude=None):
    Persists the given Pydantic model to the given path.

_get_mssparkutils():
    Returns the mssparkutils module if it is loaded, otherwise returns None.

"""
from pathlib import Path
import sys
from pyspark.sql import SparkSession
from configuration_compiler.configuration_content_wrapper import (
    DttConfigurationContentWrapper,
    RmtConfigurationContentWrapper,
)
from configuration_compiler.column_transformation.proposed_paths_generator import ProposedPathsResponse
from configuration_compiler.data_feed_configuration_compiler import DataFeedConfigurationCompiler
from configuration_compiler.mount_helpers import LocalFileSystemAccess

from configuration_compiler.path_helpers import uri_parent_path
from configuration_compiler.rmt_configuration_compiler import RMTConfigurationCompiler
from pydantic.main import BaseModel


def persist_dtt_spec(
    spark: SparkSession,
    out_path: str,
    dmf_adaptor_file_location: str = "",
    target_db_semantics_file_location: str = "",
    target_db_semantics_config_file_location: str = "",
    target_db_schema_file_location: str = "",
    db_schema_config_location: str = "",
    env_config_file_location: str = "",
    adaptor_file_content: str = "",
    target_db_semantics_file_content: str = "",
    target_db_semantics_config_file_content: str = "",
    target_db_schema_file_content: str = "",
    db_schema_config_content: str = "",
    env_config_file_content: str = "",
):
    """Generates a DTT spec from the given configuration files and persists it to the given path.
    Arguments:
        spark: SparkSession
        out_path: str, where to persist the spec
        adaptor_file_location: str, path to the adaptor configuration file
        target_db_semantics_file_location: str, path to the target DB semantics file
        target_db_semantics_config_file_location: str, path to the target DB semantics config file
        target_db_schema_file_location: str, path to the target DB schema file
        db_schema_config_location: str, path to the DB schema config file
        env_config_file_location: str, path to the environment config file
        adaptor_file_content: str, content of the adaptor configuration file
        target_db_semantics_file_content: str, content of the target DB semantics file
        target_db_semantics_config_file_content: str, content of the target DB semantics config file
        target_db_schema_file_content: str, content of the target DB schema file
        db_schema_config_content: str, content of the DB schema config file
        env_config_file_content: str, content of the environment config file
    """
    config_content_wrapper = DttConfigurationContentWrapper(
        spark=spark,
        adaptor_path=dmf_adaptor_file_location,
        target_db_semantics_path=target_db_semantics_file_location,
        target_db_semantics_config_path=target_db_semantics_config_file_location,
        target_db_schema_path=target_db_schema_file_location,
        db_schema_config_path=db_schema_config_location,
        env_config_path=env_config_file_location,
        dmf_adaptor_content=adaptor_file_content,
        target_db_semantics_content=target_db_semantics_file_content,
        target_db_semantics_config_content=target_db_semantics_config_file_content,
        target_db_schema_content=target_db_schema_file_content,
        db_schema_config_content=db_schema_config_content,
        env_config_content=env_config_file_content,
    )
    config = DataFeedConfigurationCompiler.compile_configuration(config_content_wrapper)

    out_path_parent = uri_parent_path(out_path)
    with LocalFileSystemAccess(out_path_parent, mode="w", mssparkutils=_get_mssparkutils()) as lfs:
        out_path_local = lfs.adapt_to_local_path(out_path)
        _persist_model(config, out_path_local)


def persist_rmt_spec(
    spark: SparkSession,
    out_path: str,
    adaptor_file_location: str = "",
    target_db_semantics_file_location: str = "",
    env_config_file_location: str = "",
    target_db_schema_file_location: str = "",
    db_schema_config_location: str = "",
    adaptor_file_content: str = "",
    target_db_semantics_file_content: str = "",
    target_db_schema_file_content: str = "",
    db_schema_config_content: str = "",
    env_config_file_content: str = "",
):
    """Generates an RMT spec from the given configuration files and persists it to the given path.
    Arguments:
        spark: SparkSession
        out_path: str, where to persist the spec
        adaptor_file_location: str, path to the adaptor configuration file
        target_db_semantics_file_location: str, path to the target DB semantics file
        env_config_file_location: str, path to the environment config file
        target_db_schema_file_location: str, path to the target DB schema file
        db_schema_config_location: str, path to the DB schema config file
        dmf_adaptor_file_content: str, content of the adaptor configuration file
        target_db_semantics_file_content: str, content of the target DB semantics file
        target_db_schema_file_content: str, content of the target DB schema file
        db_schema_config_content: str, content of the DB schema config file
        env_config_file_content: str, content of the environment config file
    """
    config_content_wrapper = RmtConfigurationContentWrapper(
        spark=spark,
        adaptor_path=adaptor_file_location,
        target_db_semantics_path=target_db_semantics_file_location,
        target_db_schema_path=target_db_schema_file_location,
        db_schema_config_path=db_schema_config_location,
        env_config_path=env_config_file_location,
        adaptor_content=adaptor_file_content,
        target_db_semantics_content=target_db_semantics_file_content,
        target_db_schema_content=target_db_schema_file_content,
        db_schema_config_content=db_schema_config_content,
        env_config_content=env_config_file_content,
    )
    config = RMTConfigurationCompiler.compile_rmt_model(config_content_wrapper)

    out_path_parent = uri_parent_path(out_path)
    with LocalFileSystemAccess(out_path_parent, mode="w", mssparkutils=_get_mssparkutils()) as lfs:
        out_path_local = lfs.adapt_to_local_path(out_path)
        _persist_model(config, out_path_local)


def generate_dtt_specs(
    spark: SparkSession,
    dtt_spec_out_path: str,
    rmt_spec_out_path: str,
    dmf_adaptor_file_location: str,
    target_db_semantics_file_location: str,
    target_db_semantics_config_file_location: str,
    target_db_schema_file_location: str,
    db_schema_config_location: str,
    env_config_file_location: str,
):
    """Generates DTT and RMT specs from the given configuration files and persists them to the given paths.
    Arguments:
        spark: SparkSession
        dtt_spec_out_path: str, where to persist the DTT spec
        rmt_spec_out_path: str, where to persist the RMT spec
        adaptor_file_location: str, path to the adaptor configuration file
        target_db_semantics_file_location: str, path to the target DB semantics file
        target_db_semantics_config_file_location: str, path to the target DB semantics config file
        target_db_schema_file_location: str, path to the target DB schema file
        db_schema_config_location: str, path to the DB schema config file
        env_config_file_location: str, path to the environment config file
    """
    persist_dtt_spec(
        spark=spark,
        out_path=dtt_spec_out_path,
        dmf_adaptor_file_location=dmf_adaptor_file_location,
        target_db_semantics_file_location=target_db_semantics_file_location,
        target_db_semantics_config_file_location=target_db_semantics_config_file_location,
        target_db_schema_file_location=target_db_schema_file_location,
        db_schema_config_location=db_schema_config_location,
        env_config_file_location=env_config_file_location,
    )
    persist_rmt_spec(
        spark=spark,
        out_path=rmt_spec_out_path,
        adaptor_file_location=dmf_adaptor_file_location,
        target_db_semantics_file_location=target_db_semantics_file_location,
        env_config_file_location=env_config_file_location,
        target_db_schema_file_location=target_db_schema_file_location,
        db_schema_config_location=db_schema_config_location,
    )


def get_proposed_paths(
    dmf_adaptor_file_location: str,
    target_db_semantics_file_location: str,
    target_db_schema_file_location: str,
    db_schema_config_location: str,
    source_table_name: str,
    source_field_name: str,
    target_table_name: str,
    target_field_name: str,
) -> ProposedPathsResponse:
    parent_path_uri = uri_parent_path(dmf_adaptor_file_location)
    with LocalFileSystemAccess(parent_path_uri, mode="r", mssparkutils=_get_mssparkutils()) as lfs:
        return DataFeedConfigurationCompiler.get_proposed_paths(
            adaptor_file_location=lfs.adapt_to_local_path(dmf_adaptor_file_location),
            target_db_semantics_file_location=lfs.adapt_to_local_path(target_db_semantics_file_location),
            target_db_schema_file_location=lfs.adapt_to_local_path(target_db_schema_file_location),
            db_schema_config_location=lfs.adapt_to_local_path(db_schema_config_location),
            source_table_name=source_table_name,
            source_field_name=source_field_name,
            target_table_name=target_table_name,
            target_field_name=target_field_name,
        )


def _persist_model(config: BaseModel, out_path: Path, exclude=None):
    json_str = config.model_dump_json(indent=2, by_alias=True, exclude=exclude)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(json_str)


def _get_mssparkutils():
    if "notebookutils.mssparkutils" in sys.modules:
        return sys.modules["notebookutils.mssparkutils"]
    return None

# SIG # Begin Windows Authenticode signature block
# MIIoKQYJKoZIhvcNAQcCoIIoGjCCKBYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDvHkH08tCJAuxS
# T/ruBITABloOqqR0PtjTcY538mnffKCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgkwghoFAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINHLL0DQ28ksYxU8pK/RWevX
# uit+CNslzDMcY+G7nt/1MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAw1zyQSXxPUBU5b9aP7bNIf2SSFxUgkOs9i+LTwy6fqNko/dv8IOAPmcl
# 9C83hzbTS6tOnQrqUIbesU+6g5n0fH9eC6EoBBzYMx5c+3jmkmbXR5v/UpHTij3E
# M8eKH7/0qFY5cK3PBSfmf8Lit7OQom2ZOsJZumzerl50iLiuR68WVGNgjCsRiL5t
# Eabde3lShe327LvMUe1gVX53u6hSatux5LOxvKtv42ikRhWlEAJmpwmLdxOQ8mMV
# 1uRNg9G8vUM/9TGVNLHs+IHaUtQohpXQfxYFLhyQxIq7etN7e8EJTxKbUbyWhW8a
# YM4B1lPPJx3Fs5uIJkLWUDlQ463bIaGCF5MwghePBgorBgEEAYI3AwMBMYIXfzCC
# F3sGCSqGSIb3DQEHAqCCF2wwghdoAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCC/UvFW1Y4H3Re9sGE0FZ/ru6rU9RzyVb8ZhBVmRtoWAwIGZXsMFg16
# GBIyMDI0MDExMTEyMjE1OS4xNVowBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo3RjAwLTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# EeowggcgMIIFCKADAgECAhMzAAAB1akCz8WnyelaAAEAAAHVMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIzMDUyNTE5MTIz
# MFoXDTI0MDIwMTE5MTIzMFowgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo3RjAwLTA1RTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAMV9qTns6mH2+7G2WgAGItzp6dP7IofrX1v46EZ2TKGA
# 3ORfzQpQYj+MSo5UxXhKq39Q8UWJ3Ha3u/ZIROPa0DO5Uq0N+rYcGm7zS9nS/JAP
# J1W3gwMvi0lIqqBih8LEMgGtbMkmOAGiUp04nHW63ZPI5z5Q6bt73a1U8emN2D46
# Z/fVMtR/+ii7IA4n8iefaKHcBI/RBib4AVCOFgM0O7y7Mx3AcXlB3Cyxw1r09VIZ
# 50t0Muj2MvoOg8Xg1ijTqW+8RC5In0ibBl8EYvL/yGkTtEPh7C8kqYzX63p5C4Sx
# NeOsYzZaORbXxKBRnyf5Wkva6ToCEOQJrfnkjnfWnQmSqmiift0e4tR1lJA7jSqZ
# UhDqpAJqe8iZOqY2AT+s8nSuCvSEw8j+5HVP+JovSYSrhupqT7exrwj4UBg4j88L
# tX7MR6T6x3Ja1pf6d1saW/9ElvmZBoafw26duR+8cPVC3kPSua0w56RgyrtCNioT
# cUQ//ABjhMO4nGy2OxrYdeLbJQMSDgwkvr8m+xBdOg5n4jFHopPm3l8HkWllgGlU
# syZrembnPpVe+Retizfc1cmpVYvCKzBrs1QVXzsSzayi70h3DfIBmYchhaA5D4Mh
# jWdjdobkM4OLA3WsnIRv6ZtYNqCt1XFydyvpQoo7j16g1NcRb6xxR/obBcbQoTKZ
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUr9Bco07flsEw7PdHmCJfsCVrY5owHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBAGZF12q9C7KNGnHQcbG86p98WtuAUCDSPza/
# S/tH7/xrvRLZXi3vIpgpKxAYjqm+3UDwkaa5nKOYhebDbcCQjltmTG9KDCzyusG0
# nD29qQRyRxYVBvskbpvrXzHSz1DcMvR1GrjpBlGebtTrbfiV5y+Oy0CjDfR0/ROc
# hpw9Yqk9zdCAH5YOeCU3Z91PWu5DpYhUF6eamOkb3KlEA0pTHk1Fyl0kBBbYWoQd
# NLc21v7S0KoiQ0cnloWwXp6FGi9ZmnQxgjP1ukkeLHRWuN0tUw6l7vC/ra33QTdS
# sTYqZXClDnCwwPphSxygKxJFBmsDkBvBM4Jkml4bbPe8Oj+G688rxN5MnYu278i1
# eDEiUg5Cn+1scCI3xem3D8mYhmD151D8WINogjAblgex+ba7tPA4XJ3o6ovDXxnm
# P8i8M/OWTBYnGTpEckXl1Lizd+fIvDcMcF7kNq/opgHifzH9wSYP9Hjj/yBLk9+4
# bWyuMt3LIa3KHQqJENKaPD59ruLVU+h6aJ0NY1nuSw1p0xp3hmgO+CSo5XgDpr43
# wchz8/qDSKut7MtZSBspdI3yIf1E/5YkXHl8EcTgAXGtsBRDZmfmMOYcAjfBhxAO
# ecRg/nUDvlYXA+y8Gt+tvX7prV+5MQfUBh044zLx9fzEqjQTRiz7tvEi8U+xSlLN
# 8WMGiWaHMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA00w
# ggI1AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0YwMC0wNUUwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAE4S
# L5L9lUV7rDUh3fWboqB7bqU0oIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDpScssMCIYDzIwMjQwMTExMDIwNDI4
# WhgPMjAyNDAxMTIwMjA0MjhaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOlJyywC
# AQAwBwIBAAICK2AwBwIBAAICE7kwCgIFAOlLHKwCAQAwNgYKKwYBBAGEWQoEAjEo
# MCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG
# 9w0BAQsFAAOCAQEAqpCeOBeMRAVGpesj+XbMoOrkna2fCgcaY54MzPy3jkzD5vcl
# 7ixXIHYwWiFy0Ce12hVMjltg88jAY6YCHaaVsbkzv8dAggul2FuVf1ZBbWSWyF2A
# yTJVK7ntAbDxFlsKi6Dbq4X5kylWkYi5TGbpDhQbIGwBriisF6Z8WJVzMYw4mWGe
# JbvDIIy3AAXbeKl3NbR0E637HaEfJj01oTQ+9pdnnxTGfesf/qpaqcj7/oTeryX+
# 1t2YCrEjSpZeWNCALfh6w1kDhvy3dDbNBCVLeKU47GNgf59wwiACDS/vrBoxKguh
# TaGOmeKrvjek7AMC4wkYAA6h+0b0ELdxCbGnEzGCBA0wggQJAgEBMIGTMHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB1akCz8WnyelaAAEAAAHVMA0G
# CWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJ
# KoZIhvcNAQkEMSIEIJ+RVbl4zwSA557Al8OD7p8pB4ArpRdFJCfIF5505We7MIH6
# BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg2b8jhgzXrokwzsQohxi+VxuvYIeM
# oLQtQ6alkhsGwf8wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAAdWpAs/Fp8npWgABAAAB1TAiBCDfmXlnu7+KoWpEQUzPFDlQUyHPd/03
# c3vPQtCnwGAxFDANBgkqhkiG9w0BAQsFAASCAgAht1GGLDM10rPyfsKPDP3l+adQ
# SObGfh+dDNhUb7E9V7C6UCgUktnA/EozeMh/1I1lqZzAlAxQJmObzT+ntw86nYNT
# fK+fWtWMb8/Zi6tOQJHz9gbvTCXxu2UiAxp1KTTRGXXwbqDvA6KI0+ThRdMeG9Rq
# 7maP1EHYx0VDiylmYBgt5N0o3RnSrk3wyOx7OF4+xfZs9WEHvZgVgCqjhHWSR9tR
# JDB9E17c0mREpaFsEeWyO7nmh+JDPaTi6Tu+4C8iAVIWoGJRRF0uJ2KLkbZIHFZa
# EgQFEzMSfEdiZyAFtDneO2lpsh2x6DiaPFT20GWnid6cnuRvcZ0KpKa7dxXpIlTl
# WJo5YYQGmAtdGoqRvqNFEHxSmWhJEr1ovmL7psR4/uSrk94oy01OgxUxIhm1QQ35
# HagRD0sNPQ1u/QNEQ3nRmdkNDdJ4CYox9oKTTWUJ71u8F8fOVqR0T+IbIO2lE4Y0
# JNC9VW27MV7PwnezZzhFclQr9syXuMnUQX3HD0pKaTu3ComwUHzn/FfC6rlDu4bW
# oMAVmNftinSM3DcosiifcS7J9o7dC/zBZtp4mJeqV+i3nKLUv2mQklh+Ex9wrdyx
# R2u83FBuORM2jIxS2Jq9uj54tWppmbttGSqeIDOlVco+uN7n+VQ7uTmQIAXo1dMI
# Iv8JKjMZZTyN1TX0mQ==
# SIG # End Windows Authenticode signature block