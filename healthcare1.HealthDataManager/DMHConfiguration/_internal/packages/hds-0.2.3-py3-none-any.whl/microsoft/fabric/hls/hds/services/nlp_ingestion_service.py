# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
from typing import Dict
from notebookutils import mssparkutils
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.nlp.constants import NLPConstants as NC
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.nlp.nlp_manager import NLPManager
from microsoft.fabric.hls.hds.utils.utils import FolderPath
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter

telemetry_reporter = TelemetryReporter()

# Report NLPIngestionService module import
telemetry_reporter.report_usage(feature_name=GC.LIBRARY_IMPORT_FEATURE_NAME,
                                activity_name=GC.NLP_ENRICHMENT_ACTIVITY_NAME)

class NLPIngestionService:

    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        target_lakehouse_name: str,
        nlp_api_endpoint: str = "",
        kv_name: str = "",
        nlp_secret_name: str = "",
        **kwargs,
        ):
        """
        Initialize the NLPIngestionService which transforms a given table in the lakehouse and uses the Microsoft Text Analytics for Health
        to extract and label relevant medical information from unstructured texts

        Args:
            - spark_session (SparkSession): The SparkSession object.
            - nlp_api_endpoint (str): The NLP API endpoint.
            - kv_name (str): The key vault name.
            - nlp_secret_name (str): The NLP secret name.
            - workspace_name (str): The name of the fabric Workspace
            - solution_name: Name of the HDS-Healthcare data solutions OneLake workload solution
            - target_lakehouse_name (str): The lakehouse name of where the target tables are located
            **kwargs: Additional keyword arguments
                - tables_path (str): The name of the lakehouse where the source table is located. The target tables are also written to this lakehouse. Default is "abfss://{workspace_name}@{one_lake_endpoint}/{target_lakehouse_name}.Lakehouse/Tables".
                - enable_text_analytics_logs (boolean):  Indicates whether or not to log text analytics API requests. Disabled by default.
                - nlp_config_dir (str): The flattening config path. The default is "abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/fhir43/transformation/nlp
                - nlp_config_file_name (str): The name of the NLP config file in the nlp_config_dir. Default is nlp_config.json
                - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
        """

        self.spark = spark
        self.nlp_api_endpoint = nlp_api_endpoint
        self.nlp_secret_name = nlp_secret_name
        self.kv_name = kv_name
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.target_lakehouse_name = target_lakehouse_name
        self.language_service_token = ""
        self._logger = LoggingHelper.get_nlpingestion_logger(
            self.spark, self.__class__.__name__, GC.LOGGING_LEVEL)
        self.one_lake_endpoint = kwargs.get("one_lake_endpoint", GC.DEFAULT_ONE_LAKE_ENDPOINT)
        self.enable_text_analytics_logs = kwargs.get("enable_text_analytics_logs", GC.ENABLE_TEXT_ANALYTICS_LOGS)
        self.nlp_config_name = kwargs.get('nlp_config_file_name', GC.NLP_CONFIG_NAME)
        
        try:
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(workspace_name=self.workspace_name,
                                                                                        one_lake_endpoint=self.one_lake_endpoint,
                                                                                        solution_name=self.solution_name)
            self.tables_path = kwargs.get("tables_path",
                                        FolderPath.get_fabric_tables_path(
                                            workspace_name=self.workspace_name,
                                            one_lake_endpoint=self.one_lake_endpoint,
                                            lakehouse_name=self.target_lakehouse_name
                                            ),
            )
            

            self.kv_uri = FolderPath.get_key_vault_uri(self.kv_name)
            self.nlp_config_dir = kwargs.get('nlp_config_dir',
                                            FolderPath.get_fabric_workload_files_nlp_config_root_folder_path(root_path=self.config_files_root_path)
            )
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise

    def run_nlp_pipeline(self,
                         resource_type: str,
                         nlp_column_mappings:Dict[str, str],
                         document_limit: int
                         ) -> dict:
        """
        Run the NLP pipeline.

        Args:
            resource_type (str): The resource type.
            nlp_column_mappings (dict): Mapping of the dataframe column
                with the unstructured text to analyze
            document_limit (int): The document limit.

        Returns:
            dict: The NLP pipeline status.
        """
        # Report Silver NLP Enrichment Pipeline Usage
        telemetry_reporter.report_usage(feature_name=GC.LIBRARY_USAGE_FEATURE_NAME,
                                        activity_name=GC.NLP_ENRICHMENT_ACTIVITY_NAME)
        
        nlp_manager = NLPManager(self.spark,
                                solution_name=self.solution_name,
                                workspace_name=self.workspace_name,
                                nlp_api_endpoint=self.nlp_api_endpoint,
                                nlp_credentials=self.language_service_token,
                                flatten_config_dir=self.nlp_config_dir,
                                flatten_config_name=self.nlp_config_name,
                                silver_database_path=self.tables_path,
                                nlp_columns_mapping=nlp_column_mappings,
                                enable_text_analytics_logs=self.enable_text_analytics_logs)

        return nlp_manager.run_nlp_pipeline(table_name=resource_type,
                                            document_limit=document_limit)
        
        
    def setup(self):
        """Invoke nlpmanager to create nlp tables
        """
        
        nlp_manager = NLPManager(self.spark,
                                solution_name=self.solution_name,
                                workspace_name=self.workspace_name,
                                nlp_api_endpoint=self.nlp_api_endpoint,
                                nlp_credentials=self.language_service_token,
                                flatten_config_dir=self.nlp_config_dir,
                                flatten_config_name=self.nlp_config_name,
                                silver_database_path=self.tables_path)
        return nlp_manager.create_nlp_tables()

    def run(
        self,
        table_name: str = GC.DOCUMENT_REFERENCE_CONTENT_RESOURCE,
        nlp_column_mappings:Dict[str, str] = NC.DEFAULT_NLP_COLUMNS_NAMING,
        document_limit: int = GC.DOCUMENT_LIMIT,
        ) -> None:
        """
        Run the TA4H transformation.

        Args:
            resource_type (str, optional): The resource type. Defaults to `DocumentReferenceContent`.
            nlp_column_mappings (dict): Mapping of the dataframe column
                with the unstructured text to analyze. Defaults to to `DocumentReferenceContent` column mapping
            document_limit (int, optional): The document limit. Defaults to 1000.
        """
       
        self._logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")
        
        if not self.nlp_api_endpoint:
            raise ValueError(f"{LC.NULL_ARGUMENT_ERR_MSG.format(argument_name='nlp_api_endpoint')}")
        if not self.kv_name:
            raise ValueError(f"{LC.NULL_ARGUMENT_ERR_MSG.format(argument_name='kv_name')}")
        if not self.nlp_secret_name:
            raise ValueError(f"{LC.NULL_ARGUMENT_ERR_MSG.format(argument_name='nlp_secret_name')}")
        if not self.workspace_name:
            raise ValueError(f"{LC.NULL_ARGUMENT_ERR_MSG.format(argument_name='workspace_name')}")
            
        # get secret from keyvault
        self.language_service_token = mssparkutils.credentials.getSecret(self.kv_uri, self.nlp_secret_name)

        try:
            mssparkutils.fs.exists(file=f"{self.nlp_config_dir}/{self.nlp_config_name}")
        except Exception as ex:
            raise ValueError(
                f"Error in NLPIngestionService Service. The NLP configuration path {self.nlp_config_dir}/{self.nlp_config_name} does not exist"
            ) from ex

        nlp_status = self.run_nlp_pipeline(table_name, nlp_column_mappings, document_limit)
        self._logger.info(str(nlp_status))
