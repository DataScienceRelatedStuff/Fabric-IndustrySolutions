from dmf.workflow.processors_scheduler import TargetProcessorScheduler


class MockTargetProcessor:
    def __init__(self, target):
        self.target = target

    def __eq__(self, __o: object) -> bool:
        if isinstance(__o, MockTargetProcessor):
            return self.target == __o.target
        return False

    def __str__(self):
        return f"TargetProcessor({self.target})"

    def __repr__(self):
        return self.__str__()


class TestPartitionTransformersByTargetStorage:
    def test_partition_transformers_by_target_storage(self):
        processors = []
        for target in ["a", "b", "a", "b", "c", "b", "a"]:
            processors.append((MockTargetProcessor(target), target))
        groups = TargetProcessorScheduler._group_processors_by_target_id(processors)
        assert len(groups) == 3
        assert groups[0].processors == [MockTargetProcessor("a"), MockTargetProcessor("a"), MockTargetProcessor("a")]
        assert groups[1].processors == [MockTargetProcessor("b"), MockTargetProcessor("b"), MockTargetProcessor("b")]
        assert groups[2].processors == [MockTargetProcessor("c")]

    def test_partition_transformers_by_target_storage_empty(self):
        processors = []
        partitioned_processors = TargetProcessorScheduler._group_processors_by_target_id(processors)
        assert partitioned_processors == []

    def test_partition_transformers_by_target_all_unique(self):
        processors = []
        for target in ["a", "b", "c", "d", "e", "f"]:
            processors.append((MockTargetProcessor(target), target))
        groups = TargetProcessorScheduler._group_processors_by_target_id(processors)
        assert len(groups) == 6
        for group, target in zip(groups, ["a", "b", "c", "d", "e", "f"]):
            processors = group.processors
            assert len(processors) == 1
            assert processors[0] == MockTargetProcessor(target)

    def test_partition_transformers_by_target_all_non_unique(self):
        processors = []
        for target in ["a", "a", "a", "a"]:
            processors.append((MockTargetProcessor(target), target))
        groups = TargetProcessorScheduler._group_processors_by_target_id(processors)
        assert len(groups) == 1
        assert groups[0].processors == [
            MockTargetProcessor("a"),
            MockTargetProcessor("a"),
            MockTargetProcessor("a"),
            MockTargetProcessor("a")
        ]

    def test_partition_transformers_by_target_all_single(self):
        processors = []
        for target in ["a"]:
            processors.append((MockTargetProcessor(target), target))
        groups = TargetProcessorScheduler._group_processors_by_target_id(processors)
        assert len(groups) == 1
        assert groups[0].processors == [MockTargetProcessor("a")]
