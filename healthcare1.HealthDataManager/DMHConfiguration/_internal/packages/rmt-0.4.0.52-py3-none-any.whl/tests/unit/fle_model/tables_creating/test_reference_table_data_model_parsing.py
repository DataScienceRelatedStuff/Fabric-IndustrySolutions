import pytest
from pydantic import ValidationError

from rmt.file_model.tables_creating.reference_table_data_file_model import ReferenceTableDataModel


@pytest.fixture(scope="module")
def data_dir(tests_data_dir):
    return tests_data_dir / "reference_tables_data_model"


class TestReferenceTableDataModelParsing:
    def test_parsing(self, data_dir):
        with open(data_dir / "LocationType.json", encoding="utf-8") as f:
            ReferenceTableDataModel.model_validate_json(f.read())

    def test_invalid_data_rows_raise_parsing_rrror(self, data_dir):
        with open(data_dir / "LocationType_bad_rows.json", encoding="utf-8") as f:
            with pytest.raises(ValidationError, match="is not defined as a fieldMapping.referenceFieldName"):
                ReferenceTableDataModel.model_validate_json(f.read())
