from concurrent.futures import ThreadPoolExecutor

import pytest

from dmf.utils.utils import parallel_process


@pytest.fixture(scope="module")
def executor():
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="test") as executor:
        yield executor


def test_parallel_process_single_arg(executor):
    def func(x):
        return x

    inputs = [1, 2, 3, 4, 5]
    results = parallel_process(executor, func, inputs)
    assert list(results) == inputs


def test_parallel_multiple_args(executor):
    def func(x, y):
        return x+y

    inputs = [(1, 2), (3, 4), (5, 6)]
    results = parallel_process(executor, func, inputs)
    assert list(results) == [3, 7, 11]


def test_parallel_with_aggregator(executor):
    def func(x, y):
        return x+y

    def aggregator(results):
        return sum(results)

    inputs = [(1, 2), (3, 4), (5, 6)]
    results = parallel_process(executor, func, inputs, aggregator)
    assert results == 21


def test_parallel_multiple_args_with_closure(executor):
    z = 9

    def func(x, y):
        return x+y+z

    inputs = [(1, 2), (3, 4), (5, 6)]
    results = parallel_process(executor, func, inputs)
    assert list(results) == [12, 16, 20]


def test_exception_is_raised(executor):
    def func(x):
        if x == 3:
            raise ValueError(x)
        return x

    inputs = [1, 2, 3, 4, 5]
    with pytest.raises(ValueError):
        parallel_process(executor, func, inputs)
