import re
import json
import os
from requests.models import Response
from pyspark.sql import SparkSession, types as T
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants
from notebookutils import mssparkutils

def get_suffix(stringValue: str,prefix: str) -> str:
    if(stringValue.startswith(prefix)):
        return stringValue[len(prefix):].lstrip()
    return None

class Utils:
    @staticmethod
    def load_config_file(spark: SparkSession, config_path: str) -> str:
        """
        Load file content specified in config_path

        Arguments:
        - config_path: the path to the configuration
        
        Returns:
            str: the content of the file as string
        """
        schema_content = spark.sparkContext.wholeTextFiles(
            config_path).collect()[0][1]
        return str(schema_content)
    
    @staticmethod
    def load_schema_from_avro_schema(spark: SparkSession, avro_schema: str) -> T.StructType:
        """
        Transform AVRO schema to spark internal StructType

        The function requires spark avro library (spark-avro_2.12-3.2.1.jar) 
        to be installed/run with spark
        
        Argument:
        - spark: SparkSession - spark session to access schemaconverter
        - avro_schema: str - the string representation of avro schema
        
        Returns:
            T.StructType - the avro schema as StructType
        """
        # It uses SchemaConverters to convert avro schema to StructType
        # Other option (without protected methods) would be construction like below:
        # create empty dataframe using avro schema provided:
        # df_schema_only = spark.read.format("avro").option("avroSchema", avro_schema).load()
        # df_schema_only.schema - contains suitable schema for loading other file
        
        java_schema_type = spark.\
            _jvm.org.apache.spark.sql.avro.SchemaConverters.toSqlType(  # type: ignore
            spark._jvm.org.apache.avro.Schema.Parser().parse(avro_schema)  # type: ignore
            )
        json_schema = json.loads(java_schema_type.dataType().json())
        return T.StructType.fromJson(json_schema)
    
    @staticmethod
    def load_config(spark: SparkSession, config_path: str):
        """
        Load main configuration and initialize internal list with supported resources
        """
        config_content = spark.sparkContext.wholeTextFiles(
            config_path).collect()[0][1]

        main_config_json = json.loads(str(config_content))
        return {
            entry[GlobalConstants.SILVER_CONFIG_NAME_KEY]: entry
            for entry in main_config_json[
                GlobalConstants.SILVER_CONFIG_RESOURCES_KEY
            ]
        }
        
    @staticmethod
    def is_files_in_path(spark: SparkSession, path: str) -> bool:
        """Checks for any files in the path

        Args:
            spark (SparkSession): Spark Session
            path (str): The file path to check

        Returns:
            bool: True if there are files in the path, false otherwise
        """
        hpath = spark._jvm.org.apache.hadoop.fs.Path(path)
        fs = hpath.getFileSystem(spark._jsc.hadoopConfiguration())
        return len(fs.globStatus(hpath)) > 0
    
    @staticmethod
    def path_exists(path: str) -> bool:
        """
        This method is used to check if the path exists

        Args:
            path (str): the file path to check

        Returns:
            bool: True if path exists and false otherwise
        """        
        try:
            mssparkutils.fs.ls(path)
        except Exception as e:
            return False
        return True
    
    @staticmethod 
    def list_files(directory_to_iterate: str):  
        """
        This method is used to list all the files from the specified folder
        """      
        files = mssparkutils.fs.ls(directory_to_iterate)
        return files
    
    @staticmethod 
    def create_folder(folderpath: str):  
        """
        This method is used to create folders in the specified folder
        """      
        mssparkutils.fs.mkdirs(folderpath)  
    
    @staticmethod 
    def join_path(*path_list: str) -> str :        
        """
        This method is used to join all the input path and return the final path
        """      
        return  os.path.join(*path_list)   
    
    @staticmethod 
    def move_files(from_path: str, to_path: str, files: list):
        """
        This method is used to move files from one path to another

        Args:
            from_path (str): the path from where files needs to be moved
            to_path (str): the path to which files needs to be moved
            files (list): list of files to be moved
        """        
        
        for file in files:
            mssparkutils.fs.mv(os.path.join(from_path, file), os.path.join(to_path, file) )
            
    @staticmethod
    def get_file_names(dir_path: str) -> list:
        """
        This method is used to get all the file names present inside a directory

        Args:
            dir_path (str): directory path from where file names are to be fetched

        Returns:
            list: list of file names
        """ 
               
        return [file.name for file in mssparkutils.fs.ls(dir_path)]
    
    @staticmethod
    def remove_dir(dir_path: str, recursive : bool = True):
        """
        This method is used to remove a directory

        Args:
            dir_path (str): directory path to be removed
            recursive (bool): set the last parameter as True to remove all files and directories recursively
        """        
        
        mssparkutils.fs.rm(dir_path, recursive)
    
    @staticmethod
    def is_guid(identifier: str) -> bool:
        """
        Validates if the identifier is a GUID.
        """
        guid_pattern = re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
        return bool(guid_pattern.match(identifier))
    
    @staticmethod
    def is_valid_artifact_identifiers(workspace_identifier: str, artifact_identifier) -> bool:
        """
        Validates to ensure there is no mismatch in Identifiers. They should both be artifact GUIDs or Names.
        """
        return Utils.is_guid(identifier=workspace_identifier) == Utils.is_guid(identifier=artifact_identifier)
    
    @staticmethod
    def get_app_insights_instrumentation_key(spark: SparkSession):
        """
        Parses the app insights connection string and returns the instrumentation key
                
        Args:
            spark (SparkSession): Spark Session
        """
        app_insights_connection_string = Utils.get_app_insights_connection_string(spark)
        if not app_insights_connection_string:
            return None
        app_insights_connection_string_components = app_insights_connection_string.split(";")
        for component in app_insights_connection_string_components:
            key, value = component.split("=")
            if key == 'InstrumentationKey':
                return component
        return None
    
    @staticmethod
    def get_app_insights_connection_string(spark: SparkSession):
        """
        Retrieves app insights connection string from Key Vault
        
        Args:
            spark (SparkSession): Spark Session
        """
        
        secret_name = spark.conf.get(GlobalConstants.SPARK_APP_INSIGHTS_INGESTION_ENDPOINT_KEY_SECRET_NAME, None)
        if not secret_name:
            return None
        
        return Utils.get_key_vault_secret(spark, secret_name)
      
    @staticmethod
    def get_key_vault_secret(spark: SparkSession, kv_secret_name: str):
        """
        Returns Key Vault secret value given the key that stored in the key vault
        
        Args:
            spark (SparkSession): Spark Session
            key_secret_name (str): The name of the secret
        """

        kv_name = spark.conf.get(GlobalConstants.SPARK_KEY_VAULT_NAME, None)
        if not kv_name:
            return None
        
        kv_uri = FolderPath.get_key_vault_uri(kv_name)
        kv_secret_value = mssparkutils.credentials.getSecret(kv_uri, kv_secret_name)
        return kv_secret_value
    
    @staticmethod
    def get_error_message(response: Response) -> str:
        """
        Retrieves error message from response object
        
        Args:
            response (Response): response object from http call

        Returns:
            str: The error message (output) from the http response
        """
        try:
            response = response.json()
            output_str = response.get("output")
            if (output_str):
                return output_str
            return LoggingConstants.FHIREXPORTSERVICE_NO_ERROR_MSG
        except Exception:
            return LoggingConstants.FHIREXPORTSERVICE_UNABLE_TO_PARSE_ERR_MSG
    
class FolderPath:
    
    @staticmethod
    def get_fabric_tables_path(workspace_name: str, one_lake_endpoint: str, lakehouse_name: str) -> str:
        if not Utils.is_valid_artifact_identifiers(workspace_identifier=workspace_name, artifact_identifier=lakehouse_name):
            raise ValueError(LoggingConstants.FABRIC_MISMATCHED_IDENTIFIERS_ERR_MSG.format(workspace_name=workspace_name, lakehouse_name=lakehouse_name))
        
        suffix = '' if Utils.is_guid(lakehouse_name) else '.Lakehouse'
        return f'abfss://{workspace_name}@{one_lake_endpoint}/{lakehouse_name}{suffix}/Tables'
    
    @staticmethod
    def get_fabric_files_path(workspace_name: str, one_lake_endpoint: str, lakehouse_name: str) -> str:
        if not Utils.is_valid_artifact_identifiers(workspace_identifier=workspace_name, artifact_identifier=lakehouse_name):
            raise ValueError(LoggingConstants.FABRIC_MISMATCHED_IDENTIFIERS_ERR_MSG.format(workspace_name=workspace_name, lakehouse_name=lakehouse_name))
        
        suffix = '' if Utils.is_guid(lakehouse_name) else '.Lakehouse'
        return f'abfss://{workspace_name}@{one_lake_endpoint}/{lakehouse_name}{suffix}/Files'
    
    @staticmethod
    def get_fabric_workload_files_root_path(workspace_name: str, one_lake_endpoint: str, solution_name: str) -> str:
        if not Utils.is_valid_artifact_identifiers(workspace_identifier=workspace_name, artifact_identifier=solution_name):
            raise ValueError(LoggingConstants.WORKLOAD_MISMATCHED_IDENTIFIERS_ERR_MSG.format(workspace_name=workspace_name, solution_name=solution_name))
        
        return f'abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}'
    
    @staticmethod
    def get_fabric_workload_files_vocab_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DATA_MANAGER_SAMPLE_DATA_FOLDER_ROOT}/{GlobalConstants.DEFAULT_OMOP_VOCABULARY_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_checkpoint_folder_path(root_path: str, checkpoint_folder_name: str) -> str:
        return f"{root_path}/{GlobalConstants.DATA_MANAGER_CHECKPOINT_FOLDER_ROOT}/{checkpoint_folder_name}"
    
    @staticmethod
    def get_fabric_workload_files_schema_root_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_SCHEMA_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_flatten_config_root_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_FLATTEN_CONFIG_DIR}"
    
    @staticmethod
    def get_fabric_workload_files_flatten_config_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_FLATTEN_CONFIG_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_nlp_config_root_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_NLP_CONFIG_DIR}"
    
    @staticmethod
    def get_fabric_workload_files_omop_config_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_OMOP_CONFIG_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_omop_scripts_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_OMOP_SCRIPTS_PATH}"
    
    @staticmethod
    def get_fabric_workload_dtt_file_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_DTT_FILE_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_rmt_mapping_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_RMT_MAPPING_FOLDER_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_dtt_secondary_lake_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_DTT_SECONDARY_LAKE_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_poa_dtt_secondary_lake_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_PATIENT_OUTREACH_DTT_SECONDARY_LAKE_PATH}"
    
    @staticmethod
    def get_key_vault_uri(kv_name: str) -> str:
        return f'https://{kv_name}.vault.azure.net/'
    
    @staticmethod
    def get_dmf_configuration_files(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_DMF_CONFIG_PATH}"
    
    @staticmethod
    def get_rmt_configuration_files(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_RMT_CONFIG_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_idm_config_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_IDM_CONFIG_PATH}"
    
    @staticmethod
    def get_fabric_workload_files_idm_dtt_secondary_lake_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_IDM_DTT_SECONDARY_LAKE_PATH}"
    
    @staticmethod
    def get_idm_dmf_configuration_files(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_IDM_DMF_CONFIG_PATH}"
    
    @staticmethod
    def get_idm_rmt_configuration_files(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_IDM_RMT_CONFIG_PATH}"
    
    @staticmethod
    def get_idm_environment_configuration_file(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_IDM_ENV_CONFIG_PATH}"
   
    @staticmethod
    def get_idm_fabric_workload_files_rmt_mapping_folder_path(root_path: str) -> str:
        return f"{root_path}/{GlobalConstants.DEFAULT_IDM_RMT_REFERENCE_DATA_FOLDER}"

    
