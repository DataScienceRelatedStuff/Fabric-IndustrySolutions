# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
"""
Module with a class is handling the archive files to extract and move them into temp folder.

"""
import io
import os
from pyspark.sql import SparkSession
import zipfile
from microsoft.fabric.hls.hds.medical_imaging.dicom.core.constants import ImagingStudyConstants as C
from microsoft.fabric.hls.hds.utils.utils import Utils as PlatformCommonUtil
from microsoft.fabric.hls.hds.medical_imaging.dicom.utils.utils import Utils
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants as GC
from concurrent.futures import ThreadPoolExecutor, as_completed

class ArchiveExtractHandler:
    """
    Module with a class is handling the archive files to extract and move them into temp folder.
    """    
    
    def __init__(self,  spark : SparkSession,
                        extract_current_date_path : str,
                        max_thread_size_archive_extract: int):
        
        self._spark = spark        
        self._extract_current_date_path = extract_current_date_path
        self._max_thread_size_archive_extract = max_thread_size_archive_extract
        self._logger = LoggingHelper.get_imaging_metadata_extraction_logger(
                    self._spark, self.__class__.__name__, GC.LOGGING_LEVEL)
    
    def begin_archive_extracts(self, archive_files_lst : list):

            hadoop_file_system = Utils.get_hadoop_filesystem(self._spark)
            results = []            
            
            with ThreadPoolExecutor(max_workers = C.MAX_THREAD_SIZE_ARCHIVE_FILES) as executor :
                for archive_file in archive_files_lst:        
                    
                    file_bytes = self._convert_to_bytes(archive_file.path)    
                    results.append(executor.submit(
                        self._extract_archive_file,
                        file_bytes,
                        self._extract_current_date_path,
                        archive_file.path,
                        hadoop_file_system))
            
            exceptions = []
            for future in as_completed(results):
                try:
                    future.result()
                except Exception as exc:                
                    exceptions.append(str(exc))
                else:
                    if future.result():
                        self._logger.info(LC.ARCHIVE_EXTRACT_FILES_INFO_MSG.format(
                            archive_file_name = future.result()['archive_filename'],
                            total_files_succeeded = future.result()['success_file_count'], 
                            failed = future.result()['failed_file_count']))
                    
            if exceptions:
                self._logger.error(LC.ARCHIVE_EXTRACT_FAILED_ERR_MSG.format(
                    archive_file_name= exceptions))
            
            if results :
                total_success_files_count = len(results) - len(exceptions)                
                self._logger.info(LC.ARCHIVE_EXTRACT_FILES_PROCESSED_INFO_MSG.format(                        
                        total_files_succeeded = f"{total_success_files_count}/{len(results)}", 
                        failed = f"{len(exceptions)}/{len(results)}"))
                if (exceptions) : raise

    def move_dcm_files(self, files_lst_dcm : list, max_thread_size_dcm_file : int):
        """
        This method moves dcm files from "drop folder" location to current year/month/day path

        Args:
            files_lst_dcm (list): list of files to be processed
            max_thread_size_dcm_file: maximum number of threads to span to move the dcm files from drop to target folder
        """        
        results = []
        with ThreadPoolExecutor(max_workers = max_thread_size_dcm_file) as executor:
            for file in files_lst_dcm:
                rename_target_filename = PlatformCommonUtil.join_path(self._extract_current_date_path, Utils.get_current_timestamp_in_utc() + "_" + file.name)
                results.append(executor.submit(
                    Utils.move_files,
                    file.path,
                    rename_target_filename,
                    True))
                
        exceptions = []
        for future in as_completed(results):  
            try:
                future.result()
            except Exception as exc:                
                exceptions.append(str(exc))
        
        if exceptions:
            self._logger.error(LC.DROP_FILES_MOVEMENT_FAILED_ERR_MSG.format(
                dcm_files= exceptions))        
        if results :
            total_success_files_count = len(results) - len(exceptions)                
            self._logger.info(LC.DROP_FILES_MOVEMENT_PROCESSED_INFO_MSG.format(                        
                    total_files_succeeded = f"{total_success_files_count}/{len(results)}", 
                    failed = f"{len(exceptions)}/{len(results)}"))

    def _extract_archive_file(self, file_bytes : io.BytesIO, directory_to_extract : str, archive_filename : str, file_system):
        
        with zipfile.ZipFile(file_bytes, "r") as zip_ref:
                        
            file_list = list(filter(lambda file_extension: file_extension.endswith('.dcm'), zip_ref.namelist()))
            #Handling zip files not having a single DCM file, return the below object.
            if not file_list : 
                return  {   "archive_filename": archive_filename,
                            "success_file_count": 0, 
                            "failed_file_count": 0
                        }
            
            results = []
            with ThreadPoolExecutor(max_workers = self._max_thread_size_archive_extract) as executor:
                for file_name in file_list:
                    results.append(executor.submit(
                        self.write_file,
                        zip_ref,
                        directory_to_extract,
                        file_name,
                        file_system))
                    
            exceptions = []
            for future in as_completed(results):  
                try:
                    future.result()
                except Exception as exc:                
                    exceptions.append(str(exc))
            
            if exceptions:
                self._logger.error(LC.ARCHIVE_EXTRACT_FAILED_ERR_MSG.format(
                    archive_file_name= exceptions))
            
            if results :
                total = len(results) - len(exceptions)
                archive_extraction_result = \
                                {   "archive_filename":archive_filename,
                                    "success_file_count": total, 
                                    "failed_file_count": len(exceptions)
                                }
        return archive_extraction_result

    def write_file(self, zip_ref, directory_to_write : str, file_name : str, file_system):    
        with zip_ref.open(file_name) as file:
            output_file_path = PlatformCommonUtil.join_path(directory_to_write, Utils.get_current_timestamp_in_utc() + "_" + str(os.path.basename(file_name)))
            output_stream = file_system.create(self._spark._jvm.org.apache.hadoop.fs.Path(output_file_path))
            output_stream.write(file.read())
            output_stream.close()
        return file_name

    def _convert_to_bytes(self,archive_file_path : str) -> io.BytesIO :            
        archive_file_binary = self._spark.sparkContext.binaryFiles(archive_file_path).values().collect()[0]
        archive_file_byte = io.BytesIO(bytearray(archive_file_binary))        
        return archive_file_byte