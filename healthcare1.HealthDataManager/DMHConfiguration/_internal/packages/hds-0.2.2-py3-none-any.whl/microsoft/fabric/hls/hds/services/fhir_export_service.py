# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import time
from http import HTTPStatus
from datetime import datetime, timedelta
import requests
from notebookutils import mssparkutils
from pyspark.sql import SparkSession
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter
from microsoft.fabric.hls.hds.utils.utils import Utils

telemetry_reporter = TelemetryReporter()

# Report FHIRExportService module import
telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
                                activity_name=GlobalConstants.FHIR_EXPORT_ACTIVITY_NAME)

class FHIRExportService:   
    def __init__(self, spark: SparkSession, key_vault: str, azure_function_url: str) -> None:
        """
            Args:
                - spark (SparkSession): The current Spark session
                - key_vault (str): The name of the key vault that contains the ExportFunctionKey
                - azure_function_url (str): The azure function URL
        """
        self.spark = spark
        self.key_vault = key_vault
        self.azure_function_url = azure_function_url
        self._logger = LoggingHelper.get_fhirexport_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL)

    def _get_function_secret(self) -> str:
        """
            Retrieves the ExportFunctionKey secret from a user-specified key vault.
        """
        token = mssparkutils.credentials.getSecret(self.key_vault, "ExportFunctionKey")
        return token
    
    def _trigger_azure_function(self) -> str:
        """
            Triggers a user-specified azure function and returns the status URL to monitor.
        """
        constructed_url = f"{self.azure_function_url}{self._get_function_secret()}"
        response = requests.get(constructed_url)
        self._logger.info(f"{LC.FHIREXPORTSERVICE_RESPONSE_INFO_MSG.format(trigger_type='Azure Function', code=response.status_code)}")
        if response.status_code == HTTPStatus.ACCEPTED:
            status_query_uri = response.headers['Location']
            return status_query_uri
        else:
            self._logger.error(f"{LC.FHIREXPORTSERVICE_TRIGGER_ERR_MSG.format(code=response.status_code)}")
            raise RuntimeError(f"{LC.FHIREXPORTSERVICE_TRIGGER_ERR_MSG.format(code=response.status_code)}")
    
    def _poll_http_call(self, status_query_uri: str, max_polling_days: int) -> None:
        """
            Polls a given status URL until a 202 response code is received or until
            max_polling_days days have passed.

            Args:
                - status_query_uri (str): the status URL of the orchestration instance
                - max_polling_days (int): the maximum number of days for polling
        """
        start_time = datetime.now()
        
        while True:
            current_time = datetime.now()
            elapsed_time = current_time - start_time

            if elapsed_time > timedelta(days=max_polling_days):
                self._logger.error(f"{LC.FHIREXPORTSERVICE_MAX_DURATION_ERR_MSG.format(max_days=max_polling_days)}")
                raise Exception(f"{LC.FHIREXPORTSERVICE_MAX_DURATION_ERR_MSG.format(max_days=max_polling_days)}")
            
            response = requests.get(status_query_uri)
            
            if response.status_code == HTTPStatus.OK:
                self._logger.info(f"{LC.FHIREXPORTSERVICE_RESPONSE_INFO_MSG.format(trigger_type='polling', code=response.status_code)}")
                self._logger.info(f"{LC.FHIREXPORTSERVICE_SUCCESS_INFO_MSG}")
                break
            elif response.status_code == HTTPStatus.ACCEPTED:
                self._logger.debug(f"{LC.FHIREXPORTSERVICE_IN_PROGRESS_DEBUG_MSG}")
            else:
                error_message = Utils.get_error_message(response)
                self._logger.error(f"{LC.FHIREXPORTSERVICE_POLLING_ERR_MSG.format(code=response.status_code, message=error_message)}")
                self._logger.error(f"{LC.FHIREXPORTSERVICE_FAILURE_ERR_MSG}")
                raise Exception(f"{LC.FHIREXPORTSERVICE_POLLING_ERR_MSG.format(code=response.status_code, message=error_message)}")
            time.sleep(10)
    
    def run_pipeline(self, max_days: int) -> None:
        """
            Triggers the FHIRExport pipeline.
        """
        # Report FHIR Export Service Usage
        telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
                                        activity_name=GlobalConstants.FHIR_EXPORT_ACTIVITY_NAME)
        
        status_query_uri = self._trigger_azure_function()
        
        try:
            # Start polling the status_query_uri. _poll_http_call will log the return code and break/raise an Exception 
            self._logger.info(f"{LC.FHIREXPORTSERVICE_TRIGGER_SUCCESS_INFO_MSG}")
            self._poll_http_call(status_query_uri, max_days)
        except Exception as e:
            # If the status_query_uri cannot be polled, run_pipeline will raise an exception
            self._logger.error(f"{LC.FHIREXPORTSERVICE_EXCEPTION_ERR_MSG.format(exception_message=e)}")
            raise Exception(f"{LC.FHIREXPORTSERVICE_EXCEPTION_ERR_MSG.format(exception_message=e)}")