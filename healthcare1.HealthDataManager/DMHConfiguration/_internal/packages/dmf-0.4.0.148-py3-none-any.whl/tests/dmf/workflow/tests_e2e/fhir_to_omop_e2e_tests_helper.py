from shutil import rmtree
from tempfile import mkdtemp
from tests.dmf.workflow.tests_e2e.dmf_e2e_common import DmfE2ECommon
from tests.utils.config_reduction import config_reduction
from pathlib import Path
from pyspark.sql.functions import date_add, col
from pyspark.sql import DataFrame
from typing import List
from pyspark.sql import SparkSession
from tests.utils.constants import Constants
from tests.conftest import transformation_spec_file_name

fhir_omop_target_tables_location = Constants.SINK_TABLES_ROOT / "omop"


class FhirToOmopE2ETestsHelper:
    def __init__(
            self,
            spark: SparkSession,
            transformation_spec_path: Path,
            env_config_file_path: Path,
            source_table: str,
            target_table: str,
            test_name: str,
            source_pk_field_name: str,
            format="delta",
    ):
        self.spark = spark
        self.source_table = source_table
        self.target_table = target_table
        self.source_pk_field_name = source_pk_field_name
        self.test_name = test_name
        self.format = format
        self.transformation_spec_path = transformation_spec_path
        self.env_config_file_path = env_config_file_path

    def __enter__(self):
        self.temp_dir = mkdtemp()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.temp_dir:
            rmtree(self.temp_dir)

    @staticmethod
    def reduced_transformation_spec_path(test_name: str) -> Path:
        return Constants.GENERATED_TRANSFORMATION_SPECS_ROOT / test_name / transformation_spec_file_name

    def reduce_transformation_spec(self,
                                   test_name: str,
                                   sources,
                                   source_fields_per_source=None,
                                   target_fields_per_source_field=None):
        reduced_path = self.reduced_transformation_spec_path(test_name)
        config_reduction.reduce_transformation_spec(
            json_path=self.transformation_spec_path,
            new_path=reduced_path,
            sources=sources,
            source_fields_per_source=source_fields_per_source,
            target_fields_per_source_field=target_fields_per_source_field
        )

    def generate_day_zero_df(
            self,
            records_pks: List[str]
    ) -> DataFrame:
        source_df = self.spark.read.format(self.format).load(str(Constants.FHIR_TABLES_LOCATION / self.source_table))
        return source_df.filter(col(self.source_pk_field_name).isin(records_pks))

    def generate_day_one_df(
            self,
            records_pks: List[str],
            bump_records_dates: bool = True
    ) -> DataFrame:
        source_df = self.spark.read.format(self.format).load(str(Constants.FHIR_TABLES_LOCATION / self.source_table))
        df = source_df.filter(col(self.source_pk_field_name).isin(records_pks))
        if bump_records_dates:
            df = df.withColumn("meta_lastUpdated", date_add("meta_lastUpdated", 1))
        return df

    def __get_target_df(self) -> DataFrame:
        path = str(Path(Constants.SINK_TABLES_ROOT) / "omop" / self.test_name / self.target_table)
        return self.spark.read.format(self.format).load(path)

    def simulate_day_zero_and_one_transactions(
            self,
            day_0_df: DataFrame,
            day_1_df: DataFrame,
            test_folder: str,
    ) -> DataFrame:
        if not self.temp_dir:
            return None

        day_0_data_location = Path(self.temp_dir) / "day_0"
        day_0_df.write.format(self.format).save(str(day_0_data_location / self.source_table))

        day_1_data_location = Path(self.temp_dir) / "day_1"
        day_1_df.write.format(self.format).save(str(day_1_data_location / self.source_table))

        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=self.spark,
            test_name=self.test_name,
            source_tables_location=day_0_data_location,
            target_tables_to_check=[],
            target_tables_location=fhir_omop_target_tables_location / self.test_name,
            env_config_file_path=self.env_config_file_path,
            test_folder=test_folder,
        )

        assert self.__get_target_df().count() == day_0_df.count(), "Target should contain the same count of records from day zero"

        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=self.spark,
            test_name=self.test_name,
            source_tables_location=day_1_data_location,
            target_tables_to_check=[],
            env_config_file_path=self.env_config_file_path,
            target_tables_location=fhir_omop_target_tables_location / self.test_name,
            test_folder=test_folder,
        )

        return self.__get_target_df()
