from typing import Dict

import pytest

from rmt.contract.configuration.internal.model_internal import ModelInternal


class TestModel:

    def test_model_reading(self):
        rmt_spec = {
            "source_domain": "aaa",
            "secondary_lake_location": "bbb",
            "reference_tables": [
                {
                    "table_name": "concept",
                    "key_field": "concept_id",
                    "name_field": "",
                    "columns": [
                        {
                            "name": "concept_id",
                            "type": "int",
                            "is_nullable": False
                        }
                    ]
                },
                {
                    "table_name": "ActivityType",
                    "key_field": "ActivityTypeId",
                    "name_field": "ActivityTypeName",
                    "columns": [
                        {
                            "name": "ActivityTypeId",
                            "type": "int",
                            "is_nullable": False
                        },
                        {
                            "name": "ActivityTypeName",
                            "type": "string",
                            "is_nullable": False
                        }
                    ]
                }
            ]
        }

        rmt_model = ModelInternal(**rmt_spec)

        assert rmt_model.source_domain == "aaa"
        assert rmt_model.secondary_lake_location == "bbb"
        assert isinstance(rmt_model.reference_tables, Dict)
        assert "concept" in rmt_model.reference_tables
        assert "ActivityType" in rmt_model.reference_tables

    def test_no_ref_tables(self):
        rmt_spec_no_ref_tables = {
            "source_domain": "aaa",
            "secondary_lake_location": "bbb"
        }

        with pytest.raises(Exception):
            ModelInternal(**rmt_spec_no_ref_tables)

    def test_model_no_source_domain(self):
        rmt_spec_no_source_domain = {
            "secondary_lake_location": "bbb",
            "reference_tables": [
                {
                    "table_name": "concept",
                    "key_field": "concept_id",
                    "name_field": "",
                    "columns": [
                        {
                            "name": "concept_id",
                            "type": "int",
                            "is_nullable": False
                        }
                    ]
                },
                {
                    "table_name": "ActivityType",
                    "key_field": "ActivityTypeId",
                    "name_field": "ActivityTypeName",
                    "columns": [
                        {
                            "name": "ActivityTypeId",
                            "type": "int",
                            "is_nullable": False
                        },
                        {
                            "name": "ActivityTypeName",
                            "type": "string",
                            "is_nullable": False
                        }
                    ]
                }
            ]
        }

        with pytest.raises(Exception):
            ModelInternal(**rmt_spec_no_source_domain)

        rmt_spec_null_source_domain = {
            "source_domain": None,
            "secondary_lake_location": "bbb",
            "reference_tables": [
                {
                    "table_name": "concept",
                    "key_field": "concept_id",
                    "name_field": "",
                    "columns": [
                        {
                            "name": "concept_id",
                            "type": "int",
                            "is_nullable": False
                        }
                    ]
                },
                {
                    "table_name": "ActivityType",
                    "key_field": "ActivityTypeId",
                    "name_field": "ActivityTypeName",
                    "columns": [
                        {
                            "name": "ActivityTypeId",
                            "type": "int",
                            "is_nullable": False
                        },
                        {
                            "name": "ActivityTypeName",
                            "type": "string",
                            "is_nullable": False
                        }
                    ]
                }
            ]
        }

        with pytest.raises(Exception):
            ModelInternal(**rmt_spec_null_source_domain)

    def test_model_no_secondary_lake_location(self):
        rmt_spec_no_secondary_lake_location = {
            "source_domain": "aaa",
            "reference_tables": [
                {
                    "table_name": "concept",
                    "key_field": "concept_id",
                    "name_field": "",
                    "columns": [
                        {
                            "name": "concept_id",
                            "type": "int",
                            "is_nullable": False
                        }
                    ]
                },
                {
                    "table_name": "ActivityType",
                    "key_field": "ActivityTypeId",
                    "name_field": "ActivityTypeName",
                    "columns": [
                        {
                            "name": "ActivityTypeId",
                            "type": "int",
                            "is_nullable": False
                        },
                        {
                            "name": "ActivityTypeName",
                            "type": "string",
                            "is_nullable": False
                        }
                    ]
                }
            ]
        }

        with pytest.raises(Exception):
            ModelInternal(**rmt_spec_no_secondary_lake_location)

        rmt_spec_null_secondary_lake_location = {
            "source_domain": "aaa",
            "secondary_lake_location": None,
            "reference_tables": [
                {
                    "table_name": "concept",
                    "key_field": "concept_id",
                    "name_field": "",
                    "columns": [
                        {
                            "name": "concept_id",
                            "type": "int",
                            "is_nullable": False
                        }
                    ]
                },
                {
                    "table_name": "ActivityType",
                    "key_field": "ActivityTypeId",
                    "name_field": "ActivityTypeName",
                    "columns": [
                        {
                            "name": "ActivityTypeId",
                            "type": "int",
                            "is_nullable": False
                        },
                        {
                            "name": "ActivityTypeName",
                            "type": "string",
                            "is_nullable": False
                        }
                    ]
                }
            ]
        }

        with pytest.raises(Exception):
            ModelInternal(**rmt_spec_null_secondary_lake_location)
