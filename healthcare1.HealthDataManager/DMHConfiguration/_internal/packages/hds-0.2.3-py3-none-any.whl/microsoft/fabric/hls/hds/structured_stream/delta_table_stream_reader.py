from pyspark.sql import SparkSession, DataFrame

class DeltaTableStreamReader:

    """
    DeltaTable Stream Reader service for reading a delta table using spark structured streaming 
    """

    def __init__(self,
    spark: SparkSession, **kwargs):

        """
        Initialize DeltaTableStreamReader
        Args:
            - kwargs: dict - An optional dictionary of options to be set on the stream. See here for a list of options available - https://docs.databricks.com/structured-streaming/delta-lake.html
                - maxBytesPerTrigger: int - maximum number of bytes to be considered in every trigger
                - ignoreChanges: str - true or false to indicate whether to throw exception on data modifiying changes
        """

        self.spark = spark
        self.kwargs = kwargs

    def set_up_streaming(self, delta_table_path:str) -> DataFrame:
        """
        Set up streaming on a delta table

        Args:
            - delta_table_path: The path to the delta table
        Returns: 
            - A streaming Dataframe
        """
        delta_table_streaming_df = self.spark.readStream.format("delta")
        for option, value in self.kwargs.items():
            delta_table_streaming_df = delta_table_streaming_df.option(option, value)

        return delta_table_streaming_df.load(delta_table_path)
