# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import json
import concurrent.futures
from notebookutils import mssparkutils
from pyspark.sql import DataFrame, SparkSession, functions as f, types as T
from microsoft.fabric.hls.hds.errors.bronze_ingestion_failed_error import BronzeIngestionFailedError
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.dataframe_utils import append_to_delta_table_using_path
from microsoft.fabric.hls.hds.structured_stream.file_stream_reader import FileStreamReader
from microsoft.fabric.hls.hds.structured_stream.stream_orchestrator import StreamOrchestrator
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import LoggingConstants as LC
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter

telemetry_reporter = TelemetryReporter()

# Report BronzeIngestionService module import
telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
                                activity_name=GlobalConstants.BRONZE_INGESTION_ACTIVITY_NAME)

class BronzeIngestionService:
    def __init__(self, 
                 spark: SparkSession,
                 workspace_name: str,
                 solution_name: str,
                 target_lakehouse_name: str,
                 **kwargs) -> None:
        """
        Args:
            - spark: spark session
            - workspace_name: Name of the Fabric Workspace
            - solution_name: Name of the HDS-Healthcare data solutions OneLake workload solution
            - target_lakehouse_name (str): The lakehouse name of where the target tables are located
            - **kwargs (dict): An optional dictionary that customer can use to configure the bronze_ingestion service
                - max_files_per_trigger (int): maximum number of new files to be considered in every trigger.
                - source_path_pattern (variable): The pattern to use for monitoring source folders. Default will be the landing zone contract paths under `abfss://{workspace_name}@{one_lake_endpoint}/{target_lakehouse_name}.Lakehouse/Files/landing_zone/**/**/**/{resource_name}`
                - checkpoint_path (str): the Files path to where the checkpoint files will be located. Default will be 'abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/{target_lakehouse_name}`
                - schemafile_path (str): the Files path to where the schema files will be located. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/fhir4_3/schema`
                - target_tables_path (str): The path to the bronze tables. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{target_lakehouse_name}.Lakehouse/Tables`
                - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
        """
        self.spark: SparkSession = spark
        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.target_lakehouse_name = target_lakehouse_name
        self.one_lake_endpoint = kwargs.get("one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT)
        self._logger = LoggingHelper.get_bronzeingestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )
        self.max_files_per_trigger = kwargs.get(
            "maxFilesPerTrigger",
            GlobalConstants.DEFAULT_NUMBER_OF_FILES_PER_TRIGGER_BRONZE,
        )
        try:
            self.config_files_root_path = FolderPath.get_fabric_workload_files_root_path(workspace_name=self.workspace_name,
                                                                                        one_lake_endpoint=self.one_lake_endpoint,
                                                                                        solution_name=self.solution_name)
            self.target_tables_path = kwargs.get(
                "target_tables_path",
                FolderPath.get_fabric_tables_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    lakehouse_name=self.target_lakehouse_name
                ),
            )
            self._logger = LoggingHelper.get_bronzeingestion_logger(
                self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
            )
            self.source_path_pattern = kwargs.get(
                "source_path_pattern",
                f"{FolderPath.get_fabric_files_path(workspace_name=self.workspace_name, one_lake_endpoint=self.one_lake_endpoint, lakehouse_name=self.target_lakehouse_name)}/{GlobalConstants.DEFAULT_LANDINGZONE_SOURCE_PATTERN}",
            )
            self.checkpoint_path = kwargs.get(
                "checkpoint_path",
                FolderPath.get_fabric_workload_files_checkpoint_folder_path(root_path=self.config_files_root_path,
                                                                            checkpoint_folder_name=self.target_lakehouse_name)
            )
            self.schemafile_path = kwargs.get(
                "schemafile_path",
                FolderPath.get_fabric_workload_files_schema_root_folder_path(root_path=self.config_files_root_path),
            )
            
            self._validate_args()
        except Exception as ex:
            self._logger.error(message=str(ex))
            raise

    def ingest(self) -> None:
        """
        After getting a list of supported resource types/schemas, iterate through the list
        and set up streaming on each of those resources
        """
        # Report Raw to Bronze Ingestion Pipeline Usage
        telemetry_reporter.report_usage(feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
                                        activity_name=GlobalConstants.BRONZE_INGESTION_ACTIVITY_NAME)
        
        self._logger.info(f"{LC.BRONZE_INGESTION_START_INFO_MSG}")
        streaming_queries = []
        resources_with_no_data = {}
        # returns resources to monitor
        resources_to_stream = self.get_resource_schemas()
        self._logger.info(
            f"{LC.BRONZE_INGEST_RSC_LIST_INFO_MSG.format(resources_to_stream.keys())}"
        )
        # initializes the FileStreamReader
        file_stream_reader = FileStreamReader(self.spark)
        for actual_rsc, schema_obj in resources_to_stream.items():
            # the path to set up streaming on
            streaming_path = self.source_path_pattern.replace(
                "<resource_name>", actual_rsc
            )

            # If there is no data in the streaming, create empty bronze tables
            # else start streaming on the path
            if not Utils.is_files_in_path(spark=self.spark, path=streaming_path):
                self._logger.info(
                    f"{LC.BRONZE_INGESTION_PATH_NOT_FOUND_INFO_MSG.format(path=streaming_path, resource_name=actual_rsc)}"
                )
                resources_with_no_data[actual_rsc.lower()] = schema_obj
            else:
                self._logger.info(
                    f"{LC.SET_STRUCTURED_STREAMING_INFO_MSG.format(streaming_path)}"
                )
                df = file_stream_reader.set_up_streaming_json(
                    schema_obj,
                    streaming_path,
                    maxFilesPerTrigger=self.max_files_per_trigger,
                )
                rsc_query = self.start_streaming(df, actual_rsc.lower())
                streaming_queries.append(rsc_query)

        if resources_with_no_data:
            self._create_empty_bronze_tables(resources_with_no_data)

        stream_orchestrator = StreamOrchestrator(self.spark)
        stream_orchestrator.await_all_termination(streaming_queries)

        self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")

    def _validate_args(self) -> None:
        """
        Validate bronze ingestion service arguments
        """
        
        # source_path_pattern must have <resource_name> in the string
        if "<resource_name>" not in self.source_path_pattern:
            raise ValueError(f"{LC.INVALID_ARGUMENT} {LC.BRONZE_SOURCE_PATH_PATTERN_MUST_CONTAIN_SUBSTRING}")
    
    def _create_empty_bronze_tables(self, resources_with_no_data: dict):
        """Create empty bronze tables in bronze_lakehouse

        Args:
            resources_with_no_data (dict): A key-value pair consisting of resource name and its' schema, {"resource_name":schema_obj}
        """
        self._logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")
        futures = []

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=len(resources_with_no_data)
        ) as executor:
            for resource_name, schema in resources_with_no_data.items():
                # create empty dataframe with schema
                if self.spark.catalog.tableExists(
                    resource_name, self.target_lakehouse_name
                ):
                    self._logger.info(
                        f"{LC.TABLE_EXISTS.format(table_name=resource_name, lakehouse=self.target_lakehouse_name)}"
                    )
                    continue
                empty_df = self.spark.createDataFrame([], schema)
                futures.append(
                    executor.submit(
                        append_to_delta_table_using_path,
                        df_to_process=empty_df,
                        delta_table_path=f"{self.target_tables_path}/{resource_name}",
                        logger=self._logger,
                    )
                )
            exceptions = []
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()
                except Exception as ex:
                    exceptions.append(ex)

            if exceptions:
                raise BronzeIngestionFailedError(
                    f"{LC.CREATING_EMPTY_TABLES_ERR_MSG.format(lakehouse=self.target_tables_path,exception_details=exceptions)}"
                )

        self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")

    def _load_schema_file(self, schema_fullpath: str) -> list:
        """
        Given the path to a schema, load the schema and return the resource type and schema object

        Args:
            schema_fullpath (str): the path to the schema
        """
        self._logger.info(
            f"{LC.BRONZE_INGESTION_START_LOAD_INFO_MSG.format(path=schema_fullpath)}"
        )
        schema_content = self.spark.sparkContext.wholeTextFiles(
            schema_fullpath
        ).collect()[0][1]
        parsed_schema = self.spark._jvm.org.apache.avro.Schema.Parser().parse(
            str(schema_content)
        )

        # Get the "name" value from the dictionary
        parsed_json = json.loads(str(parsed_schema))
        name_value = parsed_json["name"]

        java_schema_type = (
            self.spark._jvm.org.apache.spark.sql.avro.SchemaConverters.toSqlType(
                parsed_schema
            )
        )  # type: ignore

        json_schema = json.loads(java_schema_type.dataType().json())
        return [name_value, T.StructType.fromJson(json_schema)]  # type: ignore

    def get_resource_schemas(self) -> dict:
        """
        Retrieve all supported schemas in the global schema path and its corresponding resource type
        """
        resource_schemas = dict()
        self._logger.info(
            f"{LC.BRONZE_INGESTION_START_LOAD_INFO_MSG.format(path=self.schemafile_path)}"
        )
        resource_files = mssparkutils.fs.ls(f"{self.schemafile_path}")

        for file_info in resource_files:
            # Return schema object and type retrieved from schema
            schema_list = self._load_schema_file(file_info.path)
            resource_type = schema_list[0]
            schema_obj = schema_list[1]
            # Add to the list of found schemas
            resource_schemas[resource_type] = schema_obj
        self._logger.info(f"{LC.BRONZE_INGESTION_END_LOAD_INFO_MSG}")
        return resource_schemas

    def start_streaming(self, df, resource_name):
        """
        The query to start the ingestion into bronze. Meant to be run in notebook

        Args:
            df (DataFrame): the DataFrame passed from the initial ingest call
            epochId (provided): the unique identifier to ensure fault-tolerance. This value is provided.
            resource_name (str): the name of the resource to target
        Returns:
            StreamingQuery: a query object for each resource
        """
        self._logger.info(f"{LC.INGESTION_START_STREAM_INFO_MSG.format(resource_name)}")
        query = (
            df.writeStream.format("delta")
            .trigger(availableNow=True)
            .option("checkpointLocation", f"{self.checkpoint_path}/{resource_name}")
            .foreachBatch(
                lambda df, epochId: self._filter_by_resource_type_if_exists_and_append_to_delta_table_using_path(
                    df=df, resource_name=resource_name
                )
            )
            .queryName(f"bronze.{resource_name}")
            .start()
        )
        return query

    def _filter_by_resource_type_if_exists_and_append_to_delta_table_using_path(
        self, df: DataFrame, resource_name: str
    ):
        """
        Filter given dataframe by resource type to ensure all the resources in the dataframe are of the same type
        Append the result to the appropriate delta table
        Args:
            df (DataFrame): the DataFrame to filter and ingest
            resource_name (str): the name of the resource to target
        """
        self._logger.info(LC.BEGAN_EXECUTION_INFO_MSG)

        listColumns = df.columns
        if GlobalConstants.RESOURCE_TYPE in listColumns:
            self._logger.info(
                f"{LC.FILTERING_BRONZE_DF_ON_RESOURCE_TYPE_INFO_MSG.format(resource_name = resource_name)}"
            )
            df = df.filter(f.lower(GlobalConstants.RESOURCE_TYPE) == resource_name.lower())

        # append dataframe to delta table
        append_to_delta_table_using_path(
            df_to_process=df,
            delta_table_path=f"{self.target_tables_path}/{resource_name}",
            logger=self._logger,
        )
