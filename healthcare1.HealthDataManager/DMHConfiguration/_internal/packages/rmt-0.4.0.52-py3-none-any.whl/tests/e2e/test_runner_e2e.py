import json
import os
import tempfile
from typing import List

import pytest
from pyspark.sql import DataFrame

from tests.common.test_case_common import TestCaseCommon
from tests.common.tester_runner import TesterRunner
from tests.conftest import TESTS_ROOT_DIR

rmt_spec_path = TESTS_ROOT_DIR / "data" / "rmt_spec" / "rmt_spec.json"


@pytest.fixture(scope="module")
def target_path():
    return tempfile.mkdtemp()


class TestRunnerE2E:
    @staticmethod
    def _run_with_local_runner_and_mapping_definitions_folder_names(
        spark, test_name: str, folder_names: List[str], delete=True, number_of_partition_files: int = -1
    ) -> DataFrame:
        if delete:
            TestCaseCommon.clean_mapping_output_for_test(test_name)
        if not os.path.exists(TestCaseCommon.mapping_output_path_by_test_name(test_name)):
            os.makedirs(TestCaseCommon.mapping_output_path_by_test_name(test_name))

        mapping_definitions_folders = [
            os.path.join(TESTS_ROOT_DIR, "data", "mapping_definitions", folder_name) for folder_name in folder_names
        ]
        rmt_spec_path = os.path.join(TESTS_ROOT_DIR, "data", "rmt_spec", "rmt_spec.json")

        TesterRunner(spark, test_name, rmt_spec_path).create_reference_values_mapping(
            mapping_definitions_folders, number_of_partition_files
        )
        return spark.read.format("delta").load(TestCaseCommon.mapping_output_path_by_test_name(test_name))

    def test_e2e_with_2_mapping_definition_and_2_overrides_and_optional_paramaters(self, spark):
        mapping_dataframe = TestRunnerE2E._run_with_local_runner_and_mapping_definitions_folder_names(
            spark=spark,
            test_name="test_e2e_with_2_mapping_definition_and_2_overrides",
            folder_names=["concept_query_and_gender_values", "concept_values", "gender_values2"],
            delete=True,
            number_of_partition_files=1,
        )
        assert mapping_dataframe.count() == 20

    def test_write_reference_mapping_e2e(self, spark, target_path):
        data_root_folder = TESTS_ROOT_DIR / "data" / "reference_tables_data_integration" / "Common"
        TesterRunner(spark, "test_write_reference_mapping_e2e", rmt_spec_path).create_reference_data_tables(
            target_path, [data_root_folder]
        )
        # check PartyType table
        party_type_df = spark.read.format("delta").load(os.path.join(target_path, "PartyType"))
        with open(data_root_folder / "PartyType.json", encoding="utf-8") as f:
            party_type_json_data = json.load(f)
        df_data_dict = {
            r.PartyTypeId: r.PartyTypeName for r in party_type_df.select("PartyTypeId", "PartyTypeName").collect()
        }
        json_data_dict = {r["id"]: r["name"] for r in party_type_json_data["data"]}
        assert df_data_dict == json_data_dict
        # check ProcessType table
        process_type_df = spark.read.format("delta").load(os.path.join(target_path, "ProcessType"))
        with open(data_root_folder / "ProcessType.json", encoding="utf-8") as f:
            process_type_json_data = json.load(f)
        df_data_dict = {
            r.ProcessTypeId: r.ProcessTypeName
            for r in process_type_df.select("ProcessTypeId", "ProcessTypeName").collect()
        }
        json_data_dict = {r["id"]: r["name"] for r in process_type_json_data["data"]}
        assert df_data_dict == json_data_dict
