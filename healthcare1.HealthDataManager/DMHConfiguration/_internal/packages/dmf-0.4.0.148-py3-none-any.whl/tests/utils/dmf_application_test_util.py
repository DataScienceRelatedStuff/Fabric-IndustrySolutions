import traceback
from pathlib import Path

from pyspark.sql import SparkSession
from dmf.model.data_feed_configuration import DataFeedConfiguration
from dmf.utils.common import Common
from dmf.logging import Logger
from dmf.workflow.dmf_application import DMFApplication
from dmf.utils.global_constants import GlobalConstants
from tests.utils.constants import Constants
from tests.utils.envcompile.env_compiler import EnvCompiler


class DMFApplicationTestUtil:

    @staticmethod
    def generate_config_from_file(spark: SparkSession,
                                  transformation_spec_file_location: Path,
                                  env_config_file_path: Path,
                                  source_tables_location: Path,
                                  target_tables_location: Path = Constants.SINK_TABLES_ROOT) -> DataFeedConfiguration:
        try:
            dmf_contract_str_compiled = DMFApplicationTestUtil._compile_config_from_path(spark,
                                                                                         transformation_spec_file_location,
                                                                                         env_config_file_path,
                                                                                         source_tables_location,
                                                                                         target_tables_location)
            config = DataFeedConfiguration.from_str(dmf_contract_str_compiled)
        except Exception as e:
            Logger.error(f"an error accrued while parsing the contract file.{e}")
            Logger.error(traceback.format_exc())
            raise

        return config

    @staticmethod
    def _compile_config_from_path(spark: SparkSession,
                                  transformation_spec_file_location: Path,
                                  env_config_file_path: Path,
                                  source_tables_location: Path,
                                  target_tables_location: Path) -> str:
        try:
            transformation_spec_content = Common.read_configuration_file(transformation_spec_file_location)
            env_config_str = Common.read_configuration_file(env_config_file_path)

            env_config_str = env_config_str.replace("MOCK_SOURCE_LOCATION", str(source_tables_location))
            env_config_str = env_config_str.replace("MOCK_TARGET_LOCATION", str(target_tables_location))
            env_config_str = env_config_str.replace("MOCK_SECONDARY_LAKE_LOCATION", spark.conf.get(
                GlobalConstants.SPARK_CONFIG_SECONDARY_LAKE_ROOT_VARIABLE))
            return EnvCompiler.compile(transformation_spec_content, env_config_str)
        except Exception as e:
            Logger.error(f"an error accrued while compiling the contract file.{e}")
            Logger.error(traceback.format_exc())
            raise

    @staticmethod
    def start_dmf(config: DataFeedConfiguration, spark: SparkSession):
        DMFApplication._start(config, spark)

    @staticmethod
    def start_from_transformation_spec(spark: SparkSession,
                                       transformation_spec_file_location: Path,
                                       env_config_file_path: Path,
                                       source_tables_location: Path,
                                       target_tables_location: Path = Constants.SINK_TABLES_ROOT):
        """This method starts dmf. requires all configuration files paths on a local accessible file system
        """
        config = DMFApplicationTestUtil.generate_config_from_file(
            spark, transformation_spec_file_location, env_config_file_path, source_tables_location,
            target_tables_location)

        DMFApplication._start(config, spark)
