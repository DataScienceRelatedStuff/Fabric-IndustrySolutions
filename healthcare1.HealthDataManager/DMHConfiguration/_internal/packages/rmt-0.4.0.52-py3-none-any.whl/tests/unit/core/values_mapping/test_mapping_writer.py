from rmt.core.values_mapping.mapping_schema import MappingSchema
from rmt.core.values_mapping.mapping_writer import MappingWriter
from tests.common.test_case_common import TestCaseCommon


class TestMappingWriter:
    data = [
        (
            "HLC",
            "source_value_1",
            "concept",
            "conceptId",
            1,
        ),
        (
            "HLC",
            "source_value_2",
            "concept",
            "conceptId",
            2,
        ),
        (
            "HLC",
            "source_value_3",
            "concept",
            "conceptId",
            3,
        ),
    ]

    def test_overwrite(self, spark):
        mapping_output_full_path = TestCaseCommon.mapping_output_path_by_test_name("test_overwrite")
        TestCaseCommon.clean_mapping_output_for_test("test_overwrite")
        mapping_df = spark.createDataFrame(self.data, MappingSchema.schema)
        MappingWriter.overwrite(mapping_df, mapping_output_full_path)
        df = spark.read.format("delta").load(mapping_output_full_path)
        assert df.count() == 3
        assert (
            df.where(f"{MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN} == 'HLC'").count()
            == 3
        )
        assert (
            df.where(
                f"{MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE} == 'source_value_1'"
            ).count()
            == 1
        )

    def test_overwrite_with_number_of_files(self, spark):
        mapping_output_full_path = TestCaseCommon.mapping_output_path_by_test_name("test_overwrite_with_number_of_files")
        TestCaseCommon.clean_mapping_output_for_test("test_overwrite")
        mapping_df = spark.createDataFrame(self.data, MappingSchema.schema)
        MappingWriter.overwrite(mapping_df, mapping_output_full_path, 1)
        df = spark.read.format("delta").load(mapping_output_full_path)
        assert df.count() == 3
        assert (
            df.where(f"{MappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN} == 'HLC'").count()
            == 3
        )
        assert (
            df.where(
                f"{MappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE} == 'source_value_1'"
            ).count()
            == 1
        )
        TestCaseCommon.assert_number_of_partition_files(mapping_output_full_path, "HLC", "concept", 1)
