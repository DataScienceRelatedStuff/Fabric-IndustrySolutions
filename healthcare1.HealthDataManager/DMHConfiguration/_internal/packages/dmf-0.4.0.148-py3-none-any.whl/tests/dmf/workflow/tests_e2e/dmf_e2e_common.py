from pathlib import Path
from typing import List, Optional
import uuid
from project_root import PROJECT_ROOT_DIR
from pyspark.sql import SparkSession
from tests.utils.dmf_application_test_util import DMFApplicationTestUtil
from tests.conftest import transformation_spec_file_name


class DmfE2ECommon:

    @staticmethod
    def run_e2e_on_storage(spark,
                           transformation_spec_path: Path,
                           target_tables_to_check: List[str],
                           source_tables_location: Path,
                           target_tables_location: Path,
                           env_config_file_path: Path,
                           test_name: str = str(uuid.uuid4())
                           ) -> str:

        DMFApplicationTestUtil. \
            start_from_transformation_spec(spark=spark, transformation_spec_file_location=transformation_spec_path,
                                           env_config_file_path=env_config_file_path,
                                           source_tables_location=source_tables_location,
                                           target_tables_location=target_tables_location)
        for target_table_name in target_tables_to_check:
            target_df = spark.read.format("delta").load(str(target_tables_location / target_table_name))
            assert target_df.count() > 0, f"Target table {target_table_name} is empty"
        return test_name

    @staticmethod
    def run_e2e_storage_and_test_name(spark: SparkSession,
                                      test_name: str,
                                      target_tables_to_check: Optional[List[str]],
                                      source_tables_location: Path,
                                      target_tables_location: Path,
                                      env_config_file_path: Path,
                                      test_folder=None) -> str:

        if target_tables_to_check is None:
            target_tables_to_check = []
        if test_folder is None:
            test_folder = Path(PROJECT_ROOT_DIR) / 'tests' / 'dmf' / 'workflow' / 'tests_e2e'
        transformation_spec_path = DmfE2ECommon.override_transformation_spec_by_test_folder_path(test_folder / test_name)
        return DmfE2ECommon.run_e2e_on_storage(spark, transformation_spec_path, target_tables_to_check,
                                               source_tables_location, target_tables_location, env_config_file_path,
                                               test_name)

    @staticmethod
    def override_transformation_spec_by_test_folder_path(test_folder_path: Path) -> Path:
        transformation_spec_path = None
        for file in test_folder_path.iterdir():
            if file.name == transformation_spec_file_name:
                transformation_spec_path = test_folder_path / file
        return transformation_spec_path
