import os
import tempfile

import pytest
from pyspark.sql import Row
from pyspark.sql.types import IntegerType, StringType, StructField, StructType

from rmt.contract.configuration.reference_table import ReferenceTable, TableColumn
from rmt.core.tables_creating.model.internal import ReferenceTableData, ReferenceTableFieldMapping
from rmt.core.tables_creating.reference_tables_writer import ReferenceTablesWriter


@pytest.fixture(scope="function")
def target_path():
    return tempfile.mkdtemp()


table_name = "reftable1"
key_field = "TypeId"
name_field = "TypeName"
field_mapping = [
    ReferenceTableFieldMapping(referenceFieldName="col1", adrmFieldName=key_field),
    ReferenceTableFieldMapping(referenceFieldName="col2", adrmFieldName=name_field),
]


@pytest.fixture(scope="function")
def ref_table1_data():
    return ReferenceTableData(
        adrmTableName=table_name,
        data=[{"col1": 1, "col2": "one"}, {"col1": 2, "col2": "two"}],
        fieldMapping=field_mapping,
    )


@pytest.fixture(scope="function")
def ref_table11_data():
    return ReferenceTableData(
        adrmTableName=table_name,
        data=[{"col1": 3, "col2": "three"}, {"col1": 4, "col2": "four"}],
        fieldMapping=field_mapping,
    )


ref_tables = {
    table_name: ReferenceTable(
        table_name=table_name,
        key_field=key_field,
        name_field=name_field,
        columns=[
            TableColumn(name=key_field, type=IntegerType(), is_nullable=False),
            TableColumn(name=name_field, type=StringType(), is_nullable=False),
        ],
    )
}


class TestReferenceTablesWriter:
    def test_rows_are_written_in_correct_schema_and_format(self, spark, target_path, ref_table1_data, ref_table11_data):
        ref_tables_data = {table_name: [ref_table1_data]}
        writer = ReferenceTablesWriter(spark, ref_tables_data, ref_tables, target_path)
        writer.overwrite()
        df = self._read_ref_table(spark, os.path.join(target_path, table_name))
        assert df.schema == StructType([StructField(key_field, IntegerType()), StructField(name_field, StringType())])
        assert sorted(df.collect()) == sorted([Row(TypeId=1, TypeName="one"), Row(TypeId=2, TypeName="two")])

    def test_rows_are_merged_from_two_tables(self, spark, target_path, ref_table1_data, ref_table11_data):
        ref_tables_data = {table_name: [ref_table1_data, ref_table11_data]}
        writer = ReferenceTablesWriter(spark, ref_tables_data, ref_tables, target_path)
        writer.overwrite()
        df = self._read_ref_table(spark, os.path.join(target_path, table_name))
        assert df.schema == StructType([StructField(key_field, IntegerType()), StructField(name_field, StringType())])
        assert sorted(df.collect()) == sorted(
            [
                Row(TypeId=1, TypeName="one"),
                Row(TypeId=2, TypeName="two"),
                Row(TypeId=3, TypeName="three"),
                Row(TypeId=4, TypeName="four"),
            ]
        )

    def test_rows_are_overwritten_every_write(self, spark, target_path, ref_table1_data, ref_table11_data):
        ref_tables_data = {table_name: [ref_table1_data, ref_table11_data]}
        writer = ReferenceTablesWriter(spark, ref_tables_data, ref_tables, target_path)
        writer.overwrite()
        df = self._read_ref_table(spark, os.path.join(target_path, table_name))
        assert sorted(df.collect()) == sorted(
            [
                Row(TypeId=1, TypeName="one"),
                Row(TypeId=2, TypeName="two"),
                Row(TypeId=3, TypeName="three"),
                Row(TypeId=4, TypeName="four"),
            ]
        )
        # change the data and write again
        # remove the last row
        ref_table11_data.data = ref_table11_data.data[:-1]
        ref_tables_data = {table_name: [ref_table1_data, ref_table11_data]}
        writer = ReferenceTablesWriter(spark, ref_tables_data, ref_tables, target_path)
        writer.overwrite()
        df = self._read_ref_table(spark, os.path.join(target_path, table_name))
        assert sorted(df.collect()) == sorted(
            [
                Row(TypeId=1, TypeName="one"),
                Row(TypeId=2, TypeName="two"),
                Row(TypeId=3, TypeName="three"),
            ]
        )

    def _read_ref_table(self, spark, target_path: str):
        return spark.read.format("delta").load(target_path)
