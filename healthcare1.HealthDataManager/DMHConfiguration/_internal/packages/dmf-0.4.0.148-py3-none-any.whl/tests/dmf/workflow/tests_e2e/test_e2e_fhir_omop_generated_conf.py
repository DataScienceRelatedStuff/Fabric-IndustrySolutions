from pandas import DataFrame
import pytest
from pathlib import Path
from dmf.utils.global_constants import GlobalConstants
from project_root import PROJECT_ROOT_DIR
from tests.utils.config_reduction import config_reduction
from tests.utils.constants import Constants
from tests.dmf.workflow.tests_e2e.dmf_e2e_common import DmfE2ECommon
from tests.conftest import reference_mapping_data_path


class TestE2EFhirOmopGeneratedConf:
    def _assert_target_dataframe_field(self, spark, test_name: str, target_table_name: str, target_field_name: str):
        target_data_location = Constants.SINK_TABLES_ROOT / "omop" / test_name
        target_df = spark.read.format("delta").load(str(target_data_location / target_table_name))
        target_df = target_df.select(target_field_name)
        assert target_df.count() > 0

    def reduced_config_path(self, test_name: str) -> Path:
        return Constants.GENERATED_TRANSFORMATION_SPECS_ROOT / test_name / "ts.json"

    def reduce_config(
        self,
        test_name: str,
        sources,
        fhir_omop_ts_file_path: Path,
        source_fields_per_source=None,
        target_fields_per_source_field=None,
    ):
        reduced_path = self.reduced_config_path(test_name)
        config_reduction.reduce_transformation_spec(
            json_path=fhir_omop_ts_file_path,
            new_path=reduced_path,
            sources=sources,
            source_fields_per_source=source_fields_per_source,
            target_fields_per_source_field=target_fields_per_source_field,
        )

    @pytest.mark.long
    def test_e2e_condition_on_primary_key(
        self, spark, fhir_omop_env_config_path, fhir_omop_dmf_transformation_spec_path
    ):
        test_name = "condition_on_primary_key"
        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name
        self.reduce_config(
            test_name,
            sources=["Patient", "PatientAddress"],
            fhir_omop_ts_file_path=fhir_omop_dmf_transformation_spec_path,
            source_fields_per_source={"Patient": ["p_id", "addressId", "deceasedDate"]},
            target_fields_per_source_field={
                "Patient": {
                    "p_id": [("person", "person_id"), ("death", "person_id")],
                    "addressId": [("location", "location_id")],
                    "deceasedDate": [("death", "death_date")],
                }
            },
        )

        fhir_tables_location = Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "parquet"
        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=spark,
            test_name=test_name,
            source_tables_location=fhir_tables_location,
            target_tables_location=target_data_location,
            target_tables_to_check=["person", "death"],
            test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT,
            env_config_file_path=fhir_omop_env_config_path,
        )

        patient_df = spark.read.format("delta").load(str(fhir_tables_location / "Patient"))
        person_df = spark.read.format("delta").load(str(target_data_location / "person"))
        assert person_df.count() == patient_df.count(), "persons count should be equal to patients count"
        death_df = spark.read.format("delta").load(str(target_data_location / "death"))
        dead_patients_ids_df = patient_df.where("isnotnull(deceased_dateTime)").select("id")
        # fix to read with test folder
        person_mapping_df = spark.read.format("delta").load(
            str(Path(spark.conf.get("spark.sql.warehouse.dir")) / GlobalConstants.ID_MAPPING_PATH / "PERSON_ID_MAPPING")
        )
        adrm_dead_person_ids = dead_patients_ids_df.join(
            person_mapping_df, on=person_mapping_df.INTERNAL_ID == dead_patients_ids_df.id, how="inner"
        ).select("ADRM_ID")
        assert set(row.person_id for row in death_df.select("person_id").collect()) == set(
            row.ADRM_ID for row in adrm_dead_person_ids.select("ADRM_ID").collect()
        ), "persons ids in death table should be equal to dead patients ids"

    @pytest.mark.long
    def test_e2e_fhir_omop_no_partitions(
        self, spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path
    ):
        test_name = "no_partitions"
        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name
        # key_mapping_location = Constants.SPARK_WAREHOUSE_LOCATION  / "key_mapping"

        self.reduce_config(
            test_name,
            fhir_omop_ts_file_path=fhir_omop_dmf_transformation_spec_path,
            sources=["Observation"],
            source_fields_per_source={
                "Observation": [
                    "id_calc",
                    "code_coding_code",
                    "observation_datetime",
                    "observation_date" "value_quantity_value_calc",
                    "value_quantity_unit",
                ]
            },
            target_fields_per_source_field={
                "Observation": {
                    "id_calc": [("observation", "observation_id")],
                    "code_coding_code": [("observation", "observation_source_value")],
                    "observation_datetime": [("observation", "observation_datetime")],
                    "observation_date": [("observation", "observation_date")],
                    "value_quantity_value_calc": [("observation", "value_as_number")],
                    "value_quantity_unit": [("observation", "unit_source_value")],
                }
            },
        )

        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=spark,
            test_name=test_name,
            target_tables_to_check=["observation"],
            source_tables_location=Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "parquet",
            target_tables_location=target_data_location,
            env_config_file_path=fhir_omop_env_config_path,
            test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT,
        )

    def test_e2e_fhir_omop_modified_field_to_different_target_tables(
        self, spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path
    ):
        test_name = "modified_field_to_different_target_tables"
        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name
        # key_mapping_location = Constants.SPARK_WAREHOUSE_LOCATION  / "key_mapping"

        self.reduce_config(
            test_name,
            fhir_omop_ts_file_path=fhir_omop_dmf_transformation_spec_path,
            sources=["Observation"],
            source_fields_per_source={
                "Observation": ["id_calc", "code_coding_code", "meta_lastUpdated", "observation_date"]
            },
            target_fields_per_source_field={
                "Observation": {
                    "id_calc": [("observation", "observation_id"), ("measurement", "measurement_id")],
                    "meta_lastUpdated": [("observation", "SourceModifiedOn"), ("measurement", "SourceModifiedOn")],
                    "code_coding_code": [("observation", "observation_source_value")],
                    "observation_date": [("measurement", "measurement_date")],
                }
            },
        )

        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=spark,
            test_name=test_name,
            target_tables_to_check=["observation", "measurement"],
            source_tables_location=Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "parquet",
            target_tables_location=target_data_location,
            env_config_file_path=fhir_omop_env_config_path,
            test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT,
        )

        self._assert_target_dataframe_field(spark, test_name, "observation", "SourceModifiedOn")
        self._assert_target_dataframe_field(spark, test_name, "measurement", "SourceModifiedOn")

    def test_e2e_fhir_omop_reference(
        self, spark, fhir_omop_dmf_transformation_spec_path, fhir_omop_env_config_path, reference_mapping_data_omop
    ):
        # todo e2e use without static data? default value 0 should be taken from config
        test_name = "fhir_omop_reference"
        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name
        # key_mapping_location = Constants.SPARK_WAREHOUSE_LOCATION  / "key_mapping"

        self.reduce_config(
            test_name,
            fhir_omop_ts_file_path=fhir_omop_dmf_transformation_spec_path,
            sources=["Observation"],
            source_fields_per_source={
                "Observation": ["id_calc", "observation_standard", "observation_NH", "code_coding_code"]
            },
            target_fields_per_source_field={
                "Observation": {
                    "id_calc": [("observation", "observation_id")],
                    "observation_standard": [("observation", "observation_concept_id")],
                    "observation_NH": [("observation", "observation_source_concept_id")],
                    "code_coding_code": [("observation", "observation_source_value")],
                }
            },
        )
        source_tables_location = Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "sample"
        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=spark,
            test_name=test_name,
            target_tables_to_check=["observation"],
            source_tables_location=source_tables_location,
            target_tables_location=target_data_location,
            env_config_file_path=fhir_omop_env_config_path,
            test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT,
        )

        reference_mapping_df = spark.read.format("delta").load(str(reference_mapping_data_path))

        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name
        target_df = spark.read.load(str(target_data_location / "observation"))
        assert "observation_concept_id" in target_df.columns
        assert (
            target_df.where("observation_source_value = '65750-2'").select("observation_concept_id").collect()[0][0]
            == 1
        )
        assert (
            target_df.where("observation_source_value = '6085-5'").select("observation_concept_id").collect()[0][0] == 0
        )

        assert "observation_source_concept_id" in target_df.columns
        assert (
            target_df.where("observation_source_value = '65750-2'")
            .select("observation_source_concept_id")
            .collect()[0][0]
            == 2
        )
        assert (
            target_df.where("observation_source_value = '6085-5'")
            .select("observation_source_concept_id")
            .collect()[0][0]
            == 0
        )

    def assert_condition_on_source_and_target(
        self, source_df: DataFrame, target_df: DataFrame, source_condition: str, target_condition
    ):
        filtered_source_df = source_df.where(source_condition)
        filtered_target_df = target_df.where(target_condition)
        assert filtered_source_df.count() == filtered_target_df.count()

    def test_e2e_condition_with_expression(
        self, spark, fhir_omop_env_config_path, fhir_omop_dmf_transformation_spec_path, reference_mapping_data_omop
    ):
        test_name = "test_e2e_condition_with_expression"
        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name

        self.reduce_config(
            test_name,
            fhir_omop_ts_file_path=fhir_omop_dmf_transformation_spec_path,
            sources=["Observation"],
            source_fields_per_source={
                "Observation": [
                    "id_calc",
                    "subject_reference_id_calc",
                    "observation_standard",
                    "observation_NH",
                    "code_coding_code",
                    "value_quantity_unit",
                    "value_quantity_value_calc",
                    "observation_date_calc",
                ]
            },
            target_fields_per_source_field={
                "Observation": {
                    "id_calc": [("observation", "observation_id"), ("measurement", "measurement_id")],
                    "subject_reference_id_calc": [("observation", "person_id"), ("measurement", "person_id")],
                    "observation_standard": [
                        ("observation", "observation_concept_id"),
                        ("measurement", "measurement_concept_id"),
                    ],
                    "observation_NH": [("observation", "observation_source_concept_id")],
                    "code_coding_code": [("observation", "observation_source_value")],
                    "value_quantity_unit": [("observation", "unit_source_value")],
                    "valasseue_quantity_value_calc": [("observation", "value_as_number")],
                    "observation_date_calc": [("observation", "observation_date")],
                }
            },
        )

        source_tables_location = Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "sample"

        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=spark,
            test_name=test_name,
            source_tables_location=source_tables_location,
            target_tables_location=target_data_location,
            target_tables_to_check=["observation"],
            test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT,
            env_config_file_path=fhir_omop_env_config_path,
        )

        defualt_reference_value = 0
        subject_reference_id_calc = "subject_reference_id"
        observation_date_calc = "to_date(coalesce(effective_dateTime,effective_period_end,effective_instant))"

        observation_id_condition = "subject_reference_type = 'Patient' and category[0].coding[0].code = 'laboratory'"
        measurment_id_condition = "subject_reference_type = 'Patient' and category[0].coding[0].code != 'laboratory'"
        fk_condition = f"{subject_reference_id_calc} != '26b37ecb59267ce5b12098c610b364498691327f'"
        reference_condition = "code_coding_code = '65750-2'"
        regular_condition = f"{observation_date_calc} > '2022-01-01'"

        observation_source_df = spark.read.format("delta").load(str(source_tables_location / "Observation"))
        observation_target_df = spark.read.format("delta").load(str(target_data_location / "observation"))
        measurement_target_df = spark.read.format("delta").load(str(target_data_location / "measurement"))

        # check condition on id's
        filtered_source_df = observation_source_df.where(observation_id_condition)
        assert observation_target_df.count() == filtered_source_df.count()

        filtered_source_df = observation_source_df.where(measurment_id_condition)
        assert measurement_target_df.count() == filtered_source_df.count()

        # check condition on fk
        self.assert_condition_on_source_and_target(
            observation_source_df, observation_target_df, fk_condition, "person_id is not NULL"
        )

        # check condition on reference values
        self.assert_condition_on_source_and_target(
            observation_source_df,
            observation_target_df,
            reference_condition,
            f"observation_concept_id != {defualt_reference_value}",
        )

        # check condition on regular field
        self.assert_condition_on_source_and_target(
            observation_source_df, observation_target_df, regular_condition, "observation_date is not NULL"
        )

    def test_e2e_missing_tables(self, spark, fhir_omop_env_config_path, fhir_omop_dmf_transformation_spec_path):
        """_summary_
        This test is to check that the DMF will not fail if a table is missing from the source.
        The test will run the DMF on
        missing storage source tbale - Condition
        missing query source table -missing PatientAddress from query that contains Patient and PatientAddress
        exisiting source table Observation - to see that this table was procecced
        the assert will be on the target on of Condition - observation and measurment.
        """
        test_name = "test_e2e_missing_tables"
        target_data_location = Path(Constants.SINK_TABLES_ROOT) / "omop" / test_name

        self.reduce_config(
            test_name,
            fhir_omop_ts_file_path=fhir_omop_dmf_transformation_spec_path,
            sources=["Observation", "Patient", "Condition"],
            source_fields_per_source={
                "Observation": [
                    "id_calc",
                    "meta_lastUpdated",
                    "code_coding_code",
                ],
                "Patient": ["p_id", "p_meta_lastUpdated", "deceasedDate", "addressId", "gender"],
                "Condition": ["id", "meta_lastUpdated", "clinicalStatus_coding_code"],
            },
            target_fields_per_source_field={
                "Observation": {
                    "id_calc": [("observation", "observation_id"), ("measurement", "measurement_id")],
                    "meta_lastUpdated": [("observation", "SourceModifiedOn"), ("measurement", "SourceModifiedOn")],
                    "code_coding_code": [("observation", "observation_source_value")],
                },
                "Patient": {
                    "p_id": [("death", "person_id"), ("person", "person_id")],
                    "p_meta_lastUpdated": [
                        ("death", "SourceModifiedOn"),
                        ("person", "SourceModifiedOn"),
                        ("location", "SourceModifiedOn"),
                    ],
                    "deceasedDate": [("death", "death_date")],
                    "addressId": [("location", "location_id")],
                    "gender": [("person", "gender_source_value")],
                },
                "Condition": {
                    "id": [("condition_occurrence", "condition_occurrence_id")],
                    "meta_lastUpdated": [("condition_occurrence", "SourceModifiedOn")],
                    "clinicalStatus_coding_code": [("condition_occurrence", "condition_status_source_value")],
                },
            },
        )

        source_tables_location = Path(PROJECT_ROOT_DIR) / "tests" / "data" / "db" / "fhir" / "sample"

        DmfE2ECommon.run_e2e_storage_and_test_name(
            spark=spark,
            test_name=test_name,
            source_tables_location=source_tables_location,
            target_tables_location=target_data_location,
            target_tables_to_check=["observation"],
            test_folder=Constants.GENERATED_TRANSFORMATION_SPECS_ROOT,
            env_config_file_path=fhir_omop_env_config_path,
        )
