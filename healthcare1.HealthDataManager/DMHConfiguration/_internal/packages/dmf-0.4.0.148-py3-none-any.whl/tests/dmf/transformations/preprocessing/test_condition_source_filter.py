from typing import FrozenSet, List, Optional

from pyspark import Row
from dmf.model.common.data_access_definition import DataAccessDefinition
from dmf.model.common.data_source_type_enum import DataSourceTypeEnum
from dmf.model.reference_values_configuration import SourceToReferenceMapping
from dmf.model.source_configuration import SourceConfiguration
from dmf.model.target_configuration.target_configuration import TargetConfiguration
from dmf.model.target_configuration.target_transformation import ColumnTransformation
from dmf.model.target_configuration.target_table_schema import TargetTableSchema, TableColumn
from pyspark.sql.types import StringType, StructField, StructType
from pyspark.sql import DataFrame, functions as F

from dmf.transformations.processor.conditions.condition_source_columns_applier import ConditionedSourceColumnsApplier


class TestConditionSourceFilter:
    key_name = "id"
    lucky_column = "lucky"
    unlucky_column = "unlucky"
    neutral_column = "neutral"
    source_schema = StructType([
        StructField(key_name, StringType(), False),
        StructField(lucky_column, StringType(), True),
        StructField(unlucky_column, StringType(), True),
        StructField(neutral_column, StringType(), True),
    ])
    schema_names_and_types = {f.name: f.dataType for f in source_schema.fields}
    source_data = [
        ("id1", "a", "b", "c"),
        ("id2", "a", "a", "a"),
        ("id3", "b", "b", "b"),
    ]
    default_reference_value =12345
    def test_attributes_with_true_conditions_are_mapped(self, spark):
        config = self.source_config([
            self._target_column_mapping(self.key_name, "true"),
            self._target_column_mapping(self.lucky_column, "true"),
            self._target_column_mapping(self.unlucky_column, "false"),
            self._target_column_mapping(self.neutral_column, None),
        ])
        source_df = spark.createDataFrame(self.source_data, self.source_schema)
        df, added_columns = ConditionedSourceColumnsApplier(spark, config, source_df, self.default_reference_value).apply()
        self._assert_added_fields_are_like(df, added_columns, [self.key_name, self.lucky_column, self.unlucky_column])
        id_column_mapping = self._find_column_mapping_by_name(config, self.key_name)
        lucky_column_mapping = self._find_column_mapping_by_name(config, self.lucky_column)
        assert df.select(lucky_column_mapping.source_field_name).filter(f"{lucky_column_mapping.source_field_name} IS NOT NULL").count() == 3
        assert df.select(id_column_mapping.source_field_name).filter(f"{id_column_mapping.source_field_name} IS NOT NULL").count() == 3

    def test_attributes_with_conditions_referencing_other_columns_are_mapped_conditionally(self, spark):
        config = self.source_config([
            self._target_column_mapping(self.key_name, "true"),
            self._target_column_mapping(self.lucky_column, "true"),
            self._target_column_mapping(self.unlucky_column, f"{self.neutral_column}='a' or {self.neutral_column}='b'"),
            self._target_column_mapping(self.neutral_column, None),
        ])
        source_df = spark.createDataFrame(self.source_data, self.source_schema)
        df, added_columns = ConditionedSourceColumnsApplier(spark, config, source_df, self.default_reference_value).apply()
        self._assert_added_fields_are_like(df, added_columns, [self.key_name, self.lucky_column, self.unlucky_column])
        id_column_mapping = self._find_column_mapping_by_name(config, self.key_name)
        lucky_column_mapping = self._find_column_mapping_by_name(config, self.lucky_column)
        unlucky_column_mapping = self._find_column_mapping_by_name(config, self.unlucky_column)
        assert df.select(id_column_mapping.source_field_name).filter(f"{id_column_mapping.source_field_name} IS NOT NULL").count() == 3
        assert df.select(lucky_column_mapping.source_field_name).filter(f"{lucky_column_mapping.source_field_name} IS NOT NULL").count() == 3
        assert df.select(unlucky_column_mapping.source_field_name).filter(f"{unlucky_column_mapping.source_field_name} IS NOT NULL").count() == 2

    def test_attributes_with_false_conditions_are_not_mapped(self, spark):
        config = self.source_config([
            self._target_column_mapping(self.key_name, "true"),
            self._target_column_mapping(self.lucky_column, "true"),
            self._target_column_mapping(self.unlucky_column, "false"),
            self._target_column_mapping(self.neutral_column, None),
        ])
        source_df = spark.createDataFrame(self.source_data, self.source_schema)
        df, added_columns = ConditionedSourceColumnsApplier(spark, config, source_df, self.default_reference_value).apply()
        self._assert_added_fields_are_like(df, added_columns, [self.key_name, self.lucky_column, self.unlucky_column])
        unlucky_column_mapping = self._find_column_mapping_by_name(config, self.unlucky_column)
        assert df.select(unlucky_column_mapping.source_field_name).filter(f"{unlucky_column_mapping.source_field_name} IS NOT NULL").count() == 0

    def test_attributes_without_conditions_are_mapped(self, spark):
        config = self.source_config([
            self._target_column_mapping(self.key_name, "true"),
            self._target_column_mapping(self.lucky_column, "true"),
            self._target_column_mapping(self.unlucky_column, "false"),
            self._target_column_mapping(self.neutral_column, None),
        ])
        source_df = spark.createDataFrame(self.source_data, self.source_schema)
        df, added_columns = ConditionedSourceColumnsApplier(spark, config, source_df, self.default_reference_value).apply()
        self._assert_added_fields_are_like(df, added_columns, [self.key_name, self.lucky_column, self.unlucky_column])
        assert df.select(self.neutral_column).filter(F.col(self.neutral_column).isNotNull()).count() == 3

    def test_primary_ids_with_conditions_evaluated_false_filter_their_row(self, spark):
        config = self.source_config([
            self._target_column_mapping(self.key_name, f"{self.neutral_column} = 'b'"),
            self._target_column_mapping(self.lucky_column, "true"),
            self._target_column_mapping(self.unlucky_column, "false"),
            self._target_column_mapping(self.neutral_column, None),
        ])
        source_df = spark.createDataFrame(self.source_data, self.source_schema)
        df, added_columns = ConditionedSourceColumnsApplier(spark, config, source_df, self.default_reference_value).apply()
        self._assert_added_fields_are_like(df, added_columns, [self.key_name, self.lucky_column, self.unlucky_column])
        id_column_mapping = self._find_column_mapping_by_name(config, self.key_name)
        assert df.select(id_column_mapping.source_field_name).filter(f"{id_column_mapping.source_field_name} IS NOT NULL").collect() == [Row(id='id3')]

    def test_attributes_with_reference_fields(self, spark):
        config = self.source_config([
            self._target_column_mapping(self.key_name, "true"),
            self._target_column_mapping(self.lucky_column, "true"),
            self._target_column_mapping(self.unlucky_column, "false"),
            self._target_column_mapping(self.neutral_column, None),
        ], [self.lucky_column, self.unlucky_column])
        
        source_df = spark.createDataFrame(self.source_data, self.source_schema)
        df, added_columns = ConditionedSourceColumnsApplier(spark, config, source_df, self.default_reference_value).apply()
        self._assert_added_fields_are_like(df, added_columns, [self.key_name, self.lucky_column, self.unlucky_column])
        id_column_mapping = self._find_column_mapping_by_name(config, self.key_name)
        lucky_column_mapping = self._find_column_mapping_by_name(config, self.lucky_column)
        unlucky_column_mapping = self._find_column_mapping_by_name(config, self.unlucky_column)
        assert df.select(id_column_mapping.source_field_name).filter(f"{id_column_mapping.source_field_name} IS NOT NULL").count() == 3
        assert df.select(lucky_column_mapping.source_field_name).filter(f"{lucky_column_mapping.source_field_name} != '{self.default_reference_value}'").count() == 3
        assert df.select(unlucky_column_mapping.source_field_name).filter(f"{unlucky_column_mapping.source_field_name} != '{self.default_reference_value}'").count() == 0
        
        
    def _find_column_mapping_by_name(self, config, name: str):
        return next(tcm for tcm in config.all_column_transformations if tcm.original_source_field_name == name)

    def _assert_added_fields_are_like(self, result_df: DataFrame, reported_added_columns: List[TableColumn], like: List[str]):
        added_fields = set(result_df.schema.fields) - set(self.source_schema.fields)
        added_fields_names = set(field.name for field in added_fields)
        self._assert_reported_added_fields(reported_added_columns, added_fields_names)
        self._assert_actual_added_fields_are_as_expected(like, added_fields_names)

    def _assert_actual_added_fields_are_as_expected(self, like, added_field_names):
        for actual_field_name, expected_field_name in zip(sorted(added_field_names), sorted(like)):
            assert actual_field_name.startswith(expected_field_name)

    def _assert_reported_added_fields(self, reported_added_columns, added_field_names):
        assert set(tc.name for tc in reported_added_columns) == set(added_field_names)

    def source_config(self, columns_mapping: List[ColumnTransformation], reference_field_names = None) -> SourceConfiguration:
        if reference_field_names is None:
            reference_field_names={}
        tc = TargetConfiguration(
            feed_id="feed_id",
            target_id="target_id",
            data_access_definition=DataAccessDefinition(
                data_source_id="target_id",
                data_source_type=DataSourceTypeEnum.TABLE,
                data_source_owner_id="owner_id",
                data_format="delta"
            ),
            target_columns_transformations=frozenset(columns_mapping),
            partitions_config=frozenset(),
            temporal_tables_semantics=None,
            table_schema=TargetTableSchema(
                id="target_id",
                relations=frozenset(),
                columns=frozenset(),
                db="db"
            ),
            target_modified_date_column_name="modifiedOn"
        )
        return SourceConfiguration(
            source_id="source_id",
            feed_id="feed_id",
            data_access_definition=DataAccessDefinition(
                data_source_id="source_id",
                data_source_type=DataSourceTypeEnum.TABLE,
                data_source_owner_id="owner_id",
                data_format="delta"
            ),
            schema=None,
            target_configurations=frozenset([tc]),
            mapping_definitions=frozenset(),
            create_view_only=False,
            view_alias=None,
            source_to_reference_mappings=self.source_to_reference_mapping(reference_field_names),
            source_table_column_name="source_table_column_name",
        )

    def _target_column_mapping(self,
                               name: str,
                               condition: Optional[str],
                               literal_value: Optional[str] = None) -> ColumnTransformation:
        return ColumnTransformation(
            transformation_target_id="target_id",
            original_source_field_name=name,
            target_field_name=name,
            target_field_type=StringType(),
            source_field_type=StringType(),
            target_field_value=literal_value,
            is_source_primary_key=False,
            source_field_calculated_value=None,
            target_field_condition=condition,
            owner_target_id="target_id",
            should_be_id_mapped=False,
        )
    
    def source_to_reference_mapping(self, reference_field_names :List[str]) -> FrozenSet[SourceToReferenceMapping]:
        source_to_reference_mappings = []
        for reference_field_name in reference_field_names:
            source_to_reference_mapping = SourceToReferenceMapping(
                source_field_name=reference_field_name,
                target_reference_field_name="target_reference_field_name",
                target_reference_table_name=" target_reference_table_name")
            source_to_reference_mappings.append(source_to_reference_mapping)
        return frozenset(source_to_reference_mappings)
                
            
