# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# --------------------------------------------------------------------------
import traceback
from notebookutils import mssparkutils
from typing import Dict
import typing_extensions
from importlib import reload
from pyspark.sql import SparkSession
from rmt.runners.fabric_runner import FabricRunner as FabricRunner_RMT
from configuration_compiler.api import persist_rmt_spec
from configuration_compiler.api import persist_dtt_spec
from dmf.runners.fabric.fabric_runner import FabricRunner as FabricRunner_DMF
from microsoft.fabric.hls.hds.ddl_helper.ddl_helper import DDLHelper
from microsoft.fabric.hls.hds.global_constants.global_constants import GlobalConstants
from microsoft.fabric.hls.hds.global_constants.logging_constants import (
    LoggingConstants as LC,
)
from microsoft.fabric.hls.hds.services.vocabulary_ingestion_service import (
    VocabularyIngestionService,
)
from microsoft.fabric.hls.hds.utils.logging_helper import LoggingHelper
from microsoft.fabric.hls.hds.utils.utils import FolderPath, Utils
from microsoft.fabric.hls.hds.utils.extension_parser import ExtensionParser
from microsoft.fabric.hls.hds.utils.telemetry_reporter import TelemetryReporter

telemetry_reporter = TelemetryReporter()

# Report OMOPIngestionService module import
telemetry_reporter.report_usage(
    feature_name=GlobalConstants.LIBRARY_IMPORT_FEATURE_NAME,
    activity_name=GlobalConstants.OMOP_INGESTION_ACTIVITY_NAME,
)


class OMOPIngestionService:
    def __init__(
        self,
        spark: SparkSession,
        workspace_name: str,
        solution_name: str,
        source_lakehouse_name: str,
        target_lakehouse_name: str,
        **kwargs,
    ):
        """
        Uses DTT library to transform and ingest data into OMOP(Gold tables)
        Args:
        - spark: spark session
        - workspace_name - str: Name of the Fabric Workspace
        - solution_name: Name of the DMH OneLake workload solution
        - source_lakehouse_name: str- The lakehouse name of where the source tables are located. Expected to be the silver database as per the medallion architecture
        - target_lakehouse_name: str - The lakehouse name of where the target tables are located. Expected to be the gold database(omop in our case) as per the medallion architecture

        kwargs: Optional. Additional arguments to be set on the OMOPIngestionService
        Possible values:
         - omop_config_path: str - The path to the OMOP config folder. The default is "abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/fhir43/transformation/omop
         - vocabulary_path: str - The path to vocabulary. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{vocab_lakehouse_name}.Lakehouse/Files/sample_data_and_vocab/msft_dmh_omop_vocab_data`
         - omop_scripts_path: str - The path to where the vocabulary is stored. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHConfiguration/_internal/omop/scripts`
         - checkpoint_path: str - The path to the vocabulary structured streaming checkpoint folder. Default will be `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/vocab`
         - one_lake_endpoint (str): The one lake endpoint. Default is `onelake.dfs.fabric.microsoft.com`
         - vocab_lakehouse_name (str): The lakehouse name of where the vocab data resides.  Expected to be the bronze lakehouse in the Healthcare data solutions for health architecture.
        """
        self.spark = spark
        self._logger = LoggingHelper.get_omopingestion_logger(
            self.spark, self.__class__.__name__, GlobalConstants.LOGGING_LEVEL
        )

        ExtensionParser.register(spark)

        self.workspace_name = workspace_name
        self.solution_name = solution_name
        self.source_lakehouse_name = source_lakehouse_name
        self.target_lakehouse_name = target_lakehouse_name
        self.one_lake_endpoint = kwargs.get(
            "one_lake_endpoint", GlobalConstants.DEFAULT_ONE_LAKE_ENDPOINT
        )
        self.vocab_lakehouse_name = kwargs.get("vocab_lakehouse_name")

        try:
            self.config_files_root_path = (
                FolderPath.get_fabric_workload_files_root_path(
                    workspace_name=self.workspace_name,
                    one_lake_endpoint=self.one_lake_endpoint,
                    solution_name=self.solution_name,
                )
            )
            self.source_tables_path = FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.source_lakehouse_name,
            )

            self.omop_tables_path = FolderPath.get_fabric_tables_path(
                workspace_name=self.workspace_name,
                one_lake_endpoint=self.one_lake_endpoint,
                lakehouse_name=self.target_lakehouse_name,
            )
            self.vocab_ingestion_checkpoint_path = kwargs.get(
                "checkpoint_path",
                FolderPath.get_fabric_workload_files_checkpoint_folder_path(
                    root_path=self.config_files_root_path,
                    checkpoint_folder_name=GlobalConstants.VOCAB_CHECKPOINT_FOLDER,
                ),
            )
            self.omop_config_path = kwargs.get(
                "omop_config_path",
                FolderPath.get_fabric_workload_files_omop_config_folder_path(
                    root_path=self.config_files_root_path
                ),
            )
            self.dtt_secondary_lake_path = (
                FolderPath.get_fabric_workload_files_dtt_secondary_lake_folder_path(
                    root_path=self.config_files_root_path
                )
            )
            self.vocabulary_path = kwargs.get(
                "vocabulary_path",
                FolderPath.get_fabric_workload_files_vocab_folder_path(
                    root_path=self.config_files_root_path
                ),
            )
            self.omop_scripts_path = kwargs.get(
                "omop_scripts_path",
                FolderPath.get_fabric_workload_files_omop_scripts_folder_path(
                    root_path=self.config_files_root_path
                ),
            )
            self.dmf_config_path = FolderPath.get_dmf_configuration_files(
                root_path=self.config_files_root_path
            )
            self.rmt_config_path = FolderPath.get_rmt_configuration_files(
                root_path=self.config_files_root_path
            )
            self.dtt_dir = FolderPath.get_fabric_workload_dtt_file_path(
                root_path=self.config_files_root_path
            )
            self.env_config_path = f"{self.dtt_dir}/{GlobalConstants.ENV_CONFIG_PATH}"
            self.rmt_mapping_input_dir = (
                FolderPath.get_fabric_workload_files_rmt_mapping_folder_path(
                    root_path=self.config_files_root_path
                )
            )

            self.setDTTAppInsightsKey()

        except Exception as ex:
            self._logger.error(message=str(ex))
            raise

        self.placeholder_values: Dict = {
            "@omopDatabaseSchema": f"`{self.target_lakehouse_name}`"
        }

        # db config to read src storage, check if it exists
        self.dtt_env_config = f"""{{
            "storage": {{
                "source": {{
                    "entities": {{
                        "default": {{
                            "location": "{self.source_tables_path}",
                            "format": "delta"
                        }}
                    }}
                }},
                "target": {{
                    "entities": {{
                        "default": {{
                            "location": "{self.omop_tables_path}",
                            "format": "delta"
                        }}
                    }}
                }},
                "secondary_lake": {{
                    "location": "{self.dtt_secondary_lake_path}"
                }}
            }}
        }}"""

        self.rmt_input = f"""{{
            "query":
                {{
                    "tables": [
                        {{
                            "name": "concept",
                            "path" : "{self.omop_tables_path}/concept"
                        }},
                        {{
                            "name": "concept_relationship",
                            "path" : "{self.omop_tables_path}/concept_relationship"
                        }},
                        {{
                            "name": "vocabulary",
                            "path" : "{self.omop_tables_path}/fhir_system_to_omop_vocab_mapping"
                        }}
                    ],
                    "sql": "with unique_relationship as (select *, row_number() over (partition by concept_id_1 order by valid_start_date desc) as row_number from concept_relationship WHERE relationship_id = 'Maps to') select cr.concept_id_2 as target_value , concat_ws('<->', c.concept_code, fv.Fhir_Uri) as source_value from concept c inner join vocabulary fv on c.vocabulary_id = fv.vocabulary_id left outer join unique_relationship cr on c.concept_id = cr.concept_id_1 and cr.relationship_id = 'Maps to' and cr.row_number = 1 UNION select c.concept_id as target_value, concat_ws('<->', c.concept_code, fv.Fhir_Uri,'NH') as source_value from CONCEPT c inner join vocabulary fv on c.vocabulary_id = fv.vocabulary_id"
                }}
            }}"""

    def setDTTAppInsightsKey(self):
        """
        set the DTT's application insights instrumentation key and ingestion endpoint to spark configuration
        """

        dtt_app_insights_connection_string = Utils.get_app_insights_connection_string(
            spark=self.spark
        )
        
        if dtt_app_insights_connection_string:
            self.spark.conf.set(
                GlobalConstants.SPARK_DTT_APP_INSIGHTS_CONNECTION_STRING,
                dtt_app_insights_connection_string,
            )
            self._logger.info(f"{LC.DTT_APP_INSIGHTS_SET_INFO_MSG}")

    def ingest_vocab_data(self):
        """
        Call the VocabularyIngestionService to ingest data into omop vocab tables
        """
        vocabulary_ingestion_service = VocabularyIngestionService(
            spark=self.spark,
            target_tables_path=self.omop_tables_path,
            vocabulary_path=self.vocabulary_path,
            checkpoint_path=self.vocab_ingestion_checkpoint_path,
        )
        vocabulary_ingestion_service.ingest_vocab_data(
            vocab_schema=GlobalConstants.OMOP_VOCAB_SCHEMA
        )

    def ingest(self):
        """Using DTT ingest source data into OMOP tables"""

        # Report Silver to OMOP Ingestion Pipeline Usage
        telemetry_reporter.report_usage(
            feature_name=GlobalConstants.LIBRARY_USAGE_FEATURE_NAME,
            activity_name=GlobalConstants.OMOP_INGESTION_ACTIVITY_NAME,
        )

        try:
            self._logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")
            # Create OMOP Tables if they do not exist
            self.__create_omop_tables()

            # Ingest OMOP Vocab data
            self.ingest_vocab_data()

            # Call DTT to transform Data
            self.__dtt_workflow()
            self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")
        except Exception as ex:
            self._logger.error(
                f"{LC.OMOP_TRANSFORMATION_EXCEPTION_ERROR_MSG.format(str(ex), traceback.print_exc())}"
            )
            raise

    def __create_omop_tables(self):
        """Call DDLHelper to run SQ scripts to create OMOP tables"""

        self._logger.info(f"{LC.BEGAN_EXECUTION_INFO_MSG}")
        ddl_helper = DDLHelper(
            spark_session=self.spark,
            sql_script_path=self.omop_scripts_path,
            placeholder_values=self.placeholder_values,
        )
        ddl_helper.execute_ddl_script("/omop_extension.sql")
        ddl_helper.execute_ddl_script(
            f"/{GlobalConstants.OMOP_VERSION_54}/omop_tables.sql"
        )
        self._logger.info(f"{LC.COMPLETED_EXECUTION_INFO_MSG}")

    def __dtt_workflow(self):
        """Invokes the dtt workflow"""

        rmt_mapping_input_file_path = f"{self.rmt_mapping_input_dir}/concept.json"
        rmt_mapping_folder_path = [f"{self.rmt_mapping_input_dir}"]

        # todo: rmt being updated to take file contents vs. path, once ready remove logic below
        # Please note that the current logic creates the Concept.json under in the DMHCheckpoint workload folder i.e `abfss://{workspace_name}@{one_lake_endpoint}/{solution_name}/DMHCheckpoint/dtt/mapping`
        mssparkutils.fs.put(self.env_config_path, self.dtt_env_config, overwrite=True)
        mssparkutils.fs.mkdirs(self.rmt_mapping_input_dir)
        mssparkutils.fs.put(rmt_mapping_input_file_path, self.rmt_input, overwrite=True)

        self._logger.info(
            f"{LC.RMT_CREATED_CONCEPT_FILE.format(self.rmt_mapping_input_dir)}"
        )

        dtt_adapter = f"{self.omop_config_path}/{GlobalConstants.DMF_ADAPTER_FILE}"
        db_target_schema = f"{self.omop_config_path}/{GlobalConstants.DB_TARGET_SCHEMA}"
        db_target_schema_config = (
            f"{self.omop_config_path}/{GlobalConstants.DB_TARGET_SCHEMA_CONFIG}"
        )
        db_semantics = f"{self.omop_config_path}/{GlobalConstants.DB_SEMANTICS}"
        db_semantics_config = (
            f"{self.omop_config_path}/{GlobalConstants.DB_SEMANTICS_CONFIG}"
        )

        # load typing_extensions for RMT
        reload(typing_extensions)

        # RMT CC
        persist_rmt_spec(
            spark=self.spark,
            out_path=self.rmt_config_path,
            adaptor_file_location=dtt_adapter,
            target_db_semantics_file_location=db_semantics,
            env_config_file_location=self.env_config_path,
            target_db_schema_file_location=db_target_schema,
            db_schema_config_location=db_target_schema_config,
        )

        # DMF CC
        persist_dtt_spec(
            spark=self.spark,
            out_path=self.dmf_config_path,
            dmf_adaptor_file_location=dtt_adapter,
            target_db_semantics_file_location=db_semantics,
            target_db_semantics_config_file_location=db_semantics_config,
            target_db_schema_file_location=db_target_schema,
            db_schema_config_location=db_target_schema_config,
            env_config_file_location=self.env_config_path,
        )

        FabricRunner_RMT.create_reference_values_mapping(
            spark=self.spark,
            rmt_spec_path=self.rmt_config_path,
            ordered_mapping_definitions_folders=rmt_mapping_folder_path,
        )

        self._logger.info(f"{LC.RMT_SUCCESS_INFO_MSG}")
        FabricRunner_DMF.run(
            spark=self.spark, transformation_spec_path=self.dmf_config_path
        )
        self._logger.info(f"{LC.DTT_SUCCESS_INFO_MSG}")
