import os
import shutil
import sys
from pathlib import Path

import pytest
from pyspark.sql import SparkSession

from rmt.core import logger as core_logger
from rmt.runners.runner import REFERENCE_MAPPING_PATH
from rmt.tools.logging import Logger


def find_project_root(current_path, marker) -> Path:
    current_path = Path(current_path)
    while current_path != current_path.parent:
        if (current_path / marker).exists():
            return current_path
        current_path = current_path.parent
    raise FileNotFoundError(f"Could not find {marker} in {current_path} or any of its parents")


PROJECT_ROOT = find_project_root(Path.cwd(), ".git")
TESTS_ROOT_DIR = PROJECT_ROOT / "tests"
MAPPING_OUTPUT_ROOT = os.path.join(TESTS_ROOT_DIR, "data", "output")
REFERENCE_MAPPING_FULL_PATH = os.path.join(MAPPING_OUTPUT_ROOT, REFERENCE_MAPPING_PATH)
REFERENCE_MAPPING_FOR_TESTS_FULL_PATH = os.path.join(MAPPING_OUTPUT_ROOT, "TESTS_MAPPING")


def set_env():
    """
    This points pyspark in to find the active python installation. Ideally it should be your virtual env
    """
    os.environ["PYSPARK_PYTHON"] = sys.executable
    os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable


@pytest.fixture(scope="session")
def tests_root_dir():
    return TESTS_ROOT_DIR


@pytest.fixture(scope="session")
def tests_data_dir(tests_root_dir):
    return tests_root_dir / "data"


@pytest.fixture(scope="session")
def spark() -> SparkSession:
    spark = spark_session()
    if os.path.exists(REFERENCE_MAPPING_FULL_PATH):
        shutil.rmtree(REFERENCE_MAPPING_FULL_PATH)
    if os.path.exists(REFERENCE_MAPPING_FOR_TESTS_FULL_PATH):
        shutil.rmtree(REFERENCE_MAPPING_FOR_TESTS_FULL_PATH)
    yield spark
    spark.stop()


@pytest.fixture(autouse=True)
def logger(spark):
    core_logger.set_logger(Logger.init_logger(spark))


def spark_session() -> SparkSession:
    set_env()
    spark = (
        SparkSession.builder.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config(
            "spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog",
        )
        .config("spark.jars.packages", "io.delta:delta-core_2.12:2.2.0")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")
    Logger.init_logger(spark)
    return spark
