from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, StructType, StructField, TimestampType

from dmf.transformations.utils.min_date_filter import MinDateFilter


class TestMinDateFilter:
    def test_min_date_filter(self, spark: SparkSession):
        schema = StructType(
            [
                StructField("id", StringType(), True),
                StructField("SourceModifiedOn", TimestampType(), True),
            ]
        )
        data = [
            ("a", datetime(2022, 9, 1)),
            ("b", datetime(2022, 9, 2)),
            ("c", datetime(2022, 9, 3)),
            ("d", datetime(2022, 9, 4)),
        ]
        source_df = spark.createDataFrame(data, schema)
        df = MinDateFilter.filter(source_df, datetime.min, "SourceModifiedOn")
        assert df.count() == 4
        df = MinDateFilter.filter(source_df, datetime(2022, 9, 3, 12), "SourceModifiedOn")
        assert df.count() == 1
        df = MinDateFilter.filter(source_df, datetime.max, "SourceModifiedOn")
        assert df.count() == 0
