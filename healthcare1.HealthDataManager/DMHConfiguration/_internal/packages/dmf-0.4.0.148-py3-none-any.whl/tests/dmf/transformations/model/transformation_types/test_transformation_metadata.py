from unittest.mock import Mock
from dmf.model.source_configuration import SourceTableSchema
from dmf.model.target_configuration.target_configuration import TargetConfiguration
from dmf.model.target_configuration.target_table_schema import DurationTableSemantics, TableColumn, TargetTableSchema
from dmf.model.target_configuration.target_transformation import ColumnTransformation
from dmf.transformations.model.transformation_metadata_factory import TransformationMetaDataFactory
from dmf.transformations.model.transformation_types import Source2TargetIdMapping
import pytest


def _create_target_config(group_by_cols=None):
    target_config = Mock(spec=TargetConfiguration)
    target_config.temporal_tables_semantics = None
    target_config.feed_id = "feed_1"
    target_config.table_schema = Mock(spec=TargetTableSchema)
    pk1 = Mock(spec=TableColumn)
    pk1.name = "pk1"
    pk1.is_primary_key = True
    pk2 = Mock(spec=TableColumn)
    pk2.name = "pk2"
    pk2.is_primary_key = True
    target_config.table_schema.columns = frozenset([pk1, pk2])
    if group_by_cols is not None:
        target_config.table_schema.duration_semantics = Mock(spec=DurationTableSemantics)
        target_config.table_schema.duration_semantics.group_by_cols = group_by_cols
    else:
        target_config.table_schema.duration_semantics = None
    tct1 = _create_column_transformation('soucre_col0', 'pk1', is_source_primary_key=True)
    tct2 = _create_column_transformation('source_col1', 'target_col1')
    tct3 = _create_column_transformation('source_col1', 'target_id')
    tct4 = _create_column_transformation('source_col2', 'target_col2')
    tct5 = _create_column_transformation('source_col3', 'target_modified_date')
    target_config.target_columns_transformations = (tct1, tct2, tct3, tct4, tct5)
    target_config.target_modified_date_column_name = "target_modified_date"
    return target_config


def _create_column_transformation(source_field_name,
                                  target_field_name,
                                  is_source_primary_key=False,
                                  has_source_field=True):
    ct = Mock(spec=ColumnTransformation)
    ct.has_source_field = has_source_field
    ct.is_source_primary_key = is_source_primary_key
    ct.source_field_name = source_field_name
    ct.target_field_name = target_field_name
    return ct


def _create_table_schema():
    source_table_schema = Mock(spec=SourceTableSchema)
    source_table_schema.source_modified_date_column_name = "modified_date"
    source_table_schema.source_deleted_status_column_name = "deleted"
    source_table_schema.source_active_status_column_name = "active"
    return source_table_schema


def _create_metadata(group_by_cols=None):
    mock_source_table_schema = _create_table_schema()
    mock_target_configuration = _create_target_config(group_by_cols)
    return TransformationMetaDataFactory(
        source_schema=mock_source_table_schema,
        target_config=mock_target_configuration,
        source_partitions_configs=[],
        source_to_target_ids_mapping=[
            Source2TargetIdMapping("source_id", "target_id", "mapping_df")
        ],
        source_ids_with_conditions=[],
    ).create()


@pytest.fixture(scope="function")
def metadata():
    return _create_metadata()


class TestTransformationMetaData:
    def test_source_to_target_col_names_mapping(self, metadata):
        expected_mapping = {
            "soucre_col0": ["pk1"],
            "source_col1": ["target_col1"],
            "source_col2": ["target_col2"],
            "source_col3": ["target_modified_date"],
        }
        assert metadata.source_to_target_col_names_mapping == expected_mapping

    def test_target_key_col_names(self, metadata):
        assert sorted(metadata.target_key_col_names) == ["pk1", "pk2"]

    def test_target_key_col_names_with_group_by_cols(self):
        metadata = _create_metadata(group_by_cols=["pk1"])
        assert metadata.target_key_col_names == ["pk1"]

    def test_target_data_col_names(self, metadata):
        assert metadata.target_data_col_names == frozenset([
            "target_col1", "target_col2"])
