from typing import List
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StringType, StructType, StructField
from dmf.transformations.steps.source_changes_selector import SourceChangesSelector
from dmf.utils.global_constants import GlobalConstants as GConstants
from tests.utils.dataframe_utils import is_data_identical

OPEN_START = GConstants.START_OF_TIME_PY_DT
OPEN_END = GConstants.END_OF_TIME_PY_DT


class TestSourceChangesSelector:
    _key_col_name = "key"
    _partition_col_name = "partition"
    _data1_col_name = "data1"
    _data2_col_name = "data2"
    _source_other_col_name = "source_other"
    _target_other_col_name = "target_other"

    _source_schema = StructType([
        StructField(_partition_col_name, StringType(), True),
        StructField(_key_col_name, StringType(), True),
        StructField(_data1_col_name, StringType(), True),
        StructField(_data2_col_name, StringType(), True),
        StructField(_source_other_col_name, StringType(), True)])
    
    _target_schema = StructType([
        StructField(_partition_col_name, StringType(), True),
        StructField(_key_col_name, StringType(), True),
        StructField(_data1_col_name, StringType(), True),
        StructField(_data2_col_name, StringType(), True),
        StructField(_target_other_col_name, StringType(), True)])

    def run_test(self, spark: SparkSession, source_data: List, target_data: List, expected_df: DataFrame):

        source_df = spark.createDataFrame(source_data, self._source_schema)
        target_df = spark.createDataFrame(target_data, self._target_schema)
        source_changes_df = SourceChangesSelector.get_source_changes(source_df, target_df, [self._partition_col_name], [self._key_col_name], [self._data1_col_name, self._data2_col_name])
        result_df = source_changes_df.select(*target_df.columns)
        if not is_data_identical(result_df, expected_df):
            assert False

    def test_update_in_one_data_field(self, spark: SparkSession):

        source_data = [
            ("partition-1", "key-1", "dataa-1", "datab-0", "other1"),
            ("partition-1", "key-2", "dataa-0", "datab-0", "other2"),
        ]

        target_data = [
            ("partition-1", "key-1", "dataa-0", "datab-0", "other3"),
            ("partition-1", "key-2", "dataa-0", "datab-0", "other4"),
        ]

        expected_rows = [
            ("partition-1", "key-1", "dataa-1", "datab-0", "other3")
        ]
        
        expected_df = spark.createDataFrame(expected_rows, self._target_schema)

        self.run_test(spark, source_data, target_data, expected_df)

    def test_update_in_two_data_field(self, spark: SparkSession):

        source_data = [
            ("partition-1", "key-1", "dataa-1", "datab-1", "other1"),
            ("partition-1", "key-2", "dataa-0", "datab-0", "other2"),
        ]

        target_data = [
            ("partition-1", "key-1", "dataa-0", "datab-0", "other3"),
            ("partition-1", "key-2", "dataa-0", "datab-0", "other4"),
        ]

        expected_rows = [
            ("partition-1", "key-1", "dataa-1", "datab-1", "other3")
        ]

        expected_df = spark.createDataFrame(expected_rows, self._target_schema)

        self.run_test(spark, source_data, target_data, expected_df)

    def test_new(self, spark: SparkSession):

        source_data = [
            ("partition-1", "key-3", "dataa-0", "datab-0", "other1"),
        ]

        target_data = [
            ("partition-1", "key-1", "dataa-0", "datab-0", "other2"),
            ("partition-1", "key-2", "dataa-0", "datab-0", "other3"),
        ]

        expected_rows = [
            ("partition-1", "key-3", "dataa-0", "datab-0", None),
        ]

        expected_df = spark.createDataFrame(expected_rows, self._target_schema)

        self.run_test(spark, source_data, target_data, expected_df)

    def test_partition(self, spark: SparkSession):

        source_data = [
            ("partition-1", "key-1", "dataa-1", "datab-0", "other1"),
            ("partition-2", "key-2", "dataa-1", "datab-0", "other2"),
        ]

        target_data = [
            ("partition-1", "key-1", "dataa-0", "datab-0", "other3"),
            ("partition-2", "key-2", "dataa-1", "datab-0", "other4"),
            ("partition-1", "key-3", "dataa-0", "datab-0", "other5"),
        ]

        expected_rows = [
            ("partition-1", "key-1", "dataa-1", "datab-0", "other3"),
        ]

        expected_df = spark.createDataFrame(expected_rows, self._target_schema)

        self.run_test(spark, source_data, target_data, expected_df)


