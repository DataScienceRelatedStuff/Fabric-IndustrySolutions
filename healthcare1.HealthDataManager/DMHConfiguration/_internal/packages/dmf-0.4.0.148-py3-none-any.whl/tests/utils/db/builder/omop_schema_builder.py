import os.path
from pathlib import Path
from typing import FrozenSet, Set
from tests.utils.db.config_model.db_schema_config.ext_model import DBConfigModel
from tests.utils.db.config_model.db_schema.ext_model import DBSchemaModel
from tests.utils.db.config_model.semantics_config.ext_model import SemanticsConfigModel
from dmf.transformations.model.transformation_types import PartitionConfig

from tests.utils.db.builder.schema_builder import SchemaBuilder
from tests.utils.constants import Constants
from tests.utils.db.model.column import Column
from tests.utils.db.model.table import Table

target_omop_tables = {
    "PERSON",
    "OBSERVATION_PERIOD",
    "VISIT_OCCURRENCE",
    "VISIT_DETAIL",
    "CONDITION_OCCURRENCE",
    "DRUG_EXPOSURE",
    "PROCEDURE_OCCURRENCE",
    "DEVICE_EXPOSURE",
    "MEASUREMENT",
    "OBSERVATION",
    "DEATH",
    "NOTE",
    "NOTE_NLP",
    "SPECIMEN",
    "FACT_RELATIONSHIP",
    "LOCATION",
    "CARE_SITE",
    "PROVIDER",
    "PAYER_PLAN_PERIOD",
    "COST",
    "DRUG_ERA",
    "DOSE_ERA",
    "CONDITION_ERA",
    "EPISODE",
    "EPISODE_EVENT",
    "METADATA",
    "CDM_SOURCE",
    "CONCEPT",
    "VOCABULARY",
    "DOMAIN",
    "CONCEPT_CLASS",
    "CONCEPT_RELATIONSHIP",
    "RELATIONSHIP",
    "CONCEPT_SYNONYM",
    "CONCEPT_ANCESTOR",
    "SOURCE_TO_CONCEPT_MAP",
    "DRUG_STRENGTH",
    "COHORT",
    "COHORT_DEFINITION"

}


class OmopSchemaBuilder(SchemaBuilder):
    def __init__(self, spark, metadata_file, db, warehouse_location, schema_config_file_path, db_semantics_config_file_path):
        super().__init__(spark, metadata_file, db, warehouse_location)
        self.schema_config_file_path = schema_config_file_path
        self.db_semantics_config_file_path = db_semantics_config_file_path

    def _used_tables(self) -> Set:
        return target_omop_tables

    @staticmethod
    def _read_file(path) -> str:
        with open(path) as fh:
            return fh.read()

    def parse_tables(self):
        db_schema_model: DBSchemaModel = DBSchemaModel.from_str(
            OmopSchemaBuilder._read_file(self.metadata_file)
        )
        db_schema_config: DBConfigModel = DBConfigModel.from_str(
            OmopSchemaBuilder._read_file(self.schema_config_file_path)
        )
        db_schema_model: DBSchemaModel = db_schema_config.adapt_schema(db_schema_model)
        semantics_config_model = SemanticsConfigModel.from_str(
            OmopSchemaBuilder._read_file(self.db_semantics_config_file_path))

        for table_model in db_schema_model.tables:
            partition_columns = []
            table_partition_rules: FrozenSet[PartitionConfig] = semantics_config_model.partition_rules_for_table(table_model.name)
            for partition_config in table_partition_rules:
                column_type = partition_config.partition_col_type
                partition_columns.append(Column(name=partition_config.partition_col_name,
                                                type=partition_config.partition_col_type.simpleString()))

            table = Table(name=table_model.name,
                          type=table_model.tableType,
                          format="parquet",
                          partition_columns=partition_columns,
                          additional_properties={},
                          location_root=Path(self.data_location()),
                          db=self.db)
            for column in table_model.storageDescriptor.columns:
                column_type = column.originDataTypeName
                table.columns.append(Column(name=column.name,
                                            type=column.originDataTypeName.typeName,
                                            precision=column_type.precision,
                                            scale=column_type.scale
                                            )
                                     )
            self.tables[table_model.name] = table

    @staticmethod
    def data_location() -> str:
        return os.path.join(Constants.SINK_TABLES_ROOT, "omop")
