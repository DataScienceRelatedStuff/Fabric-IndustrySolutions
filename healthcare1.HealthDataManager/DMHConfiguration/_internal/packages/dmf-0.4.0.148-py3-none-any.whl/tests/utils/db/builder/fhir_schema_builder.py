import os.path
from typing import Set
from tests.utils.db.builder.schema_builder import SchemaBuilder
from project_root import PROJECT_ROOT_DIR


used_fhir_tables = {
    "Patient",
    "PatientAddress",
    "PatientGeneralPractitioner"


}


class FhirSchemaBuilder(SchemaBuilder):

    def _used_tables(self) -> Set:
        return used_fhir_tables

    @staticmethod
    def data_location() -> str:
        return os.path.join(PROJECT_ROOT_DIR, "tests", "data", "db", "fhir")
